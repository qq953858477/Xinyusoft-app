function numberlimit()
{
     return function(scope, element, attr) {

        //element.bind('keyup', function(event) {
        //    if( attr.autohq=='S' && element.val().length==6)
        //    {
        //        scope.selectSecurityHQ(element.val());
        //    }
        //
        //    if( attr.autohq=='F' && element.val().length>=5)
        //    {
        //        scope.selectFutureHQ(element.val());
        //    }
        //
        //});
         
         element.bind('keydown', function(event) {
            var k = event.keyCode;
            var value = element.val();
            if(isFunKey(k)) {
                return true;
            }
            if(isNaN(value + getChar(k)) && attr.autohq=='S') {
                return false;
            }

            return true;
          
        });
         
       
     };
}

function changeprice()
{
     return function(scope, element, attr) {

        element.bind('change', function(event) {
           
            if(!isNaN(element.val()) && element.val().length!=0 )
            {
              scope.setZdkm(Number(element.val()));  
            } 
          
        });
         element.bind('keyup', function(event) {
          
            if(!isNaN(element.val())  && element.val().length!=0)
            {
              scope.setZdkm(Number(element.val()));  
            } 
          
        })
     };
}


function isFunKey(code) {
    // 8 --> Backspace
    // 35 --> End
    // 36 --> Home
    // 37 --> Left Arrow
    // 39 --> Right Arrow
    // 46 --> Delete
    // 112~123 --> F1~F12
    var funKeys = [8, 9, 35, 36, 37, 39, 46];
    for(var i = 112; i <= 123; i++) {
        funKeys.push(i);
    }
    for(var i = 0; i < funKeys.length; i++) {
        if(funKeys[i] == code) {
            return true;
        }
    }
    return false;
}

function getChar(k) {
    if(k >= 48 && k <= 57) {
        return String.fromCharCode(k);
    }
    if(k >= 96 && k <= 105) {
        return String.fromCharCode(k - 48);
    }
    if(k == 110 || k == 190 || k== 188  || k==229) {
        return ".";
    }
    if(k == 109 || k == 189 || k==173) {
        return "-";
    }
    if(k == 107 || k == 187) {
        return "+";
    }
    return "#";
}