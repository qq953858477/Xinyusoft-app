﻿var dataF = [];
function getQuote(chartObj,code) {
			var marketCode = code.substring(0,2);
			var stockCode = code.substring(2,code.length);
			//var url = "";
			//if(dataF.length==0){
			//	url = "../ESBServlet?command=hq.gettimeline&stockCode="+stockCode+"&marketCode="+marketCode+"";
			//}else{
			//	var date = dataF[dataF.length-1]["time"];
			//	console.log(date);
			//	url = "../ESBServlet?command=hq.gettimeline&stockCode="+stockCode+"&marketCode="+marketCode+"&dateTime="+date;
			//}
			//console.log(url);
        	var gq = null;

			var message = {};
			message['stockCode'] = stockCode;
			message['marketCode'] = marketCode;
			if(dataF.length!=0)
			{
				var date = dataF[dataF.length-1]["time"];
				message['dateTime'] = date;
			}
			hqajaxService.sendMessage('hq.gettimeline', message, function(data)
			{
					//console.log("data", data)
				if(data.op.code.toString() == "Y")
				{
					for(var i = 0; i<data.data.length; i++)
					{
						if(dataF.length>0)
						{
							if(Number(dataF[dataF.length-1].time) > Number(data.data[i].time))
							{
								
								//本地时间比服务器端时间大，过滤掉
								continue;
							}
						}
						dataF.push(data.data[i]);
					}

					gq = {quote: {
						time: stock["date"]+stock["time"],
						open: stock["open"],
						preClose: stock["preclose"],
						highest: stock["high"],
						lowest: stock["low"],
						price: stock["close"],
						volume: stock["volume"],
						amount: stock["amount"]
					},mins:dataF};

					chartObj.paint(gq);
				}
			});
        	return dataF;
        }