var loadingStart = new Date();
var imgCountAll = 999;
var imgCountLoaded = 999;
var imgReport = '\n';
var cssCountAll = 999;
var cssCountLoaded = 999;
var cssReport = '\n';
var jsCountAll = 999;
var jsCountLoaded = 999;
var jsReport = '\n';
var audioCountAll = 999;
var audioCountLoaded = 999;
var audioReport = '\n';
var isDebugMode = true;

function Preload() {

    this.loadImageList = function(imageList) {
        imgCountLoaded = 0;
        eval('imgCountAll = imageList.length;');
        eval('var loadingStartPrivate = new Date();');
        function loadIMG(imgObj,imgSrc,imgSize,loadedCallback) {
            var xmlHttp = new XMLHttpRequest();
            if (xmlHttp == null) {
                alert('您的浏览器不支持Ajax！');
            }else {
                xmlHttp.open('GET', imgSrc, false);
                xmlHttp.onreadystatechange = function () {
//                var result;
                    if (xmlHttp.readyState == 4) {
//                    result = xmlHttp.responseText;
//                    console.log(result);
                        eval('imgCountLoaded++;' +
                            'imgReport +=("["+imgCountLoaded+"/"+imgCountAll+"]图片 '+imgObj+' 完成加载，文件大小 '+imgSize+'，耗时 "+(new Date-loadingStartPrivate)+"ms，时间段 "+(loadingStartPrivate-loadingStart)+"~"+(new Date-loadingStart)+"ms。\\n");' +
                            'if(imgCountLoaded==imgCountAll) {' +
                            '    imgReport +=("-- 所有 "+imgCountAll+" 张图片已全部加载完毕。 --");' +
                            '    if(!!isDebugMode) console.log(imgReport);' +
                            '}else {' +
                            '    loadIMG(imageList[imgCountLoaded].imgObj,imageList[imgCountLoaded].imgSrc,imageList[imgCountLoaded].imgSize);' +
                            '}' +
                            ''+loadedCallback+'');
                    }
                };
                xmlHttp.send(null);
            }
        }
        loadIMG(imageList[0].imgObj,imageList[0].imgSrc,imageList[0].imgSize,imageList[0].loadedCallback);
    }
    this.loadCssList = function(cssList) {
        cssCountLoaded = 0;
        eval('cssCountAll = cssList.length;');
        eval('var loadingStartPrivate = new Date();');
        function loadCSS(cssObj,cssHref,cssSize,loadedCallback) {
            var xmlHttp = new XMLHttpRequest();
            if (xmlHttp == null) {
                alert('您的浏览器不支持Ajax！');
            }else {
                xmlHttp.open('GET', cssHref, false);
                xmlHttp.onreadystatechange = function () {
//                var result;
                    if (xmlHttp.readyState == 4) {
//                    result = xmlHttp.responseText;
//                    console.log(result);
                        eval('var doc = document;');
                        eval('var ' + cssObj + ' = doc.createElement("link");');
                        eval(cssObj + '.setAttribute("rel", "stylesheet");');
                        eval(cssObj + '.setAttribute("type", "text/css");');
                        eval(cssObj + '.setAttribute("href", "' + cssHref + '");');
                        eval(''+cssObj+'.setAttribute("id", "'+cssObj+'");');

                        eval('var heads = doc.getElementsByTagName("head");');
                        eval('if(heads.length) heads[0].appendChild(' + cssObj + ');' +
                            'else doc.documentElement.appendChild(' + cssObj + ');');
                        eval('cssCountLoaded++;' +
                            'cssReport +=("["+cssCountLoaded+"/"+cssCountAll+"]样式表 ' + cssObj + ' 完成加载，文件大小 ' + cssSize + '，耗时 "+(new Date-loadingStartPrivate)+"ms，时间段 "+(loadingStartPrivate-loadingStart)+"~"+(new Date-loadingStart)+"ms。\\n");' +
                            'if(cssCountLoaded==cssCountAll) {' +
                            '    cssReport +=("-- 所有 "+cssCountAll+" 张样式表已全部下载完毕。 --");' +
                            '    if(!!isDebugMode) console.log(cssReport); }' +
                            'else {' +
                            '    loadCSS(cssList[cssCountLoaded].cssObj,cssList[cssCountLoaded].cssHref,cssList[cssCountLoaded].cssSize);' +
                            '}' +
                            ''+loadedCallback+'');
                    }
                };
                xmlHttp.send(null);
            }
        }
        //顺序加载CSS
        loadCSS(cssList[0].cssObj,cssList[0].cssHref,cssList[0].cssSize,cssList[0].loadedCallback);
    }
    this.loadJavascriptList = function(jsList) {
        jsCountLoaded = 0;
        eval('jsCountAll = jsList.length;');
        eval('var loadingStartPrivate = new Date();');
        function loadJS(jsObj,jsSrc,jsSize,loadedCallback) {
            var xmlHttp = new XMLHttpRequest();
            if (xmlHttp == null) {
                alert('您的浏览器不支持Ajax！');
            }else {
                xmlHttp.open('GET', jsSrc, false);
                xmlHttp.onreadystatechange = function() {
//                var result;
                    if (xmlHttp.readyState == 4) {
//                    result = xmlHttp.responseText;
//                    console.log(result);

                        eval('var _doc = document.getElementsByTagName("head")[0];');
                        eval('var '+jsObj+' = document.createElement("script");');
                        eval(''+jsObj+'.setAttribute("type", "text/javascript");');
                        eval(''+jsObj+'.setAttribute("src", "'+jsSrc+'");');
                        eval(''+jsObj+'.setAttribute("id", "'+jsObj+'");');
                        eval('_doc.appendChild('+jsObj+');');
                        eval('' +
                            'jsCountLoaded++;' +
                            'jsReport += ("["+jsCountLoaded+"/"+jsCountAll+"]脚本 '+jsObj+' 完成加载，文件大小 '+jsSize+'，耗时 "+(new Date-loadingStartPrivate)+"ms，时间段 "+(loadingStartPrivate-loadingStart)+"~"+(new Date-loadingStart)+"ms。\\n");' +
                            'if(jsCountLoaded==jsCountAll) {' +
                            '    jsReport += ("-- 所有 "+jsCountAll+" 个脚本已全部下载完毕。 --");' +
                            '    if(!!isDebugMode) console.log(jsReport);' +
                            '}else {' +
                            '    loadJS(jsList[jsCountLoaded].jsObj,jsList[jsCountLoaded].jsSrc,jsList[jsCountLoaded].jsSize);' +
                            '}' +
                            ''+loadedCallback+'');
                    }
                };
                xmlHttp.send(null);
            }
        }
        //顺序加载JS
        loadJS(jsList[0].jsObj,jsList[0].jsSrc,jsList[0].jsSize,jsList[0].loadedCallback);
    }
    this.loadAudioList = function(audioList) {
        audioCountLoaded = 0;
        eval('audioCountAll = audioList.length;');
        eval('var loadingStartPrivate = new Date();');
        function loadAudio(audioObj,audioSrc,audioSize,loadedCallback) {
            var xmlHttp = new XMLHttpRequest();
            if (xmlHttp == null) {
                alert('您的浏览器不支持Ajax！');
            }else {
                xmlHttp.open('GET', audioSrc, false);
                xmlHttp.onreadystatechange = function() {
//                var result;
                    if (xmlHttp.readyState == 4) {
//                    result = xmlHttp.responseText;
//                    console.log(result);

                        eval('var _doc = document.getElementsByTagName("head")[0];');
                        eval('var '+audioObj+' = document.createElement("audio");');
//                        eval(''+audioObj+'.setAttribute("type", "text/javascript");');
                        eval(''+audioObj+'.setAttribute("src", "'+audioSrc+'");');
                        eval(''+audioObj+'.setAttribute("preload", "auto");');
                        eval(''+audioObj+'.setAttribute("id", "'+audioObj+'");');
                        eval('_doc.appendChild('+audioObj+');');
                        eval('' +
                            'audioCountLoaded++;' +
                            'audioReport += ("["+audioCountLoaded+"/"+audioCountAll+"]音频 '+audioObj+' 完成加载，文件大小 '+audioSize+'，耗时 "+(new Date-loadingStartPrivate)+"ms，时间段 "+(loadingStartPrivate-loadingStart)+"~"+(new Date-loadingStart)+"ms。\\n");' +
                            'if(audioCountLoaded==audioCountAll) {' +
                            '    audioReport += ("-- 所有 "+audioCountAll+" 个音频已全部下载完毕。 --");' +
                            '    if(!!isDebugMode) console.log(audioReport);' +
                            '}else {' +
                            '    loadAudio(audioList[audioCountLoaded].audioObj,audioList[audioCountLoaded].audioSrc,audioList[audioCountLoaded].audioSize);' +
                            '}' +
                            ''+loadedCallback+'');
                    }
                };
                xmlHttp.send(null);
            }
        }
        //顺序加载JS
        loadAudio(audioList[0].audioObj,audioList[0].audioSrc,audioList[0].audioSize,audioList[0].loadedCallback);
    }

}



