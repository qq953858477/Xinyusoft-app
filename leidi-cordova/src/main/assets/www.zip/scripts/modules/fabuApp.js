/**
 * Created by wangtao on 2015/8/20 0020.
 */
var fabuApp = angular.module("fabuApp", ['ui.router', 'ngAnimate','infinite-scroll']);

fabuApp.run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            if(document.getElementById("fabuApp")){
                document.getElementById("fabuApp").style.display = "";
            }

        }
    ]
);

fabuApp.factory('jpajaxService',[ '$http', jpajaxService]);
/** 控制器*/
fabuApp.controller('fabuController',['$scope','jpajaxService', fabuController]);

fabuApp.directive('fabu',function(){
    return {
        restrict: 'E',
        templateUrl: 'template/fabuTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: fabuController
    };
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['fabuApp']);
});