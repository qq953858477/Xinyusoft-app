/**
 * Created by qw1 on 2014/12/7.
 */
var fundAdjustmentModule = angular.module('fundAdjustmentApp',['ngCookies']);
fundAdjustmentModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
fundAdjustmentModule.controller('fundAdjustmentCtrl',['$scope','ajaxService', '$cookieStore', fundAdjustmentCtrl]);


/**过滤器*/
fundAdjustmentModule.filter('numberFormatFilter', numberFormatFilter);

fundAdjustmentModule.run(function() {
    document.getElementById("fundAdjustmentMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['fundAdjustmentApp']);
});
