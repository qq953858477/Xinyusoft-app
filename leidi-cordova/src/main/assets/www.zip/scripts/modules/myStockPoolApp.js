/**
 * Created by qw1 on 2015/4/17.
 */
var myStockPoolModule = angular.module('myStockPoolApp',['ngCookies','ngTouch']);
myStockPoolModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
myStockPoolModule.controller('myStockPoolCtrl',['$scope','ajaxService', '$cookieStore', myStockPoolCtrl]);

myStockPoolModule.run(function() {
    document.getElementById("myStockPoolmain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['myStockPoolApp']);
});