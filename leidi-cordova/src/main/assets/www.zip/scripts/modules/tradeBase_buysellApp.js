/**
 * Created by qw1 on 2014/12/7.
 */
var tradeBase_buysellModule = angular.module('tradeBase_buysellApp',['ngCookies', 'ngRoute','ngTouch']);
tradeBase_buysellModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
tradeBase_buysellModule.directive('autohq', autohq);



/** 控制器*/
tradeBase_buysellModule.controller('tradeBase_buysellCtrl',['$scope','ajaxService', '$cookieStore',tradeBase_buysellCtrl]);



/**过滤器*/
tradeBase_buysellModule.filter('numberFormatFilter',numberFormatFilter);

tradeBase_buysellModule.run(function() {
    document.getElementById("tradeBase_buysellMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradeBase_buysellApp']);
});
