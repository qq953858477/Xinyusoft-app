/**
 * Created by qw1 on 2014/12/7.
 */
var updownBaseModule = angular.module('updownBaseApp',['ngCookies','ngTouch']);
updownBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
updownBaseModule.directive('fxonestockhqbase', fxonestockhqbase);
updownBaseModule.controller('updownBaseCtrl',['$scope','ajaxService', '$cookieStore',updownBaseCtrl]);

/**过滤器*/
updownBaseModule.filter('numberFormatFilter', numberFormatFilter);


updownBaseModule.run(function() {
    document.getElementById("updownBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['updownBaseApp']);
});
