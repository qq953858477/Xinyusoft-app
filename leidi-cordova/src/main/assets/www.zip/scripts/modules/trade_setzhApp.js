/**
 * Created by qw1 on 2014/12/7.
 */
var trade_setzhModule = angular.module('trade_setzhApp',['ngCookies', 'ngRoute','ngTouch']);
trade_setzhModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
trade_setzhModule.directive('autohq', autohq);
/** 控制器*/
trade_setzhModule.controller('trade_setzhCtrl',['$scope','ajaxService', '$cookieStore',trade_setzhCtrl]);

/**过滤器*/
trade_setzhModule.filter('numberFormatFilter',numberFormatFilter);


trade_setzhModule.run(function() {
    document.getElementById("trade_setzhMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['trade_setzhApp']);
});
