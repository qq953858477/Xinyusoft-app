/**
 * Created by qw1 on 2014/12/7.
 */
var gtapplyModule = angular.module('gtapplyApp',['ngCookies','ngTouch']);
gtapplyModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//gtapplyModule.directive('lcsinfo', lcsinfo);
gtapplyModule.directive('gtsypl', gtsypl);
/** 控制器*/
//gtapplyModule.controller('lcs_infoCtrl',['$scope','ajaxService', '$cookieStore', lcs_infoCtrl]);
gtapplyModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);
gtapplyModule.controller('gtapplyCtrl',['$scope','ajaxService', '$cookieStore', gtapplyCtrl]);

/**过滤器*/
gtapplyModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gtapplyMain").style.display = "";
}

gtapplyModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtapplyApp']);
});
