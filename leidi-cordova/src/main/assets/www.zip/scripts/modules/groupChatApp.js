﻿/**
 * Created by qw1 on 2015/4/17.
 */
var groupChatModule = angular.module('groupChatApp',['ngCookies','ngTouch']);
groupChatModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
groupChatModule.controller('groupChatCtrl',['$scope','ajaxService', '$cookieStore','$sce',groupChatCtrl]);
groupChatModule.run(function() {
    document.getElementById("groupChatmain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['groupChatApp']);
});
