/**
 * Created by qw1 on 2014/12/7.
 */
var optionalBaseModule = angular.module('optionalBaseApp',['ngCookies','ngTouch']);
optionalBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
optionalBaseModule.directive('onestockhqbase', onestockhqbase);
optionalBaseModule.directive('indexbase', indexbase);
optionalBaseModule.controller('optionalBaseCtrl',['$scope','ajaxService', '$cookieStore',optionalBaseCtrl]);

/**过滤器*/
optionalBaseModule.filter('numberFormatFilter', numberFormatFilter);


optionalBaseModule.run(function() {
    document.getElementById("optionalBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['optionalBaseApp']);
});
