/**
 * Created by qw1 on 2014/12/7.
 */
var myGroupBaseModule = angular.module('myGroupBaseApp',['ngCookies', 'ngRoute']);
myGroupBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
myGroupBaseModule.directive('autohq', autohq);
/** 控制器*/
myGroupBaseModule.controller('myGroupBaseCtrl',['$scope','ajaxService', '$cookieStore',myGroupBaseCtrl]);

/**路由管理器*/
//myGroupBaseModule.
//    config(['$routeProvider', function($routeProvider) {
//        $routeProvider.
//            when('/gentou', {templateUrl: 'myGroupBaseMain.html', controller: 'myGroupBaseCtrl'}).
//            otherwise({redirectTo: '/'});
//    }]);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("myGroupBaseMain").style.display = "";
}

myGroupBaseModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['myGroupBaseApp']);
});
