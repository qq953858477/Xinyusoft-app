/**
 * Created by qw1 on 2014/12/7.
 */
var oneManagedAccountModule = angular.module('oneManagedAccountApp',['ngCookies', 'ngRoute','ngTouch']);
oneManagedAccountModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//homeModule.directive('numberlimit', numberlimit);
oneManagedAccountModule.directive('autohq', autohq);
oneManagedAccountModule.directive('tradesynthetical', tradesynthetical);
oneManagedAccountModule.directive('tradeinfo', tradeinfo);
oneManagedAccountModule.directive('tradequery', tradequery);
/** tradesynthetical控制器*/
oneManagedAccountModule.controller('tradesyntheticalCtrl',['$scope','ajaxService', '$cookieStore',tradesyntheticalCtrl]);
/** tradeInfo控制器*/
oneManagedAccountModule.controller('tradeinfoCtrl',['$scope','ajaxService', '$cookieStore', tradeinfoCtrl]);
/**tradequeryCtrl**/
oneManagedAccountModule.controller('tradequeryCtrl',['$scope','ajaxService', '$cookieStore', tradequeryCtrl]);

/** 控制器*/
oneManagedAccountModule.controller('oneManagedAccountCtrl',['$scope','ajaxService', '$cookieStore',oneManagedAccountCtrl]);
/**空白 控制器*/
oneManagedAccountModule.controller('emptyCtrl',['$scope', 'ajaxService', '$cookieStore', emptyCtrl]);
/**买入 控制器*/
oneManagedAccountModule.controller('buyCtrl',['$scope', 'ajaxService', '$cookieStore', buyCtrl]);
/**卖出 控制器*/
oneManagedAccountModule.controller('sellCtrl',['$scope', 'ajaxService', '$cookieStore', sellCtrl]);
/**市价买入 控制器*/
oneManagedAccountModule.controller('flashbuyCtrl',['$scope', 'ajaxService', '$cookieStore', flashbuyCtrl]);
/**市价卖出 控制器*/
oneManagedAccountModule.controller('flashsellCtrl',['$scope', 'ajaxService', '$cookieStore', flashsellCtrl]);
/**撤单 控制器*/
oneManagedAccountModule.controller('cancellationCtrl',['$scope', 'ajaxService', '$cookieStore', cancellationCtrl]);

/**持仓 控制器*/
oneManagedAccountModule.controller('cccxCtrl',['$scope', 'ajaxService', '$cookieStore', cccxCtrl]);
/**当日成交 控制器*/
oneManagedAccountModule.controller('drcjCtrl',['$scope', 'ajaxService', '$cookieStore', drcjCtrl]);
/**当日委托 控制器*/
oneManagedAccountModule.controller('drwtCtrl',['$scope', 'ajaxService', '$cookieStore', drwtCtrl]);
/**历史成交 控制器*/
oneManagedAccountModule.controller('lscjCtrl',['$scope', 'ajaxService', '$cookieStore', lscjCtrl]);
/**历史委托 控制器*/
oneManagedAccountModule.controller('lswtCtrl',['$scope', 'ajaxService', '$cookieStore', lswtCtrl]);


/**过滤器*/
oneManagedAccountModule.filter('numberFormatFilter',numberFormatFilter);

/**路由管理器*/
oneManagedAccountModule.
    config(['$routeProvider', function($routeProvider) {
        $routeProvider.
            //when('/empty', {templateUrl: 'views/buy.html', controller: 'emptyCtrl'}).
            when('/buy', {templateUrl: 'views/buy.html', controller: 'buyCtrl'}).
            when('/sell', {templateUrl: 'views/sell.html', controller: 'sellCtrl'}).
            when('/flashbuy', {templateUrl: 'views/flashbuy.html', controller: 'buyCtrl'}).
            when('/flashsell', {templateUrl: 'views/flashsell.html', controller: 'sellCtrl'}).
            when('/cancellation', {templateUrl: 'views/cancellation.html', controller: 'cancellationCtrl'}).
            when('/cccx', {templateUrl: 'views/cccx.html', controller: 'cccxCtrl'}).
            when('/drcj', {templateUrl: 'views/drcj.html', controller: 'drcjCtrl'}).
            when('/drwt', {templateUrl: 'views/drwt.html', controller: 'drwtCtrl'}).
            when('/lscj', {templateUrl: 'views/lscj.html', controller: 'lscjCtrl'}).
            when('/lswt', {templateUrl: 'views/lswt.html', controller: 'lswtCtrl'}).
            otherwise({redirectTo: '/empty'});
    }]);


oneManagedAccountModule.run(function() {
    document.getElementById("oneManagedAccountMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['oneManagedAccountApp']);
});
