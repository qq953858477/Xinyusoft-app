/**
 * Created by qw1 on 2014/12/7.
 */
var gt_ybmModule = angular.module('gt_ybmApp',['ngCookies','ngTouch']);
gt_ybmModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

//gt_ybmModule.directive('lcsinfo', lcsinfo);
gt_ybmModule.directive('gtsypl', gtsypl);
/** 控制器*/
//gt_ybmModule.controller('lcs_infoCtrl',['$scope','ajaxService', '$cookieStore', lcs_infoCtrl]);
gt_ybmModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);

gt_ybmModule.controller('gt_ybmCtrl',['$scope','ajaxService', '$cookieStore', gt_ybmCtrl]);

/**过滤器*/
gt_ybmModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_ybmain").style.display = "";
}
gt_ybmModule.run(function()
{
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_ybmApp']);
});
