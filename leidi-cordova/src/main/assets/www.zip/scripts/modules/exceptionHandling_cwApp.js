/**
 * Created by qw1 on 2014/12/7.
 */
var exceptionHandling_cwModule = angular.module('exceptionHandling_cwApp',['ngCookies']);
exceptionHandling_cwModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
exceptionHandling_cwModule.controller('exceptionHandling_cwCtrl',['$scope','ajaxService', '$cookieStore', exceptionHandling_cwCtrl]);


/**过滤器*/
exceptionHandling_cwModule.filter('numberFormatFilter', numberFormatFilter);

exceptionHandling_cwModule.run(function() {
    document.getElementById("exceptionHandling_cwMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['exceptionHandling_cwApp']);
});
