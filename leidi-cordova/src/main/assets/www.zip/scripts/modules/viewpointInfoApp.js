/**
 * Created by qw1 on 2014/12/7.
 */
var viewpointInfoModule = angular.module('viewpointInfoApp',['ngCookies']);
viewpointInfoModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
viewpointInfoModule.controller('viewpointInfoCtrl',['$scope','ajaxService', '$cookieStore', viewpointInfoCtrl]);


/**过滤器*/
viewpointInfoModule.filter('numberFormatFilter', numberFormatFilter);

viewpointInfoModule.run(function() {
    document.getElementById("viewpointInfoMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['viewpointInfoApp']);
});
