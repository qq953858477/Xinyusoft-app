/**
 * Created by wangtao on 2015/9/3 0003.
 */
//cp1(A)； 交易期：cp2(B)；解除中：cp3(D) ；cp4(G)：延期中（报名）；cp5（C）：已结束；
function getParameter(param) {
    var query = window.location.search;
    //console.log("getParameter", query);
    var iLen = param.length;
    var iStart = query.indexOf(param);
    if (iStart == -1) {
        return "";
    }
    iStart += iLen + 1;
    var iEnd = query.indexOf("&", iStart);
    if (iEnd == -1) {
        return query.substring(iStart);
    }
    else {
        return query.substring(iStart, iEnd);
    }
}

function gtTabService($scope) {
    var tabs = [
        {
            id: 'kb',
            name: '快报！',
            //directUrl: '',
            isActive: false,
            indexID: '0'
        },
        {
            id: 'dqgt',
            name: '我的跟投',
            //directUrl: '',
            isActive: false,
            indexID: '1'
        },
        {
            id: 'jrsyb',
            name: '今日收益榜',
            //directUrl: '',
            isActive: false,
            indexID: '2'
        },
        {
            id: 'gtbm',
            name: '跟投报名',
            //directUrl: '',
            isActive: false,
            indexID: '3'
        }
    ];


    function changeTab(tab) {
        var currentTab;
        for (var i = 0; i < tabs.length; i++) {
            var tempTab = tabs[i];
            if (tempTab.id == tab['id'])
            {
                tempTab.isActive = true;
                currentTab = tempTab;
                //window.location.href = tempTab.directUrl;
            } else {
                tempTab.isActive = false;
            }
        }
        return currentTab;
    }

    return {
        tabs: tabs,
        changeTab: changeTab
    }
}

function gtController($scope, ajaxService, gtTabService) {

    $scope.gttabs = gtTabService.tabs;

    $scope.gtCPlist = [];

    $scope.homegtintervalDuration = 5000;//间隔时间，8000毫秒
    $scope.homegtintervalId;

    $scope.sydscxArray = [];//定时收益刷新（实盘中、解除中）
    $scope.sydscxIds = "";//定时收益刷新（服务的id）
    $scope.delgzmark = true;//是否可删除
    $scope.xhintData = [];//服务、理财师最新状态
    $scope.gzAllArray = [];
    $scope.checkisdelMark = false;//是否需检查是否取消关注服务 true:需要检查、false：不需要检查
    $scope.qxgzObj = null;//选中的关注对象

    $scope.gzorderobj = "+gzindex";
    //去除
    $scope.homegtClearInterval = function () {
        if ($scope.homegtintervalId != undefined) {
            clearInterval($scope.homegtintervalId);
        }
    }
    //$scope.gtLcsCPlist = [];
    //var localStorage = window.localStorage;
    //$scope.userObj = JSON.parse(localStorage.getItem('user'));
    //$scope.userid = $scope.userObj.f_id;

    //userid 关注人id
    //concernttype 关注类型 1：自选股； 2：解盘； 3：理财服务；4：理财师；5：普通用户；6：新手必读，7：解套，8：理财师专访
    //concerntid 关注人id
    //belonguserid 对象所属userid
    //linkurl 进入url
    //logo
    //lastmsgtime 最后一条消息时间 格式  yyyy-mm-dd hh:mm:ss
    //lastmsg 最后一条消息内容

    $scope.getspsyCallBack = function(_data)
    {
        //console.log("更新", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.productprofitlist;
            for(var i = 0;i<arr.length;i++)
            {
                for(var j = 0;j<$scope.gzAllArray.length;j++)
                {
                    if($scope.gzAllArray[j].concernttype == "3")//服务
                    {
                        //console.log("4556", $scope.gzAllArray[j].fwinfo.status);
                        if($scope.gzAllArray[j].fwinfo.productid == arr[i].productid)//相同服务
                        {
                            $scope.gzAllArray[j].fwinfo.drsyl = parseFloat(arr[i].jrsy);
                            $scope.gzAllArray[j].fwinfo.ljsyl = parseFloat(arr[i].ljsy);
                            break;
                        }
                    }
                }
            }
        }
    }

    $scope.getspsy = function()
    {
        var message = {};
        message['ids'] = $scope.sydscxIds;
        //console.log("更新",message);
        ajaxService.sendMessage('gentou.selectgentouproductprofitbyidsaction', message, $scope.getspsyCallBack);
    }

    $scope.setXhintstatus = function(_data)
    {
        //alert("setXhintstatus");
        var arr = _data.unReadMessageNumList;
        for(var i = 0;i<$scope.gzAllArray.length;i++)
        {
            for(var j = 0;j<arr.length;j++)
            {
                if($scope.gzAllArray[i].taskGoal == arr[j].taskGoal)
                {
                    var xhintnum =  parseInt(arr[j].unReadMessageNum);
                    if(xhintnum>0)
                    {
                        $scope.gzAllArray[i].hintstatus = true;
                        break;
                    }
                }
            }
        }
        //alert("setXhintstatus Finished");
    }

    $scope.dsinfo = function()
    {
        $scope.sydscxIds = "";
        for(var i = 0;i<$scope.sydscxArray.length;i++)
        {
            if(i == 0)
            {
                $scope.sydscxIds = $scope.sydscxArray[i];
            }
            else
            {
                $scope.sydscxIds = $scope.sydscxIds + "," + $scope.sydscxArray[i];
            }
        }

        $scope.homegtClearInterval();

        //console.log("测试", $scope.sydscxIds);
        if($scope.sydscxIds != "")
        {
            $scope.homegtintervalId = setInterval($scope.getspsy, $scope.homegtintervalDuration);
        }

        //获取服务、理财师等状态
        //console.log(JSON.stringify($scope.xhintData));
        //try
        //{
        //    navigator.SqliteUserPlugin.selectToSomeMessage(function (data){
        //        //alert("selectappback2:" + data);
        //        var _data = JSON.parse(data);
        //        $scope.setXhintstatus(_data);
        //    }, JSON.stringify($scope.xhintData));
        //}catch (e){
        //    //alert("selectxhinterror:" + e.toString());
        //}

    }

    $scope.gzinfocheckisExist = function(_obj)
    {
        var checkmarkid = -1;//表示未有相关数据
        for(var i = 0;i<$scope.gzAllArray.length;i++)
        {
            //if(_obj.concernttype == "3" || _obj.concernttype == "1")
            //{
            //    if($scope.gzAllArray[i].concernttype == _obj.concernttype && $scope.gzAllArray[i].belonguserid == _obj.belonguserid && $scope.gzAllArray[i].taskGoal == _obj.taskGoal)
            //    {
            //        checkmarkid = i;
            //        break;
            //    }
            //}
            //else if(_obj.concernttype == "1")
            //{
            //    if($scope.gzAllArray[i].concernttype == _obj.concernttype && $scope.gzAllArray[i].belonguserid == _obj.belonguserid)
            //    {
            //        checkmarkid = i;
            //        break;
            //    }
            //}
            //if($scope.gzAllArray[i].concernttype == _obj.concernttype && $scope.gzAllArray[i].belonguserid == _obj.belonguserid && $scope.gzAllArray[i].fid == _obj.fid)
            if($scope.gzAllArray[i].fid == _obj.fid)
            {
                checkmarkid = i;
                break;
            }
        }
        return checkmarkid;
    }


    $scope.getgzallCallback = function(_data)
    {
        //console.log("关注", _data);
        //$scope.gzAllArray = [];
        //alert("关注："+_data);
        $scope.sydscxArray = [];
        //$scope.xhintData = [];
        var dqgzarr = [];//当前的所有关注

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.datalist;
            for(var i = 0;i<arr.length;i++)
            {
                //if(arr[i].f_concernttype == "1")//自选股
                //{
                //    var obj = {};
                //    obj.concernttype = "1";
                //    obj.zxgcount = 0;
                //    if(!!arr[i].f_lastmsg)
                //    {
                //        obj.zxgcount = arr[i].f_lastmsg.zxgcount;
                //        obj.lastcontent = arr[i].f_lastmsg.optmsg + "股票" + arr[i].f_lastmsg.stockname;
                //    }
                //    if(!!arr[i].f_lastmsgtime)
                //    {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0,10);
                //        obj.lastmsgtimesfm = arr[i].f_lastmsgtime.substr(0,19);
                //    }
                //    if(!!arr[i].f_createtime)
                //    {
                //        obj.createtimestr = arr[i].f_createtime.substr(0,19);
                //    }
                //    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                //    if(!!arr[i].userinfo)
                //    {
                //        obj.username = arr[i].userinfo.f_nickname;//自选股所属的用户
                //    }
                //    if(obj.belonguserid == $scope.userid)//是自己的
                //    {
                //        obj.title = "我的自选股";
                //        obj.gzindex = 7;
                //    }
                //    else//其他人的
                //    {
                //        obj.title = obj.username +"的自选股";
                //        obj.gzindex = 4;
                //    }
                //    obj.fid = arr[i].f_id;
                //    obj.taskGoal = "zxg_" + arr[i].f_belonguserid;
                //    var checkmarkid  = $scope.gzinfocheckisExist(obj);
                //    if(checkmarkid == -1)//未有
                //    {
                //        $scope.gzAllArray.push(obj);
                //    }
                //    else
                //    {
                //        $scope.gzAllArray[checkmarkid] = obj;
                //    }
                //}
                //else if(arr[i].f_concernttype == "2")//解盘
                //{
                //    var obj = {};
                //    obj.concernttype = "2";
                //    if(!!arr[i].f_lastmsgtime) {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                //        obj.lastmsgtimesfm = arr[i].f_lastmsgtime.substr(0,19);
                //    }
                //    if(!!arr[i].f_createtime)
                //    {
                //        obj.createtimestr = arr[i].f_createtime.substr(0,19);
                //    }
                //    obj.lastcontent = arr[i].f_lastmsg;
                //    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                //    if(!!arr[i].userinfo) {
                //        obj.username = arr[i].userinfo.f_nickname;//解盘所属的用户
                //    }
                //    if(obj.belonguserid == $scope.userid)//是自己的
                //    {
                //        obj.title = "我的解盘";
                //        obj.gzindex = 6;
                //    }
                //    else//其他人的
                //    {
                //        obj.title = obj.username + "的解盘";
                //        obj.gzindex = 3;
                //    }
                //    obj.fid = arr[i].f_id;
                //    var checkmarkid  = $scope.gzinfocheckisExist(obj);
                //    if(checkmarkid == -1)//未有
                //    {
                //        $scope.gzAllArray.push(obj);
                //    }
                //    else
                //    {
                //        $scope.gzAllArray[checkmarkid] = obj;
                //    }
                //}
                //else if(arr[i].f_concernttype == "4")//理财师
                //{
                //    var obj = {};
                //    obj.concernttype = "4";
                //    if(!!arr[i].f_lastmsgtime) {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                //        obj.lastmsgtimesfm = arr[i].f_lastmsgtime.substr(0,19);
                //    }
                //    if(!!arr[i].f_createtime)
                //    {
                //        obj.createtimestr = arr[i].f_createtime.substr(0,19);
                //    }
                //    if(!!arr[i].f_lastmsg) {
                //        obj.lastcontent = arr[i].f_lastmsg;
                //    }
                //    else
                //    {
                //        obj.lastcontent = "";
                //    }
                //    obj.belonguserid = arr[i].f_belonguserid;//所属的用户id
                //    if(!!arr[i].showdata)
                //    {
                //        obj.username = arr[i].showdata.user.user.f_nickname;//所属的用户
                //        obj.usernamestr = obj.username;
                //        obj.head = arr[i].showdata.user.user.f_head;
                //        if(obj.lastcontent == "")
                //        {
                //            obj.lastcontent = arr[i].showdata.tzln;
                //        }
                //    }
                //    obj.fid = arr[i].f_id;
                //    obj.gzindex = 2;
                //    var hintobj = {};
                //    hintobj.taskGoal = "lcs_" + arr[i].f_belonguserid;
                //    obj.taskGoal = hintobj.taskGoal;
                //    obj.hintstatus = false;//是否显示红点
                //
                //    var checkmarkid  = $scope.gzinfocheckisExist(obj);
                //    if(checkmarkid == -1)//未有
                //    {
                //        $scope.gzAllArray.push(obj);
                //        $scope.xhintData.push(hintobj);
                //    }
                //    else
                //    {
                //        obj.hintstatus = $scope.gzAllArray[checkmarkid].hintstatus;
                //        $scope.gzAllArray[checkmarkid] = obj;
                //    }
                //}
                //else if(arr[i].f_concernttype == "7")//解套
                //{
                //    var obj = {};
                //    obj.concernttype = "7";
                //    if(!!arr[i].f_lastmsgtime) {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                //        obj.lastmsgtimesfm = arr[i].f_lastmsgtime.substr(0,19);
                //    }
                //    if(!!arr[i].f_createtime)
                //    {
                //        obj.createtimestr = arr[i].f_createtime.substr(0,19);
                //    }
                //    obj.lastcontent = arr[i].f_lastmsg;
                //    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                //    obj.fid = arr[i].f_id;
                //    if(obj.belonguserid == $scope.userid)//是自己的
                //    {
                //        obj.title = "我的解套";
                //        obj.gzindex = 8;
                //
                //        var checkmarkid  = $scope.gzinfocheckisExist(obj);
                //        if(checkmarkid == -1)//未有
                //        {
                //            $scope.gzAllArray.push(obj);
                //        }
                //        else
                //        {
                //            $scope.gzAllArray[checkmarkid] = obj;
                //        }
                //    }
                //}
                if(arr[i].f_concernttype == "3")//服务
                {
                    var obj = {};
                    var hintobj = {};
                    obj.concernttype = "3";
                    if(!!arr[i].f_lastmsgtime) {
                        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                        obj.lastmsgtimesfm = arr[i].f_lastmsgtime.substr(0,19);
                    }
                    if(!!arr[i].f_createtime)
                    {
                        obj.createtimestr = arr[i].f_createtime.substr(0,19);
                    }
                    obj.belonguserid = arr[i].f_belonguserid;//所属的用户id
                    obj.fid = arr[i].f_id;
                    obj.gzindex = 1;
                    var arr2 = arr[i].showdata;//服务用户等信息
                    if(!!arr2)
                    {
                        var obj2 = {};
                        obj2.account = arr2.account;//当前被跟投的账户
                        var bgtuser = arr2.user.user;
                        obj2.headurl = bgtuser.f_head;
                        obj2.username = bgtuser.f_nickname;
                        obj2.fbzuserid = bgtuser.f_id;
                        obj2.productname = arr2.name;
                        if(obj2.productname.length>5)
                        {
                            obj2.productnamestr = obj2.productname.substr(0,5);
                        }
                        else
                        {
                            obj2.productnamestr = obj2.productname;
                        }
                        obj2.productid = arr2.id;
                        $scope.sydscxArray.push(obj2.productid);
                        obj2.gentoucount = arr2.gentoucount;
                        obj2.drsyl = parseFloat(arr2.jrsy);
                        obj2.ljsyl = parseFloat(arr2.ljsy);
                        obj2.rundays = arr2.rundays;
                        obj2.cjcount = arr2.cjcount;
                        obj2.cw = arr2.cw;
                        if(parseFloat(obj2.cw) == 0)
                        {
                            obj2.cwvalue = "空仓";//当前仓位
                        }
                        else if(parseFloat(obj2.cw) == 1)
                        {
                            obj2.cwvalue = "满仓";//当前仓位
                        }
                        else
                        {
                            obj2.cwvalue = (parseFloat(obj2.cw)*100).toFixed(0) + "%";//当前仓位
                        }
                        obj2.buycount = arr2.buycount;
                        obj2.sellcount = arr2.sellcount;
                        obj.fwinfo = obj2;

                        hintobj.taskGoal = "product_" + arr2.id;
                        obj.taskGoal = hintobj.taskGoal;
                        obj.hintstatus = false;//是否显示红点

                        var checkmarkid  = $scope.gzinfocheckisExist(obj);
                        if(checkmarkid == -1)//未有
                        {
                            $scope.gzAllArray.push(obj);
                            $scope.xhintData.push(hintobj);
                        }
                        else
                        {
                            obj.hintstatus = $scope.gzAllArray[checkmarkid].hintstatus;
                            $scope.gzAllArray[checkmarkid] = obj;
                        }

                        dqgzarr.push(obj);
                    }
                }
            }
            //判断是否有关注被删除
            var gzlistindexarr = [];
            for(var i = 0;i<$scope.gzAllArray.length;i++)
            {
                var mark = false;
                for(var j = 0;j<dqgzarr.length;j++)
                {
                    if($scope.gzAllArray[i].fid == dqgzarr[j].fid)
                    {
                        mark = true;
                        break;
                    }
                }
                if(mark == false)//未找到匹配
                {
                    gzlistindexarr.push(i);
                }
            }
            for(var i = 0;i<gzlistindexarr.length;i++)
            {
                $scope.gzAllArray.splice(gzlistindexarr[i],1);
            }
            var hintlistindexarr = [];
            for(var i = 0;i<$scope.xhintData.length;i++)
            {
                var mark = false;
                for(var j = 0;j<dqgzarr.length;j++)
                {
                    if(!!dqgzarr[j].taskGoal)
                    {
                        if($scope.xhintData[i].taskGoal == dqgzarr[j].taskGoal)
                        {
                            mark = true;
                            break;
                        }
                    }
                }
                if(mark == false)//未找到匹配
                {
                    hintlistindexarr.push(i);
                }
            }
            for(var i = 0;i<hintlistindexarr.length;i++)
            {
                $scope.xhintData.splice(hintlistindexarr[i],1);
            }
            //if($scope.checkisdelMark)//需要判断
            //{
            //    //console.log("删除");
            //    if($scope.qxgzObj != null)
            //    {
            //        var mark = false;
            //        for(var i = 0;i<arr.length;i++)
            //        {
            //            if($scope.qxgzObj.fid == arr[i].f_id)
            //            {
            //                mark = true;//未被取消关注
            //                break;
            //            }
            //        }
            //        if(mark == false)//已被取消
            //        {
            //            for(var i = 0;i<$scope.gzAllArray.length;i++)
            //            {
            //                if($scope.qxgzObj.fid == $scope.gzAllArray[i].fid)
            //                {
            //                    $scope.gzAllArray.splice(i,1);
            //                    break;
            //                }
            //            }
            //            for(var i = 0;i<$scope.xhintData.length;i++)
            //            {
            //                if($scope.xhintData[i].taskGoal == $scope.qxgzObj.taskGoal)
            //                {
            //                    $scope.xhintData.splice(i,1);
            //                    break;
            //                }
            //            }
            //        }
            //        $scope.qxgzObj = null;
            //    }
            //    $scope.checkisdelMark = false;
            //}

            $scope.dsinfo();
        }
        if($scope.delgzmark == false)
        {
            $scope.delgzmark = true;
            try{
                layer.closeAll();
            }
            catch (e){}
        }
        if($scope.gzAllArray.length>0)
        {
            $scope.gzAllArray.sort(function(a, b)
            {
                var aDate;
                var bDate;
                if(!!a.lastmsgtimesfm)
                {
                    var aDate1 = new Date(a.lastmsgtimesfm.replace(/-/g, "/"));//最后一次更新时间
                    var aDate2 = new Date(a.createtimestr.replace(/-/g, "/"));//关注时间
                    //console.log(a.concernttype, aDate1.getTime(), aDate2.getTime());
                    if(aDate1.getTime() >= aDate2.getTime())
                    {
                        //console.log("1", "lastmsgtimesfm");
                        aDate = aDate1;
                    }
                    else
                    {
                        //console.log("2", "createtimestr");
                        aDate = aDate2;
                    }
                }
                else
                {
                    aDate = new Date(a.createtimestr.replace(/-/g, "/"));
                }
                if(!!b.lastmsgtimesfm)
                {
                    var bDate1 = new Date(b.lastmsgtimesfm.replace(/-/g, "/"));//最后一次更新时间
                    var bDate2 = new Date(b.createtimestr.replace(/-/g, "/"));//关注时间
                    if(bDate1.getTime() >= bDate2.getTime())
                    {
                        bDate = bDate1;
                    }
                    else
                    {
                        bDate = bDate2;
                    }
                }
                else
                {
                    bDate = new Date(b.createtimestr.replace(/-/g, "/"));
                }

                //console.log(new Date(b.lastmsgtimesfm.replace(/-/g, "/")), new Date(a.lastmsgtimesfm.replace(/-/g, "/")), new Date(b.lastmsgtimesfm.replace(/-/g, "/")) - new Date(a.lastmsgtimesfm.replace(/-/g, "/")));
                //return new Date(b.lastmsgtimesfm.replace(/-/g, "/")) - new Date(a.lastmsgtimesfm.replace(/-/g, "/"));
                return bDate - aDate;
            });

            //var arr1 = [];
            //var arr2 = [];
            //var arr3 = [];
            //var arr4 = [];
            ////var arr5 = [];
            //var arr6 = [];
            //var arr7 = [];
            //var arr8 = [];
            //for(var i = 0;i<$scope.gzAllArray.length;i++)
            //{
            //    //console.log("index",$scope.gzAllArray[i].gzindex);
            //    if($scope.gzAllArray[i].gzindex == 1)
            //    {
            //        arr1.push($scope.gzAllArray[i]);
            //    }
            //    else if($scope.gzAllArray[i].gzindex == 2)
            //    {
            //        arr2.push($scope.gzAllArray[i]);
            //    }
            //    else if($scope.gzAllArray[i].gzindex == 3)
            //    {
            //        arr3.push($scope.gzAllArray[i]);
            //    }
            //    else if($scope.gzAllArray[i].gzindex == 4)
            //    {
            //        arr4.push($scope.gzAllArray[i]);
            //    }
            //    //else if($scope.gzAllArray[i].gzindex == 5)
            //    //{
            //    //    arr5.push($scope.gzAllArray[i]);
            //    //}
            //    else if($scope.gzAllArray[i].gzindex == 6)
            //    {
            //        arr6.push($scope.gzAllArray[i]);
            //    }
            //    else if($scope.gzAllArray[i].gzindex == 7)
            //    {
            //        arr7.push($scope.gzAllArray[i]);
            //    }
            //    else if($scope.gzAllArray[i].gzindex == 8)
            //    {
            //        arr8.push($scope.gzAllArray[i]);
            //    }
            //}
            ////console.log(arr1.length, arr2.length, arr3.length,arr4.length, arr6.length, arr7.length, arr8.length);
            //var arrall = arr1.concat(arr2);
            //arrall = arrall.concat(arr3);
            //arrall = arrall.concat(arr4);
            //arrall = arrall.concat(arr6);
            //arrall = arrall.concat(arr7);
            //arrall = arrall.concat(arr8);
            //$scope.gzAllArray = arrall;
        }
    }

    //所有关注的信息
    $scope.getgzall = function()
    {
        $scope.homegtClearInterval();
        var message = {};
        message['userid'] = $scope.userid;//getParameter('userid');
        //console.log("关注的", message);
        ajaxService.sendMessage('user.getconcerntbyuseridaction', message, $scope.getgzallCallback);
    }

    //$scope.$watch('currentTab.id', function (newValue, oldValue) {
    //if (newValue == 'dqgt')
    //{
    //    $scope.currentGT();
    //    //$scope.currentGTLCS();
    //} else if (newValue == 'jrsyb') {
    //    $scope.jrsyb();
    //} else if (newValue == 'gtbm') {
    //    $scope.gtbm();
    //}
    //else if (newValue == 'kb') {
    //    //$scope.getkb();
    //}

    //});

    $scope.martetinit = function(newValue, oldValue, scope)
    {
        //console.log("12212", newValue, oldValue);
        if(newValue)
        {
            $scope.getgzall();
            //$scope.getzhmxCount();
            //$scope.homegtintervalId = setInterval($scope.gtget, $scope.homegtintervalDuration);
            //$scope.currentTab = gtTabService.tabs[tabindex];
        }
        else
        {
            $scope.homegtClearInterval();
        }
    }

    $scope.$watch('basetabOneShow', $scope.martetinit);

    $scope.gtget = function () {
        //var localStorage = window.localStorage;
        //var tabindex = localStorage.getItem("spbaseChildIndex");
        //if(tabindex == null || tabindex == undefined)
        //{
        //    tabindex = 0;
        //}
        //var valu = gtTabService.tabs[tabindex].id;
        //if (valu == 'dqgt')
        //{
        //    $scope.currentGT();
        //    //$scope.currentGTLCS();
        //} else if (valu == 'jrsyb') {
        //    $scope.jrsyb();
        //} else if (valu == 'gtbm') {
        //    //$scope.gtbm();
        //}
        //else if (valu == 'kb') {
        //    //$scope.getkb();
        //}
        $scope.jrsyb();
    }

    $scope.changeTab = function (tab)
    {
        //$scope.currentTab = gtTabService.changeTab(tab);
        //var localStorage = window.localStorage;
        //localStorage.setItem("spbaseChildIndex", $scope.currentTab.indexID);
        //console.log($scope.gttabs);
    }

    $scope.updateqxgz = function()
    {
        try
        {
            for(var i = 0;i<$scope.gzAllArray.length;i++)
            {
                //if($scope.gzAllArray[i].concernttype == $scope.qxgzObj.concernttype && $scope.gzAllArray[i].belonguserid == $scope.qxgzObj.belonguserid && $scope.gzAllArray[i].fid == $scope.qxgzObj.fid)
                if($scope.gzAllArray[i].fid == $scope.qxgzObj.fid)
                {
                    $scope.gzAllArray.splice(i,1);
                    break;
                }
            }

            for(var i = 0;i<$scope.xhintData.length;i++)
            {
                if($scope.xhintData[i].taskGoal == $scope.qxgzObj.taskGoal)
                {
                    $scope.xhintData.splice(i,1);
                    break;
                }
            }
            if($scope.qxgzObj.f_concernttype == "3")
            {
                //if($scope.qxgzObj.fwinfo.status == "cp3" || $scope.qxgzObj.fwinfo.status == "cp4")
                //{
                    for(var j = 0;j< $scope.sydscxArray.length; j++)
                    {
                        if($scope.qxgzObj.fwinfo.productid == $scope.sydscxArray[j])
                        {
                            $scope.sydscxArray[i].splice(j,1);
                            break;
                        }
                    }
                //}
            }
        }catch (e){}
        if($scope.delgzmark == false)
        {
            $scope.delgzmark = true;
            try{
                layer.closeAll();
            }
            catch (e){}
        }
        $scope.qxgzObj = null;
    }

    $scope.delgzItemCallback = function(_data)
    {
        //console.log("删除返回",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.updateqxgz();
        }
        else
        {
            $scope.delgzmark = true;
            try{
                layer.closeAll();
            }
            catch (e){}
            myAlert("取消关注失败，原因：" + _data.op.info);
        }
        //$scope.delgzmark = true;
    }

    //删除关注
    $scope.delgzItem = function(_obj)
    {
        //console.log("删除");
        if($scope.delgzmark == true)
        {
            $scope.delgzmark = false;
            var message = {};
            message['userid'] = $scope.userid;
            message['concernttype'] = _obj.concernttype;
            message['belonguserid'] = _obj.belonguserid;
            if(_obj.concernttype == "3")
            {
                message['concerntid'] = _obj.fwinfo.productid;
            }
            else if(_obj.concernttype == "4")
            {
                message['concerntid'] = _obj.belonguserid;
            }
            //console.log("删除关注的", message);
            $scope.qxgzObj = _obj;
            myMsg("正在取消关注，请稍候...");
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.delgzItemCallback);
        }
    }

    //跟投list点击
    $scope.gtlistItemClick = function(_obj2)
    {
        var _obj = _obj2.fwinfo;
        if(_obj.fbzuserid == $scope.userObj.f_id) {

            //setbackList(window.location.href);
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            openNewInterface("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("关注"), "dqdataupdate", "", "", window.location.href);

        }
        else
        {
            //$scope.checkisdelMark = true;
            //$scope.qxgzObj = _obj2;
            //setbackList(window.location.href);
            //    window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            openNewInterface("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid +"&&opentype=newwebview"+ "&&backtitle=" + encodeURI("关注"), "dqdataupdate", "", "", window.location.href);
        }

        _obj2.hintstatus = false;
        //try
        //{
        //    navigator.SqliteUserPlugin.deleteFramTaskGoal(function (data){
        //        //alert("清空未读消息成功");
        //    }, _obj2.taskGoal);
        //}catch (e){
        //    //alert("清空未读error:" + e.toString());
        //}

    }

    //理财师个人空间
    $scope.gt_lcsspaceClick = function(_obj)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _obj.belonguserid);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list", "dqdataupdate", "", "", window.location.href);
        _obj.hintstatus = false;
        //try
        //{
        //    navigator.SqliteUserPlugin.deleteFramTaskGoal(function (data){
        //        //alert("清空未读消息成功");
        //    }, _obj.taskGoal);
        //}catch (e){
        //    //alert("清空未读error:" + e.toString());
        //}
    }

    //我的解套
    $scope.me_jietao = function(_obj)
    {
        //window.location.href = "jtBase.html";
        openNewInterface("jtBase.html?opentype=newwebview", "dqdataupdate", "", "", window.location.href);
    }

    //新手必读
    $scope.home_sxbdClick = function()
    {
        $scope.gotoxsbdDiv();
    }

    //我的解盘
    $scope.me_myjpClick = function(_obj)
    {
        //alert("我的解盘");
        if(_obj.belonguserid == $scope.userid)
        {
            //window.location.href = "jiepan_relative.html?userid=" + $scope.userObj.f_id +"&&abletofb=true&&fbuser="+$scope.userObj.f_id + "&title=" + encodeURI("我的解盘") + "&backtitle=" + encodeURI("关注");
            openNewInterface("jiepan_relative.html?userid=" + $scope.userObj.f_id +"&&abletofb=true&&fbuser="+$scope.userObj.f_id + "&title=" + encodeURI("我的解盘") + "&backtitle=" + encodeURI("关注") +"&opentype=newwebview", "dqdataupdate", "", "", window.location.href);
        }
        else
        {
            openNewInterface("jiepan_relative.html?userid=" + $scope.userObj.f_id +"&&abletofb=false&&fbuser="+_obj.belonguserid + "&title=" + encodeURI("解盘") + "&backtitle=" + encodeURI("关注") + "&&opentype=newwebview", "dqdataupdate", "", "", window.location.href);
        }
    }

    //自选股
    $scope.me_zxClick = function(_obj)
    {
        if(_obj.belonguserid == $scope.userid)
        {
            openNewInterface("optionalBase.html" + "?backtitle=" + encodeURI("关注"), "zxgupdateCallBack", "", "", window.location.href);
        }
        else
        {
            //$scope.checkisdelMark = true;
            //$scope.qxgzObj = _obj;
            openNewInterface("peopleoptionalBase.html?peopleID=" + _obj.belonguserid + "&backtitle=" + encodeURI("关注") + "&&opentype=newwebview", "dqdataupdate", "", "", window.location.href);
        }

    }

    zxgupdateCallBack = function()
    {
        $scope.basezxgUpdate();
        $scope.getgzall();
    }


    dqdataupdate = function()
    {
        $scope.getgzall();
    }

    ////自选股更新
    //$scope.zxgupdateCallBack = function()
    //{
    //    $scope.basezxgUpdate();
    //}

    $scope.homeupdatefw = function()
    {
        //$scope.getgzfw();
    }

    //跟投宝服务在线
    $scope.fwonelineClick = function()
    {
        openNewInterface("gtbonlineBase.html" + "?opentype=newwebview&&backtitle=" + encodeURI("关注"), "", "", "", window.location.href);
    }
}
function gt() {
    return {
        restrict: 'E',
        templateUrl: 'template/gt.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: gtController
    };
}
