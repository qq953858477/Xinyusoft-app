function gtsyjrjyjl()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_sy_jrjyjl.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyjrjyjlCtrl($scope, ajaxService, $cookieStore) {
    $scope.childaccount = "";
    $scope.drjyjlArray = [];//当日交易记录

    //当日交易记录
    $scope.getdrjyjlCallBack = function(_data)
    {
        $scope.drjyjlArray = [];
        //console.log("今日交易记录", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.changepositionlist;
            //var arr2 = [];
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.time = arr[i].wtsj.toString().substr(11,8);
                obj.gpdm = arr[i].code;
                obj.exchange = arr[i].exchange;
                obj.gpmc = arr[i].name;
                obj.side = arr[i].side.toString();
                if(obj.side == "B")
                {
                    obj.sideStr = "买入";
                }
                else
                {
                    obj.sideStr = "卖出";
                }
                obj.wtsl = arr[i].wtsl + "股";//成交数量。原先是显示委托数量，后改成显示成交数量，前端未动，后端将成交数量命名为wtsl
                obj.wtjg = parseFloat(arr[i].wtjg).toFixed(2) + "元";//成交价格，原因同上。
                obj.asset = getzqStatus(arr[i].basetype);
                //arr2.push(obj);
                $scope.drjyjlArray.push(obj);
            }
        }
    }

    $scope.getdrjyjl = function()
    {
        //console.log("今日交易记录", 121);
        var message = {};
        message['account'] = $scope.childaccount;
        var str = gettodayno();
        message['kssj'] = str;
        message['jssj'] = str;
        //console.log("今日交易记录", message);
        ajaxService.sendMessage("sunflower.p_selectaccountpositionchangerecord", message, $scope.getdrjyjlCallBack) ;
    }


    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsyjrjyjl")
        {
            //console.log("caption", _data.caption, _data.account);
            $scope.childaccount = _data.account;
            //获取资产信息
            $scope.getdrjyjl();
        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsyjrjyjl"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);


    //查看行情
    $scope.hqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        obj.account = $scope.childaccount;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //window.location.href = "tradinglive_info.html";
        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            openNewInterface("tradinglive_info.html?opentype=newwebview");
        }

    }

    //查看行情
    $scope.drjyjlhqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.gpmc);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            openNewInterface("onestockHQHtml.html?opentype=newwebview");
        }

    }
}
