function gtsysyt()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_sy_syt.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}
function gtsysytCtrl($scope, ajaxService, $cookieStore) {
    $scope.childaccount = "";
    $scope.tuData = [];


    $scope.gethqdataCallBack = function(_data)
    {
        //console.log("大盘指数", _data);
        var data1 = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var pro = arr[i].split("-");
                var obj = {};
                obj.day = Number(pro[0]);
                obj.open = Number(pro[2]) / 10000;
                obj.close =  Number(pro[5]) / 10000;
                obj.high = Number(pro[3]) / 10000;
                obj.low = Number(pro[4]) /10000;
                obj.vol= pro[7];
                obj.preClose =  Number(pro[9]) / 10000;
                obj.amount = pro[6];
                data1.push(obj);
            }
        }

        var delarr = [];
        for(var i = 0;i<$scope.tuData.length;i++)
        {
            var mark = false;
            for(var j = 0;j<data1.length;j++)
            {
                if($scope.tuData[i].day == data1[j].day)
                {
                    data1[j].syl = $scope.tuData[i].syl;
                    $scope.tuData[i] = data1[j];
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                delarr.push(i);
            }
        }
        for(var i = 0;i<delarr.length;i++)
        {
            for(var j = 0;j<$scope.tuData.length;j++)
            {
                $scope.tuData.splice(delarr[i],1);
                break;
            }
        }
        //console.log($scope.tuData.length);
        var mycanvas1 = document.getElementById("klineCanvas");
        //console.log("window.screen.availWidth", window.screen.availWidth);
        //console.log("mycanvas1.style.width", mycanvas1.style.width);
        mycanvas1.width = document.documentElement.clientWidth*0.98;
        //mycanvas1.width = window.screen.availWidth*0.98;
        //mycanvas1.width = 300;
        //mycanvas1.heigh = window.screen.availWidth/2;
        //mycanvas1.style.width = mycanvas1.width;
        //mycanvas1.style.heigh = mycanvas1.heigh;
        //console.log(mycanvas1.width,  mycanvas1.heigh, mycanvas1.style.width, mycanvas1.style.heigh);
        var klinechart = new KLineChart($scope.tuData, mycanvas1, 2);
        klinechart.draw();
    }

    $scope.gethqdata = function(_ksrq, _jsrq)
    {
        var message = {};
        message['cycle'] = "d";//周期 d：日，w：周，M：月
        message['symbol'] = "000001";//股票代码
        message['exchange'] = "sh";//交易所
        message['startDate'] = _ksrq;//开始日期
        message['endDate'] = _jsrq;//结束日期
        message['fqtype'] = "1";//复权类型 1：不复权；2：前复权；3：后复权
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("hq.getklinesegaction", message, $scope.gethqdataCallBack);
    }


    $scope.getsylDataCallBack = function(_data)
    {
        //console.log("收益率", _data);
        $scope.tuData = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.netlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                if(!!arr[i].day)
                {
                    obj.day = arr[i].day;
                    obj.syl = (arr[i].net -1)*100;
                    $scope.tuData.push(obj);
                }
            }
            //console.log("$scope.tuData", $scope.tuData.length);
            if($scope.tuData.length>0)
            {
                $scope.gethqdata($scope.tuData[0].day, $scope.tuData[$scope.tuData.length-1].day);
            }
        }
    }

    $scope.getsylData = function()
    {
        var message = {};
        message['startDate'] = $scope.gtsytstartdate;//开始日期
        message['endDate'] = $scope.gtsytenddate;//结束日期
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("counter.getsecurityhisnetaction", message, $scope.getsylDataCallBack);
    }


    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsysyt")
        {
            //console.log("caption", _data.caption);
            $scope.childaccount = _data.account;
            //获取资产信息
            $scope.getsylData();
        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsysyt"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);

}
