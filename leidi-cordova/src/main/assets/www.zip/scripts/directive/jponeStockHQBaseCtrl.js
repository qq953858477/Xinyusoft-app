function jponestockhqbase()
{
    return {
        restrict: 'E',
        templateUrl: 'view/oneStockHQBase.html',
        controller:['$scope','ajaxService','$sce',jponeStockHQBaseCtrl],
        //template: '<span>Hi there444</span>',
        //replace: true
        transclude: true
    };
}

var htmlType = "onestockhqType";
var code = "";
var sshqCanvasWidth = 0;
var sshqCanvasHeight = 0;
var hqajaxService;
var stock;
var klCycle = "day";


/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function jponeStockHQBaseCtrl($scope, ajaxService, $sce) {

    $scope.sessionID = "";//session
    $scope.index = "1";//跳转至当前页面时的位置
    //$scope.stockcode = "";//代码
    //$scope.exchange = "";//交易所
    $scope.stockname = "";
    $scope.stocktc = "";
    $scope.stockInfo = null;
    $scope.datestr = "";//头部时间和状态
    $scope.zxgStatus = false;//非自选股状态

    $scope.oneStockHQBaseMainShow = true;//主界面
    $scope.f10DivShow = false;//f10
    $scope.f10Src = "";//f10地址

    $scope.oneStockHQbasetab1Show = true;
    $scope.oneStockHQbasetab2Show = false;
    $scope.oneStockHQbasetab3Show = false;
    $scope.oneStockHQbasetab4Show = false;
    $scope.oneStockHQbasetab5Show = false;

    $scope.stock = {};
    $scope.stock.netchange = "--";//涨跌
    $scope.stock.netchangeratio = "--";//涨跌幅
    $scope.stock.close = "--";//最新
    $scope.stock.open =  "--";//今开
    $scope.stock.preclose = "--";//昨收
    $scope.stock.volume = "--";//成交量
    $scope.stock.amplituderatio = "--";//振幅
    $scope.stock.high = "--";//最高
    $scope.stock.low = "--";//最低
    $scope.stock.amount = "--";//成交额

    $scope.stock.capitalization = "--";//总市值
    $scope.stock.peratio = "--";//市盈率
    $scope.stock.turnoverRatio = "--";//换手
    $scope.stock.currencyValue = "--";//流通

    $scope.zxglist = [];//自选股

    hqajaxService = ajaxService;

    $scope.ssintervalDuration = 5000;//间隔时间，8000毫秒
    $scope.ssintervalId;

    $scope.zxgczMark = true;//是否可以添加、删除操作
    $scope.back = "";


    //获取时间格式和开盘状态
    function getDateStr(d,t){
        var date = d+"";
        var time = Number(t)/1000;
        var HH = "";
        var mm = "";
        var ss = "";
        var status = "";
        var timeStr = time+"";
        if(timeStr.length == 6)
        {
            HH = timeStr.substring(0,2);
            mm = timeStr.substring(2,4);
            ss = timeStr.substring(4,6);
        }
        else
        {
            HH = "0"+timeStr.substring(0,1);
            mm = timeStr.substring(1,3);
            ss = timeStr.substring(3,5);
        }

        if((Number(HH) == 9 && Number(mm) >= 30) && (Number(HH) <= 11 && Number(mm) <= 30))
        {
            status = "交易中";
        }
        else if((Number(HH) == 11 && Number(mm) > 30) && Number(HH) < 13)
        {
            status = "午间休市";
        }
        else if((Number(HH) >= 13) && Number(HH) < 15)
        {
            status = "交易中";
        }
        else if(Number(HH) == 9 && Number(mm) >= 15)
        {
            status = "集合竞价";
        }
        else if(Number(HH) >= 15)
        {
            status = "已收盘";
        }

        var mon = date.substring(4,6);
        var day = date.substring(6,8);

        //return status + "  " + mon+"-"+day + " " + HH + ":"+mm + ":"+ss;
        return status;
    }

    //去除
    $scope.onestockhqbaseClearInterval = function()
    {
        if($scope.ssintervalId != undefined)
        {
            clearInterval($scope.ssintervalId);
        }
    }
    //加载股票信息
    $scope.hqloadStockInfo = function()
    {
        htmlType = "onestockhqType";
        var message = {};
        message['code'] = $scope.exchange + $scope.stockcode;
        ajaxService.sendMessage('hq.getsnapshot', message, $scope.getsnapshotCallBack);
    }

    $scope.getsnapshotCallBack = function(_data)
    {
        //console.log("个股", _data);
        if(_data.op.code.toString() == "Y" && _data.datalist.length>0)
        {
            var obj  = _data.datalist[0];
            $scope.stock = {};
            $scope.stock.netchange = Number(obj.netchange).toFixed(2);//涨跌
            $scope.stock.close = Number(obj.close).toFixed(2);//最新
            $scope.stock.open =  Number(obj.open).toFixed(2);//今开
            $scope.stock.preclose = Number(obj.preclose).toFixed(2);//昨收
            $scope.stock.volume = (obj.volume/100).toFixed(0);//成交量
            //console.log(obj.volume);
            $scope.stock.amplituderatio = Number(obj.amplituderatio).toFixed(2);//振幅
            $scope.stock.high = Number(obj.high).toFixed(2);//最高
            $scope.stock.low = Number(obj.low).toFixed(2);//最低
            $scope.stock.amount = obj.amount;//成交额
            if(Number(obj.peratio)<0)
            {
                $scope.stock.peratio = "--";//市盈率
            }
            else
            {
                $scope.stock.peratio = Number(obj.peratio).toFixed(2) ;//市盈率
            }
            $scope.stock.turnoverRatio = Number(obj.turnoverratio).toFixed(2);//换手

            $scope.stock.capitalization1 = obj.capitalization;//总市值
            var capitalization2 = Number($scope.stock.capitalization1) / 100000000;
            var capitalizationpro = ($scope.stock.capitalization1+"").split(".");
            var fixed1 = capitalizationpro[0].length - 3;
            $scope.stock.capitalization = capitalization2.toFixed(Math.abs(fixed1))+"亿";

            $scope.stock.currencyvalue1 = obj.currencyvalue;//流通
            var currencyValue2= Number($scope.stock.currencyvalue1) / 100000000;
            var currencyValuepro = ($scope.stock.currencyValue1+"").split(".");

            var fixed2 = currencyValuepro[0].length - 7;
            $scope.stock.currencyvalue = currencyValue2.toFixed(Math.abs(fixed2))+"亿";

            $scope.stock.inside1 = Number(obj.inside)/100; //内盘
            if(Number($scope.stock.inside1) > 1000)
            {
                var inside1 = Number($scope.stock.inside1) / 10000;
                var insidepro = (inside1+"").split(".");
                var fixed = insidepro[0].length - 3;
                $scope.stock.inside = inside1.toFixed(Math.abs(fixed))+"万";
            }
            else
            {
                $scope.stock.inside = $scope.stock.inside1.toString();
            }


            $scope.stock.outside1 = Number(obj.outside)/100;//外盘
            if(Number($scope.stock.outside1) > 1000)
            {
                var outside1 = Number($scope.stock.outside1) / 10000;
                var outsidepro = (outside1+"").split(".");
                var fixed = outsidepro[0].length - 3;
                $scope.stock.outside = outside1.toFixed(Math.abs(fixed))+"万";
            }
            else
            {
                $scope.stock.outside = $scope.stock.outside1.toString();
            }



            if(Number(obj.netchangeratio) > 0)
            {
                $scope.stock.netchangeratio = "+" + Number(obj.netchangeratio).toFixed(2);//涨跌幅
                $scope.stock.status = "1";//1:红，2：绿，3：白
            }
            else
            {
                $scope.stock.netchangeratio = Number(obj.netchangeratio).toFixed(2);
                if(Number(obj.netchangeratio)<0)
                {
                    $scope.stock.status = "2";
                }
                else
                {
                    $scope.stock.status = "3";
                }
            }

            var date = obj.date;
            var time = obj.time;
            //$scope.datestr = getDateStr(date,time);

            var exchangestatustype = _data[$scope.exchange+"_status"].exchangestatustype;

            if(exchangestatustype =="0")
            {
                $scope.datestr = "集合竞价";
            }
            else if(exchangestatustype =="1")
            {
                $scope.datestr = "交易中";
            }
            else if(exchangestatustype =="2")
            {
                $scope.datestr = "午间休市";
            }
            else if(exchangestatustype =="3")
            {
                $scope.datestr = "已收盘";
            }
            else if(exchangestatustype =="4")
            {
                $scope.datestr = "未开盘";
            }
            else if(exchangestatustype =="5")
            {
                $scope.datestr = "法定节假日休市";
            }

            stock = $scope.stock;
            if($scope.oneStockHQbasetab1Show)
            {
                drawF();
            }
            else if($scope.oneStockHQbasetab2Show)
            {
                draw5F();
            }
            if($scope.datestr != "交易中")
            {
                $scope.onestockhqbaseClearInterval();
            }
        }
    }


    $scope.init = function()
    {
        $scope.onestockhqbaseClear();
        try
        {
            $scope.stockInfo = $cookieStore.get('stockInfo');
            $scope.zxglist = $cookieStore.get('cookiezxgList');
            //console.log("zxglist.length", $scope.zxglist.length);
        }catch (e){}

        sshqCanvasWidth = getWidth();//- 10;
        sshqCanvasHeight = 280;

            code = $scope.exchange + $scope.stockcode;
            //$scope.back = $scope.stockInfo.back;
            console.log(code);
            $scope.stocktc = $scope.exchange.toUpperCase() + $scope.stockcode;
            $scope.hqloadStockInfo();
            $scope.ssintervalId = setInterval($scope.hqloadStockInfo, $scope.ssintervalDuration);

    }

    $scope.onestockhqbaseinit = function(newValue, oldValue, scope)
    {
        //console.log(newValue, oldValue);
        if(newValue)
        {
            console.log("hq");
            $scope.oneStockHQBaseMainShow = true;
            $scope.f10DivShow = false;
            $scope.f10Src = "";
            $scope.init();
        }
        else
        {
            $scope.onestockhqbaseClearInterval();
        }
    }
    $scope.$watch('hqJPId', $scope.onestockhqbaseinit);

    //切换
    $scope.tabChange = function(_str)
    {
        switch (_str)
        {
            case "1":
                $scope.oneStockHQbasetab1Show = true;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                drawF();
                break;
            case "2":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = true;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                draw5F()
                break;
            case "3":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = true;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                klCycle = "day";
                drawKL();
                break;
            case "4":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = true;
                $scope.oneStockHQbasetab5Show = false;
                klCycle = "week";
                drawWeekKL();
                break;
            case "5":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = true;
                klCycle = "month";
                drawMonthKL();
            default :
                break;
        }
    }

    //清空界面数据
    $scope.onestockhqbaseClear = function()
    {
        $scope.stock = {};
        $scope.stock.netchange = "--";//涨跌
        $scope.stock.netchangeratio = "--";//涨跌幅
        $scope.stock.close = "--";//最新
        $scope.stock.open =  "--";//今开
        $scope.stock.preclose = "--";//昨收
        $scope.stock.volume = "--";//成交量
        $scope.stock.amplituderatio = "--";//振幅
        $scope.stock.high = "--";//最高
        $scope.stock.low = "--";//最低
        $scope.stock.amount = "--";//成交额

        $scope.stock.capitalization = "--";//总市值
        $scope.stock.peratio = "--";//市盈率
        $scope.stock.turnoverRatio = "--";//换手
        $scope.stock.currencyValue = "--";//流通

        //$scope.stockcode = "";//代码
        //$scope.exchange = "";//交易所
        $scope.stockname = "";
        $scope.stockInfo = null;
        $scope.datestr = "";//头部时间和状态

        $scope.oneStockHQbasetab1Show = true;
        $scope.oneStockHQbasetab2Show = false;
        $scope.oneStockHQbasetab3Show = false;
        $scope.oneStockHQbasetab4Show = false;
        $scope.oneStockHQbasetab5Show = false;

        $scope.onestockhqbaseClearInterval();

        $("#onestockhqbasesshqLine").clearCanvasAll();
        $("#onestockhqbasefiveLine").clearCanvasAll();
        $("#onestockhqbasecanvasKL").clearCanvasAll();
        $("#onestockhqbasecanvasWeekKL").clearCanvasAll();
        $("#onestockhqbasecanvasMonthKL").clearCanvasAll();

        dataF = [];
        data5F = [];
        data5FDate = [];
        f5PreClose = 0;
        f5High = 0;
        f5Low = 0;
        dayKLpainter = null;
        weekKLpainter = null;
        monthKLpainter = null;
        sshqChart = null;
        fivechart = null;
    }

    //添加自选股
    $scope.addNewzxgClick = function()
    {
        if($scope.zxgczMark)
        {
            $scope.zxgczMark = false;
            var message = {};
            message['exchange'] = $scope.exchange;
            message['symbol'] = $scope.stockcode;
            message['source'] = "xrk";
            message['userid'] = $scope.userObj.f_id;
            //console.log(message['exchange'], message['symbol'], message['source'], message['userid']);
            ajaxService.sendMessage('hq.addzxgaction', message, $scope.onestockhqbaseaddzxgactionCallBack);

        }
    }

    $scope.onestockhqbaseaddzxgactionCallBack = function(_data)
    {
        //console.log("添加自选股", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.zxgStatus = true;
            if($scope.back == "searchlist")
            {
                for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
                {
                    if($scope.stocktc == $scope.allSearchStockListArray[i].tc)
                    {
                        $scope.allSearchStockListArray[i].status = "1";
                        $scope.allSearchStockListArray[i].statusstr = "已添加";
                        break;
                    }
                }
            }
            var obj = {};
            obj.gpdm = $scope.stockcode;
            obj.zqjc = $scope.stockname
            obj.exchange = $scope.exchange
            obj.label = obj.zqjc + "(" + obj.gpdm + ")";
            obj.tc = $scope.stocktc;
            obj.zxj = "0";
            obj.status = "";
            obj.xzzt = "1";//选中状态，样式更改
            obj.zd = "0";
            obj.zdf = "0";
            $scope.oneStockInfo.index = $scope.stocklist.length;
            $scope.stocklist.push($scope.oneStockInfo);

            var obj2 = {};
            obj2.tc = $scope.stocktc;
            $scope.zxglist.push(obj2);
            $cookieStore.put('cookiezxgList', $scope.zxglist);
        }

        $scope.zxgczMark = true;
    }

    //删除自选股
    $scope.delzxgClick = function()
    {
        //console.log("del");
        if($scope.zxgczMark)
        {
            $scope.zxgczMark = false;
            var message = {};
            message['exchange'] = $scope.exchange;
            message['symbol'] = $scope.stockcode;
            message['userid'] = $scope.userObj.f_id;
            ajaxService.sendMessage('hq.deletezxgaction', message, $scope.deletezxgactionCallBack);

        }

    }

    $scope.deletezxgactionCallBack = function(_data)
    {
        //console.log("删除自选股", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.zxgStatus = false;
            if($scope.back == "searchlist")
            {
                for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
                {
                    if($scope.stocktc == $scope.allSearchStockListArray[i].tc)
                    {
                        $scope.allSearchStockListArray[i].status = "0";
                        $scope.allSearchStockListArray[i].statusstr = "添加";
                        break;
                    }
                }
            }
            for(var i= 0; i< $scope.stocklist.length;i++)
            {
                if($scope.stocktc == $scope.stocklist[i].tc)
                {
                    $scope.stocklist.splice(i,1);
                    break;
                }
            }

            for(var i= 0; i< $scope.zxglist.length;i++)
            {
                if($scope.stocktc == $scope.zxglist[i].tc)
                {
                    $scope.zxglist.splice(i,1);
                    break;
                }
            }
            $cookieStore.put('cookiezxgList', $scope.zxglist);
        }

        $scope.zxgczMark = true;
    }

    //F10
    $scope.F10Click = function()
    {
        //console.log("f10");
        $scope.onestockhqbaseClearInterval();
        $scope.oneStockHQBaseMainShow = false;
        $scope.f10DivShow = true;
        $scope.f10Src = $sce.trustAsResourceUrl("http://222.173.35.134:900/f10/stock/"+$scope.stockcode+"/index.htm");
    }

    //f10返回
    $scope.f10backto = function()
    {
        $scope.oneStockHQBaseMainShow = true;
        $scope.f10DivShow = false;
        $scope.f10Src = "";
        $scope.hqloadStockInfo();
        $scope.ssintervalId = setInterval($scope.hqloadStockInfo, $scope.ssintervalDuration);
    }

    //返回上一级
    $scope.backtoP = function()
    {
        $scope.onestockhqbaseClear();
        if($scope.back == "searchlist")//搜索界面
        {
            $scope.onestockhqbaseBacktoSearchList();
        }
        else//自选股列表界面
        {
            $scope.onestockhqbaseBacktoggList();
        }
    }

}



