/**
 * Created by wangtao on 2015/8/20 0020.
 */

function getParameter(param) {
    var query = window.location.search;
    //console.log("getParameter", query);
    var iLen = param.length;
    var iStart = query.indexOf(param);
    if (iStart == -1) {
        return "";
    }
    iStart += iLen + 1;
    var iEnd = query.indexOf("&", iStart);
    if (iEnd == -1) {
        return query.substring(iStart);
    }
    else {
        return query.substring(iStart, iEnd);
    }
}

function tabService($stateParams, $location, $state) {
    var tabs = [
    //    {
    //    id: 0,
    //    name: '个股',
    //    isactive: true,
    //    typeLastId: ""
    //}, {
    //    id: 1,
    //    name: '市场',
    //    isactive: false,
    //    typeLastId: ""
    //}, /*{
    // id: 2,
    // name: '行业',
    // isactive: false,
    // typeLastId: 0
    // },*/ {
    //    id: 3,
    //    name: '概念',
    //    isactive: false,
    //    typeLastId: ""
    //},
        {
        id: 4,
        name: '观点',
        isactive: false,
        typeLastId: ""
    }
    ];

    //获取入参
    var getParameter =function (param) {
        var query = window.location.search;
        //console.log("getParameter", query);
        var iLen = param.length;
        var iStart = query.indexOf(param);
        if (iStart == -1) {
            return "";
        }
        iStart += iLen + 1;
        var iEnd = query.indexOf("&", iStart);
        if (iEnd == -1) {
            return query.substring(iStart);
        }
        else {
            return query.substring(iStart, iEnd);
        }
    }

    $stateParams = $location.search();
    var changeTab = function (id) {
        var currentTab;
        //console.log(id);
        //$scope.showTab = id;
        for (var i = 0; i < tabs.length; i++) {
            var tabTemp = tabs[i];
            if (tabTemp.id == id) {
                tabTemp.isactive = true;
                tabTemp['typeLastId'] = "";
                currentTab = tabTemp;
                //currentTab["params"]=$location.search();
                //$state.go(""+id, $stateParams);
            } else {
                tabTemp.isactive = false;
            }
        }

        return currentTab;
    };

    var tabObject = {
        changeTabFunction: changeTab,
        tabs: tabs,
        getParam:getParameter
    }
    //$location.onUrlChange()
    return tabObject;
}