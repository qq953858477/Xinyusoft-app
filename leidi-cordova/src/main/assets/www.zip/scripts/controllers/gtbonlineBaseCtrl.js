
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gtbonlineBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面
    $scope.backtitle = "";

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    //初始相关操作界面
    $scope.myfinInit = function()
    {
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }
    }

    $scope.myfinInit();

    //意见反馈
    $scope.me_suggestionClick = function()
    {
        setbackList(window.location.href);
        window.location.href = "suggestions.html"+"?backtitle=" + encodeURI("返回");
    }



    //开户返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



