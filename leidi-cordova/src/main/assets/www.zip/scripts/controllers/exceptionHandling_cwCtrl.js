
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function exceptionHandling_cwCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.backtitle = "";
    $scope.productid = "";//产品id
    $scope.exceptionArr = [];//差异数据
    $scope.bqtjmark = true;

    $scope.selectkh = "";
    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.productid = getParameter("productid");
    $scope.exceptionErrorInfo = "";

    $scope.getexceptionCallBack = function(_data)
    {
        //console.log("差异", _data);
        $scope.exceptionArr = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.position;
            if(arr.length>0)
            {
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.exchange = arr[i].exchange;
                    obj.side = arr[i].side;
                    if(obj.side == "B")
                    {
                        obj.sidestr = "买入";
                    }
                    else
                    {
                        obj.sidestr = "卖出";
                    }
                    obj.stockcode = arr[i].stockcode;
                    obj.stockname = arr[i].stockname;
                    obj.sync = arr[i].sync;
                    obj.syncnum = arr[i].syncnum;
                    $scope.exceptionArr.push(obj);
                }
            }
            else
            {
                $scope.exceptionErrorInfo = _data.op.info;
            }
        }
        else
        {
            $scope.exceptionErrorInfo = _data.op.info;
        }
    }

    $scope.getexception = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        ajaxService.sendMessage("gentou.selectcheckposition", message, $scope.getexceptionCallBack);
    }


    //初始相关操作界面
    $scope.myfinInit = function()
    {
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));

        $scope.getexception();
    }

    $scope.myfinInit();

    //改变状态
    $scope.exceptionChangeStatus = function(_obj)
    {
        if(_obj.sync == "Y")
        {
            _obj.sync = "N";
        }
        else
        {
            _obj.sync = "Y";
        }
    }

    //仓位补齐
    $scope.cwbqClick = function()
    {
        if($scope.exceptionArr.length>0)
        {
            if($scope.bqtjmark == true)
            {
                var str = "";
                for(var i = 0;i<$scope.exceptionArr.length;i++)
                {
                    if(i == 0)
                    {
                        str = $scope.productid + "-" + $scope.exceptionArr[i].exchange + "-"+ $scope.exceptionArr[i].stockcode + "-" + $scope.exceptionArr[i].sync;
                    }
                    else
                    {
                        str = str + "," + $scope.productid + "-" + $scope.exceptionArr[i].exchange + "-"+ $scope.exceptionArr[i].stockcode + "-" + $scope.exceptionArr[i].sync;
                    }
                }
                $scope.bqtjmark = false;

                var message = {};
                message['confirmlist'] = str;
                ajaxService.sendMessage("gentou.checkpositionconfirmaction", message, $scope.cwbqCallBack);

            }
        }
    }

    $scope.cwbqCallBack = function(_data)
    {
        //console.log("仓位补齐",_data);
        if(_data.op.code.toString() == "Y")
        {
            myAlert("请求提交成功");
        }
        else
        {
            myAlert("请求提交失败，原因：" + _data.op.info);
        }

        $scope.bqtjmark = true;
        $scope.getexception();
    }


    //开户返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



