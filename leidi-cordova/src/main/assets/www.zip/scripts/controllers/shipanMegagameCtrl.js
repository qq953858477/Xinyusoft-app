
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function shipanMegagameCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.dsbmDiv = false;//报名界面
    $scope.bmsuccessDiv = false;//报名成功界面
    $scope.bmfirst = false;//报名第一步
    $scope.bmsecond = false;//报名第二步
    //$scope.ybminDiv = false;//已报名
    $scope.userName = "";
    $scope.backtitle = "";

    $scope.spdsArray = [];//大赛
    $scope.homedqdsObj = null;
    $scope.errorInfo = "";//报错信息
    $scope.bmmark = true;//是否可以点击报名

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
    $scope.bcid = localStorage.getItem('bcid')

    $scope.spdshomebg = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/spds_homebg.jpg?20160411";//首页背景
    //$scope.spdshomedq = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/spds_homedq.png?20160411";//首页可操作
    //$scope.spdsbmindex = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/spds_bmindex.jpg?20160411";//报名界面图

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.inprevhome = "1";//首页：1；报名成功页面：2

    $scope.isbmorsp = "";//是报名还是进入实盘 0：报名；1：实盘
    $scope.zhListArray = [];//可用账户
    $scope.dqxzaccount = null;//当前选择的账户
    $scope.addSecurityAccountShow = false;//添加账户界面
    $scope.selectedzqgs = {};//证券公司id
    $scope.newzqzhpassword = "";//新的证券账号密码
    $scope.newzqzhtxpassword = "";//新的证券通讯密码
    $scope.newzqyj = "0.0003";//新的证券账号佣金
    $scope.newxm = "";//新的账户姓名
    $scope.zsaddinfo = "";//真实账户添加操作中提示信息;
    $scope.addnewzqzhMark = true;

    //点击不显示手机弹出的键盘
    $scope.closePopClick = function()
    {}

    $scope.getisjoinganme = function()
    {
        //var message = {};
        //message['userid'] = $scope.userObj.f_id;
        //message['gametype'] = "T";//M，模拟大赛；R，实盘大赛
        //message['status'] = "A";//A，报名中；B，实盘中；C，已结束； D，大赛准备中
        //message['gameid'] = $scope.homedqdsObj.id;
        //ajaxService.sendMessage("tradegame.selectjoingameaction", message, $scope.getisjoinganmeCallBack);
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['gameid'] = $scope.homedqdsObj.id;
        message['page.size'] = "max";
        message['page.no'] = "";
        ajaxService.sendMessage("tradegame.selectgamejoinaction", message, $scope.getisjoinganmeCallBack);
    }

    $scope.getisjoinganmeCallBack = function(_data)
    {
        //console.log("是否报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gamejoinlist;
            if(arr.length == 0)//未报名
            {
                //$scope.mainShow = false;
                //$scope.dsbmDiv = true;
                $scope.isbmorsp = "0";//报名
            }
            else
            {
                $scope.isbmorsp = "1";

                $scope.homedqdsObj.zqgsname = arr[0].moneyinfo.companyname;
                $scope.homedqdsObj.zqgszh = arr[0].moneyinfo.belongaccount;
                $scope.homedqdsObj.zqgsid = arr[0].moneyinfo.company;
            }
        }
        else
        {
            $scope.isbmorsp = "0";
            //$scope.mainShow = false;
            //$scope.dsbmDiv = true;
        }
    }


    $scope.checkcanApplyCallBack = function(_data)
    {
        //console.log("是否可以报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.homedqdsObj.canbm = true;
        }
        else
        {
            $scope.homedqdsObj.canbm = false;
        }

        $scope.getisjoinganme();
    }

    $scope.checkcanApply = function()
    {
        var message = {};
        message['gameid'] = $scope.homedqdsObj.id;
        //console.log("入参", message);
        ajaxService.sendMessage("tradegame.isgamecanapplyrule", message, $scope.checkcanApplyCallBack);

    }

    $scope.getshipanInfoCallBack = function(_data)
    {
        $scope.spdsArray = [];
        //console.log("模拟", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gamelist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.id = arr[i].id;//id
                obj.name = arr[i].name;
                obj.descurl = arr[i].descurl;
                obj.prizeurl = arr[i].prizeurl;
                var str = arr[i].beginday;
                obj.beginday = str.substr(0,4) + "." + str.substr(4,2) + "." + str.substr(6,2);
                var str2= arr[i].endday;
                obj.endday = str2.substr(0,4) + "." + str2.substr(4,2) + "." + str2.substr(6,2);
                obj.money = arr[i].money;
                $scope.spdsArray.push(obj);
            }
        }

        if($scope.spdsArray.length>0)
        {
            $scope.homedqdsObj = $scope.spdsArray[0];
            //查询是否可以报名
            $scope.checkcanApply();
        }
    }

    $scope.getshipanInfo = function()
    {
        var message = {};
        message['userid'] = $scope.bcid;
        message['page.size'] = "max";
        message['page.no'] = "1";
        message['type'] = "T";
        //console.log("入参", message);
        ajaxService.sendMessage("tradegame.selectgameaction", message, $scope.getshipanInfoCallBack);
    }

    //初始相关操作界面
    $scope.myfinInit = function()
    {
        //学校信息
        $scope.getshipanInfo();
        $scope.inprevhome = "1";
    }

    $scope.myfinInit();

    //当前操作
    $scope.dqczClick = function()
    {
        //$scope.isbmorsp = "0";//报名
        if($scope.isbmorsp == "0")
        {
            //进入报名界面
            $scope.mainShow = false;
            $scope.dsbmDiv = true;
            $scope.bmfirst = true;
            $scope.bmsecond = false;
        }
        else
        {
            //进入报名成功界面
            $scope.mainShow = false;
            $scope.bmsuccessDiv = true;
            $scope.inprevhome = "2";
        }
    }

    //实盘大赛报名
    $scope.gotospbmClick = function()
    {
        $scope.bmfirst = false;
        $scope.bmsecond = true;
        $scope.getzhlb();
        //获取证券账户
    }

    $scope.p_getaccountlistCallBack = function(_data)
    {
        //console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.check = false;
                obj.experience = element[item].experience.toString();
                if(obj.experience != "Y" && obj.zqgs != 'moni')//Y:跟投基金
                {
                    $scope.zhListArray.push(obj);
                }
            }
        }
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }

    //账户选择，单一
    $scope.zhcheckClick = function (_obj)
    {
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }
        _obj.check = true;
        $scope.dqxzaccount = _obj;
    }

    $scope.surespbmClick = function()//确定报名
    {
        if($scope.bmmark) {
            $scope.bmmark = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['gameid'] = $scope.homedqdsObj.id;
            message['account'] = $scope.dqxzaccount.account;
            //console.log("获取账户列表",$scope.userObj.f_id);
            ajaxService.sendMessage("tradegame.p_applyrealgame", message, $scope.surespbmCallBack);
        }
    }

    $scope.surespbmCallBack = function(_data)
    {
        //实盘大赛报名
        if(_data.op.code.toString() == "Y")
        {
            $scope.bmsuccessDiv = true;
            $scope.dsbmDiv = false;
            $scope.homedqdsObj.zqgsname = $scope.dqxzaccount.zqgsname;
            $scope.homedqdsObj.zqgszh = $scope.dqxzaccount.account;
            $scope.homedqdsObj.zqgsid = $scope.dqxzaccount.company;
            $scope.inprevhome = "2";
            $scope.isbmorsp = "1";
        }
        else
        {
            $scope.errorInfo = "报名失败，原因：" + _data.op.info;
        }
        $scope.bmmark = true;
    }


    //添加账户
    $scope.tjzhClick = function()
    {
        $scope.dsbmDiv = false;
        $scope.addSecurityAccountShow = true;//添加账号界面显示
        $scope.zqgsItemShow = false;//证券公司列表
        $scope.zszhShow = false;//真实账户

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqzhtxpassword = "";
        $scope.newzqyj = "0.0003";
        $scope.newxm = "";
        $scope.addnewzqzhMark = true;
        $scope.getzqgs();
    }

    //获取证券公司
    $scope.getzqgs = function()
    {
        //console.log("证券公司");
        $scope.zqgsArray = [];
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['company'] = "";
        message['name'] = "";
        message['desc'] = "";
        message['market'] = "";
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getsecuritycompany", message, $scope.selectsecuritycompanyactionCallBack);
    }

    //获取证券公司
    $scope.selectsecuritycompanyactionCallBack = function(_data)
    {
        //console.log("证券公司", _data);
        if(_data.op.code.toString() == "Y") {
            var element = _data.securitycompanylist;
            //console.log(element.length);
            for (var item = 0;item < element.length; item++){
                var obj = {};
                obj.id = element[item]['company'];
                obj.name = element[item]['name'];
                obj.logo = getzqgsLogo(element[item]['company']);
                obj.apistatus = element[item]['apistatus'];//接口状态 0：表示正常，1：查资金有问题
                obj.passpwdflag = element[item]['passpwdflag'];//通讯密码 Y：需要，N：不需要
                //console.log("obj.apistatus", obj.apistatus, obj.name);
                if(obj.id != "moni")
                {
                    $scope.zqgsArray.push(obj);
                }
            }
        }
    }

    //返回home
    $scope.addzhBackto = function()
    {
        $scope.dsbmDiv = true;
        $scope.addSecurityAccountShow = false;//添加账号界面显示
        $scope.zszhShow = false;

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqzhtxpassword = "";
        $scope.newzqyj = "0.0003";
        $scope.newxm = "";
    }

    //进入添加界面
    $scope.zqgsItemClick = function(_obj)
    {
        $scope.zqgsItemShow = true;
        $scope.selectedzqgs = _obj;
    }

    //返回证券公司列表
    $scope.backtozqgslist = function()
    {
        $scope.zqgsItemShow = false;
        $scope.selectedzqgs = {};

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqzhtxpassword = "";
        $scope.newzqyj = "0.0003";
        $scope.newxm = "";
        $scope.addnewzqzhMark = true;
        $scope.zsaddinfo = "";
    }

    //确定增加关联账号
    $scope.addnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.newzqzh == "")
            {
                $scope.zsaddinfo = "请输入证券账号";
                return;
            }
            if($scope.newzqzhpassword == "")
            {
                $scope.zsaddinfo = "请输入交易密码";
                return;
            }
            if($scope.selectedzqgs.passpwdflag == 'Y')//需要通讯密码
            {
                if($scope.newzqzhtxpassword == "")
                {
                    $scope.zsaddinfo = "请输入通讯密码";
                    return;
                }
            }
            $scope.zsaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['account'] = $scope.newzqzh;//当前账号
            if($scope.selectedzqgs.passpwdflag == 'Y')
            {
                message['password'] = $scope.newzqzhpassword + "," + $scope.newzqzhtxpassword;
            }
            else
            {
                message['password'] = $scope.newzqzhpassword;
            }
            message['company'] = $scope.selectedzqgs.id;
            //onsole.log($scope.selectedzqgs.id)
            message['source'] = "A";
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.newzqyj;
            message['name'] = $scope.newxm;//备注名
            //console.log("增加证券账户");
            $scope.zsaddinfo = "添加账户中，请稍候...";
            ajaxService.sendMessage("sunflower.p_bindsecurity", message, $scope.p_bindsecurityaccountCallBack);
        }
    }

    $scope.p_bindsecurityaccountCallBack = function(_data)
    {
        //console.log("增加证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            //查询证券账号列表
            $scope.getzhlb2();

            //返回账号列表
            $scope.dsbmDiv = true;
            $scope.addSecurityAccountShow = false;
            $scope.zqgsItemShow = false;
            $scope.zszhShow = false;
            $scope.newzqzh = "";
            $scope.newzqzhpassword = "";
            $scope.newzqzhtxpassword = "";
            $scope.newzqyj = "0.0003";
            $scope.newxm = "";
            $scope.selectedzqgs = {};
            $scope.zsaddinfo = "";
        }
        else
        {
            //alert("添加账号失败，原因：" + _data.op.info);
            $scope.zsaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }

    $scope.getzhlb2 = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack2);

    }

    $scope.p_getaccountlistCallBack2 = function(_data)
    {
        //console.log("获取账户列表", _data);
        var arr = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.experience = element[item].experience.toString();
                if(obj.experience != "Y" && obj.zqgs != 'moni')//Y:跟投基金
                {
                    arr.push(obj);
                }
            }
        }

        for(var j = 0;j<$scope.zhListArray.length;j++)
        {
            $scope.zhListArray[j].check = false;
        }

        for(var i = 0;i<arr.length;i++)
        {
            var mark = false;
            for(var j = 0;j<$scope.zhListArray.length;j++)
            {
                if($scope.zhListArray[j].account == arr[i].account)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)//新加的
            {
                arr[i].check = true;
                $scope.zhListArray.push(arr[i]);
                $scope.dqxzaccount = arr[i];
                break;
            }
        }
    }

    $scope.bmackto = function()
    {
        $scope.mainShow = true;
        $scope.dsbmDiv = false;
    }


    $scope.bmsuccessackto = function()
    {
        $scope.inprevhome = "1";
        $scope.bmsuccessDiv = false;
        $scope.dsbmDiv = false;
        $scope.mainShow = true;
    }

    //分享
    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);


        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/shipangame_index.html");
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = '股王今来实盘炒股大赛';
        var desc = '全新赛制 常规赛：2016年5月~11月，每月一期，共7期。总决赛：2016年12月。百分百实盘！';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/shipangame_index.html";
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    $scope.pyqfx = function()
    {
        var title = '股王今来实盘炒股大赛';
        var desc = '全新赛制 常规赛：2016年5月~11月，每月一期，共7期。总决赛：2016年12月。百分百实盘！';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/shipangame_index.html";
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        //alert("$scope.inprevhome：" + $scope.inprevhome);
        if($scope.inprevhome == "2")
        {
            $scope.bmsuccessDiv = false;
        }
        else
        {
            $scope.mainShow = false;
        }
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/shipangame_index.html";
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        if($scope.inprevhome == "2")
        {
            $scope.bmsuccessDiv = true;
        }
        else
        {
            $scope.mainShow = true;
        }
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    //开户返回
    $scope.spdsBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    //大赛规则
    $scope.spdsgzClick = function()
    {
        openNewInterface("shipan_guize.html?opentype=newwebview");
    }
    //大赛奖品
    //$scope.dsjpClick = function()
    //{
    //    openNewInterface("moni_dasaijp.html?opentype=newwebview");
    //}

    //开户
    $scope.khClick = function()
    {
        //setbackList("myFinancialBase.html");
        //window.location = "openAccounts.html";
        openNewInterface("openAccounts.html?opentype=newwebview");

    }

}



