
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gtreleaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.fbZeroShow = true;//发布第一步之前，签署协议
    $scope.fbfirstShow = false;//发布第一步
    $scope.fbsecondShow = false;//第二步
    $scope.fbthirdShow = false;//第三步
    $scope.fbfourthShow = false;//第四步
    $scope.fbfiveShow = false;//第五步
    $scope.gtfwszDivShow = false;//跟投服务设置

    $scope.zqlistArray = [];//周期列表
    $scope.gtname = "";//名称
    $scope.gtdesc = "";//描述
    $scope.zqValue = "";//周期
    $scope.mbsy = "";//目标收益
    $scope.gtminmoney = "";//最小跟投金额
    $scope.gtmaxmoney = "";//最大跟投金额
    $scope.fwyjtrzj = "";//预计投入资金
    $scope.firstErrorInfo = "";//第一步错误信息
    $scope.thirdErrorInfo = "";//第三步错误提示
    $scope.fouthErrorInfo = "";//第四步错误提示
    $scope.dzgkcheck = false;//是否公开给大众

    $scope.bmjzsj = new Date();//报名截止时间
    $scope.lcsstatus = "0";//是否是理财师 2：理财师，非2：不是理财师
    $scope.zhListArray = [];//可发布用的账户
    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.fcfsArray = [];
    $scope.fcfs = null;//分成方式
    $scope.dqxzaccount = null;//当前选择的账户
    $scope.addMark = true;//是否可以操作

    $scope.ybdzhListArray = [];//已经被绑定账户，发布：被跟投账户不可用

    $scope.backtitle = "";//返回页面名称
    $scope.backtitle = decodeURI(getParameter("backtitle"));
    $scope.opentype = "";
    $scope.opentype = getParameter("opentype");//打开当前页面的方式

    $scope.assetopenflaggentou = "Y";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "Y";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "Y";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "Y";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "Y";//对跟投者，交易指令公开

    $scope.assetopenflagall = "Y"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "Y";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "Y"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "Y";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "Y";//对大众，交易指令公开

    $scope.getfcfsCallBack = function(_data)
    {
        $scope.fcfsArray = [];
        //console.log("分层方式",_data );
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.platformsharelist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.id = arr[i].id;
                obj.type = arr[i].type.toString();
                obj.share = arr[i].share;
                var fc = (parseInt(obj.share)/10);
                obj.label = fc +":" + (10-fc);
                obj.desc = arr[i].desc;
                obj.targetprofit = arr[i].targetprofit;
                obj.status = false;
                //if(fc == 2)
                //{
                    $scope.fcfsArray.push(obj);
                //}
            }
        }
    }

    //获取分层方式
    $scope.getfcfs = function()
    {
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['targetprofit'] = "";
        message['share'] = "";
        message['type'] = "";
        message['period'] = $scope.zqValue;
        //console.log("周期", message['period']);
        ajaxService.sendMessage('gentou.selectplatformshareaction',message, $scope.getfcfsCallBack);
    }

    $scope.setzq = function()
    {
        //console.log(3333);
        $scope.zqlistArray = [];
        var obj = {};
        obj.label = "1周";
        obj.value = "1w";
        obj.check = true;
        $scope.zqlistArray.push(obj);

        obj = {};
        obj.label = "1个月";
        obj.value="1m";
        obj.check = false;
        $scope.zqlistArray.push(obj);

        obj = {};
        obj.label = "3个月";
        obj.value="3m";
        obj.check = false;
        $scope.zqlistArray.push(obj);

        obj = {};
        obj.label = "半年";
        obj.value = "6m";
        obj.check = false;
        $scope.zqlistArray.push(obj);

        obj = {};
        obj.label = "一年";
        obj.value="12m";
        obj.check = false;
        $scope.zqlistArray.push(obj);

        $scope.zqValue = "1w";
        $scope.getfcfs();
        //console.log($scope.zqlist.length)
    }

    $scope.p_getaccountlistCallBack = function(_data)
    {
        //console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.check = false;
                obj.experience = element[item].experience.toString();
                if(obj.experience == "Y")
                {
                    obj.zqgsname = "跟投基金";
                }
                //if(element[item].accountstatus.toString() != "b")//非绑定账户
                if(element[item].accountstatus.toString() != "c" && element[item].accountstatus.toString() != "b")//非绑定账户
                {
                    if(obj.experience != "Y")//过滤掉跟投基金
                    {
                        $scope.zhListArray.push(obj);
                    }
                }
                else
                {
                    var arr = [];
                    if(element[item].accountstatus.toString() == "c")//被跟投
                    {
                        var obj2 = {};
                        obj2.productid = element[item].product.id;
                        obj2.productname = element[item].product.name;
                        arr.push(obj2);
                    }
                    else if(element[item].accountstatus.toString() == "b")//跟投其他人
                    {
                        var arr2 = element[item].linklist;
                        for(var i = 0;i<arr2.length;i++)
                        {
                            var obj2 = {};
                            obj2.productid = arr2[i].productid;
                            obj2.productname = arr2[i].productname;
                            arr.push(obj2);
                        }
                        var arr3 = element[item].linkapplylist;
                        for(var i = 0;i<arr3.length;i++)
                        {
                            var obj2 = {};
                            obj2.productid = arr3[i].productid;
                            obj2.productname = arr3[i].productname;
                            arr.push(obj2);
                        }
                    }
                    obj.productlist = arr;
                    $scope.ybdzhListArray.push(obj);
                }
            }
        }
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        $scope.ybdzhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }

    //初始相关操作界面
    $scope.gtfbInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.lcsstatus = localStorage.getItem("lcsstatus");
            $scope.setzq();
            $scope.getzhlb();

        }catch (e){}
    }

    $scope.gtfbInit();

    $scope.tyqsClick = function()
    {
        $scope.fbZeroShow = false;//发布第一步之前，签署协议
        $scope.fbfirstShow = true;//发布第一步
    }

    //服务时长（周期）
    $scope.zqcheckClick = function (_obj)
    {
        //console.log("check");
        for(var i = 0;i<$scope.zqlistArray.length;i++)
        {
            if($scope.zqlistArray[i].check)
            {
                $scope.zqlistArray[i].check = false;

                break;
            }
        }
        _obj.check = true;
        $scope.zqValue = _obj.value;
        $scope.getfcfs();
    }

    $scope.fcfsClick = function(_obj)
    {
        for(var i = 0;i<$scope.fcfsArray.length;i++)
        {
            if($scope.fcfsArray[i].status)
            {
                $scope.fcfsArray[i].status = false;
                break;
            }
        }
        _obj.status = true;
        $scope.fcfs = _obj;
    }

    $scope.gotosecondClick = function()
    {
        if($scope.gtname == "")
        {
            $scope.firstErrorInfo = "请先输入服务名称";
            return;
        }
        if($scope.gtname.length >8)
        {
            $scope.firstErrorInfo = "服务名称不超过8个字，请重新输入";
            return;
        }
        if($scope.zqValue == "")
        {
            $scope.firstErrorInfo = "请先选择服务时长";
            return;
        }
        if($scope.mbsy == "" || $scope.mbsy == "0")
        {
            $scope.firstErrorInfo = "请输入目标收益";
            return;
        }
        if(numericCheck($scope.mbsy) == false)
        {
            $scope.firstErrorInfo = "目标收益含有特殊字符，请输入有效值";
            return;
        }
        if($scope.gtminmoney == "")
        {
            $scope.firstErrorInfo = "请输入最小跟投金额";
            return;
        }
        if(valueCheck($scope.gtminmoney) == false)
        {
            $scope.firstErrorInfo = "最小跟投金额含有特殊字符，请输入有效值";
            return;
        }
        if($scope.gtmaxmoney == "")
        {
            $scope.firstErrorInfo = "请输入最大跟投金额";
            return;
        }
        if(valueCheck($scope.gtmaxmoney) == false)
        {
            $scope.firstErrorInfo = "最大跟投金额含有特殊字符，请输入有效值";
            return;
        }
        if(parseFloat($scope.gtminmoney)> parseFloat($scope.gtmaxmoney))
        {
            $scope.firstErrorInfo = "最小跟投金额大于最大跟投金额，请重新输入";
            return;
        }
        if($scope.fwyjtrzj == "")
        {
            $scope.firstErrorInfo = "请输入预计投入资金";
            return;
        }
        if(valueCheck($scope.fwyjtrzj) == false)
        {
            $scope.firstErrorInfo = "最大跟投金额含有特殊字符，请输入有效值";
            return;
        }
        if($scope.fcfs == null)
        {
            $scope.firstErrorInfo = "请选择分成比例";
            return;
        }

        //console.log("周期", $scope.zqValue);
        //console.log("周期", $scope.zqValue);

        $scope.firstErrorInfo = "";
        $scope.fbfirstShow = false;
        $scope.fbthirdShow = true;
    }

    //返回协议界面
    $scope.backtoxyClick = function()
    {
        $scope.fbZeroShow = true;//发布第一步之前，签署协议
        $scope.fbfirstShow = false;//发布第一步
    }

    $scope.gotothirdClick = function()
    {
        //$scope.fbsecondShow = false;
        //$scope.fbthirdShow = true;
    }

    //返回第二步
    $scope.backtosecondClick = function()
    {
        $scope.fbfirstShow = true;
        $scope.fbthirdShow = false;
    }

    $scope.dzgkcheckClick = function()
    {
        $scope.dzgkcheck = ! $scope.dzgkcheck;
    }

    $scope.gotofourthClick = function()
    {
        if($scope.bmjzsj == "")
        {
            $scope.thirdErrorInfo = "请选择报名截止时间";
            return;
        }
        var today = new Date();
        var yesterday_milliseconds=today.getTime()-1000*60*60*24;
        var yesterday = new Date();
        yesterday.setTime(yesterday_milliseconds);
        //console.log(today, yesterday);
        if ($scope.bmjzsj<yesterday)
        {
            $scope.thirdErrorInfo = "报名截止时间不应小于当前日期";
            return;
        }

        //console.log("报名截止时间", $scope.bmjzsj)
        $scope.thirdErrorInfo = "";
        $scope.fbthirdShow = false;
        $scope.gtfwszDivShow = true;
        //$scope.fbfourthShow = true;

    }

    //从服务设置界面返回上一步
    $scope.backtoproClick = function()
    {
        $scope.thirdErrorInfo = "";
        $scope.fbthirdShow = true;
        $scope.gtfwszDivShow = false;
    }

    //从服务设置界面进入下一步
    $scope.gotonextClick = function()
    {
        $scope.gtfwszDivShow = false;
        $scope.fbfourthShow = true;
    }

    //返回第三部
    $scope.backtothirdClick = function()
    {
        $scope.gtfwszDivShow = true;
        $scope.fbfourthShow = false;
    }


    //账户选择，单一
    $scope.zhcheckClick = function (_obj)
    {
        //console.log("check");
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }
        _obj.check = true;
        $scope.dqxzaccount = _obj;
    }

    //沪深
    $scope.hscheckClick = function()
    {
        $scope.hscheck = !$scope.hscheck;
    }
    //创业板
    $scope.cybcheckClick = function()
    {
        $scope.cybcheck = !$scope.cybcheck;
    }
    //港股通
    $scope.ggtcheckClick = function()
    {
        $scope.ggtcheck = !$scope.ggtcheck;
    }

    //信息确认提交
    $scope.endClick = function()
    {
        //var mark = false;
        //for(var i = 0;i<$scope.zhListArray.length;i++)
        //{
        //    if($scope.zhListArray[i].check)
        //    {
        //        mark = true;
        //    }
        //}
        if($scope.addMark)
        {
            if( $scope.dqxzaccount == null)
            {
                $scope.fouthErrorInfo = "请选择账户";
                return;
            }
            if($scope.hscheck == false && $scope.cybcheck == false &&  $scope.ggtcheck == false)
            {
                $scope.fouthErrorInfo = "请选择需开通的业务";
                return;
            }
            $scope.fouthErrorInfo = "跟投发布中，请稍候...";
            $scope.addMark = false;
            //提交
            $scope.tjInfo();

            //$scope.gotofinished();
        }
    }

    $scope.tjInfo = function()
    {
        var message = {};
        message['account'] = $scope.dqxzaccount.account;
        message['userid'] = $scope.userObj.f_id;
        message['name'] = $scope.gtname;
        message['minmoney'] = $scope.gtminmoney;
        message['maxmoney'] = $scope.gtmaxmoney;
        message['gentouperiod'] = $scope.zqValue;
        if($scope.dzgkcheck)
        {
            message['property'] = "public";
        }
        else
        {
            message['property'] = "private";
        }
        message['endapplyday'] = $scope.getDateFull($scope.bmjzsj);
        message['targetprofit'] = $scope.mbsy;
        message['sharetypes'] = $scope.getfcfsvalue2();
        message['bussiness'] = $scope.getktyw();
        message['desc'] = $scope.gtdesc;//描述
        message['planmoney'] = $scope.fwyjtrzj;//预计投入资金

        message['assetopenflaggentou'] = $scope.assetopenflaggentou;
        message['clearpositionopenflaggentou'] = $scope.clearpositionopenflaggentou;
        message['positionamountopenflaggentou'] = $scope.positionamountopenflaggentou;
        message['positionvarietyopenflaggentou'] = $scope.positionvarietyopenflaggentou;
        message['tradecommandopenflaggentou'] = $scope.tradecommandopenflaggentou;
        message['assetopenflagall'] = $scope.assetopenflagall;
        message['clearpositionopenflagall'] = $scope.clearpositionopenflagall;
        message['positionamountopenflagall'] = $scope.positionamountopenflagall;
        message['positionvarietyopenflagall'] = $scope.positionvarietyopenflagall;
        message['tradecommandopenflagall'] = $scope.tradecommandopenflagall;

        //console.log("发布跟投",message);
        ajaxService.sendMessage("sunflower.p_addproduct", message, $scope.p_addproductCallBack);
    }

    $scope.p_addproductCallBack = function(_data)
    {
        //console.log("发布",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.fouthErrorInfo = "";
            $scope.gotofinished();
        }
        else
        {
            $scope.fouthErrorInfo = "发布跟投失败，原因：" + _data.op.info;
        }
        $scope.addMark = true;

    }

    //进入完成提示界面
    $scope.gotofinished = function()
    {
        $scope.fbfourthShow = false;
        $scope.fbfiveShow = true;
    }

    //针对大众的设置
    $scope.cpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflagall = $scope.sztrueValue($scope.assetopenflagall);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflagall = $scope.sztrueValue($scope.positionvarietyopenflagall);
            if($scope.positionvarietyopenflagall == "N")
            {
                $scope.positionamountopenflagall = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflagall == "Y")
            {
                $scope.positionamountopenflagall = $scope.sztrueValue($scope.positionamountopenflagall);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflagall = $scope.sztrueValue($scope.clearpositionopenflagall);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflagall = $scope.sztrueValue($scope.tradecommandopenflagall);
        }
    }

    //针对跟投者的设置
    $scope.gtzcpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflaggentou = $scope.sztrueValue($scope.assetopenflaggentou);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflaggentou = $scope.sztrueValue($scope.positionvarietyopenflaggentou);
            if($scope.positionvarietyopenflaggentou == "N")
            {
                $scope.positionamountopenflaggentou = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflaggentou == "Y")
            {
                $scope.positionamountopenflaggentou = $scope.sztrueValue($scope.positionamountopenflaggentou);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflaggentou = $scope.sztrueValue($scope.clearpositionopenflaggentou);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflaggentou = $scope.sztrueValue($scope.tradecommandopenflaggentou);
        }
    }

    $scope.sztrueValue = function(_str)
    {
        var str ="";
        if(_str == "Y")
        {
            str = "N";
        }
        else
        {
            str = "Y";
        }
        return str;
    }


    $scope.backtoP = function()
    {
        $scope.fbgtBackto();
    }

    $scope.fbgtBackto = function()
    {
        //window.location = getParameter("backurl");
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    //查看分成方式
    $scope.gotofcfs = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //分成方式
    $scope.getfcfsvalue = function()
    {
        var str = "";
        //console.log($scope.fcfsArray.length);
        for(var i = 0;i<$scope.fcfsArray.length;i++)
        {
            //if($scope.mbsy)
            if(i == 0)
            {
                if($scope.fcfsArray[i].type == "A")
                {
                    str = $scope.fcfsArray[i].targetprofit+"|" + $scope.fcfsArray[i].share;
                }
                else if($scope.fcfsArray[i].type == "B")
                {
                    str = $scope.mbsy+"|" + $scope.fcfsArray[i].share;
                }
            }
            else
            {
                if($scope.fcfsArray[i].type == "A")
                {
                    str = str + "," + $scope.fcfsArray[i].targetprofit+"|" + $scope.fcfsArray[i].share;
                }
                else if($scope.fcfsArray[i].type == "B")
                {
                    str = str + "," +  $scope.mbsy+"|" + $scope.fcfsArray[i].share;
                }
            }
        }
        //console.log("分成方式",str);
        return str;
    }

    //分成方式
    $scope.getfcfsvalue2 = function()
    {
        var str = "";
        if($scope.fcfs.type == "A")
        {
            str = $scope.fcfs.targetprofit+"|" + $scope.fcfs.share;
        }
        else if($scope.fcfs.type == "B")
        {
            str = $scope.mbsy+"|" + $scope.fcfs.share;
        }
        return str;
    }

    $scope.getktyw = function()
    {
        var str = "";
        if($scope.hscheck)
        {
            str = "A";
        }
        if($scope.cybcheck)
        {
            if(str == "")
            {
                str = "C";
            }
            else
            {
                str = str + ",C";
            }
        }
        if($scope.ggtcheck)
        {
            if(str == "")
            {
                str = "H";
            }
            else
            {
                str = str + ",H";
            }
        }
        return str;
    }

    $scope.getDateFull = function(_str)
    {
        //console.log("日期",_str);
        var yyyy = _str.getFullYear();
        //console.log("日期",yyyy);
        var mm = _str.getMonth() + 1;
        //console.log("日期",mm);
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        //console.log("日期",mm);
        var dd = _str.getDate();
        //console.log("日期",dd);
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }
        //console.log("日期",yyyy , mm , dd);
        return yyyy + "" + mm + "" + dd;
    }
}



