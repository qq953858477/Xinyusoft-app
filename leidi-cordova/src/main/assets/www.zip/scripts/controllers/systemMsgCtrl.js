﻿//var sqScope = null;
/**
 * 控制器
 */

	
function systemMsgCtrl($scope, ajaxService, $cookieStore,$sce) {
    //sqScope = $scope;
    $scope.userObj = {};//当前用户信息
    $scope.userName = "";//当前用户的名称
    $scope.onePersonName = "";//朋友名称
    $scope.onePersonID = "";//朋友id
    $scope.onePersoniulr = "images/ico02_1.png";//朋友头像
    $scope.currentUserid = "";//当前用户id
    $scope.currentiulr = "images/ico02_1.png";//当前用户头像
    $scope.gchatList = [];//聊天记录
	$scope.gandfArray = [];//群成员列表
	//alert(angular.toJson($scope.gchatList));
    $scope.mainShow = true;//主显示对象
    $scope.ws;
    $scope.chartMessage = "";//需发送的信息
    $scope.chartListArray =[];//聊天信息
    $scope.lastmsgreadID = "0";//最后读取消息的编号，0则表示未读取过
    $scope.newmsgcount = "5";//未读消息获取的条数
        //$scope.hisinfoClickShow = false;//是否显示可点击获取历史消息，$scope.lastmsgreadID大于0或者totalBefore大于0
    var wsjson = mywsConfig;
	var recordnum = 10;//查询的记录条数每次自增20
	var selectid = "";
	var lastrecord = "";
	var msgnum = 0;//页面上应显示的消息数量
	var pull = false;//判断是否触发下拉事件
	var oncenum = 0;//单次查询的数量(若用户数据少于10条即查询对应条数)
	//alert(angular.toJson(wsjson));
    $scope.websocketurl = wsjson.url;
    $scope.channelID = wsjson.channelID;
    $scope.topic= wsjson.topic;
	$scope.pic = "images/user01.png";
    $scope.onePersonName = decodeURI(getParameter("name"));
    $scope.onePersonID = getParameter("id");
	$scope.lastmsgreadID = "";
	$scope.newmsgcount = "";
	//alert($scope.onePersonID);

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
    $scope.currentiulr = decodeURIComponent(localStorage.getItem('iconurl'));
    $scope.currentUserid = $scope.userObj.f_id;
    $scope.onePersoniulr = decodeURIComponent(getParameter("headurl"));
    //$scope.lastmsgreadID = getParameter("lastmsgid");
    //$scope.newmsgcount = getParameter("newmsgcount");
	$scope.newmsg = [];
	$scope.type = getParameter("type");
	if($scope.type == "group"){
		$scope.group_id = getParameter("groupid");
		$scope.group_name = decodeURI(getParameter("groupname"));
		$scope.master_id = getParameter("masterid");
		//alert(getParameter("masterid"));
		$scope.onePersonName = $scope.group_name;
		$scope.onePersonID = $scope.group_id;
		//alert($scope.onePersonID);
		$scope.pic = "images/peoples.png";
		
		//alert("groupid="+$scope.group_id);
		//alert("groupname="+$scope.group_name);
		//alert("masterid="+$scope.master_id);
	}
	var selectid = $scope.onePersonID;//聊天对象的id,用于sql查询
	//获取好友列表//上次最后一次读取的位置id
    $scope.getFriends = function()
    {
		//alert("getfriend");
		if($scope.type == "group"){
			//alert("group");
			var message = {};
			message['userid'] = $scope.currentUserid;
			message['friendid'] = $scope.group_id;
			message['subjecttype'] = "groupTalk";
			message['subjectid'] = $scope.group_id;
			//alert(angular.toJson(message));
			//ajaxService.sendMessage("user.GetLastMsgRead", message, $scope.getgroupAllInfoCallBack);
		}else{
			var message = {};
			message['user.id'] = $scope.userObj.f_id;
			message['friendinfo'] = "Y";
			ajaxService.sendMessage("user.selectfriendinfo", message, $scope.getfriendAllInfoCallBack) ;
		}
        
	}
	
	//获取好友信息回调函数
	$scope.getfriendAllInfoCallBack = function(_data)
    {
		//alert(angular.toJson(_data));
        if(_data.op.code.toString() == "Y")
        {	
			//alert(_data.op);
            var element = _data.friendlist;
				for (var item in element)
				{ 
					//alert(element[item]['f_friend_id']);
					//alert($scope.onePersonID);
					if(element[item]['f_friend_id']==$scope.onePersonID){
						$scope.newmsgcount = element[item]['newmsgcount'];//有多少未读消息
						$scope.lastmsgreadID =  element[item]['lastmsgid'];//已经读过的消息位置  
						//alert($scope.lastmsgreadID+"and"+$scope.newmsgcount);
						$scope.init();
					}	
				}
        }

    }
	//获取群组信息回调函数
	$scope.getgroupAllInfoCallBack = function(_data)
    {
		//alert(angular.toJson(_data));
        if(_data.op.code.toString() == "Y")
        {
			$scope.newmsgcount = _data.newmsgcount;//有多少未读消息
			$scope.lastmsgreadID =  _data.lastmsgid;//已经读过的消息位置  
			//alert($scope.lastmsgreadID+"and"+$scope.newmsgcount);
			$scope.init();
        }
    }

    $scope.getTimesql = function(time)
    {
        return isshowTime(time);
    }
	$scope.getTime = function(_str)
    {
        var str2 = "";
        if($scope.gchatList.length>0)
        {
            //console.log($scope.gchatList[$scope.gchatList.length-1].t);
            str2 = $scope.gchatList[$scope.gchatList.length-1].t;
        }
        else
        {
            str2 = "20150601010101";
        }
        return showTimeFun(str2, _str);
    }
    //Div显示底部
    $scope.setScrollHeight = function()
    {
        var chartD = document.getElementById('chartDiv');
        chartD.scrollTop = chartD.scrollHeight;
        //console.log(chartD.scrollTop, chartD.scrollHeight);
    }

    //创建连接，准备接收推送消息
    $scope.receiveMessage = function()
    {
        //聊天
        //$scope.ws = webSocketReq(function(event){console.log("linkapply", event.toString())},null,"1","ws://121.40.177.191:8871", channelID);		//ws://10.29.226.22:8888 ws://121.40.177.191:8881
        //微信
        console.log($scope.websocketurl, $scope.channelID, $scope.topic);
        if($scope.websocketurl != "" && $scope.channelID != "" && $scope.topic != "")
        {	if($scope.type =="group"){
				//alert(1);
				$scope.topic = $scope.group_id;
				$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.currentUserid, $scope.websocketurl, $scope.channelID, $scope.topic);
			}else{
				$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.currentUserid, $scope.websocketurl, $scope.channelID, $scope.topic);
			}
            
        }

        //app
        //$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.currentUserid,"ws://127.0.0.1:6688", channelID, topic);
    }

    //聊天
    $scope.chatonMessage = function(event)
    {
        $scope.$apply($scope.chatonMessagedeal(event));
    }

    $scope.chatonMessagedeal = function(event)
    {
        //console.log(event.data);
        var _data = JSON.parse(event.data);
        console.log("聊天信息推送", _data);
        if(_data != null)
        {
            //console.log("_data.type", _data.type);
			if($scope.type == "group"){
				//alert(_data.topic)
				if(_data.topic.toString() == $scope.group_id)
				{
					if(_data.type == "text")
					{
						var obj = {};
						obj.u  = _data.f.toString();//发送方
						obj.c = _data.content.toString();//内容
						obj.t = _data.t.toString();
						obj.showTime = $scope.getTime(obj.t);
						obj.isshow = true;
						if(obj.showTime == null || obj.showTime == "")
						{
							obj.isshow = false;
						}
						obj.i = $scope.onePersonID;
						obj.lastmsgid = _data.i.toString();//当前位置
						for(var i=0;i<$scope.gandfArray.length;i++){
							if($scope.gandfArray[i].id==obj.u){
								obj.f_head = $scope.gandfArray[i].iconUrl;
							}
						}
						//obj.f_head = $scope.onePersoniulr;
						obj.type = "1";
						if(obj.u != $scope.currentUserid){
							$scope.gchatList.push(obj);
							//myScroll.scrollTo(0, -81, 100);
							//alert("insert1");
							//alert(obj.lastmsgid);
							insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,obj.lastmsgid);
							//select();
							chatrecord = [];
						}
					}
				   
					$scope.sendReceipt($scope.gchatList[$scope.gchatList.length-1].lastmsgid);//发送回执，表示收到信息
				}
			}else
            if(_data.f.toString() == $scope.onePersonID && _data.r.toString() == $scope.currentUserid)
            {
                if(_data.type == "text")
                {
                    var obj = {};
                    obj.u  = _data.f.toString();//发送方
                    obj.c = _data.content.toString();//内容
                    obj.t = _data.t.toString();
                    obj.showTime = $scope.getTime(obj.t);
                    obj.isshow = true;
                    if(obj.showTime == null || obj.showTime == "")
                    {
                        obj.isshow = false;
                    }
                    obj.i = _data.r.toString();//接收方
                    obj.lastmsgid = _data.i.toString();//当前位置
                    obj.f_head = $scope.onePersoniulr;
                    obj.type = "1";
                    $scope.gchatList.push(obj);
					//alert("insert1");
					insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,obj.lastmsgid);
					//select();
					chatrecord = [];
                }
               
                $scope.sendReceipt($scope.gchatList[$scope.gchatList.length-1].lastmsgid);//发送回执，表示收到信息
            }
            //Div显示底部
            //$scope.setScrollHeight();
        }
    }

    //发送回执
    $scope.sendReceipt = function(_lastmsgid)
    {
        $scope.lastmsgreadID = _lastmsgid;
        console.log("回执", $scope.lastmsgreadID);
        var message = {};
        message['lastmsgid'] = _lastmsgid;//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = "";//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
		if($scope.type=="group"){
			message['friendid'] = $scope.group_id;
		}else{
			message['friendid'] = $scope.onePersonID;
		}
        message['subjecttype'] = "friendTalk";
        message['subjectid'] ="";
        message['msgamount'] = "1";//查询条数
        console.log($scope.lastmsgreadID, $scope.currentUserid);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.sendReceiptCallBack);
    }

    //回执返回
    $scope.sendReceiptCallBack = function(_data)
    {

    }


    $scope.getUnreadInfoCallBack = function(_data)
    {
		//alert("unread="+angular.toJson(_data));
        //console.log("未读取的信息", _data);
		if($scope.type == "group"){
			if(_data.op.code.toString() == "Y")
			{	
				var arr = _data.msglist;
				for (var i = 0; i < arr.length; i++) {
					var obj = {};
					if(arr[i].type == "text")
					{
						obj.u = arr[i].f.toString();//发送方
						obj.i = $scope.onePersonID;//接收方
						obj.c = arr[i].content.toString();//内容
						obj.t = arr[i].t.toString();
						obj.lastmsgid = arr[i].i.toString();//当前位置
						if (obj.u == $scope.currentUserid) {
							obj.f_head = $scope.currentiulr;
						}
						else {
							for(var i=0;i<$scope.gandfArray.length;i++){
								if($scope.gandfArray[i].id==obj.u){
									obj.f_head = $scope.gandfArray[i].iconUrl;
								}
							}	
						}
						obj.type = "1";
						//$scope.gchatList.push(obj);
						//insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type);
						//alert("kaishi");
						count();
						select(selectid);
						lasttime(obj);
					}
				}

				for (var i = 0; i < $scope.gchatList.length; i++) {
					var _str = "";
					var _str2 = "";
					if (i == 0) {
						_str2 = "201506010101";
					}
					else {
						_str2 = $scope.gchatList[i - 1].t;
					}
					_str = $scope.gchatList[i].t;
					$scope.gchatList[i].showTime = showTimeFun(_str2, _str);
					$scope.gchatList[i].isshow = true;
					if ($scope.gchatList[i].showTime == null || $scope.gchatList[i].showTime == "") {
						$scope.gchatList[i].isshow = false;
					}
				}

				$scope.lastmsgreadID = (parseInt($scope.lastmsgreadID) + arr.length-1).toString();//位置变动到读取完成的地方

				//Div显示底部
				//$scope.setScrollHeight();

			}
		}else
        if(_data.op.code.toString() == "Y")
        {	
            var arr = _data.msglist;
            for (var i = 0; i < arr.length; i++) {
                var obj = {};
                if(arr[i].type == "text")
                {
                    obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    obj.t = arr[i].t.toString();
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                    }
                    obj.type = "1";
                    //$scope.gchatList.push(obj);
					//insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type);
					//alert("kaishi");
					count();
					select(selectid);
					lasttime(obj);
                }
            }

            for (var i = 0; i < $scope.gchatList.length; i++) {
                var _str = "";
                var _str2 = "";
                if (i == 0) {
                    _str2 = "201506010101";
                }
                else {
                    _str2 = $scope.gchatList[i - 1].t;
                }
                _str = $scope.gchatList[i].t;
                $scope.gchatList[i].showTime = showTimeFun(_str2, _str);
                $scope.gchatList[i].isshow = true;
                if ($scope.gchatList[i].showTime == null || $scope.gchatList[i].showTime == "") {
                    $scope.gchatList[i].isshow = false;
                }
            }

            $scope.lastmsgreadID = (parseInt($scope.lastmsgreadID) + arr.length-1).toString();//位置变动到读取完成的地方

            //Div显示底部
            //$scope.setScrollHeight();

        }
        //侦听推送
        $scope.receiveMessage();
    }

    //获取未读取的信息
    $scope.getUnreadInfo = function()
    {
        //$scope.receiveMessage();
        var message = {};
        message['lastmsgid'] = $scope.lastmsgreadID;//(parseInt($scope.lastmsgreadID)+1).toString();//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = "";//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
        if($scope.type=="group"){
			message['friendid'] = $scope.group_id;
			message['subjecttype'] = "groupTalk";
			message['subjectid'] = $scope.group_id;
		}else{
			message['friendid'] = $scope.onePersonID;
			message['subjecttype'] = "friendTalk";
			message['subjectid'] ="";
		}
        message['msgamount'] = "";//$scope.newmsgcount;//查询条数
        console.log($scope.lastmsgreadID, $scope.currentUserid);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.getUnreadInfoCallBack);
    }


    $scope.init = function()
    {
        //获取未读取的信息
        $scope.getUnreadInfo();
    }
	//获取当前好友的最后消息id
	//$scope.getFriends();

    //返回列表界面
    $scope.onePersonbackto = function()
    {	
		//if($scope.type=="group"){
		//	window.location = "gtbBase.html";
		//}else{
		//	window.location = "myGroupBase.html";
		//}
        window.location = getbackList();
        
    }
    //点击不显示手机弹出的键盘
    $scope.closePopClick = function(){
        //console.log("545");
		//alert(1);
		document.getElementById("bkclose").blur();
        //if($scope.moreBtnAreaShow)
        //{	
         //   $scope.moreBtnAreaClick();
        //}

    };
	
	//sqlite
	var chatrecord = [];
	function insert(send, receive, context, time, f_head, type, lastmsgid) {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS system (send integer , receive integer, context text, time text, f_head text, type text, lastmsgid text)");
					log("插入数据")
					tx.executeSql(
							"INSERT INTO system (send, receive, context, time, f_head, type, lastmsgid) VALUES (?,?,?,?,?,?,?)",
							[send, receive, context, time, f_head, type,lastmsgid],function(tx,res){
								//myScroll.scrollTo(0, -50, 100);
								//alert("插入成功");
								msgnum = msgnum+1;
								myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
							});
				})	
	}
	//数据总数
	function count() {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
			db.transaction(function(tx) {
				tx.executeSql("CREATE TABLE IF NOT EXISTS system (send integer , receive integer, context text, time text, f_head text, type text, lastmsgid text)");
				tx.executeSql("SELECT rowid,time FROM system where send = "+selectid+" or receive = "+selectid,[],
					function(tx,res){
						//alert(10000);
						//alert("res.rows.length=="+res.rows.length);
						if(res.rows.length<10){
							recordnum = 0;
							msgnum = res.rows.length;
							oncenum = res.rows.length;
						}else{
							recordnum = res.rows.length-10;	
							msgnum = 10;
							oncenum = 10;
						}
						chatrecord = [];
						//alert("num="+recordnum);
					});
			})
	}
	//就算最后一条记录的id
	function lasttime(param) {
		//alert(angular.toJson(param));
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
			db.transaction(function(tx) {
				tx.executeSql("SELECT rowid,lastmsgid FROM system where send = "+selectid+" or receive = "+selectid+" order by rowid desc LIMIT 1",[],
					function(tx,res){
						//alert(10000);
						//alert(2);
						if(res.rows.length!=0){
							lastrecord = res.rows.item(0).lastmsgid;
							//alert("lastrecord="+lastrecord);
							//alert(param.lastmsgid);
							if(Number(param.lastmsgid) != Number(lastrecord)){
								//alert("id不同");
								insert(param.u, param.i, param.c, param.t, param.f_head, param.type, param.lastmsgid);
								$scope.newmsg.push(param);
								//alert(angular.toJson($scope.newmsg));
								//alert($scope.gchatList);
								if($scope.newmsgcount == 0){
									for(var i=0;i<$scope.newmsg.length;i++){
										$scope.gchatList.push($scope.newmsg[i]);
										$scope.$apply();
									}
								}
							}
						}else{
							insert(param.u, param.i, param.c, param.t, param.f_head, param.type, param.lastmsgid);
							$scope.gchatList.push(param);
						}
						//alert("num="+recordnum);
						myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
					});
			})
		return lastrecord;
	}
	//查询数据
	function select(selectid){
		//alert("selectid"+selectid);
		log("打开数据库");
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
			});
			//alert(2);
			db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM (SELECT rowid,send,receive,context,time,f_head,type FROM system where send = "+selectid+" or receive = "+selectid+") LIMIT "+recordnum+","+oncenum, [],
							function(tx, res) {
								for(var i = res.rows.length-1;i>=0;i--){
									var obj1 = {};
									obj1.u  = res.rows.item(i).send;//发送方
									obj1.c = res.rows.item(i).context;//内容
									obj1.t = res.rows.item(i).time;	
									obj1.i = res.rows.item(i).receive;//接收方
									obj1.f_head = res.rows.item(i).f_head;
									obj1.type = res.rows.item(i).type;
									if(i==0){
										obj1.isshow = true;
										obj1.showTime = $scope.getTimesql(res.rows.item(i).time);
									}else
										if(i>0&&res.rows.item(i).time-res.rows.item(i-1).time>500){
											obj1.isshow = true;
											//alert(res.rows.item(i).time);
											obj1.showTime = $scope.getTimesql(res.rows.item(i).time);
										}
									chatrecord.unshift(obj1);	
								}	
								//alert(angular.toJson(chatrecord));
								//alert("count="+$scope.newmsgcount)
								if($scope.newmsgcount == 0){
									//alert("success");
									$scope.gchatList = chatrecord;
									$scope.$apply();
								}
								if($scope.newmsgcount>0){
									$scope.newmsgcount = $scope.newmsgcount-1;
								}
								if(pull){
									if(msgnum<10){
										myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
									}else{
										myScroll.scrollToElement('div:nth-child(10)', 100);
									}
								}
								if($scope.type=="group"&&pull==false){
									if(msgnum<10){
										myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
									}else{
										myScroll.scrollToElement('div:nth-child(10)', 100);
									}
								}
							});
			})
			
	}

		
		//时间处理
	function isshowTime(pretime)
	{
		//数据库中须处理的时间
		preyear = pretime.substring(0,4);
		premouth = pretime.substring(4,6)-1;
		preday = pretime.substring(6,8);
		prehour = pretime.substring(8,10);
		premin = pretime.substring(10,12);
		presec = pretime.substring(12,14);
		var predate = new Date(preyear,premouth,preday,prehour,premin,presec);
		//当前时间
		var nowtime = new Date();
		var curmouth = nowtime.getMonth();
		var curday = nowtime.getDate();
		var curyear = nowtime.getFullYear();
		var curhour = nowtime.getHours();
		var curmin = nowtime.getMinutes();
		var cursec = nowtime.getSeconds();
		
		if(preyear==curyear&&premouth==curmouth&&preday==curday){
			return prehour+":"+premin;
		}else
			if(preyear==curyear&&premouth==curmouth&&(curday-preday)==1){
				return "昨天"+" "+prehour+":"+premin;
			}else
				if((nowtime.getTime()-predate.getTime())-(7 * 24 * 3600 * 1000)<0){
					var day = predate.getDay();
					if(day == 0){
						return "星期天"+" "+prehour+":"+premin;
					}
					if(day == 1){
						return "星期一"+" "+prehour+":"+premin;
					}
					if(day == 2){
						return "星期二"+" "+prehour+":"+premin;
					}
					if(day == 3){
						return "星期三"+" "+prehour+":"+premin;
					}
					if(day == 4){
						return "星期四"+" "+prehour+":"+premin;
					}
					if(day == 5){
						return "星期五"+" "+prehour+":"+premin;
					}
					if(day == 6){
						return "星期六"+" "+prehour+":"+premin;
					}
				}else{
					return preyear+"年"+(premouth+1)+"月"+preday+"日"+" "+prehour+":"+premin;
				}
				
	}
}

