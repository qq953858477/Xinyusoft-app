/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function trade_setzhCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.account = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.homeDivShow = true;//主界面信息
    $scope.deviceid = "";//设备号
    $scope.dzgkcheck = false;//是否大众公开
    $scope.firstszShow = false;//账户公开第一步
    $scope.secondseShow = false;//账户公开第二步
    $scope.firstErrorInfo = "";//第一步提示
    $scope.lastErrorInfo = "";
    $scope.finisheddivShow = false;//最后结束的界面

    $scope.settype = "";//1:初始公开操作，2：修改
    $scope.productid = "";//产品id
    //$scope.firstcanclick = false;//第一步能点击

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.gtname = "";//服务名称
    $scope.gtdesc = "";//理财计划
    $scope.gtminmoney = "";//最小跟投金额
    $scope.addMark = true;

    $scope.assetopenflaggentou = "Y";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "Y";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "Y";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "Y";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "Y";//对跟投者，交易指令公开

    $scope.assetopenflagall = "Y"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "Y";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "Y"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "Y";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "Y";//对大众，交易指令公开


    var localStorage = window.localStorage;
    //$scope.sessionID = localStorage.getItem('sessionid');
    $scope.account = localStorage.getItem('account');
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.accountzqgs = decodeURIComponent(localStorage.getItem('accountName'));
    $scope.accountShowValue = localStorage.getItem('accountShow');//界面显示用
    //alert("设备号   " + localStorage.getItem("deviceid"));
    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid") != undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }
    //alert("设备号   "+ $scope.deviceid);

    $scope.accountcompany = localStorage.getItem('accountcompany');//证券公司
    $scope.lcsstatus = localStorage.getItem("lcsstatus");

    $scope.settype = getParameter('type');
    $scope.productid = getParameter('productid');

    $scope.szintervalDuration = 1500;//间隔时间，8000毫秒
    $scope.szintervalId;

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflaggentou = _data.assetopenflaggentou.toString();
            $scope.clearpositionopenflaggentou = _data.clearpositionopenflaggentou.toString();
            $scope.positionamountopenflaggentou = _data.positionamountopenflaggentou.toString();
            $scope.positionvarietyopenflaggentou = _data.positionvarietyopenflaggentou.toString();
            $scope.tradecommandopenflaggentou = _data.tradecommandopenflaggentou.toString();

            $scope.assetopenflagall = _data.assetopenflagall.toString();
            $scope.clearpositionopenflagall = _data.clearpositionopenflagall.toString();
            $scope.positionamountopenflagall = _data.positionamountopenflagall.toString();
            $scope.positionvarietyopenflagall = _data.positionvarietyopenflagall.toString();
            $scope.tradecommandopenflagall = _data.tradecommandopenflagall.toString();

        }
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    $scope.zhsetinit = function()
    {
        if($scope.settype == '1')
        {
            $scope.firstszShow = true;
            $scope.secondseShow = false;
            $scope.firstErrorInfo = "";
            //$scope.firstcanclick = false;
        }
        else
        {
            $scope.getcpsz();
        }
    }

    $scope.zhsetinit();

    //第二步
    $scope.gotosecond = function()
    {
        if($scope.gtname == "")
        {
            $scope.firstErrorInfo = "请先输入服务名称";
            return;
        }
        if($scope.gtname.length >8)
        {
            $scope.firstErrorInfo = "服务名称不超过8个字，请重新输入";
            return;
        }
        if($scope.gtminmoney == "")
        {
            $scope.firstErrorInfo = "请输入最小跟投金额";
            return;
        }
        if(valueCheck($scope.gtminmoney) == false)
        {
            $scope.firstErrorInfo = "最小跟投金额含有特殊字符，请输入有效值";
            return;
        }
        if($scope.hscheck == false && $scope.cybcheck == false &&  $scope.ggtcheck == false)
        {
            $scope.firstErrorInfo = "请选择需开通的业务";
            return;
        }
        $scope.firstErrorInfo = "";
        $scope.lastErrorInfo = "";
        $scope.firstszShow = false;//账户公开第一步
        $scope.secondseShow = true;//账户公开第二步
    }

    //大众公开设置
    $scope.dzgkcheckClick = function()
    {
        $scope.dzgkcheck = !$scope.dzgkcheck;
    }

    //返回第一步
    $scope.backtoproClick = function()
    {
        $scope.firstszShow = true;//账户公开第一步
        $scope.secondseShow = false;//账户公开第二步
    }

    //确定
    $scope.gotolastClick = function()
    {
        if($scope.addMark)
        {
            $scope.lastErrorInfo = "账户公开设置中，请稍候...";
            $scope.addMark = false;
            var message = {};
            message['account'] = $scope.account;
            message['userid'] = $scope.userObj.f_id;
            message['name'] = $scope.gtname;
            message['minmoney'] = $scope.gtminmoney;
            if($scope.dzgkcheck)
            {
                message['property'] = "public";
            }
            else
            {
                message['property'] = "private";
            }
            message['desc'] = $scope.gtdesc;//描述
            message['bussiness'] = $scope.getktyw();
            message['assetopenflaggentou'] = $scope.assetopenflaggentou;
            message['clearpositionopenflaggentou'] = $scope.clearpositionopenflaggentou;
            message['positionamountopenflaggentou'] = $scope.positionamountopenflaggentou;
            message['positionvarietyopenflaggentou'] = $scope.positionvarietyopenflaggentou;
            message['tradecommandopenflaggentou'] = $scope.tradecommandopenflaggentou;
            message['assetopenflagall'] = $scope.assetopenflagall;
            message['clearpositionopenflagall'] = $scope.clearpositionopenflagall;
            message['positionamountopenflagall'] = $scope.positionamountopenflagall;
            message['positionvarietyopenflagall'] = $scope.positionvarietyopenflagall;
            message['tradecommandopenflagall'] = $scope.tradecommandopenflagall;

            //console.log("发布跟投",message);
            //$scope.gotofinished();
            ajaxService.sendMessage("sunflower.p_addproduct", message, $scope.p_addproductCallBack);
        }
    }

    $scope.p_addproductCallBack = function(_data)
    {
        //console.log("发布",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.lastErrorInfo = "";
            $scope.gotofinished();
        }
        else
        {
            $scope.lastErrorInfo = "账户公开设置失败，原因：" + _data.op.info;
        }
        $scope.addMark = true;

    }

    //进入完成提示界面
    $scope.gotofinished = function()
    {
        $scope.secondseShow = false;
        $scope.finisheddivShow = true;
    }

    //服务设置修改
    $scope.szchange = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        message['userid'] = $scope.userObj.f_id;
        message['assetopenflaggentou'] = $scope.assetopenflaggentou;
        message['clearpositionopenflaggentou'] = $scope.clearpositionopenflaggentou;
        message['positionamountopenflaggentou'] = $scope.positionamountopenflaggentou;
        message['positionvarietyopenflaggentou'] = $scope.positionvarietyopenflaggentou;
        message['tradecommandopenflaggentou'] = $scope.tradecommandopenflaggentou;
        message['assetopenflagall'] = $scope.assetopenflagall;
        message['clearpositionopenflagall'] = $scope.clearpositionopenflagall;
        message['positionamountopenflagall'] = $scope.positionamountopenflagall;
        message['positionvarietyopenflagall'] = $scope.positionvarietyopenflagall;
        message['tradecommandopenflagall'] = $scope.tradecommandopenflagall;
        ajaxService.sendMessage("sunflower.p_setproductsetting", message, $scope.cpItemszCallBack);
    }

    $scope.cpItemszCallBack = function(_data)
    {
        //console.log("设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getcpsz();
            myMsg("设置成功");
            $scope.szintervalId = setInterval($scope.szover, $scope.szintervalDuration);
        }
        else
        {
            myAlert("设置失败");
        }
    }

    $scope.szover = function()
    {
        if ($scope.szintervalId != undefined) {
            clearInterval($scope.szintervalId);
        }
        try{
            layer.closeAll();
        }
        catch (e){}
    }
    //针对大众的设置
    $scope.cpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflagall = $scope.sztrueValue($scope.assetopenflagall);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflagall = $scope.sztrueValue($scope.positionvarietyopenflagall);
            if($scope.positionvarietyopenflagall == "N")
            {
                $scope.positionamountopenflagall = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflagall == "Y")
            {
                $scope.positionamountopenflagall = $scope.sztrueValue($scope.positionamountopenflagall);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflagall = $scope.sztrueValue($scope.clearpositionopenflagall);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflagall = $scope.sztrueValue($scope.tradecommandopenflagall);
        }
    }

    //针对跟投者的设置
    $scope.gtzcpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflaggentou = $scope.sztrueValue($scope.assetopenflaggentou);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflaggentou = $scope.sztrueValue($scope.positionvarietyopenflaggentou);
            if($scope.positionvarietyopenflaggentou == "N")
            {
                $scope.positionamountopenflaggentou = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflaggentou == "Y")
            {
                $scope.positionamountopenflaggentou = $scope.sztrueValue($scope.positionamountopenflaggentou);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflaggentou = $scope.sztrueValue($scope.clearpositionopenflaggentou);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflaggentou = $scope.sztrueValue($scope.tradecommandopenflaggentou);
        }
    }

    //沪深
    $scope.hscheckClick = function()
    {
        $scope.hscheck = !$scope.hscheck;
    }
    //创业板
    $scope.cybcheckClick = function()
    {
        $scope.cybcheck = !$scope.cybcheck;
    }
    //港股通
    $scope.ggtcheckClick = function()
    {
        $scope.ggtcheck = !$scope.ggtcheck;
    }

    $scope.sztrueValue = function(_str)
    {
        var str ="";
        if(_str == "Y")
        {
            str = "N";
        }
        else
        {
            str = "Y";
        }
        return str;
    }

    $scope.getktyw = function()
    {
        var str = "";
        if($scope.hscheck)
        {
            str = "A";
        }
        if($scope.cybcheck)
        {
            if(str == "")
            {
                str = "C";
            }
            else
            {
                str = str + ",C";
            }
        }
        if($scope.ggtcheck)
        {
            if(str == "")
            {
                str = "H";
            }
            else
            {
                str = str + ",H";
            }
        }
        return str;
    }

    //返回
    $scope.gkszbackto = function()
    {

        if($scope.settype == "1")
        {
            if($scope.finisheddivShow)//已经完成公开设置
            {
                window.location.href = "tradeBase_bgt.html";
            }
            else
            {
                window.location.href = "tradeBase_wgt.html";
            }
        }
        else
        {
            window.location.href = getbackList();
        }

    }

    $scope.backtoP = function()
    {
        $scope.gkszbackto();
    }
}




