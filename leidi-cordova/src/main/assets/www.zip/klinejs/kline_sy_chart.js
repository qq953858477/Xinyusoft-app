var KLineChart = (function () {
    function KLineChart(kLineArray, chartDom, fixedNumber) {
        // 矩形之间日期高度
        this.topjjheght = 40;//图形上方距离
        this.jxzjheight = 25;//下方日期显示区
        // 当前k线的宽度、位置索引、当前界面能显示的个数
        this.currKLineWidth = [5, 3, 0];
        // k线之间的距离
        this.kLineSpace = 2;
        // k线的宽度级别
        this.kLineWidthArray = [1, 3, 7, 9, 17, 27];
        // 当前显示的kline 0-开始索引，1-结束索引 倒叙的
        this.showKLines = [0, 0, []];
        //this.upcolor = 'RGB(240,75,91)';
        this.upcolor = '#EF9FA1';
        //this.downcolor = 'RGB(43,190,101)';
        this.downcolor = '#A2D8AD';
        this.MA5Color = 'RGB(255,193,50)';
        this.MA10Color = 'RGB(128,215,245)';
        this.MA20Color = 'RGB(252,95,200)';
        this.sylColor =  'RGB(46,107,177)';
        this.indexType = 'vol';
        this.kLineArray = kLineArray;
        this.chart = chartDom.getContext('2d');
        this.width = chartDom.width;
        this.height = chartDom.height;
        this.fixedNumber = fixedNumber;
        this.chartDom = chartDom;
        this.showKLines[0] = this.kLineArray.length - 1;
        //this.initCrossCanvas(this.chartDom);
    }

    var getPixelRatio = function(context) {
        var backingStore = context.backingStorePixelRatio ||
            context.webkitBackingStorePixelRatio ||
            context.mozBackingStorePixelRatio ||
            context.msBackingStorePixelRatio ||
            context.oBackingStorePixelRatio ||
            context.backingStorePixelRatio || 1;
        return (window.devicePixelRatio || 1) / backingStore;
    };

    scale = function(scalewidth,scaleheight){
        $(this).getContent().scale(scalewidth,scaleheight);
        return $(this);
    }

    KLineChart.prototype.initCrossCanvas = function (canvasDom) {
        var _this = this;
        var linecanvas = document.createElement("canvas");
        linecanvas.id = "linecanvas";
        linecanvas.width = canvasDom.width;
        linecanvas.height = canvasDom.height;
        linecanvas.style.zindex = "1";
        linecanvas.style.position = "relative";
        linecanvas.style.float = "left";
        linecanvas.style.left = "0px";
        linecanvas.style.top = -1 * canvasDom.height + "px";
        //canvasDom.parentNode.appendChild(linecanvas);
        var myline = linecanvas.getContext('2d');
        myline.lineWidth = 1;
        var dragFlag = false;
        var dragBeginX = 0;
        linecanvas.onmousemove = function (event) {
            myline.strokeStyle = "rgb(84,105,128)";
            myline.fillStyle = "rgb(84,105,128)";
            myline.globalAlpha = 1;
            //相对值
            var xdx = event.clientX - linecanvas.offsetLeft;
            var xdy = event.clientY - linecanvas.offsetTop;
            if (!_this.xMap[xdx]) {
                if (xdx > _this.showKLines[2][0].xBegin) {
                    xdx = _this.showKLines[2][0].xBegin;
                }
                else {
                    return;
                }
            }
            myline.clearRect(0, 0, linecanvas.width, linecanvas.height);
            //画十字光标
            myline.beginPath();
            // 横线
            chartMoveTo(_this.leftwidth, _this.xMap[xdx].y, myline);
            chartLineTo(_this.leftwidth + _this.jxwidth, _this.xMap[xdx].y, myline);
            myline.stroke();
            myline.closePath();
            myline.beginPath();
            chartMoveTo(_this.xMap[xdx].x, 0, myline);
            chartLineTo(_this.xMap[xdx].x, linecanvas.height, myline);
            myline.stroke();
            myline.closePath();
            // 画个小圆点
            myline.beginPath();
            chartMoveTo(_this.xMap[xdx].x, _this.xMap[xdx].y, myline);
            myline.arc(_this.xMap[xdx].x, _this.xMap[xdx].y, 3, 0, 2 * Math.PI);
            myline.fill();
            myline.closePath();
            // 价格信息描述
            // 画个小方块
            // 方块起始位置
            var volumedesc = "成交量  " + _this.xMap[xdx].vol;
            var fkheight = 170;
            var fkwidth = myline.measureText(volumedesc).width + 20;
            var highwidth = myline.measureText("最高价  " + _this.xMap[xdx].high.toFixed(_this.fixedNumber)).width + 20;
            fkwidth = Math.max(fkwidth, highwidth);
            var fky = _this.jxsbheight / 2 - fkheight / 2;
            var fkx = _this.leftwidth;
            var mid = _this.jxsbheight / 2;
            myline.textBaseline = "middle";
            if (_this.xMap[xdx].x <= (fkwidth + _this.leftwidth)) {
                // 画右边
                fkx = _this.width - fkwidth;
            }
            myline.beginPath();
            //chartMoveTo(fkx,fky,myline);
            myline.fillStyle = 'RGB(242,245,251)';
            myline.strokeStyle = 'RGB(220,228,234)';
            myline.globalAlpha = 0.9;
            myline.fillRect(fkx, fky, fkwidth, fkheight);
            myline.strokeRect(fkx, fky, fkwidth, fkheight);
            myline.closePath();

            // 文字
            myline.font = "12px";
            myline.fillStyle = '#000000';
            myline.fillText("" + _this.xMap[xdx].day1, fkx + 10, mid - 6 * fkheight / 15);
            myline.fillText("开盘价  " + _this.xMap[xdx].open.toFixed(_this.fixedNumber), fkx + 10, mid - 4 * fkheight / 15);
            myline.fillText("最高价  " + _this.xMap[xdx].high.toFixed(_this.fixedNumber), fkx + 10, mid - 2 * fkheight / 15);
            myline.fillText("最低价  " + _this.xMap[xdx].low.toFixed(_this.fixedNumber), fkx + 10, mid);
            myline.fillText("收盘价  " + _this.xMap[xdx].close.toFixed(_this.fixedNumber), fkx + 10, mid + 2 * fkheight / 15);
            myline.fillText(volumedesc, fkx + 10, mid + 4 * fkheight / 15);
            myline.fillText("涨跌幅  " + _this.xMap[xdx].zdf + "%", fkx + 10, mid + 6 * fkheight / 15);
            // 左上方均价
            //_this.drawMA(xdx, myline);
            // 拖动事件
            if (dragFlag) {
                var nowX = event.clientX - _this.chartDom.offsetLeft;
                if (Math.abs(nowX - dragBeginX) > _this.currKLineWidth[0]) {
                    // 需要变化的k线根数
                    var count = +(Math.abs(nowX - dragBeginX) / _this.currKLineWidth[0]).toFixed(0);
                    if (nowX - dragBeginX > 0) {
                        // 往右拖，显示左边的k线
                        if ((_this.showKLines[0] - count) < _this.currKLineWidth[2]) {
                            return;
                        }
                        _this.showKLines[0] = _this.showKLines[0] - count;
                    }
                    else {
                        // 往左托
                        if (_this.showKLines[0] + count >= _this.kLineArray.length - 1) {
                            return;
                        }
                        _this.showKLines[0] = _this.showKLines[0] + count;
                    }
                    _this.initCanShowKLines();
                    _this.drawKLine();
                    //_this.drawIndex();
                    dragBeginX = nowX;
                }
            }
        };
        linecanvas.onmouseout = function (event) {
            dragFlag = false;
            myline.clearRect(0, 0, linecanvas.width, linecanvas.height);
        };
        linecanvas.onmousedown = function (event) {
            dragFlag = true;
            dragBeginX = event.clientX - _this.chartDom.offsetLeft;
        };
        linecanvas.onmouseup = function (event) {
            dragFlag = false;
        };
    };
    KLineChart.prototype.drawMA = function (xdx, myline) {
        var ma5price = " MA5 " + this.xMap[xdx].MA5.toFixed(this.fixedNumber) + " ";
        var ma10price = " MA10 " + this.xMap[xdx].MA10.toFixed(this.fixedNumber) + " ";
        var ma20price = " MA20 " + this.xMap[xdx].MA20.toFixed(this.fixedNumber) + " ";
        myline.fillStyle = this.MA5Color;
        myline.beginPath();
        var ma5x = this.leftwidth + 17;
        myline.arc(ma5x, 8, 5, 0, 2 * Math.PI);
        myline.fill();
        myline.closePath();
        myline.fillText(ma5price, ma5x + 5, 9);
        var ma10x = ma5x + myline.measureText(ma5price).width + 15;
        myline.fillStyle = this.MA10Color;
        myline.beginPath();
        myline.arc(ma10x, 8, 5, 0, 2 * Math.PI);
        myline.fill();
        myline.closePath();
        myline.fillText(ma10price, ma10x + 5, 9);
        var ma20x = ma10x + myline.measureText(ma10price).width + 15;
        myline.fillStyle = this.MA20Color;
        myline.beginPath();
        myline.arc(ma20x, 8, 5, 0, 2 * Math.PI);
        myline.fill();
        myline.closePath();
        myline.fillText(ma20price, ma20x + 5, 9);
    };

    KLineChart.prototype.draw = function () {
        var ratio = getPixelRatio(this.chartDom);
        var cwidth = this.chartDom.width;
        //console.log("ratio", ratio);
        //console.log("width, height", this.chartDom.width, this.chartDom.height);
        this.chartDom.width = this.chartDom.width * ratio;
        this.chartDom.height = this.chartDom.height * ratio;
        this.chartDom.style.width= cwidth +"px";
        //console.log("cwidth", cwidth);
        //console.log("width, height", this.chartDom.width, this.chartDom.height);
        //console.log("this.chartDom.style.width", this.chartDom.style.width);
        this.chartDom.getContext("2d").scale(ratio, ratio);
        //console.log("this.chartDom.style.width", this.chartDom.style.width);
        this.build();
        this.initCanShowKLines();
        this.drawlegend();//图例
        this.drawKLine();

        //this.drawIndex();//成交量

    };
    //图例
    KLineChart.prototype.drawlegend = function () {

        this.chart.strokeStyle = "#2E6BB1";
        this.chart.font = "12px";
        this.chart.fillStyle = "#999";
        this.chart.lineWidth = 1;
        this.chart.moveTo(this.leftwidth, 15);
        this.chart.lineTo(this.leftwidth + 15, 15);
        this.chart.textAlign = "left";
        this.chart.textBaseline = "middle";
        this.chart.fillText("收益率" + "", this.leftwidth + 15 + 3, 15);
        this.chart.stroke();
        this.chart.closePath();

        //this.chart.strokeStyle = this.upcolor;
        //this.chart.fillStyle = "#999999";
        ////this.chart.lineWidth = 1;
        //this.chart.moveTo(100, 5);
        //this.chart.lineTo(100, 10);
        //this.chart.strokeRect(95, 10, 10, 10);
        //this.chart.moveTo(100, 5);
        //this.chart.lineTo(100, 10);
        //this.chart.lineTo(90, 20);
        this.chart.beginPath();
        this.chart.fillStyle = this.upcolor;
        this.chart.strokeStyle = this.upcolor;
        this.chart.fillRect(95, 10, 6, 10);
        this.chart.fillRect(98, 5, 1, 20);
        this.chart.stroke();
        this.chart.closePath();

        this.chart.beginPath();
        this.chart.fillStyle = this.downcolor;
        this.chart.strokeStyle = this.downcolor;
        this.chart.fillRect(105, 10, 6, 10);
        this.chart.fillRect(108, 5, 1, 20);
        this.chart.stroke();
        this.chart.closePath();

        this.chart.fillStyle = "#999999";
        this.chart.textAlign = "left";
        this.chart.textBaseline = "middle";
        this.chart.fillText("大盘涨跌" + "", 115 + 3, 15);


    };
    KLineChart.prototype.drawIndex = function () {
        if (this.indexType == 'vol')
            this.drawVolume();
    };
    KLineChart.prototype.clear = function () {
        this.chart.clearRect(this.leftwidth, 0, this.jxwidth, this.jxsbheight);
        //this.chart.clearRect(this.leftwidth, this.jxsbheight + this.jxzjheight, this.jxwidth, this.jxxbheight);
        this.chart.clearRect(0, 0, this.leftwidth - 1, this.height);
    };
    KLineChart.prototype.drawKLine = function () {
        //this.clear();
        //当前的最高价 最低价
        this.chart.strokeStyle = "RGB(220,228,234)";
        this.chart.font = "12px";
        this.chart.fillStyle = "#999999";
        var minPrice = 10000000;
        var maxPrice = 0;
        for (var i = 0; i < this.showKLines[2].length; i++) {
            minPrice = Math.min(minPrice, this.showKLines[2][i].low);
            if (this.showKLines[2][i].MA5 > 0)
                minPrice = Math.min(minPrice, this.showKLines[2][i].MA5);
            if (this.showKLines[2][i].MA10 > 0)
                minPrice = Math.min(minPrice, this.showKLines[2][i].MA10);
            if (this.showKLines[2][i].MA20 > 0)
                minPrice = Math.min(minPrice, this.showKLines[2][i].MA20);
            maxPrice = Math.max(maxPrice, this.showKLines[2][i].high);
            maxPrice = Math.max(maxPrice, this.showKLines[2][i].MA5);
            maxPrice = Math.max(maxPrice, this.showKLines[2][i].MA10);
            maxPrice = Math.max(maxPrice, this.showKLines[2][i].MA20);
            var day = this.showKLines[2][i].day + "";
            this.showKLines[2][i].day1 = day.substring(0, 4) + "-" + day.substring(4, 6) + "-" + day.substring(6, 8);
        }
        maxPrice = +maxPrice.toFixed(this.fixedNumber);
        minPrice = +minPrice.toFixed(this.fixedNumber);
        var avgPrice = (minPrice + maxPrice) / 2;
        avgPrice = +avgPrice.toFixed(this.fixedNumber);
        var twoPrice = (maxPrice + avgPrice) / 2;
        //twoPrice = +twoPrice.toFixed(this.fixedNumber);
        var fourPrice = (minPrice + avgPrice) / 2;
        //fourPrice = +fourPrice.toFixed(this.fixedNumber);

        // 画左侧价格
        this.chart.textAlign = "left";
        this.chart.textBaseline = "middle";
        this.chart.fillText(maxPrice + "", this.leftwidth + this.jxwidth + 3, this.topjjheght);
        //console.log("twoPrice", twoPrice);
        //console.log("fourPrice", fourPrice);
        //this.chart.textBaseline = "middle";
        //this.chart.fillText(twoPrice + "", this.leftwidth + this.jxwidth + 3, this.topjjheght + this.jxsbheight / 4*1);
        this.chart.textBaseline = "middle";
        this.chart.fillText(avgPrice + "", this.leftwidth + this.jxwidth  + 3, this.topjjheght + this.jxsbheight / 2);
        //this.chart.textBaseline = "middle";
        //this.chart.fillText(fourPrice + "", this.leftwidth + this.jxwidth + 3, this.topjjheght + this.jxsbheight / 4*3);
        this.chart.textBaseline = "middle";
        this.chart.fillText(minPrice + "", this.leftwidth + this.jxwidth  + 3, this.topjjheght + this.jxsbheight);

        //横线
        this.chart.beginPath();
        //this.chart.fillStyle = 'RGB(229,229,229)';//灰色
        this.chart.moveTo(this.leftwidth + 0.5, this.topjjheght + 0.5);
        this.chart.lineTo(this.leftwidth + this.jxwidth + 0.5, this.topjjheght + 0.5);

        this.chart.moveTo(this.leftwidth + 0.5, this.topjjheght + this.jxsbheight / 2);
        this.chart.lineTo(this.leftwidth + this.jxwidth + 0.5, this.topjjheght + this.jxsbheight / 2);

        this.chart.moveTo(this.leftwidth + 0.5, this.topjjheght + this.jxsbheight + 0.5);
        this.chart.lineTo(this.leftwidth + this.jxwidth + 0.5, this.topjjheght + this.jxsbheight + 0.5);


        this.chart.closePath();

        this.chart.lineWidth = 1;
        this.chart.strokeStyle = 'RGB(229,229,229)';
        this.chart.stroke();


        //--------------------------------------------------------------
        var beginx = this.leftwidth;
        this.xMap = {};
        for (var i = this.showKLines[2].length - 1; i >= 0; i--) {
            var kline = this.showKLines[2][i];
            var openy = this.topjjheght + this.jxsbheight - (kline.open - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            var closey = this.topjjheght + this.jxsbheight - (kline.close - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            var highy = this.topjjheght + this.jxsbheight - (kline.high - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            var lowy = this.topjjheght + this.jxsbheight - (kline.low - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            var h = Math.abs(closey - openy);
            h = h < 1 ? 1 : h;
            this.chart.lineWidth = 1;
            if (openy >= closey) {
                // 涨的
                this.chart.fillStyle = this.upcolor;
                this.chart.strokeStyle = this.upcolor;
                this.chart.fillRect(beginx, closey, this.currKLineWidth[0] + 0.5, h);
                this.chart.beginPath();
                chartMoveTo(beginx + this.currKLineWidth[0] / 2, highy, this.chart);
                chartLineTo(beginx + this.currKLineWidth[0] / 2, lowy, this.chart);
                this.chart.stroke();
                this.chart.closePath();
            }
            else {
                this.chart.fillStyle = this.downcolor;
                this.chart.strokeStyle = this.downcolor;
                this.chart.fillRect(beginx, openy, this.currKLineWidth[0] + 0.5, h);
                this.chart.beginPath();
                chartMoveTo(beginx + this.currKLineWidth[0] / 2, highy, this.chart);
                chartLineTo(beginx + this.currKLineWidth[0] / 2, lowy, this.chart);
                this.chart.stroke();
                this.chart.closePath();
            }
            kline.x = beginx + this.currKLineWidth[0] / 2;
            kline.y = closey;
            kline.xBegin = beginx;
            if (i != (this.showKLines[2].length - 1)) {
                var prex = this.showKLines[2][i + 1].xBegin;
                while (prex <= beginx) {
                    this.xMap[++prex] = this.showKLines[2][i + 1];
                }
            }
            this.xMap[beginx] = kline;
            beginx += (this.kLineSpace + this.currKLineWidth[0]);
        }
        //this.drawMa(5, this.MA5Color, maxPrice, minPrice);//5日均线
        //this.drawMa(10, this.MA10Color, maxPrice, minPrice);//10日均线
        //this.drawMa(20, this.MA20Color, maxPrice, minPrice);//20日均线
        this.drawsyl();
    };
    KLineChart.prototype.drawVolume = function () {
        this.chart.clearRect(this.leftwidth, this.jxsbheight + this.jxzjheight, this.jxwidth, this.jxxbheight + 3);
        this.chart.clearRect(0, this.jxsbheight + this.jxzjheight, this.leftwidth - 1, this.jxxbheight);
        //成交量宽度
        var cjlkd = this.currKLineWidth[0];
        this.chart.lineWidth = cjlkd;
        var maxCjl = 0;
        for (var i = 0; i < this.showKLines[2].length; i++) {
            maxCjl = Math.max(this.showKLines[2][i].vol, maxCjl);
        }
        this.chart.fillStyle = "#999999";
        this.chart.textAlign = "right";
        this.chart.textBaseline = "top";
        this.chart.fillText((maxCjl / 10000).toFixed(2), this.leftwidth - 4, this.jxsbheight + this.jxzjheight);
        this.chart.textBaseline = "bottom";
        this.chart.fillText("万手", this.leftwidth - 4, this.height);
        for (var i = 0; i < this.showKLines[2].length; i++) {
            var kline = this.showKLines[2][i];
            var voly = this.height - (kline.vol / maxCjl * this.jxxbheight);
            this.chart.beginPath();
            if (kline.zdf >= 0) {
                this.chart.strokeStyle = this.upcolor;
            }
            else {
                this.chart.strokeStyle = this.downcolor;
            }
            chartMoveTo(kline.x, this.height, this.chart);
            chartLineTo(kline.x, voly, this.chart);
            this.chart.stroke();
            this.chart.closePath();
        }
    };
    KLineChart.prototype.drawMa = function (type, color, maxPrice, minPrice) {
        this.chart.beginPath();
        this.chart.strokeStyle = color;
        this.chart.lineWidth = 1;
        var first = true;
        for (var i = this.showKLines[2].length - 1; i >= 0; i--) {
            var kline = this.showKLines[2][i];
            var ma = 0;
            if (type == 5) {
                ma = kline.MA5;
            }
            else if (type == 10) {
                ma = kline.MA10;
            }
            else if (type == 20) {
                ma = kline.MA20;
            }
            if (ma == 0) {
                continue;
            }
            var maY = this.jxsbheight - (ma - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            if (first) {
                chartMoveTo(kline.x, maY, this.chart);
                first = false;
            }
            else {
                chartLineTo(kline.x, maY, this.chart);
            }
        }
        this.chart.stroke();
        this.chart.closePath();
    };
    KLineChart.prototype.zoomUp = function () {
        var index = this.currKLineWidth[1];
        if (index == this.kLineWidthArray.length - 1) {
            return;
        }
        else {
            index++;
        }
        this.currKLineWidth[1] = index;
        this.currKLineWidth[0] = this.kLineWidthArray[index];
        this.initCanShowKLines();
        this.drawKLine();
        //this.drawIndex();//成交量
    };
    KLineChart.prototype.zoomDown = function () {
        var index = this.currKLineWidth[1];
        if (index == 0) {
            return;
        }
        else {
            index--;
        }
        this.currKLineWidth[1] = index;
        this.currKLineWidth[0] = this.kLineWidthArray[index];
        this.initCanShowKLines(true);
        this.drawKLine();
        //this.drawIndex();//成交量
    };

    KLineChart.prototype.drawsyl = function () {
        this.chart.beginPath();
        this.chart.strokeStyle = this.sylColor;
        this.chart.lineWidth = 1;
        var first = true;
        var maxsyl;
        var minsyl;
        if(this.showKLines[2].length > 0)
        {
            maxsyl = this.showKLines[2][0].syl;
            minsyl = this.showKLines[2][0].syl;
        }
        for (var i = 1; i < this.showKLines[2].length; i++) {
            maxsyl = Math.max(this.showKLines[2][i].syl, maxsyl);
            minsyl = Math.min(this.showKLines[2][i].syl, minsyl);
        }
        maxsyl = Math.max(Math.abs(maxsyl), Math.abs(minsyl));
        maxsyl = Math.ceil(maxsyl);
        minsyl = -maxsyl;
        //console.log(maxsyl, minsyl);

        var onedw = this.jxsbheight /(Math.abs(maxsyl) + Math.abs(minsyl));
        //console.log("单位", onedw);
        for (var i = this.showKLines[2].length - 1; i >= 0; i--) {
            var kline = this.showKLines[2][i];
            //console.log("maY", kline);
            //console.log("syl", kline.syl);
            //var maY = this.jxsbheight - (ma - minPrice) / (maxPrice - minPrice) * this.jxsbheight;
            var maY = this.topjjheght + (maxsyl - kline.syl) * onedw + 0.5;
            //console.log("maY", maY);
            if (first) {
                chartMoveTo(kline.x, maY, this.chart);
                //console.log("kline.x",kline.x);
                first = false;
            }
            else {
                chartLineTo(kline.x, maY, this.chart);
            }
        }
        this.chart.stroke();
        this.chart.closePath();

        //this.chart.strokeStyle = this.sylColor;
        this.chart.fillStyle = "#999999";
        // 画左侧收益率坐标
        this.chart.textAlign = "right";
        this.chart.textBaseline = "middle";
        this.chart.fillText(maxsyl + "%" + "", this.leftwidth - 4 , this.topjjheght);
        this.chart.textBaseline = "middle";
        this.chart.fillText(0 + "%", this.leftwidth - 4, this.jxsbheight / 2 + this.topjjheght);
        this.chart.textBaseline = "middle";
        this.chart.fillText(minsyl + "%", this.leftwidth - 4 , this.jxsbheight + this.topjjheght);

        //下方日期坐标
        this.chart.textAlign = "left";
        this.chart.textBaseline = "top";
        var dstr = this.showKLines[2][this.showKLines[2].length - 1].day.toString();
        var firstDate = dstr.substr(0,4) + "-" + dstr.substr(4,2) + "-" +dstr.substr(6,2);
        this.chart.fillText( firstDate, this.showKLines[2][this.showKLines[2].length - 1].x -25 , this.jxsbheight + this.topjjheght + 8);
        if(this.showKLines[2].length>10)
        {
            var dstr = this.showKLines[2][0].day.toString();
            var firstDate = dstr.substr(0,4) + "-" + dstr.substr(4,2) + "-" +dstr.substr(6,2);
            this.chart.fillText( firstDate, this.showKLines[2][0].x -25 , this.jxsbheight + this.topjjheght + 8);
        }

    };

    /**
     * 搭建框架
     */
    KLineChart.prototype.build = function () {
        var maxValue = 0;
        var maxsyy = 0;
        for (var i = 0; i < this.kLineArray.length; i++) {
            var kLine = this.kLineArray[i];
            // 昨收盘
            if (i == 0) {
                kLine.preclose = kLine.open;
            }
            else {
                kLine.preclose = this.kLineArray[i - 1].close;
            }
            kLine.MA5 = this.getMA(this.kLineArray, i, 5);
            kLine.MA10 = this.getMA(this.kLineArray, i, 10);
            kLine.MA20 = this.getMA(this.kLineArray, i, 20);
            kLine.zdf = (kLine.close - kLine.preclose) / kLine.preclose * 100;
            kLine.zdf = +kLine.zdf.toFixed(2);
            maxValue = Math.max(kLine.high, maxValue);
            maxsyy = Math.max(Math.abs(kLine.syl), maxsyy);
        }
        maxsyy = maxsyy.toFixed(2);
        //console.log("syl", maxsyy);
        //左边坐标区
        this.leftwidth = this.chart.measureText(maxsyy.toString()).width + 5;
        //右边坐标区
        this.rightwidth = this.chart.measureText(maxValue.toString()).width + 5;
        this.jxsbheight = this.height - this.jxzjheight- this.topjjheght;
        //this.jxsbheight = this.height * 3 / 4 - this.jxzjheight;//有成交量的K线高度
        //this.jxxbheight = this.height * 1 / 4 - 2;//成交量的高度
        this.jxwidth = this.width - this.leftwidth - this.rightwidth - 4;
        // 画矩形
        //this.chart.fillStyle = 'RGB(204,204,204)';//灰色
        this.chart.fillStyle = 'RGB(255,255,255)';//白色
        this.chart.strokeStyle = 'RGB(255,255,255)';
        this.chart.font = "12px";
        this.chart.lineWidth = 1;
        //console.log(this.leftwidth, this.topjjheght, this.jxwidth, this.jxsbheight);
        this.chart.strokeRect(this.leftwidth, this.topjjheght, this.jxwidth, this.jxsbheight);
        this.chart.stroke();
        //this.chart.strokeRect(this.leftwidth, this.jxsbheight + this.jxzjheight, this.jxwidth, this.jxxbheight);
    };
    /**
     * 获取当前情况下能显示的数量
     */
    KLineChart.prototype.initCanShowKLines = function (positon) {
        if (positon === void 0) { positon = false; }
        var count = this.jxwidth / (this.currKLineWidth[0] + this.kLineSpace);
        count = Math.floor(count);
        this.currKLineWidth[2] = count;
        // 取最后count根显示
        var showKLineArray = [];
        if (positon) {
            this.showKLines[0] = this.showKLines[1] + count;
            this.showKLines[0] = this.showKLines[0] > (this.kLineArray.length - 1) ? (this.kLineArray.length - 1) : this.showKLines[0];
        }
        for (var i = this.showKLines[0]; i >= 0 && i > this.showKLines[0] - count; i--) {
            showKLineArray.push(this.kLineArray[i]);
            this.showKLines[1] = i;
        }
        this.showKLines[2] = showKLineArray;
    };
    /**
     * 获取ma均价
     * @param kLineArray
     * @param endIndex
     * @param count
     * @returns {number}
     */
    KLineChart.prototype.getMA = function (kLineArray, endIndex, count) {
        if (endIndex < count - 1) {
            return 0;
        }
        var sumPrice = 0;
        for (var i = endIndex + 1 - count; i <= endIndex; i++) {
            sumPrice += kLineArray[i].close;
        }
        var avgPrice = sumPrice / count;
        return +avgPrice.toFixed(this.fixedNumber);
    };
    return KLineChart;
})();
function chartMoveTo(x, y, chart) {
    if (chart.lineWidth == 1) {
        chart.moveTo(x + 0.5, y + 0.5);
    }
    else {
        chart.moveTo(x, y);
    }
}
function chartLineTo(x, y, chart) {
    if (chart.lineWidth == 1) {
        chart.lineTo(x + 0.5, y + 0.5);
    }
    else {
        chart.lineTo(x, y);
    }
}
var canvasPrototype = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
canvasPrototype.dottedLine = function (x1, y1, x2, y2, interval) {
    if (!interval) {
        interval = 5;
    }
    var isHorizontal = true;
    if (x1 == x2) {
        isHorizontal = false;
    }
    var len = isHorizontal ? x2 - x1 : y2 - y1;
    this.moveTo(x1, y1);
    var progress = 0;
    while (len != progress) {
        progress += interval;
        if (progress >= len) {
            progress = len;
        }
        if (isHorizontal) {
            this.moveTo(x1 + progress, y1);
            this.arc(x1 + progress, y1, 1, 0, 2 * Math.PI, true);
            this.fill();
        }
        else {
            this.moveTo(x1, y1 + progress);
            this.arc(x1, y1 + progress, 1, 0, 2 * Math.PI, true);
            this.fill();
        }
    }
};
//# sourceMappingURL=klinechart.js.map