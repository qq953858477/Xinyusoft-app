/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function gt_jsdCtrl($scope, ajaxService, $cookieStore) {

    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.username = "";
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.backtitle = "";
    $scope.gtbky = "--";

    $scope.gtLcsCPlist = [];//好友发布中的
    $scope.gethyspz = [];//好友实盘中的

    $scope.jsdobj = {};
    $scope.jsdobj.syfc = "--";//收益分成
    $scope.jsdobj.productname = "--";//产品名称
    $scope.jsdobj.lcsname = "--";//理财师名称
    $scope.jsdobj.yhname = "--";//用户名称
    $scope.jsdobj.gtje = "--";//跟投金额
    $scope.jsdobj.zq = "--";//周期
    $scope.jsdobj.fcfs = "--";//分成方式
    $scope.jsdobj.ljsy = "--";//累计收益

    $scope.pfcontetArray = [];//评分图片
    $scope.ispftjing = false;//是否评分提交中
    $scope.pjscore = 0;//评价分数
    $scope.pjdesc = "";//评论内容
    $scope.pjscorestr = "";//评分的描述

    $scope.showmore = false;//查看更多信息

    var ind = getParameter("index");
    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.linkid = getParameter("linkid");
    //$scope.productid = getParameter("productid");
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));

    $scope.p_selectlcsscoreCallBack = function(_data)
    {
        console.log("评分", _data.toString());
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.productgradelist;
            if(arr.length>0)
            {
                $scope.jsdobj.fwpj = arr[0].desc;//评价
                if($scope.jsdobj.fwpj == undefined || $scope.jsdobj.fwpj == null || $scope.jsdobj.fwpj == "")
                {
                    $scope.jsdobj.fwpj = "";
                }
                $scope.jsdobj.score = arr[0].score;
                if($scope.jsdobj.score == undefined || $scope.jsdobj.score == null || $scope.jsdobj.score == "")
                {
                    $scope.jsdobj.score = 0;
                }
                $scope.jsdobj.scoreArray = setsunflowerpf(parseInt($scope.jsdobj.score));
            }
        }
    }

    $scope.getpjInfo = function()
    {
        var message = {};
        message['accountlinkid'] = $scope.linkid;
        //message['productid'] = $scope.productid;
        message['page.size'] = "max";
        message['page.no'] = "";
        ajaxService.sendMessage("gentou.selectproductgradeaction", message, $scope.p_selectlcsscoreCallBack);
    }

    $scope.getjsdCallBack = function (_data)
    {
        console.log("jsd", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jsdobj = {};
            $scope.jsdobj.syfc = _data.settleinfo.paymoney;//收益分成
            $scope.jsdobj.ptsf = _data.settleinfo.payplatformmoney;//平台分成
            $scope.jsdobj.lcsfc = _data.settleinfo.payproductmoney;//理财师收费
            $scope.jsdobj.settleid = _data.accountlink.settleid;
            $scope.jsdobj.settleno = _data.accountlink.settleno;
            $scope.jsdobj.productname = _data.accountlink.productname;//产品名称
            $scope.jsdobj.productid = _data.accountlink.productid;
            $scope.jsdobj.lcsname = _data.accountlink.linkeduser.user.f_nickname;//理财师名称
            $scope.jsdobj.yhname = _data.accountlink.linkuser.user.f_nickname;//用户名称
            $scope.jsdobj.gtje = _data.accountlink.money;//跟投金额
            $scope.jsdobj.zq = _data.accountlink.gentouperiod;//周期
            $scope.jsdobj.rundays = _data.accountlink.rundays + "天";//实际天数
            $scope.jsdobj.mbsy = _data.accountlink.targetprofit + "%";
            $scope.jsdobj.createtime = _data.accountlink.createtime.toString().substr(0,10);
            var sharestr =  _data.accountlink.share;
            var fc = parseInt(sharestr)/10;
            $scope.jsdobj.fcfs = fc +":" +(10-fc) ;//分成方式

            $scope.jsdobj.ljsy = _data.accountlink.ljyk;//累计收益
            $scope.jsdobj.status = _data.accountlink.status;//状态
            $scope.jsdobj.gradeflat = _data.accountlink.gradeflat;//是否已经评价

            if(parseFloat($scope.jsdobj.syfc) > 0)//表示需要支付，会有支付信息，若已支付，需显示支付信息
            {
                $scope.jsdobj.isshowzfzt = true;
                var sjsharestr =  _data.settleinfo.actualshare;
                var sjfc = parseInt(sjsharestr)/10;
                $scope.jsdobj.sjfcfs = sjfc +":" +(10-sjfc) ;//分成方式
            }
            else
            {
                $scope.jsdobj.isshowzfzt = false;
            }
            //$scope.jsdobj.isshowzfzt = false;
            //console.log($scope.jsdobj.status);

            if($scope.jsdobj.status == "D")
            {
                $scope.jsdobj.statusstr = "未支付";
            }
            else if($scope.jsdobj.status == "E")
            {
                $scope.jsdobj.statusstr = "已支付";
                if($scope.jsdobj.isshowzfzt == true)
                {
                    $scope.jsdobj.zftime =  _data.settleinfo.paytime.toString().substr(0,19);
                }
            }

            if($scope.jsdobj.gradeflat == "Y")//已经评价
            {
                $scope.getpjInfo();
            }
            else
            {
                $scope.pjscore = 4;
                $scope.pjscorestr = "满意";
                $scope.pfcontetArray = setsunflowerpf(4);
            }

            ////测试
            //$scope.jsdobj.gradeflat = "Y";
            //$scope.jsdobj.fwpj = "34345354354测试";//评价
            //$scope.jsdobj.score ="5";
            //$scope.jsdobj.scoreArray = setsunflowerpf(parseInt($scope.jsdobj.score));
        }
    }

    $scope.getjsd = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        ajaxService.sendMessage("gentou.p_getsettleinfobylinkid", message, $scope.getjsdCallBack);
    }


    $scope.gtjsdinit = function()
    {
        $scope.getjsd();
    }

    $scope.gtjsdinit();


    //评分
    $scope.pfchooseClick = function(_obj)
    {
        //console.log("va", _obj.value);
        if(_obj.value == $scope.pjscore)
        {
            $scope.pjscore = $scope.pjscore - 1;
        }
        else
        {
            $scope.pjscore = _obj.value;
        }
        $scope.pfcontetArray = setsunflowerpf($scope.pjscore);

        if($scope.pjscore == 5)
        {
            $scope.pjscorestr = "非常满意";
        }
        else if($scope.pjscore == 4)
        {
            $scope.pjscorestr = "满意";
        }
        else if($scope.pjscore == 3)
        {
            $scope.pjscorestr = "可以";
        }
        else if($scope.pjscore == 2)
        {
            $scope.pjscorestr = "马马虎虎";
        }
        else if($scope.pjscore == 1)
        {
            $scope.pjscorestr = "不满意";
        }
        else if($scope.pjscore == 0)
        {
            $scope.pjscorestr = "非常不满意";
        }
    }

    //评论提交
    $scope.sureplClick = function()
    {
        if($scope.ispftjing == false)
        {
            //if($scope.pjscore == 0)
            //{
            //    myAlert("请给服务评分！");
            //    return;
            //}
            $scope.ispftjing = true;//提交中
            var message = {};
            message['userid'] =  $scope.userObj.f_id;
            message['productid'] =  $scope.jsdobj.productid;
            message['score'] =  $scope.pjscore;
            message['desc'] =  $scope.pjdesc;
            message['linkid'] =  $scope.linkid;
            //console.log(message);
            ajaxService.sendMessage("sunflower.p_lcsscore", message, $scope.p_lcsscoreCallBack);
        }
    }

    $scope.p_lcsscoreCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.pjscore = 0;
            $scope.pjdesc = "";
            $scope.pjscorestr = "";

            $scope.jsdobj.gradeflat = "Y";//已经评价
            $scope.getpjInfo();
        }
        else
        {
            myAlert("评价失败，请重试！");
        }
        $scope.ispftjing = false;
    }

    //支付
    $scope.gotozf = function()
    {
        setbackList(window.location.href);
        window.location.href="jiesuandan-pay.html?settleno=" + $scope.jsdobj.settleid + "&paymoney=" + Number($scope.jsdobj.syfc).toFixed(2) + "&productid=" + $scope.jsdobj.productid  + "&linkid=" + $scope.linkid +  "&backurl=getbackList";
    }

    //查看更多
    $scope.showMoreClick = function()
    {
        $scope.showmore = true;
    }

    //返回
    $scope.qzgtbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }
}




