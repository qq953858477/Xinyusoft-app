/**
 * Created by qw1 on 2014/12/7.
 */
var gtjsdModule = angular.module('gt_jsdApp',['ngCookies']);
gtjsdModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gtjsdModule.directive('autohq', autohq);

/** 控制器*/
gtjsdModule.controller('gt_jsdCtrl',['$scope','ajaxService', '$cookieStore',gt_jsdCtrl]);

/**过滤器*/
gtjsdModule.filter('numberFormatFilter',numberFormatFilter);


gtjsdModule.run(function() {
    document.getElementById("gt_jsdMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_jsdApp']);
});
