cordova.define("cordova-plugin-luckview.luckview", function(require, exports, module) {

var exec = require('cordova/exec');

    module.exports = {
               
        startLuckView: function(userId,url) {
            exec(null, null, "LuckViewPlugin", "startLuckView", [userId,url]);
        }
    };
               
});
