var LOCAL_IP = 'http://127.0.0.1:8888';

// uucall 的跳转接口 ，保存，查询 cookie的 接口


function jumpToUUCall(onSuccess, onError) {
	$.ajax({
		type: 'get',
		url: LOCAL_IP + '/action:jumpToUUCall',
		cache: false,
		dataType: 'json',
		success: onSuccess,
		error: onError
	});
}

//function saveCookieToLocal(cookie,onSuccess, onError) {
//	$.ajax({
//		type: 'get',
//		url: LOCAL_IP + '/action:savecookie',
//		data:{"cookie":cookie},
//		cache: false,
//		dataType: 'text',
//		success: onSuccess,
//		error: onError
//	});
//}
//
//function getCookieToLocal(onSuccess, onError) {
//	$.ajax({
//		type: 'get',
//		url: LOCAL_IP + '/action:getcookie',
//		cache: false,
//		dataType: 'text',
//		success: onSuccess,
//		error: onError
//	});
//}