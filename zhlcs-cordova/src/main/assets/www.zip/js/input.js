	$(function(){
		$("#input1").blur(function(){
		$("#input2").val($("#input1").val());
        $("#input1").hide();
		$("#input2").show();
		});
		$("#input2").focus(function(){
           $("#input1").show();
		   $("#input2").hide();
		});
	});
	setInterval("MyAutoRun()",1000);
	function MyAutoRun(){
　　　var input1Val=$("#input1").val();
      var input1ValDian="";
     for(var i=0;i<input1Val.length;i++){
     	input1ValDian+="•";
	 }

      $("#input1").val(input1ValDian);
　　};  
