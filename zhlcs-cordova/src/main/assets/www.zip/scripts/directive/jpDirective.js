/**
 * Created by wangtao on 2015/8/25 0025.
 */
function ggJpDirective() {
    return {
        //priority: 0,/*优先级priority - 当一个DOM上有多个指令时，就会需要指定指令执行的顺序。 这个优先级就是用来在执行指令的compile函数前，先排序的。高优先级的先执行。*/
        //template: '<div></div>',/*模版字符串*/
        templateUrl: 'view/gg.html',/*模版页面路径*/
        replace: false,/*替换replace - 如果被设置成true，那么页面上指令内部里面的内容会被模板替换。比如：<hello><div>这是指令内部的内容</div></hello>，hello指令内部的div内容将会被模板替换掉。*/
        transclude: false,/*transclude -  如果不想让指令内部的内容被模板替换，可以设置这个值为true。一般情况下需要和ngTransclude指令一起使用。 比如：template:"<div>hello every <div ng-transclude></div></div>"，这时，指令内部的内容会嵌入到ng-transclude这个div中。也就是变成了<div>hello every <div>这是指令内部的内容</div></div>*/
        restrict: 'E',
        controller:jiepanListCtrl
    }
}

function gnJpDirective() {
    return {
        //priority: 0,/*优先级priority - 当一个DOM上有多个指令时，就会需要指定指令执行的顺序。 这个优先级就是用来在执行指令的compile函数前，先排序的。高优先级的先执行。*/
        //template: '<div></div>',/*模版字符串*/
        templateUrl: 'view/gn.html',/*模版页面路径*/
        replace: false,/*替换replace - 如果被设置成true，那么页面上指令内部里面的内容会被模板替换。比如：<hello><div>这是指令内部的内容</div></hello>，hello指令内部的div内容将会被模板替换掉。*/
        transclude: false,/*transclude -  如果不想让指令内部的内容被模板替换，可以设置这个值为true。一般情况下需要和ngTransclude指令一起使用。 比如：template:"<div>hello every <div ng-transclude></div></div>"，这时，指令内部的内容会嵌入到ng-transclude这个div中。也就是变成了<div>hello every <div>这是指令内部的内容</div></div>*/
        restrict: 'E',
        controller:jiepanListCtrl
    }
}

function dpJpDirective() {
    return {
        //priority: 0,/*优先级priority - 当一个DOM上有多个指令时，就会需要指定指令执行的顺序。 这个优先级就是用来在执行指令的compile函数前，先排序的。高优先级的先执行。*/
        //template: '<div></div>',/*模版字符串*/
        templateUrl: 'view/dp.html',/*模版页面路径*/
        replace: false,/*替换replace - 如果被设置成true，那么页面上指令内部里面的内容会被模板替换。比如：<hello><div>这是指令内部的内容</div></hello>，hello指令内部的div内容将会被模板替换掉。*/
        transclude: false,/*transclude -  如果不想让指令内部的内容被模板替换，可以设置这个值为true。一般情况下需要和ngTransclude指令一起使用。 比如：template:"<div>hello every <div ng-transclude></div></div>"，这时，指令内部的内容会嵌入到ng-transclude这个div中。也就是变成了<div>hello every <div>这是指令内部的内容</div></div>*/
        restrict: 'E',
        controller:jiepanListCtrl
    }
}

function gnGdDirective() {
    return {
        //priority: 0,/*优先级priority - 当一个DOM上有多个指令时，就会需要指定指令执行的顺序。 这个优先级就是用来在执行指令的compile函数前，先排序的。高优先级的先执行。*/
        //template: '<div></div>',/*模版字符串*/
        templateUrl: 'view/jrgd.html',/*模版页面路径*/
        replace: false,/*替换replace - 如果被设置成true，那么页面上指令内部里面的内容会被模板替换。比如：<hello><div>这是指令内部的内容</div></hello>，hello指令内部的div内容将会被模板替换掉。*/
        transclude: false,/*transclude -  如果不想让指令内部的内容被模板替换，可以设置这个值为true。一般情况下需要和ngTransclude指令一起使用。 比如：template:"<div>hello every <div ng-transclude></div></div>"，这时，指令内部的内容会嵌入到ng-transclude这个div中。也就是变成了<div>hello every <div>这是指令内部的内容</div></div>*/
        restrict: 'E',
        controller:jiepanListCtrl
    }
}