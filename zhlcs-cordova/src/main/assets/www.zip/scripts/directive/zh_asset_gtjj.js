function zhassetgtjj()
{
     return {
         restrict: 'E',
         templateUrl: 'html/zh_asset_gtjj.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function zh_asset_gtjjCtrl($scope, ajaxService, $cookieStore) {
    $scope.kyggjj = 0;//可用跟投基金
    $scope.ysy = 0;//已使用
    $scope.yzs = 0;//已转送

    $scope.orderClumn = 'f_ljykbl';
    $scope.dqgtzArray = [];//当前跟投者中的产品信息
    $scope.dqgtbmArray = [];//当前跟投报名的产品信息

    $scope.refreshbtn = false;//刷新按钮是否显示


    $scope.getgtjjjeCallBack = function(_data)
    {
        //console.log("333", _data);
        $scope.kyggjj = parseFloat(_data.money)-parseFloat(_data.applymoney);
    }

    $scope.getzzc = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log(message);
        ajaxService.sendMessage("sunflower.getexperienceaccountaction", message, $scope.getgtjjjeCallBack);
    }



    $scope.getdqgtzinfoCallBack = function(_data)
    {
        //console.log("跟投中的产品", _data);
        $scope.dqgtzArray = [];//跟投中：gt1 (B)； 解除中：gt2(C)； 已结束/未支付：gt3(D)； 已结束/已支付：gt4(E)
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkeduser.user.f_head;
                obj.username = arr[i].linkeduser.user.f_nickname;
                obj.userid = arr[i].linkeduser.user.f_id;//被跟投者的用户信息
                obj.linkaccount = arr[i].linkaccount;//当前跟投的账户
                obj.linkid = arr[i].id;
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.gtje = parseFloat(arr[i].money);
                obj.drsyl = (parseFloat(arr[i].linkaccountmoney.jrsy) * 100).toFixed(2);
                obj.ljyk = parseFloat(arr[i].linkaccountmoney.ljyk);
                if(arr[i].status.toString() == "B")
                {
                    obj.status = "gt1";
                }
                else if(arr[i].status.toString() == "C")
                {
                    obj.status = "gt2";
                }
                else if(arr[i].status.toString() == "D")
                {
                    obj.status = "gt3";//未支付
                }
                else if(arr[i].status.toString() == "E")
                {
                    obj.status = "gt4";//已结束
                }
                $scope.dqgtzArray.push(obj);
            }
        }
    }

    //跟投中的产品信息
    $scope.dqgtzinfo = function()
    {
        $scope.dqgtzArray = [];
        var message = {};
        message['account'] = "";
        message['productid'] = "";
        message['userid'] = "";
        message['linkoriginalaccount'] = $scope.accountShowValue;
        message['page.size'] = "max";
        message['page.no'] = "";
        //console.log("$scope.linkoriginalaccount", $scope.account);
        ajaxService.sendMessage("gentou.p_selectgentou", message, $scope.getdqgtzinfoCallBack);
    }

    $scope.p_selectgentouapplyCallBack = function(_data)
    {
        $scope.dqgtbmArray = [];
        //console.log("报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinkapplylist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkuser.user.f_head;
                obj.username = arr[i].linkuser.user.f_nickname;
                obj.userid = arr[i].linkuser.user.f_id;//被跟投者的用户信息
                obj.applyaccount = arr[i].applyaccount;//当前跟投报名的账户
                obj.applyid = arr[i].id;
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.gtje = parseFloat(arr[i].money);
                obj.bmjzsj = arr[i].endapplytimedesc;
                $scope.dqgtbmArray.push(obj);
            }
        }

    }

    $scope.dqgtbminfo = function()
    {
        var message = {};
        message['applyaccount'] = $scope.accountShowValue;
        //console.log(message);
        ajaxService.sendMessage("gentou.p_selectgentouapply", message, $scope.p_selectgentouapplyCallBack);
    }


    $scope.ccquery = function()
    {
        //console.log("获取信息");
        //获取资产信息
        $scope.getzzc();
        $scope.dqgtzinfo();
        //$scope.dqgtbminfo();

        //console.log($scope.accountcompany);
        if($scope.accountcompany == "moni")
        {
            $scope.refreshbtn = false;
        }
        else
        {
            $scope.refreshbtn = true;
        }
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradequery获取参数", _data.account);
        //console.log(_data.caption);
        if(_data.caption == "zh_asset_gtjj")
        {
            //console.log(12132, _data.account);
            $scope.childaccount = _data.account;
            $scope.ccquery();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    var cstr  = {"caption": "zh_asset_gtjj"};
    $scope.$emit("getParameters", cstr);

    //跟投者
    $scope.gtItemClick = function(_obj)
    {
        if(_obj.status == "gt1")
        {
            setbackList(window.location.href);
            window.location = "gt_fwz_gtz.html?linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
        else  if(_obj.status == "gt2")
        {
            setbackList(window.location.href);
            window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
        else if(_obj.status == "gt3"||_obj.status == "gt4")
        {
            setbackList(window.location.href);
            window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
    }

    //报名
    $scope.gtbmItemClick = function(_obj)
    {
        setbackList(window.location.href);
        window.location = "gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.userid;
    }

    //查看行情
    $scope.hqclick = function(_obj)
    {
        //var obj = {};
        //obj.stockcode = _obj.stockcode;
        //obj.stockname = encodeURIComponent(_obj.stockname);
        //obj.exchange = _obj.exchange.toString().toLowerCase();
        //var localStorage = window.localStorage;
        //localStorage.setItem("stockInfo", JSON.stringify(obj));
        ////window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
    }
}
