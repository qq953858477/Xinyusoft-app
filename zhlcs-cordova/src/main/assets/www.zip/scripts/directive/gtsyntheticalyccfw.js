function gtsyntheticalyccfw()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_synthetical_ycc_fw.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyntheticalyccfwCtrl($scope, ajaxService, $cookieStore) {
    //console.log("5345");
    $scope.zhInfo = {};
    $scope.childaccount = "";
    $scope.childaccountStr = "";
    $scope.zhInfo.dqcw = "--";//当前仓位
    $scope.zhInfo.zhdqsz = "--";//账户当前市值
    //$scope.zhInfo.dysyl = "--";//当月收益率
    //$scope.zhInfo.jrsy = "--";//当日收益率
    $scope.zhInfo.qssj = "--";//起始时间
    $scope.zhInfo.qssjstr = "";//8位
    $scope.zhInfo.desc = "";//说明
    //$scope.zhInfo.ljsyl = "--";//累计收益率
    $scope.sylArray = [];//历史净值
    $scope.sylshowmaxlen = 30;//判断显示的最大个数，大于此值，则处理显示
    $scope.sylChartArray = new Object();//收益率图
    $scope.sylscaleSteps = 4;//Y轴刻度个数
    $scope.sylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.sylscaleStartValue = -20;//y轴的起始值
    $scope.sylstep = 10;//计算步长
    $scope.nohqDivShow = true;
    $scope.zhmianShow = true;//主界面
    $scope.rsyfxDivShow = false;//日收益分析界面
    $scope.gtyhlbDivShow = false;//跟投用户列表

    $scope.hqbaseoneStockHQBaseShow = false;//行情显示界面
    $scope.canadddel = true;//是否可以添加删除自选股

    $scope.ztList = [];//涨停列表
    $scope.ztaccount = 0;//涨停个数
    $scope.dtList = [];//跌停列表
    $scope.dtaccount = 0;//涨停个数
    $scope.zdttabOneShow = false;//涨停榜
    $scope.zdttabTwoShow = false;//跌停

    $scope.sytjfxArray = [];//收益分析
    $scope.sylfxShow = true;//是否显示

    $scope.info_zdhc = "--";//最大回撤
    $scope.info_zsdp = "--";//战胜大盘
    $scope.info_qjdpzdf = "--";//期间大盘涨跌幅
    $scope.cpfbzid = "";//产品发布者id
    $scope.productstatus = "";//服务的状态

    $scope.fxtabOneShow = false;
    $scope.fxtabTwoShow = false;
    $scope.fxtabThreeShow = false;

    $scope.p_getaccountupdownCallBack = function(_data)
    {
        //console.log("涨跌停", _data);
        $scope.ztList = [];//涨停
        $scope.dtList = [];//跌停
        $scope.ztaccount = 0;
        $scope.dtaccount = 0;

        var ztarr = [];
        var dtarr = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.limitup;
            for (var item = 0;item< element.length;item++)
            {
                var obj = {};
                obj.stockcode = element[item]['stockcode'].toString();
                obj.stockname = element[item]['name'].toString();
                obj.exchange = element[item]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element[item]['industry'].toString();
                var str = element[item]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element[item]['basetype']);
                ztarr.push(obj);
            }

            //console.log("zt", ztarr.length);

            var element2 = _data.limitdown;
            for (var item2 = 0;item2< element2.length;item2++)
            {
                var obj = {};
                obj.stockcode = element2[item2]['stockcode'].toString();
                obj.stockname = element2[item2]['name'].toString();
                obj.exchange = element2[item2]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element2[item2]['industry'].toString();
                var str = element2[item2]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element2[item2]['basetype']);
                dtarr.push(obj);
            }
            //console.log("dt", dtarr.length);
        }
        $scope.ztaccount = ztarr.length;
        $scope.dtaccount = dtarr.length;
        for(var i = 0;i<ztarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.ztList.length;k++)
            {
                if($scope.ztList[k].sj == ztarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = ztarr[i].sj;
                var arr = [];
                for(var j = i;j<ztarr.length;j++)
                {
                    if(ztarr[j].sj == obj.sj)
                    {
                        arr.push(ztarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.ztList.push(obj);
            }
        }

        for(var i = 0;i<dtarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.dtList.length;k++)
            {
                if($scope.dtList[k].sj == dtarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = dtarr[i].sj;
                var arr = [];
                for(var j = i;j<dtarr.length;j++)
                {
                    if(dtarr[j].sj == obj.sj)
                    {
                        arr.push(dtarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.dtList.push(obj);
            }
        }
    }

    //获取涨跌停
    $scope.getzdt = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getaccountupdown", message, $scope.p_getaccountupdownCallBack) ;

    }

    $scope.getsecurityhisnetactionCallBack = function(_data)
    {
        //console.log("tradesynthetical历史净值", _data);
        $scope.sylArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.netlist;
            for (var item in element)
            {
                var obj = {};
                var str = element[item]['day'].toString();
                obj.label= str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.value = (parseFloat(element[item]['net'])).toFixed(4);//净值
                //console.log(obj.value);
                obj.zzc = (parseFloat(element[item]['net'])).toFixed(4);//净值
                obj.ny = str.substr(0,6);//年月
                obj.status = "0";//0：显示，1：不显示，界面显示用处理
                obj.ym = "1";//是否是月末 0：是，1：不是，界面显示处理
                obj.ymshow = "1";//是否展开 0：展开，1：没有展开 ，界面显示用
                $scope.sylArray.push(obj);
            }

            var labarr = [];//收益率图label
            var dataarr = [];//收益率图data
            var sylmax = 0;//最大值
            //var sylmin = 0//最小值
            if($scope.sylArray.length>0)
            {
                sylmax = Math.abs($scope.sylArray[0].value);
            }

            for(var i = 0;i<$scope.sylArray.length;i++)
            {
                labarr.push($scope.sylArray[i].label);
                dataarr.push($scope.sylArray[i].value);
                sylmax = Math.max(sylmax, Math.abs($scope.sylArray[i].value));
                //sylmin = Math.min(sylmin, Math.abs($scope.sylArray[i].value));
            }
            //console.log(sylmax);
            if((sylmax.toString()).indexOf(".",0) != -1)
            {
                //console.log((sylmax.toString()).indexOf(".",0));
                $scope.sylstep = (sylmax.toString()).indexOf(".",0) *10;
            }
            else
            {
                $scope.sylstep = sylmax.toString().length * 10;
            }
            //console.log($scope.sylstep);
            var max = (Math.floor(sylmax/$scope.sylstep) + 1)*$scope.sylstep;
            // console.log(max)
            $scope.sylscaleStepWidth = max/2;
            $scope.sylscaleStartValue = -1*max;

            $scope.sylChartArray = new Object();

            var valueObj = new Object();
            valueObj.fillColor = "rgba(220,220,220,0.5)";
            valueObj.strokeColor = "rgba(220,220,220,0.8)";
            valueObj.highlightFill = "rgba(220,220,220,0.75)";
            valueObj.highlightFill = "rgba(220,220,220,1)";
            valueObj.data = dataarr;

            var datasetsArr = [];
            datasetsArr.push(valueObj);
            $scope.sylChartArray.labels = labarr;
            $scope.sylChartArray.datasets = datasetsArr;

            //曲线图
            var ctx = document.getElementById("chart_line").getContext("2d");
            document.getElementById("chart_line").style.width = document.getElementById("cvsDiv").style.width;
            document.getElementById("chart_line").style.height = 170;
            var myNewChart = new Chart(ctx).Line($scope.sylChartArray, {
                //scaleShowLabels: false, //纵坐标是否显示
                //scaleOverride :true ,   //是否用硬编码重写y轴网格线
                //scaleSteps : 4,        //y轴刻度的个数
                //scaleStepWidth : 300,   //y轴每个刻度的宽度
                //scaleStartValue : 0,    //y轴的起始值
                responsive : false,//是否响应，移动到图形上，出现相应的点值
                animation: false ,//是否有动画效果
                //scaleLabel : "<%=value%>%",//显示百分比
                showTooltips: false,
                pointDot : false,      //是否显示点
                scaleOverride :true ,   //是否用硬编码重写y轴网格线
                scaleSteps : $scope.sylscaleSteps,       //y轴刻度的个数
                scaleStepWidth : $scope.sylscaleStepWidth,   //y轴每个刻度的宽度
                scaleStartValue : $scope.sylscaleStartValue   //y轴的起始值
                //animationSteps : 60    //动画的步数
                //pointDot : true,        //是否显示点
                //pointDotRadius : 5,     //点的半径
                //pointDotStrokeWidth : 1,//点的线宽
                //datasetStrokeWidth : 3 //数据线的线宽

            });

            //处理是否显示
            if($scope.sylArray.length > $scope.sylshowmaxlen)//一个月内，全部显示<=30则不处理
            {
                for(var i = 0;i<$scope.sylArray.length-1; i++)
                {
                    if($scope.sylArray[i].ny == $scope.sylArray[i+1].ny)//与下一个日期的年月相同，表示不是月最后一天，不显示
                    {
                        $scope.sylArray[i].status = "1";//不显示
                    }
                    else
                    {
                        $scope.sylArray[i].ym = "0";//月末
                    }
                }
                //第一天和最后一天显示
                $scope.sylArray[0].status = "0";
                $scope.sylArray[$scope.sylArray.length - 1].status = "0";
                //最后一天作为月末数据，点击显示相同月份其他数据
                $scope.sylArray[$scope.sylArray.length - 1].ym = "0";
            }
        }
    }

    $scope.getlsjz = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        message['kssj'] = $scope.zhInfo.qssjstr;
        //console.log($scope.childaccount, "sunflower.p_getaccountnettrend");
        ajaxService.sendMessage("sunflower.p_getaccountnettrend", message, $scope.getsecurityhisnetactionCallBack) ;
    }


    $scope.p_selecthissecuritymoneyCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.info_zdhc = parseFloat(_data.tradeanaysis.maxrollback);//最大回撤
            $scope.info_zsdp = _data.tradeanaysis.conquermarket;//战胜大盘
            $scope.info_qjdpzdf = parseFloat(_data.tradeanaysis.marketchange);//期间大盘涨跌幅

            var arr = _data.tradeanaysis.sytj;

            //var gtts = 0;

            //var syarr = [];
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.syl = parseFloat(arr[i].monsyl)*100;
                if(obj.syl > 0)
                {
                    obj.flag = "1";
                }
                else if(obj.syl <0)
                {
                    obj.flag = "-1";
                }
                else
                {
                    obj.flag = "0";
                }
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    //gtts = gtts +1;
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();

                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
            //$scope.dqgtInfo.rundays = gtts;
        }
    }

    $scope.getsyfx = function()
    {
        $scope.sytjfxArray = [];

        var message = {};
        //message['account'] = $scope.childaccount;
        message['productid'] = $scope.productid;
        //message['kssj'] = $scope.zhInfo.qssjstr;
        //message['jssj'] = "";
        //message['page.size'] = "max";
        //message['page.no'] = "";
        //ajaxService.sendMessage("sunflower.getSytjAction", message, $scope.p_selecthissecuritymoneyCallBack) ;
        ajaxService.sendMessage("gentou.p_getGentouProductTradeAnaysis", message, $scope.p_selecthissecuritymoneyCallBack) ;
    }


    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("tradesynthetical可用资金", _data);
        var arr = _data.money;
        if(arr != null && arr != undefined)
        {
            if(parseFloat(arr.zsz.toString()) == 0)
            {
                $scope.zhInfo.dqcw = "空仓";//当前仓位
            }
            else if(parseFloat(arr.zsz.toString()) == parseFloat(arr.zzc.toString()))
            {
                $scope.zhInfo.dqcw = "满仓";//当前仓位
            }
            else
            {
                $scope.zhInfo.dqcw = (parseFloat(arr.zsz.toString())/parseFloat(arr.zzc.toString())*100).toFixed(0) + "%";//当前仓位
            }

            $scope.zhInfo.zhdqsz = parseFloat(arr.zsz);
            //console.log("$scope.zhInfo.dqcw", $scope.zhInfo.dqcw);
            //$scope.zhInfo.jrsy = parseFloat(arr.jrsy);//当日收益率
            ////console.log("当日收益："+ arr.jrsy, arr.ljsy);
            //$scope.zhInfo.dysyl = "--";//当月收益率
            //$scope.zhInfo.qssj = arr.createtime.toString().substr(0,10);//起始时间
            //$scope.zhInfo.ljsyl = parseFloat(arr.ljsy);//累计收益率
            //console.log("收益率：" + $scope.zhInfo.jrsy, $scope.zhInfo.ljsyl);
            //console.log($scope.isgtz);
            //if($scope.isgtz)//作为跟投者
            //{
            //    $scope.zhInfo.jrsy = parseFloat(arr.jrsy);//当日收益率
            //    $scope.zhInfo.ljsyl = parseFloat(arr.ljsy);//累计收益率
            //    $scope.zhInfo.ljsyvalue = parseFloat(arr.ljyk);//累计收益
            //    $scope.zhInfo.jryk =  parseFloat(arr.dqyk);//当日收益
            //}
        }
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack);
    }

    $scope.getcpinfoCallBack = function(_data)
    {
        //console.log("cpxx", _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.zhInfo.desc = product.desc;//说明
            //$scope.productstatus = product.status.toString();  //A：报名中，B：实盘中；D：解除中，其他：结束
            $scope.cpfbzid = product.user.user.f_id;
            $scope.cpfbznameShow = product.user.user.f_nickname;//产品发布者name
            $scope.cpfbzheadShow = product.user.user.f_head;

            //if($scope.isgtz == false)//作为被跟投者
            //{
            //    var str = product.gentouday.toString();
            //    $scope.zhInfo.qssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
            //    $scope.zhInfo.qssjstr = str.substr(0,8);
                $scope.zhInfo.openday = product.openday.toString();//20160302
                $scope.zhInfo.jrsy = parseFloat(product.jrsy);//当日收益率
                $scope.zhInfo.ljsyl = parseFloat(product.ljsy);//累计收益率
                $scope.zhInfo.ljsyvalue = parseFloat(product.ljyk);//累计收益
                $scope.zhInfo.jryk =  parseFloat(product.dqyk);

                $scope.getzdt();
                //$scope.getlsjz();
                $scope.getsyfx();
            //}
        }
    }

    $scope.getcpinfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息收益",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getcpinfoCallBack);
    }

    $scope.getgtbgeindata = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        ajaxService.sendMessage("gentou.p_getgentouinfobyid", message, $scope.getgtbgeindataCallBack);
    }


    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsynthetical")
        {
            $scope.childaccount = _data.account;
            $scope.getccinfo();
            $scope.getcpinfo();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsynthetical"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);


    $scope.fxchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.fxtabOneShow = true;
            $scope.fxtabTwoShow = false;
            $scope.fxtabThreeShow = false;
        }
        else if(_str == "2")
        {
            $scope.fxtabOneShow = false;
            $scope.fxtabTwoShow = true;
            $scope.fxtabThreeShow = false;
        }
        else if(_str == "3")
        {
            $scope.fxtabOneShow = false;
            $scope.fxtabTwoShow = false;
            $scope.fxtabThreeShow = true;
        }
    }

    //日收益分析
    $scope.rsyfxShow = function()
    {
        $scope.zhmianShow = false;
        $scope.rsyfxDivShow = true;
        $scope.fxchangeTab("1");
    }

    $scope.rsyfxbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.rsyfxDivShow = false;
    }

    //历史净值点击显示
    $scope.sylItemClick = function(_obj)
    {
        //console.log("月份", _obj.ym);
        if(_obj.ym == "0")//为月末，点击后显示对应月全部
        {
            for(var i = 1;i<$scope.sylArray.length;i++)//第一个无需处理，一直显示
            {
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "1")//同一月份且不为月末的状态切换
                {
                    if($scope.sylArray[i].status == "0")
                    {
                        $scope.sylArray[i].status = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].status = "0";
                    }
                }
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "0")//月末
                {
                    if($scope.sylArray[i].ymshow == "0")
                    {
                        $scope.sylArray[i].ymshow = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].ymshow = "0";
                    }
                }
            }
        }
    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }
    //收益分析是否显示
    $scope.sylfxShowClick = function()
    {
        $scope.sylfxShow = !$scope.sylfxShow;
    }

    //日收益分析详情
    $scope.rsyfxItem = function(_obj)
    {
        //console.log(_obj.sj);
        //setbackList(window.location.href);
        //window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate);
        openNewInterface("rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=newwebview");
    }

    //调仓日期点击显示隐藏
    $scope.tclssjShowClick = function(_obj)
    {
        //_obj.yfshow = !_obj.yfshow;
    }

    //改变跟投金额
    $scope.changegtje = function(_str)
    {
        //setbackList(window.location.href);
        //window.location.href = "fundAdjustment.html?mainaccount=" + $scope.accountShowValue + "&jetype=gt&productid=" + $scope.productid + "&linkid=" + $scope.linkid + "&opindex=" + _str;
        openNewInterface("fundAdjustment.html?mainaccount=" + $scope.accountShowValue + "&jetype=gt&productid=" + $scope.productid + "&linkid=" + $scope.linkid + "&opindex=" + _str + "&opentype=newwebview", "updategtinfo");
    }

    updategtinfo = function()
    {
        //if($scope.isgtz)//跟投者
        //{
            $scope.getgtinfo();
            $scope.getccinfo();
            $scope.getgtbgeindata();
        //}
    }

    updatefwinfo = function()
    {
        $scope.getcpinfo();
        $scope.getdqgtInfo();
    }

    //涨跌停榜切换
    $scope.zdtchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = true;
            $scope.zdttabTwoShow = false;
        }
        else
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = false;
            $scope.zdttabTwoShow = true;
        }
        gotoUp();
    }

    $scope.zdtbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.zdttabOneShow = false;
        $scope.zdttabTwoShow = false;
        gotoUp();
    }

    $scope.gphqClick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;

        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.hqbaseoneStockHQBaseShow = true;
        $scope.nohqDivShow = false;
    }

    //个股返回
    $scope.oneStockHQBaseBackto = function()
    {
        $scope.hqbaseoneStockHQBaseShow = false;
        $scope.nohqDivShow = true;
    }

    //报名
    $scope.gotobmClick = function()
    {
        //window.location = "gtapply_fwz.html?productid=" + $scope.productid + "&&bgtuserid=" + $scope.cpfbzid;
        openNewInterface("gtapply_fwz.html?productid=" + $scope.productid + "&&bgtuserid=" + $scope.cpfbzid + "&opentype=newwebview", "dqgtqyupdate");
    }

    //服务发布者个人空间
    $scope.gotolcsinfo = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", $scope.cpfbzid);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
    }

    //跟投客户列表
    $scope.gotogtlbinfo = function()
    {
        if($scope.gtzArray.length>0)
        {
            $scope.zhmianShow = false;
            $scope.gtyhlbDivShow = true;
        }
        else//直接跟投
        {
            $scope.gotobmClick();
        }
    }

    $scope.gtyhlbbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.gtyhlbDivShow = false;
    }

    dqgtqyupdate = function()
    {
        $scope.getgtzinfo();
    }
}
