//function tradequerywgt()
//{
//    return {
//        restrict: 'E',
//        templateUrl: 'html/trade_query_wgt.html',
//        controller:['$scope','ajaxService','$cookieStore', tradequerywgtCtrl],
//        //template: '<span>Hi there</span>',
//        replace: true,
//        transclude: true
//    };
//}

function tradequerywgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.zhmianShow = true;//主界面
    $scope.childaccount = "";
    $scope.childaccountStr = "";//显示用
    //侦听获取参数
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradequery获取参数", _data.account);
        $scope.childaccount = _data.account;
        $scope.childaccountStr = "***" + $scope.childaccount.substr($scope.childaccount.length-4);
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    var cstr  = {"caption": "tradequery"};
    $scope.$emit("getParameters", cstr);
    //console.log("交易查询账号", $scope.childaccount);
    //显示查询/交易
    $scope.urlChange = function(_str)
    {
        $scope.urlShow = true;
        $scope.zhmianShow = false;
        window.location.href = _str;
    }

    $scope.backtoParent = function()
    {
        $scope.urlShow = false;
        $scope.zhmianShow = true;
        window.location.href = "#/empty";
    }
    console.log("tradequery主");
}

/**空白**/
function emptyCtrl($scope, ajaxService, $cookieStore) {
}

/**持仓**/

function cccxwgtCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("查询持仓1");
    $scope.kysl = "-";//可卖数量
    $scope.wtjg = "";//委托价格
    $scope.excstockcode = "";//选中的股票
    $scope.ddlx = "j";
    $scope.wtsl = "";
    $scope.listShow = true;//显示列表或者显示操作界面
    $scope.selectdestock = {};//选中的股票
    $scope.ccsellfiveDivShow = false;
    $scope.sellErrorInfo = "";//卖出错误提示
    $scope.sellwtInfo = null;//卖出委托信息

    $scope.buysellhqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.buysellhqintervalId;

    //去除
    $scope.buysellClearInterval = function () {
        if ($scope.buysellhqintervalId != undefined) {
            clearInterval($scope.buysellhqintervalId);
        }
    }

    //console.log("查询持仓");
    var headerArray = [
//        {code: 'cc.productname', name: '合约名称', desc: '↓', type: 'number'},
//        {code: 'cc.stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'cc.cbj', name: '成本价', desc: '　', type: 'money'},
        {code: 'dqj', name: '当前价', desc: '　', type: 'money'},
        {code: 'zqsl', name: '证券数量', desc: '　', type: 'number'},
//        {code: 'cc.kysl', name: '可用数量', desc: ' ', type: 'number'},
        {code: 'yk', name: '盈亏', desc: ' ', type: 'money'},
        {code: 'cz', name: '', desc: ' ', type: 'string', width: '16px', tclass:'dirStyle'}
//        {code: 'cc.sz', name: '市值', desc: '　', type: 'money'}
//        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
    ];

    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    //五档是否显示
    $scope.ccsellfiveDivShowClick = function()
    {
        $scope.ccsellfiveDivShow = !$scope.ccsellfiveDivShow;
    }

    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        console.log("可用资金", _data);
        var arr = _data.money;
        $scope.cckyzj = parseFloat(arr.kyzj.toString());
        $scope.cczzc = parseFloat(arr.zzc.toString());
        $scope.cczsz = parseFloat(arr.zsz.toString());
        //$scope.ccljyk = parseFloat((parseFloat(arr.zzc.toString()) - parseFloat(arr.ljcrj.toString())).toFixed(2));
        //if($scope.ccljyk >0)
        //{
        //    $scope.flag = "1";
        //}
        //else if($scope.ccljyk <0)
        //{
        //    $scope.flag = "-1";
        //}
        //else
        //{
        //    $scope.flag = "0";
        //}
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        $scope.wtList = [];
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            //console.log("持仓",result)
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                $scope.ccljyk = parseFloat(result.ccyk.toString());
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = arr[i].dqj;
                        obj.yk = arr[i].fdyk;
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.ccquery = function()
    {
        //获取资产信息
        $scope.getccinfo();
        $scope.query();
    }
    $scope.ccquery();

    $scope.sellItemClick = function(_obj)
    {
        //console.log("maic")
        $scope.listShow = false;
        $scope.selectdestock = _obj;
        $scope.excstockcode = _obj.stockcodeall;
        $scope.wtjg = "";
        //$scope.wtjg = Number(_obj.dqj);
        //console.log("价格",_obj.dqj,  $scope.wtjg);
        $scope.kysl = _obj.kysl;
        $scope.queryhq(_obj.stockcode);

    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        console.log(stockcode);
        if(stockcode != null && stockcode != "" || stockcode != undefined)
        {

            var message = {};
            if (stockcode.length == 8) stockcode = stockcode.substring(2);
            if(stockcode.substr(0,2)== "00" || stockcode.substr(0,2) == "30" || stockcode.substr(0,1) == "2")
            {
                message['code'] = "sz"+stockcode;
            }
            else
            {
                message['code'] = "sh"+stockcode;
            }
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;
        }
    };

    //最大可用
    $scope.getmckyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.kysl  = _data.zdkm;
        }
    }

    $scope.getmckysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmaxcansell", message, $scope.getmckyslCallBack);

    }

    //股票行情
    $scope.sshqactionCallBack = function(_data)
    {
        console.log(_data)
        if (_data.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            if(_data.datalist.length==0)
            {
                return;
            }
            var result = _data.datalist[0];
            var obj = {};
            var buyvarr = result.bid;
            obj.buyv1 = Math.floor(Number(buyvarr[0].volume)/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1].volume)/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2].volume)/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3].volume)/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4].volume)/100)+'手';

            obj.buyp1 = Number(buyvarr[0].price).toFixed(2);
            obj.buyp2 = Number(buyvarr[1].price).toFixed(2);
            obj.buyp3 = Number(buyvarr[2].price).toFixed(2);
            obj.buyp4 = Number(buyvarr[3].price).toFixed(2);
            obj.buyp5 = Number(buyvarr[4].price).toFixed(2);


            var sellvarr = result.ask;
            obj.sellv1 = Math.floor(Number(sellvarr[0].volume)/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1].volume)/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2].volume)/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3].volume)/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4].volume)/100)+'手';

            obj.sellp1 = Number(sellvarr[0].price).toFixed(2);
            obj.sellp2 = Number(sellvarr[1].price).toFixed(2);
            obj.sellp3 = Number(sellvarr[2].price).toFixed(2);
            obj.sellp4 = Number(sellvarr[3].price).toFixed(2);
            obj.sellp5 = Number(sellvarr[4].price).toFixed(2);


            obj.stockcode = result.stockbasic.stockcode;
            obj.exchange = result.stockbasic.exchange;
            obj.lastprice = result.close;//最新价格
            obj.name = result.stockbasic.stockname;
            //$scope.kysl = "-";

            $scope.hq = obj;
            $scope.stockcodeall = $scope.hq.exchange + $scope.hq.stockcode;

            $scope.buysellhqintervalId = setInterval($scope.dscl, $scope.buysellhqintervalDuration);

            $scope.getmckysl();
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            //$scope.$apply();
        }
    }

    $scope.dscl = function()
    {
        $scope.buysellClearInterval();
        if($scope.excstockcode != null && $scope.excstockcode != "" && $scope.excstockcode != undefined)
        {
            //console.log("$scope.excstockcode",$scope.excstockcode);
            var message = {};
            message['code'] = $scope.excstockcode.toLowerCase();
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;

            if($scope.sellwtInfo != null)
            {
                if($scope.sellwtInfo.code == "Y")
                {
                    var message2 = {};
                    message2['account'] = $scope.childaccount;
                    message2['htbh'] = $scope.sellwtInfo.htbh;
                    ajaxService.sendMessage("sunflower.p_selectorder", message2, $scope.p_selectorderCallBack2) ;
                }
            }
        }

    }

    //查询委托状态
    $scope.p_selectorderCallBack2 = function(_data)
    {
        console.log("查询委托状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            if(arr.length>0)
            {
                $scope.sellwtInfo.wtsl = arr[0].wtsl;
                $scope.sellwtInfo.wtsj = arr[0].wtsj;
                $scope.sellwtInfo.cjsl = arr[0].cjsl;
                if(parseFloat(arr[0].wtjg) == 0)
                {
                    $scope.sellwtInfo.wtjg = "市价";
                }
                else
                {
                    $scope.sellwtInfo.wtjg = parseFloat(arr[0].wtjg).toFixed(2)+"元";
                }

                if(parseFloat($scope.sellwtInfo.cjsl) == 0)
                {
                    $scope.sellwtInfo.cjjg = "0.00元";
                }
                else
                {
                    $scope.sellwtInfo.cjjg = (parseFloat(arr[0].cjje)/parseFloat($scope.sellwtInfo.cjsl)).toFixed(2) + "元";
                }
                //$scope.sellwtInfo.cjsj = arr[0].cjsj;
            }
        }
    }

    $scope.limitsell = function() {
        $scope.sellwtInfo = null;
        if ($scope.excstockcode == null || $scope.excstockcode == "") {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        if ($scope.wtjg <= 0) {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtjg) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        if ($scope.wtsl <= 0 || $scope.wtsl == "" || $scope.wtsl == null) {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if(r.test($scope.wtsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if(decimaldigitsCheck($scope.wtjg.toString()) == false)
        {
            $scope.sellErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        //if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        //{
        //    $scope.sellErrorInfo = "请输入有效的卖出数量";
        //    return;
        //}
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            $scope.sellErrorInfo = "委托数量大于可用数量，请重新输入";
            return;
        }
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}
        $scope.sellErrorInfo = "";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.selectdestock.stockname + "(" + $scope.excstockcode + ")   " + $scope.wtsl + "股吗？";
        myConfirm(str, $scope.ccsellconfirm);
    }

    $scope.ccsellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.excstockcode.substring(2);
        message["exchange"] = $scope.excstockcode.substr(0, 2).toUpperCase();
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        console.log(message);

        ajaxService.sendMessage("sunflower.p_wt", message, function (result) {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.wtsl = 0;//委托数量
                $scope.sellwtInfo.wtsj = "";//委托时间
                $scope.sellwtInfo.cjsl = 0;//成交数量
                $scope.sellwtInfo.cjsj = "";//成交时间
                $scope.sellwtInfo.htbh = result.htbh;
                $scope.wtsl = "";
                $scope.kysl = "-";
            }
            else
            {
                $scope.sellwtInfo.info = result.op.info;
            }

        }, false);
    }

    //返回列表界面
    $scope.backtoSellList = function()
    {
        $scope.listShow = true;
        $scope.selectdestock = {};
        $scope.excstockcode = "";
        $scope.wtsl = "";
        $scope.query();
        $scope.buysellClearInterval();
        $scope.sellwtInfo = null;
    }

    //点击不显示手机弹出的键盘
    $scope.ccsellClosePopClick = function(){
    };
}
/**当日成交**/
function drcjCtrl($scope, ajaxService, $cookieStore)
{
    //var headerArray = [
    //    {code1: 'stockname', code2: 'cjsj', name:'成交时间' , type1: 'string', type2: 'shorttime'},
    //    {code1: 'cjjj', code2: '', name: '成交价' , type1: 'buypolicy', type2: ''},
    //    {code1: 'cjsl', code2: '', name: '成交量' , type1: 'number', type2: ''},
    //    {code1: 'side', code2: 'cjje', name: '成交额' , type1: 'exchangeflag', type2: 'money'}
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpcj.cjjj', name: '成交均价', desc: '　', type: 'buypolicy'},
//        {code: 'cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'}

        //{code: 'cjsj', name1: '成交时间',  name2: '代码3333', desc: '', type: 'shorttime'},
////        {code: 'gpcj.htbh', name: '合同编号', desc: ' ', type: 'number'},
////        {code: 'gpcj.cjbh', name: '成交编号', desc: ' ', type: 'number'},
////        {code: 'gpcj.productname', name: '产品名称', desc: '　', type: 'string'},
////        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpcj.cjjj', name: '成交均价', desc: '　', type: 'buypolicy'},
//        {code: 'cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'}
   //];
    //$scope.headers = [];
    //$scope.init = function ()
    //{
    //    for (var i = 0; i < headerArray.length; i++) {
    //        headerArray[i].id = i;
    //        //if (headerArray[i].code == $scope.orderClumn) {
    //        //    headerArray[i].desc = "↓";
    //        //} else {
    //        //    headerArray[i].desc = "";
    //        //}
    //        $scope.headers.push(headerArray[i]);
    //    }
    //};
    //$scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {
        $scope.wtList = [];
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        ajaxService.sendMessage("sunflower.p_selectcj", message, function (result) {
            console.log("当日成交", result);
            if (result.op.code == 'Y')
            {
                var arr = result.securitycjlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.cjsj = (arr[i].cjsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.cjjj = arr[i].cjjj;
                        obj.cjsl = arr[i].cjsl;
                        obj.side = arr[i].side;
                        obj.cjje = arr[i].cjje;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else
                {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.query();


}

/**当日委托**/
function drwtCtrl($scope, ajaxService, $cookieStore)
{
//    var headerArray = [
//        {code: 'wtsj', name: '委托时间', desc: '↓', type: 'shorttime'},
////        {code: 'gpwt.htbh', name: '合同编号', desc: ' ', type: 'number'},
////        {code: 'gpwt.productname', name: '产品名称', desc: '　', type: 'string'},
////        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpwt.wtjg', name: '委托价格', desc: '　', type: 'buypolicy'},
//        {code: 'wtsl', name: '委托数量', desc: '　', type: 'number'},
////        {code: 'gpwt.djje', name: '委托金额', desc: ' ', type: 'money'},
////        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
////        {code: 'gpwt.cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpwt.cjje', name: '成交金额', desc: '　', type: 'money'},
////        {code: 'gpwt.cdsl', name: '撤单数量', desc: '　', type: 'number'},
////        {code: 'gpwt.status', name: '委托状态', desc: '　', type: 'wtstatus'},
////        {code: 'gpwt.reason', name: '备注', desc: '　', type: 'string'}
//    ];
//    $scope.orderClumn = 'f_ljykbl';
//    $scope.headers = [];
//    $scope.init = function ()
//    {
//        for (var i = 0; i < headerArray.length; i++) {
//            headerArray[i].id = i;
//            if (headerArray[i].code == $scope.orderClumn) {
//                headerArray[i].desc = "↓";
//            } else {
//                headerArray[i].desc = "";
//            }
//            $scope.headers.push(headerArray[i]);
//        }
//    };
//    $scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];


    $scope.query = function () {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        ajaxService.sendMessage("sunflower.p_selectorder", message, function (result) {
            console.log("当日委托",result);
            if (result.op.code == 'Y') {
                var arr = result.securityorderlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtjg = arr[i].wtjg;
                        obj.wtsl = arr[i].wtsl;
                        obj.side = arr[i].side;
                        obj.status = arr[i].status;
                        obj.extra = arr[i].extra;
                        obj.htbh = arr[i].htbh;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

        });
    };

    $scope.query();

    //委托详情
    $scope.drwtItemClick = function(_obj)
    {
        //window.location.href = "transactionReturns.html"+"?account=" + $scope.childaccount + "&extra=" + _obj.extra + "&htbh=" + _obj.htbh + "&stockcode=" + _obj.stockcode + "&rmd=" + new Date().getTime();
        xinyuNewBrowser("transactionReturns.html"+"?account=" + $scope.childaccount + "&extra=" + _obj.extra + "&htbh=" + _obj.htbh + "&stockcode=" + _obj.stockcode + "&opentype=newwebview" + "&rmd=" + new Date().getTime());
    }
}

/**历史成交**/
function lscjCtrl($scope, ajaxService, $cookieStore)
{
    $scope.showList = false;//列表是否显示
    $scope.showNodata = false;//无数据
    $scope.isLoading = false;//加载中
    $scope.startDateValue = "";//开始日期
    $scope.endDateValue = "";//结束日期

    //$scope.wtList = [];
    //$scope.showList = false;
    //$scope.showNodata = false;
    //$scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {

        //alert("start:" + document.getElementById("startDate").value);

        //alert($scope.startDateValue + "   " +$scope.endDateValue);
        if($scope.startDateValue == "" ||  $scope.endDateValue == "")
        {
            myAlert("请先输入开始日期和结束日期");
            return;
        }
        if($scope.cheackDate2() == false)
        {
            myAlert("结束日期应大于开始日期且都应小于当前日期");
            return;
        }
        $scope.showList = false;
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];
        $scope.startday = $scope.getDateFull($scope.startDateValue);
        $scope.endday = $scope.getDateFull($scope.endDateValue);
        //alert("333   " + $scope.startday +  $scope.endday);
        var message = {};
        //message["page.pagesize"] = 'max';
        //message['page.pageno'] = "";
        message['account'] = $scope.childaccount;
        //message['combPositionId'] = "default";
        message["kssj"] = $scope.startday;
        message["jssj"] = $scope.endday;
        console.log($scope.startday, $scope.endday);
        ajaxService.sendMessage("sunflower.p_selecthiscj", message, function (result) {
            console.log("历史成交", result);
            if (result.op.code == 'Y')
            {
                var arr = result.hiscjlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.cjsj = (arr[i].cjsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        //obj.cjjj = parseFloat(parseFloat(arr[i].cjjj).toFixed(2));
                        obj.cjjj = arr[i].cjjj;
                        obj.cjsl = arr[i].cjsl;
                        obj.side = arr[i].side;
                        obj.cjje = arr[i].cjje;
                        console.log(obj.cjjj,obj.cjsl);
                        $scope.wtList.push(obj);
                    }
                    $scope.showList = true;
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else
                {
                    $scope.showList = true;
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }else {
                $scope.showList = true;
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.getDateFull = function(_str)
    {
        var yyyy = _str.getFullYear();
        var mm = _str.getMonth() + 1;
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        var dd = _str.getDate();
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }

        return yyyy + "" + mm + "" + dd;
    }

    //判断开始日期和结束日期
    $scope.cheackDate = function()
    {
        var mark = true;
        //alert("开始日期：" + $scope.startDateValue +  "   结束日期：" + $scope.endDateValue);
        try
        {
            var d1 = new Date($scope.startDateValue.replace(/-/g, "/"));
            var d2 = new Date($scope.endDateValue.replace(/-/g, "/"));
        }
        catch(e){}
        var today = new Date();
        if (Date.parse(d1) > Date.parse(today)) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if (Date.parse(d2) > Date.parse(today)) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if (Date.parse(d1) > Date.parse(d2)) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    //判断开始日期和结束日期
    $scope.cheackDate2 = function()
    {
        var mark = true;
        var today = new Date();
        if ($scope.startDateValue > today) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if ($scope.endDateValue > today) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if ($scope.startDateValue > $scope.endDateValue) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

}

/**历史委托**/
function lswtCtrl($scope, ajaxService, $cookieStore) {

    $scope.showList = false;//列表是否显示
    $scope.showNodata = false;//无数据
    $scope.isLoading = false;//加载中
    $scope.startDateValue = "";//开始日期
    $scope.endDateValue = "";//结束日期

    //var yourTime= "yyyy/mm/dd";
    //document.getElementById("startDate").attr('value',yourTime);

    $scope.query = function () {

        if($scope.startDateValue == "" ||  $scope.endDateValue == "")
        {
            myAlert("请先输入开始日期和结束日期");
            return;
        }
        if($scope.cheackDate2() == false)
        {
            myAlert("结束日期应大于开始日期且都应小于当前日期");
            return;
        }


        $scope.showList = false;
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];
        $scope.startday = $scope.getDateFull($scope.startDateValue);
        $scope.endday = $scope.getDateFull($scope.endDateValue);

        var message = {};
        //message["page.pagesize"] = 'max';
        //message['page.pageno'] = "";
        message['account'] = $scope.childaccount;
        //message['combPositionId'] = "default";
        message["kssj"] = $scope.startday;
        message["jssj"] = $scope.endday;
        console.log($scope.startday, $scope.endday, $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selecthisorder", message, function (result) {
            console.log("历史委托", result)
            if (result.op.code == 'Y') {
                var arr = result.orderlist;
                if (arr.length > 0)
                {
                    for (var i = 0; i < arr.length; i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0, 19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtjg = arr[i].wtjg;
                        obj.wtsl = arr[i].wtsl;
                        obj.side = arr[i].side;
                        obj.status = arr[i].status;
                        obj.extra = arr[i].extra;
                        obj.htbh = arr[i].htbh;
                        obj.qsday = arr[i].qsday;
                        $scope.wtList.push(obj)
                    }
                    $scope.showList = true;
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showList = true;
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            } else {
                $scope.showList = true;
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    //判断开始日期和结束日期
    $scope.cheackDate = function()
    {
        var mark = true;
        //alert("开始日期：" + $scope.startDateValue +  "   开始日期：" + $scope.endDateValue)
        var d1 = new Date($scope.startDateValue.replace(/-/g, "/"));
        var d2 = new Date($scope.endDateValue.replace(/-/g, "/"));
        //alert($scope.startDateValue.replace(/-/g, "/") + "  "  +$scope.endDateValue.replace(/-/g, "/"));
        var today = new Date();
        if (Date.parse(d1) > Date.parse(today)) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if (Date.parse(d2) > Date.parse(today)) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if (Date.parse(d1) > Date.parse(d2)) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    //判断开始日期和结束日期
    $scope.cheackDate2 = function()
    {
        var mark = true;
        var today = new Date();
        if ($scope.startDateValue > today) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if ($scope.endDateValue > today) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if ($scope.startDateValue > $scope.endDateValue) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    $scope.getDateFull = function(_str)
    {
        var yyyy = _str.getFullYear();
        var mm = _str.getMonth() + 1;
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        var dd = _str.getDate();
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }

        return yyyy + "" + mm + "" + dd;
    }

    //点击不显示手机弹出的信息
    $scope.lswtClosePopClick = function()
    {

    }

    $scope.lswtItemClick = function(_obj)
    {
        //window.location.href = "transactionReturns.html"+"?account=" + $scope.childaccount + "&extra=" + _obj.extra + "&htbh=" + _obj.htbh + "&stockcode=" + _obj.stockcode + "&qsday="+ _obj.qsday + "&rmd=" + new Date().getTime();
        xinyuNewBrowser("transactionReturns.html"+"?account=" + $scope.childaccount + "&extra=" + _obj.extra + "&htbh=" + _obj.htbh + "&stockcode=" + _obj.stockcode + "&qsday="+ _obj.qsday + "&opentype=newwebview" + "&rmd=" + new Date().getTime());
    }
}

/**历史资金流水**/
function lszjlsCtrl($scope, ajaxService, $cookieStore) {

    $scope.showList = false;//列表是否显示
    $scope.showNodata = false;//无数据
    $scope.isLoading = false;//加载中
    $scope.startDateValue = "";//开始日期
    $scope.endDateValue = "";//结束日期

    //var yourTime= "yyyy/mm/dd";
    //document.getElementById("startDate").attr('value',yourTime);

    $scope.query = function () {

        if($scope.startDateValue == "" ||  $scope.endDateValue == "")
        {
            myAlert("请先输入开始日期和结束日期");
            return;
        }
        if($scope.cheackDate2() == false)
        {
            myAlert("结束日期应大于开始日期且都应小于当前日期");
            return;
        }


        $scope.showList = false;
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];
        $scope.startday = $scope.getDateFull($scope.startDateValue);
        $scope.endday = $scope.getDateFull($scope.endDateValue);

        var message = {};
        //message["page.pagesize"] = 'max';
        //message['page.pageno'] = "";
        message['account'] = $scope.accountShowValue;
        //message['combPositionId'] = "default";
        message["kssj"] = $scope.startday;
        message["jssj"] = $scope.endday;
        console.log($scope.startday, $scope.endday, $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selectmoneyflows", message, function (result) {
            console.log("历史资金流水", result)
            if (result.op.code == 'Y') {
                var arr = result.moneyflowlist;
                if (arr.length > 0)
                {
                    for (var i = 0; i < arr.length; i++)
                    {
                        var obj = {};
                        obj.fsje = parseFloat(arr[i].fsje.toString());
                        if(obj.fsje > 0)
                        {
                            obj.typeStr = "银行转证券";
                        }
                        else
                        {
                            obj.typeStr = "证券转银行";
                            obj.fsje = -1*obj.fsje;
                        }
                        obj.status = "成功";
                        obj.date = arr[i].fssj.toString();
                        //obj.date = (arr[i].date.toString()).substr(0, 19);
                        //obj.type = arr[i].type;
                        //obj.zzje = arr[i].zzje;
                        //obj.status = arr[i].status;
                        $scope.wtList.push(obj)
                    }
                    $scope.showList = true;
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showList = true;
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            } else {
                $scope.showList = true;
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    //判断开始日期和结束日期
    $scope.cheackDate = function()
    {
        var mark = true;
        //alert("开始日期：" + $scope.startDateValue +  "   开始日期：" + $scope.endDateValue)
        var d1 = new Date($scope.startDateValue.replace(/-/g, "/"));
        var d2 = new Date($scope.endDateValue.replace(/-/g, "/"));
        //alert($scope.startDateValue.replace(/-/g, "/") + "  "  +$scope.endDateValue.replace(/-/g, "/"));
        var today = new Date();
        if (Date.parse(d1) > Date.parse(today)) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if (Date.parse(d2) > Date.parse(today)) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if (Date.parse(d1) > Date.parse(d2)) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    //判断开始日期和结束日期
    $scope.cheackDate2 = function()
    {
        var mark = true;
        var today = new Date();
        if ($scope.startDateValue > today) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if ($scope.endDateValue > today) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if ($scope.startDateValue > $scope.endDateValue) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    $scope.getDateFull = function(_str)
    {
        var yyyy = _str.getFullYear();
        var mm = _str.getMonth() + 1;
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        var dd = _str.getDate();
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }

        return yyyy + "" + mm + "" + dd;
    }
}

