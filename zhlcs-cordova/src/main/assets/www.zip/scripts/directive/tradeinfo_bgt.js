//function tradeinfobgt()
//{
//    return {
//        restrict: 'E',
//        templateUrl: 'html/trade_info_bgt.html',
//        controller:['$scope','ajaxService','$cookieStore',tradeinfobgtCtrl],
//        //template: '<span>Hi there</span>',
//        replace: true,
//        transclude: true
//    };
//}

function getEmptyHQ()
{
    var obj = {};
    obj.buyv1 = "-";
    obj.buyv2 = "-";
    obj.buyv3 = "-";
    obj.buyv4 = "-";
    obj.buyv5 = "-";
    obj.sellv1 = "-";
    obj.sellv2 = "-";
    obj.sellv3 = "-";
    obj.sellv4 = "-";
    obj.sellv5 = "-";

    obj.buyp1 = "-";
    obj.buyp2 = "-";
    obj.buyp3 = "-";
    obj.buyp4 = "-";
    obj.buyp5 = "-";

    obj.sellp1 = "-";
    obj.sellp2 = "-";
    obj.sellp3 = "-";
    obj.sellp4 = "-";
    obj.sellp5 = "-";

    obj.stockcode = "";
    obj.exchange = "";
    obj.lastprice = "-";
    obj.name = "";
    return obj;
}

function tradeinfobgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.zhmianShow = true;//主界面
    $scope.tradeType = "buy";//交易的区分

    //侦听获取参数
    $scope.$on("setParameters", function(e, _data) {
        console.log("tradeinfo获取参数",_data.account);
        $scope.childaccount = _data.account;
    });
    console.log("tradeinfo侦听");
    //向父对象说明已经侦听，可以接受入参
    var cstr  = {"caption": "tradeinfo"};
    $scope.$emit("getParameters", cstr);
    //console.log("交易查询账号", $scope.childaccount);

    //显示查询/交易
    $scope.wgttradeurlChange = function(_str, str2)
    {
        //console.log(43243);
        //console.log(str2);
        $scope.urlShow = true;
        $scope.zhmianShow = false;
        window.location.href = _str;
        //console.log("str2", str2);
        $scope.tradeType = str2;
        gotoUp();

    }

    $scope.backtoParent = function()
    {
        $scope.urlShow = false;
        $scope.zhmianShow = true;
        window.location.href = "#/empty";
    }
}

//空白
function emptyCtrl($scope, ajaxService, $cookieStore) {
}

//买卖
function buysellwgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.dqwtsjh = "";//当前委托随机号
    $scope.marketbuyMark = false;//是否市价买入
    $scope.marketsellMark = false;//是否市价卖出
    $scope.buyShow = true;//买入显示
    $scope.sellShow = false;//卖出显示
    $scope.inputstockShow = true;//显示输入框并可操作
    $scope.hq = {};
    $scope.wtjg;
    $scope.wtsl;
    $scope.kysl;
    $scope.mcjg;//卖出价格
    $scope.mcsl;//卖出数量
    $scope.mckysl;//卖出可用数量
    $scope.ddlx = "i";//报价方式
    $scope.buykyzj = 0;//可用资金
    $scope.zdkmShow = false;//最大可买是否显示
    $scope.flashbuyfiveDivShow = false;
    $scope.wtInfo = null;//委托信息
    $scope.sellwtInfo = null;//卖出委托信息
    $scope.stockcodeall = "";
    $scope.buyErrorInfo = "";//买入错误提示
    $scope.sellErrorInfo = "";//卖出错误提示

    $scope.buysellhqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.buysellhqintervalId;
    $scope.tradeallShow = true;//买卖
    $scope.gtqkDiv = false;//跟投情况

    $scope.gtqkListArray = [];
    $scope.dqzgObj = null;//当前账户

    $scope.buySearchStockListArray = [];
    $scope.buygpssShow = false;

    $scope.sellSearchStockListArray = [];
    $scope.sellgpssShow = false;

    //去除
    $scope.buysellClearInterval = function () {
        if ($scope.buysellhqintervalId != undefined) {
            clearInterval($scope.buysellhqintervalId);
        }
    }

    //买卖切换
    $scope.tradetabClick = function(_str)
    {
        if(_str == "buy")
        {
            $scope.buyShow = true;//买入显示
            $scope.sellShow = false;//卖出显示
        }
        else
        {
            $scope.buyShow = false;//买入显示
            $scope.sellShow = true;//卖出显示

            if($scope.stockcodeall != "")//卖出界面
            {
                $scope.getmckysl();
            }
        }
        if($scope.gtqkDiv)
        {
            $scope.tradeallShow = true;
            $scope.gtqkDiv = false;//跟投情况
        }
    }
    $scope.buysellinit = function()
    {
        //console.log("$scope.tradeType", $scope.tradeType);
        $scope.tradetabClick($scope.tradeType)

    }
    $scope.buysellinit();

    //点击不显示手机弹出的键盘
    $scope.buysellClosePopClick = function(){
        $scope.buySearchStockListArray = [];
    };

    $scope.marketbuyChoose = function()
    {
        //console.log($scope.marketbuyMark);
        $scope.marketbuyMark = !$scope.marketbuyMark;
        $scope.kysl = "-";
        if($scope.stockcodeall != "" && $scope.marketbuyMark)
        {
            $scope.wtjg = "";
            $scope.getkysl();
        }
    }

    $scope.marketsellChoose = function()
    {
        //console.log($scope.marketsellMark);
        $scope.marketsellMark = !$scope.marketsellMark;
        if($scope.stockcodeall != "" && $scope.marketsellMark)
        {
            $scope.mcjg = "";
        }

    }

    $scope.selectsecuritymoneyactionCallBack = function(_data)
    {
        var arr = _data.moneylist;
        if(arr.length>0)
        {
            $scope.buykyzj = parseFloat(arr[0].kyzj.toString());
            //console.log("可用资金", $scope.kyzj);
        }
    }

    //最大可用
    $scope.getkyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.kysl  = _data.kmsl;
        }
    }

    $scope.getkysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['exchange'] = $scope.stockcodeall.substring(0,2).toUpperCase();
        message['account'] = $scope.childaccount;
        if($scope.marketbuyMark)//市价
        {
            message['price'] = 0;
            //console.log("price1：", message['price']);
        }
        else
        {
            message['price'] = $scope.wtjg;
            //console.log("price2：", message['price']);
        }
        //console.log("委托价格：" ,  message['stockcode'], message['exchange'], message['account'], message['price']);
        ajaxService.sendMessage("sunflower.p_getzdkm", message, $scope.getkyslCallBack);

    }

    $scope.wtjgChange = function(_value)
    {
        //console.log("wtjgChange", $scope.wtjg);
        $scope.wtjg = _value;
        if(_value != "" && Number(_value) !=0)
        {
            $scope.getkysl();
        }
        else
        {
            $scope.kysl = "-";
        }
    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        //console.log("11111", stockcode);
        //alert("stockcode"  + stockcode);
        if(stockcode != null && stockcode != "" && stockcode != undefined)
        {
            var message = {};
            if (stockcode.length == 8) stockcode = stockcode.substring(2);
            //if(stockcode.substr(0,2) == "00" || stockcode.substr(0,2) == "30" || stockcode.substr(0,1) == "2")
            //{
            //    message['code'] = "sz"+stockcode;
            //}
            //else
            //{
            //    message['code'] = "sh"+stockcode;
            //}
            message['code'] = $scope.hq.exchange + stockcode;
            //alert("查询：" + stockcode);
            //ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack);
            $scope.buysellClearInterval();
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;
            $scope.buysellhqintervalId = setInterval($scope.dscl, $scope.buysellhqintervalDuration);
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.mcjg = "";
            $scope.mckysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    };

    $scope.gpdmchange = function()
    {
        //alert("change");
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.wtjg = "";
        //    $scope.kysl = "-";
        //    $scope.zdkmShow = false;
        //    //$scope.$apply();
        //}
        //if($scope.wtInfo != null)
        //{
        //    $scope.wtInfo = null;
        //    $scope.gtqkListArray = [];
        //}
        //$scope.stockcodeall = "";

        if($scope.hq.stockcode != "")
        {
            $scope.buygpssShow = true;
            $scope.buycheckContent();
        }
        else
        {
            console.log(12123);
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            console.log(4243);
        }
        if($scope.wtInfo != null)
        {
            $scope.wtInfo = null;
            $scope.gtqkListArray = [];
        }
        $scope.stockcodeall = "";
    }

    $scope.buycheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.buysearchStockCallBack);
    }

    //搜索股票返回
    $scope.buysearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.buySearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.buySearchStockListArray = arr;
                    if($scope.buySearchStockListArray.length == 1)
                    {
                        $scope.setbuyonegp();
                    }
                }
                else {
                    $scope.buySearchStockListArray = [];
                    $scope.buygpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
    }

    $scope.setbuyonegp = function()
    {
        if($scope.buySearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.buySearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.buySearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.buySearchStockListArray[0].exchange).toLowerCase();
                $scope.buygpssShow = false;
                $scope.queryhq($scope.buySearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.buycheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.buygpssShow = false;
        $scope.queryhq(_obj.gpdm);

    }

    //股票行情
    $scope.sshqactionCallBack = function(_data)
    {
        console.log("行情查询返回：" ,_data);
        //alert("查询返回：" + _data.code.toString());
        if (_data.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            //alert("查询返回：" + result.buyv.toString());
            if(_data.datalist.length==0)
            {
                return;
            }
            var result = _data.datalist[0];
            var obj = {};
            var buyvarr = result.bid;
            obj.buyv1 = Math.floor(Number(buyvarr[0].volume)/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1].volume)/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2].volume)/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3].volume)/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4].volume)/100)+'手';

            obj.buyp1 = Number(buyvarr[0].price).toFixed(2);
            obj.buyp2 = Number(buyvarr[1].price).toFixed(2);
            obj.buyp3 = Number(buyvarr[2].price).toFixed(2);
            obj.buyp4 = Number(buyvarr[3].price).toFixed(2);
            obj.buyp5 = Number(buyvarr[4].price).toFixed(2);


            var sellvarr = result.ask;
            obj.sellv1 = Math.floor(Number(sellvarr[0].volume)/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1].volume)/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2].volume)/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3].volume)/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4].volume)/100)+'手';

            obj.sellp1 = Number(sellvarr[0].price).toFixed(2);
            obj.sellp2 = Number(sellvarr[1].price).toFixed(2);
            obj.sellp3 = Number(sellvarr[2].price).toFixed(2);
            obj.sellp4 = Number(sellvarr[3].price).toFixed(2);
            obj.sellp5 = Number(sellvarr[4].price).toFixed(2);

            obj.stockcode = result.stockbasic.stockcode;
            obj.exchange = result.stockbasic.exchange;
            obj.lastprice = result.close;//最新价格
            obj.name = result.stockbasic.stockname;

            //if(obj.name != null && obj.name != "" && obj.name != undefined)
            //{
            //    $scope.inputstockShow = false;
            //}

            //console.log("交易所", obj.exchange);

            $scope.hq = obj;
            $scope.stockcodeall = $scope.hq.exchange + $scope.hq.stockcode;
            //$scope.wtjg = Number($scope.hq.lastprice);

            $scope.zdkmShow = true;
            //取可用数量
            if($scope.marketbuyMark && $scope.buyShow)
            {
                $scope.getkysl();
            }
            if($scope.sellShow)//卖出界面
            {
                $scope.getmckysl();
            }
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    }

    $scope.dscl = function()
    {
        //$scope.buysellClearInterval();
        if($scope.stockcodeall != null && $scope.stockcodeall != "" && $scope.stockcodeall != undefined)
        {
            var message = {};
            message['code'] = $scope.stockcodeall;
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;

            if($scope.wtInfo != null)
            {
                if($scope.wtInfo.code == "Y")
                {
                    var message2 = {};
                    message2['account'] = $scope.childaccount;
                    message2['extra'] =  $scope.dqwtsjh;
                    //console.log(message['account'],message['extra']);

                    ajaxService.sendMessage("sunflower.p_selectbatchorder", message2, $scope.buygetcjhbCallBack);
                }
            }

            if($scope.sellwtInfo != null)
            {
                if($scope.sellwtInfo.code == "Y")
                {
                    var message2 = {};
                    message2['account'] = $scope.childaccount;
                    message2['extra'] =  $scope.dqwtsjh;
                    //console.log(message['account'],message['extra']);

                    ajaxService.sendMessage("sunflower.p_selectbatchorder", message2, $scope.sellgetcjhbCallBack);
                }
            }
        }

    }

    $scope.buygetcjhbCallBack = function(_data)
    {
        console.log("查询跟投状态", _data);
        var arr = _data.securityorderlist;
        if(arr.length>0)
        {
            var mainorderobj = arr[0].mainorder;
            $scope.wtInfo.wtsl = mainorderobj.wtsl;
            $scope.wtInfo.wtsj = mainorderobj.wtsj;
            $scope.wtInfo.cjsl = mainorderobj.cjsl;
            if(parseFloat(mainorderobj.wtjg) == 0)
            {
                $scope.wtInfo.wtjg = "市价";
            }
            else
            {
                $scope.wtInfo.wtjg = parseFloat(mainorderobj.wtjg).toFixed(2)+"元";
            }

            if(parseFloat($scope.wtInfo.cjsl) == 0)
            {
                $scope.wtInfo.cjjg = "0.00元";
            }
            else
            {
                $scope.wtInfo.cjjg = (parseFloat(mainorderobj.cjje)/parseFloat($scope.wtInfo.cjsl)).toFixed(2) + "元";
            }

            var arr2 = arr[0].gentouorderlist;
            if($scope.gtqkListArray.length == 0)
            {
                //console.log("length0");
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.userid = arr2[i].user.user.f_id;
                    obj.headurl = arr2[i].user.user.f_head;
                    obj.name = arr2[i].user.user.f_nickname;
                    obj.wtsl = arr2[i].wtsl;
                    obj.wtsj = arr2[i].wtsj.toString().substr(0,10);
                    obj.cjsl = arr2[i].cjsl;
                    obj.account = arr2[i].account;
                    if(parseFloat(arr2[i].wtjg) == 0)
                    {
                        obj.wtjg = "市价";
                    }
                    else
                    {
                        obj.wtjg = parseFloat(arr2[i].wtjg).toFixed(2)+"元";
                    }

                    if(parseFloat(obj.cjsl) == 0)
                    {
                        obj.cjjg = "0.00元";
                    }
                    else
                    {
                        obj.cjjg = (parseFloat(arr2[i].cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }
                    $scope.gtqkListArray.push(obj);
                }
            }
            else
            {
                //console.log("length不为0", $scope.gtqkListArray.length);
                for(var i = 0;i<arr2.length;i++)
                {
                    for(var j = 0;j<$scope.gtqkListArray.length;j++)
                    {
                        if($scope.gtqkListArray[j].account == arr2[i].account)
                        {
                            $scope.gtqkListArray[j].wtsl = arr2[i].wtsl;
                            $scope.gtqkListArray[j].wtsj = arr2[i].wtsj.toString().substr(0,10);
                            $scope.gtqkListArray[j].cjsl = arr2[i].cjsl;
                            $scope.gtqkListArray[j].cjje = arr2[i].cjje;

                            if(parseFloat($scope.gtqkListArray[j].cjsl) == 0)
                            {
                                $scope.gtqkListArray[j].cjjg = "0.00元";
                            }
                            else
                            {
                                $scope.gtqkListArray[j].cjjg = (parseFloat($scope.gtqkListArray[j].cjje)/parseFloat(arr2[i].cjsl)).toFixed(2) + "元";
                            }

                            //console.log("2222222222", arr2[i].cjsl, $scope.gtqkListArray[j].cjje, $scope.gtqkListArray[j].cjjg);
                            break;
                        }
                    }
                }
            }
        }

    }

    $scope.sellgetcjhbCallBack = function(_data)
    {
        console.log("查询跟投状态", _data);
        var arr = _data.securityorderlist;
        if(arr.length>0)
        {
            var mainorderobj = arr[0].mainorder;
            $scope.sellwtInfo.wtsl = mainorderobj.wtsl;
            $scope.sellwtInfo.wtsj = mainorderobj.wtsj;
            $scope.sellwtInfo.cjsl = mainorderobj.cjsl;
            if(parseFloat(mainorderobj.wtjg) == 0)
            {
                $scope.sellwtInfo.wtjg = "市价";
            }
            else
            {
                $scope.sellwtInfo.wtjg = parseFloat(mainorderobj.wtjg).toFixed(2)+"元";
            }

            if(parseFloat($scope.sellwtInfo.cjsl) == 0)
            {
                $scope.sellwtInfo.cjjg = "0.00元";
            }
            else
            {
                $scope.sellwtInfo.cjjg = (parseFloat(mainorderobj.cjje)/parseFloat($scope.sellwtInfo.cjsl)).toFixed(2) + "元";
            }

            var arr2 = arr[0].gentouorderlist;
            if($scope.gtqkListArray.length == 0)
            {
                //console.log("length0");
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.userid = arr2[i].user.user.f_id;
                    obj.headurl = arr2[i].user.user.f_head;
                    obj.name = arr2[i].user.user.f_nickname;
                    obj.wtsl = arr2[i].wtsl;
                    obj.wtsj = arr2[i].wtsj.toString().substr(0,10);
                    obj.cjsl = arr2[i].cjsl;
                    obj.account = arr2[i].account;
                    if(parseFloat(arr2[i].wtjg) == 0)
                    {
                        obj.wtjg = "市价";
                    }
                    else
                    {
                        obj.wtjg = parseFloat(arr2[i].wtjg).toFixed(2)+"元";
                    }

                    if(parseFloat(obj.cjsl) == 0)
                    {
                        obj.cjjg = "0.00元";
                    }
                    else
                    {
                        obj.cjjg = (parseFloat(arr2[i].cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }
                    $scope.gtqkListArray.push(obj);
                }
            }
            else
            {
                //console.log("length不为0");
                for(var i = 0;i<arr2.length;i++)
                {
                    for(var j = 0;j<$scope.gtqkListArray.length;j++)
                    {
                        if($scope.gtqkListArray[j].account == arr2[i].account)
                        {
                            $scope.gtqkListArray[j].wtsl = arr2[i].wtsl;
                            $scope.gtqkListArray[j].wtsj = arr2[i].wtsj.toString().substr(0,10);
                            $scope.gtqkListArray[j].cjsl = arr2[i].cjsl;
                            $scope.gtqkListArray[j].cjje = arr2[i].cjje;

                            if(parseFloat($scope.gtqkListArray[j].cjsl) == 0)
                            {
                                $scope.gtqkListArray[j].cjjg = "0.00元";
                            }
                            else
                            {
                                $scope.gtqkListArray[j].cjjg = (parseFloat($scope.gtqkListArray[j].cjje)/parseFloat(arr2[i].cjsl)).toFixed(2) + "元";
                            }
                            break;
                        }
                    }
                }
            }
        }

    }

    //买入
    $scope.buyClick = function()
    {
        $scope.buyErrorInfo = "";
        if($scope.marketbuyMark)//市价买入
        {
            $scope.marketbuy();
        }
        else
        {
            $scope.limitbuy();
        }
    }

    $scope.limitbuy = function(obj)
    {
        //console.log("委托数量",$scope.wtsl);
        $scope.wtInfo = null;
        $scope.gtqkListArray = [];
        //console.log($scope.wtInfo);
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl))
        {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        if(r.test($scope.wtjg) == false)
        {
            $scope.buyErrorInfo = "请输入有效的委托价格";
            return;
        }
        if(decimaldigitsCheck($scope.wtjg.toString()) == false)
        {
            $scope.buyErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        //if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        //{
        //    $scope.buyErrorInfo = "请输入有效的委托价格";
        //    return;
        //}
        $scope.buyErrorInfo = "";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        // var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        myConfirm(str, $scope.buyconfirm)//确定买入
    }

    $scope.buyconfirm = function()
    {
        console.log("buyconfirm");
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();
        message["ddlx"] = 'limit';
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtInfo.opwtcode = "Y";//委托成功
                $scope.wtInfo.wtsl = 0;//委托数量
                $scope.wtInfo.wtsj = "";//委托时间
                $scope.wtInfo.cjsl = 0;//成交数量
                $scope.wtInfo.cjsj = "";//成交时间
                $scope.wtInfo.htbh = result.htbh;
                $scope.wtInfo.xdwtsl = $scope.wtsl;
                $scope.wtsl = 0;
                //$scope.getkysl();
            }
            else
            {
                $scope.wtInfo.opwtcode = "N";//委托成功
                $scope.wtInfo.info = result.op.info;
            }
        }, false);
    }

    //买卖五档的显示
    $scope.flashbuyfiveDivShowClick = function()
    {
        $scope.flashbuyfiveDivShow = !$scope.flashbuyfiveDivShow;
    }

    //市价买入
    $scope.marketbuy = function()
    {
        $scope.wtInfo = null;
        $scope.gtqkListArray = [];
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        $scope.buyErrorInfo = "";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        myConfirm(str, $scope.marketbuyconfirm)
    };

    $scope.marketbuyconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log("买入", message)

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtInfo.opwtcode = "Y";//委托成功
                $scope.wtInfo.wtsl = 0;//委托数量
                $scope.wtInfo.wtsj = "";//委托时间
                $scope.wtInfo.cjsl = 0;//成交数量
                $scope.wtInfo.cjsj = "";//成交时间
                $scope.wtInfo.htbh = result.htbh;
                $scope.wtInfo.xdwtsl = $scope.wtsl;
                $scope.wtsl = 0;
                $scope.getkysl();
            }
            else
            {
                $scope.wtInfo.opwtcode = "N";//委托成功
                $scope.wtInfo.info = result.op.info;
            }
        }, false);
    }

    //卖出股票代码change
    $scope.sellgpdmchange = function()
    {
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.mcjg = "";
        //    $scope.mckysl = "-";
        //}
        if($scope.hq.stockcode != "")
        {
            $scope.sellgpssShow = true;
            $scope.sellcheckContent();
        }
        else
        {
            //console.log(12123);
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.mcjg = "";
            $scope.mckysl = "-";
            console.log(4243);
        }
        if($scope.sellwtInfo != null)
        {
            $scope.sellwtInfo = null;
            $scope.gtqkListArray = [];
        }
        $scope.stockcodeall = "";
    }

    $scope.sellcheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.sellsearchStockCallBack);
    }

    //搜索股票返回
    $scope.sellsearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.sellSearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.sellSearchStockListArray = arr;
                    if($scope.sellSearchStockListArray.length == 1)
                    {
                        $scope.setsellonegp();
                    }
                }
                else {
                    $scope.sellSearchStockListArray = [];
                    $scope.sellgpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
    }

    $scope.setsellonegp = function()
    {
        if($scope.sellSearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.sellSearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.sellSearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.sellSearchStockListArray[0].exchange).toLowerCase();
                $scope.sellgpssShow = false;
                $scope.queryhq($scope.sellSearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.sellcheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.sellgpssShow = false;
        $scope.queryhq(_obj.gpdm);
    }


    //最大可用
    $scope.getmckyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.mckysl  = _data.zdkm;
        }
    }

    $scope.getmckysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmaxcansell", message, $scope.getmckyslCallBack);

    }

    $scope.mcjgChange = function(_value)
    {
        $scope.mcjg = _value;
    }

    $scope.sellClick = function()
    {
        $scope.sellErrorInfo = "";
        if($scope.marketsellMark)//市价卖出
        {
            $scope.marketsell();
        }
        else
        {
            $scope.limitsell();
        }
    }

    $scope.limitsell = function()
    {
        $scope.sellwtInfo = null;
        $scope.gtqkListArray = [];
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcjg<=0)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }
        if(r.test($scope.mcjg) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        //if($scope.mcjg.toString().length>0 && $scope.mcjg.toString().substr(0,1) == "0")
        //{
        //    $scope.sellErrorInfo = "请输入有效的卖出价格";
        //    return;
        //}
        if(decimaldigitsCheck($scope.mcjg.toString()) == false)
        {
            $scope.sellErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        $scope.sellErrorInfo = "";
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.sellconfirm);

    }

    $scope.sellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = $scope.mcjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        console.log(message);

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.opwtcode = "Y";//委托成功
                $scope.sellwtInfo.wtsl = 0;//委托数量
                $scope.sellwtInfo.wtsj = "";//委托时间
                $scope.sellwtInfo.cjsl = 0;//成交数量
                $scope.sellwtInfo.cjsj = "";//成交时间
                $scope.sellwtInfo.htbh = result.htbh;
                $scope.sellwtInfo.xdmcsl = $scope.mcsl;
                $scope.mcsl = "";
                $scope.mckysl = "-";
            }
            else
            {
                $scope.sellwtInfo.opwtcode = "N";//委托成功
                $scope.sellwtInfo.info = result.op.info;
            }

        }, false);
    }

    //市价卖出
    $scope.marketsell = function()
    {
        $scope.sellwtInfo = null;
        $scope.gtqkListArray = [];
        //console.log($scope.excstockcode)
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }
        $scope.sellErrorInfo = "";
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.marketsellconfirm);
    }

    $scope.marketsellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        console.log(message);

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.opwtcode = "Y";//委托成功
                $scope.sellwtInfo.wtsl = 0;//委托数量
                $scope.sellwtInfo.wtsj = "";//委托时间
                $scope.sellwtInfo.cjsl = 0;//成交数量
                $scope.sellwtInfo.cjsj = "";//成交时间
                $scope.sellwtInfo.htbh = result.htbh;
                $scope.sellwtInfo.xdmcsl = $scope.mcsl;
                $scope.mcsl = "";
                $scope.mckysl = "-";
                $scope.getmckysl();
            }
            else
            {
                $scope.sellwtInfo.opwtcode = "N";//委托成功
                $scope.sellwtInfo.info = result.op.info;
            }
        }, false);
    }

    //查看跟投
    $scope.gotockgt = function()
    {
        $scope.tradeallShow = false;
        $scope.gtqkDiv = true;//跟投情况

        $scope.dqzgObj = {};
        //$scope.dqzgObj.headurl = decodeURIComponent($cookieStore.get('iconurl'));
        //$scope.dqzgObj.name = decodeURIComponent($cookieStore.get('nickname'));

        var localStorage = window.localStorage;
        $scope.dqzgObj.headurl = decodeURIComponent(localStorage.getItem("iconurl"));
        $scope.dqzgObj.name = decodeURIComponent(localStorage.getItem("nickname"));
    }


    $scope.backtradeClick = function()
    {
        $scope.tradeallShow = true;
        $scope.gtqkDiv = false;//跟投情况
        $scope.gtqkListArray = [];
    }

    $scope.buysellbacktoParent = function()
    {
        $scope.buysellClearInterval();
        $scope.backtoParent();
    }
}


/**撤单**/
function cancellationCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("i do,i do it");
    $scope.cxObj = null;//单个选择的撤销
    $scope.cancellationtsInfo = "";
    $scope.cancelMark = true;//是否可以进行撤销操作
    $scope.index = 0;//撤单位置
    var headerArray = [
        {code: 'wtsj', name: '委托时间', desc: '↓', type: 'shorttime'},
//        {code: 'gpwt.htbh', name: '合同编号', desc: ' ', type: 'number'},
//        {code: 'gpwt.productname', name: '产品名称', desc: '　', type: 'string'},
        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'gpwt.side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
//        {code: 'gpwt.wtjg', name: '委托价格', desc: '　', type: 'buypolicy'},
        {code: 'wtsl', name: '委托数量', desc: '　', type: 'number'}
//        {code: 'gpwt.djje', name: '委托金额', desc: ' ', type: 'money'},
//        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
//        {code: 'gpwt.cjsl', name: '成交数量', desc: '　', type: 'number'},
//        {code: 'gpwt.cjje', name: '成交金额', desc: '　', type: 'money'},
//        {code: 'gpwt.cdsl', name: '撤单数量', desc: '　', type: 'number'},
//        {code: 'gpwt.status', name: '委托状态', desc: '　', type: 'wtstatus'},
//        {code: 'gpwt.reason', name: '备注', desc: '　', type: 'string'}
    ];
    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {
        //$scope.cancellationtsInfo = "";
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        ajaxService.sendMessage("sunflower.p_selectorder", message, function (result) {
            $scope.cancellationtsInfo = "";
            $scope.wtList = [];
            console.log("撤单查询当日委托",result);
            if (result.op.code == 'Y')
            {
                var arr = result.securityorderlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtsl = arr[i].wtsl;
                        obj.htbh = arr[i].htbh;
                        obj.extra = arr[i].extra.toString();
                        if(arr[i].status.toString() == "2" || arr[i].status.toString() == "7")
                        {
                            $scope.wtList.push(obj);
                        }
                    }

                    if($scope.wtList.length>0)
                    {
                        $scope.showNodata = false;
                        $scope.isLoading = false;
                    }
                    else
                    {
                        $scope.showNodata = true;
                        $scope.isLoading = false;
                    }
                }
                else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

        });
    };

    $scope.query();

    $scope.selectAllWt = false;
    $scope.chooseAllwt = function () {
        $scope.selectAllWt = !$scope.selectAllWt;

        if ($scope.selectAllWt)
        {
            $scope.htbhlist = [];
            for (var i = 0; i < $scope.wtList.length; i++)
            {
                //$scope.htbhlist.push($scope.wtList[i]['htbh']);
                $scope.htbhlist.push($scope.wtList[i]);
            }
        }
        else
        {
            $scope.htbhlist = [];
        }

    }

    $scope.choosewt = function (_obj) {
//        id = Number(id);
        var id = _obj.htbh;
        var idx = $scope.htbhlist.indexOf(id);
        // is currently selected
        if (idx > -1) {
            $scope.htbhlist.splice(idx, 1);
        }
        // is newly selected
        else {
            $scope.htbhlist.push(_obj);
        }
    }

    //撤销
    $scope.cancelWt = function ()
    {
        if($scope.cancelMark)
        {
            $scope.index = 0;
            $scope.Msgarr = [];
            if ($scope.htbhlist.length == 0)
            {
                $scope.cancellationtsInfo = "请选择委托";
                return;
            }
            var str = "确定撤销所选中的委托吗？";
            //console.log($scope.htbhlist.length);
            myConfirm(str, $scope.cancelconfirm);//确定撤销
        }
    }

    $scope.cancelconfirm = function()
    {
        layer.closeAll();
        $scope.cancelMark = false;
        $scope.cancelall();
    }

    $scope.cancelall = function()
    {
        $scope.cancellationtsInfo = "撤单中，请稍候...";
        var message = {};
        message['account'] = $scope.childaccount;
        message['htbh'] = $scope.htbhlist[$scope.index].htbh;
        message['extra'] = $scope.htbhlist[$scope.index].extra;
        message['stockcode'] = $scope.htbhlist[$scope.index].stockcode;
        ajaxService.sendMessage("sunflower.p_cancelorder", message, $scope.cancelactionCallBack);
    }

    $scope.cancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            var obj = {};
            obj.hybh = $scope.htbhlist[$scope.index].htbh;
            obj.info = "撤单发送成功";
            $scope.Msgarr.push(obj);
        }
        else
        {
            var obj = {};
            obj.hybh = $scope.htbhlist[$scope.index].htbh;
            obj.info = "撤单发送失败，" + result.op.info;
            $scope.Msgarr.push(obj);
        }
        $scope.index = $scope.index+1;
        if($scope.index < $scope.htbhlist.length)
        {
            $scope.cancelall();
        }
        else
        {
            var str = "";
            for(var i = 0;i<$scope.Msgarr.length;i++)
            {
                if(i == 0)
                {
                    str = "合约  " + $scope.Msgarr[i].hybh + "  " + $scope.Msgarr[i].info;
                }
                else
                {
                    str = str + "； 合约  " + $scope.Msgarr[i].hybh + "  " + $scope.Msgarr[i].info;
                }
            }
            //alert(str);
            $scope.cancellationtsInfo = str;
            $scope.Msgarr = [];
            $scope.index = 0;
            $scope.query();
            $scope.cancelMark = true;
        }
    }

    $scope.cancelOneWt = function(_obj)
    {
        if($scope.cancelMark)
        {
            var str = "确定撤销此的委托吗？";
            //console.log($scope.htbhlist.length);
            $scope.cxObj = _obj;
            myConfirm(str, $scope.cancelconfirmone);
        }
    }

    $scope.cancelconfirmone = function()
    {
        layer.closeAll();
        $scope.cancelMark = false;
        $scope.cancelOne();
    }

    $scope.cancelOne = function()
    {
        $scope.cancellationtsInfo = "撤单中，请稍候...";
        var message = {};
        message['account'] = $scope.childaccount;
        message['htbh'] = $scope.cxObj.htbh;
        message['extra'] = $scope.cxObj.extra;
        message['stockcode'] = $scope.cxObj.stockcode;
        //console.log("htbh", _obj.htbh)
        ajaxService.sendMessage("sunflower.p_cancelorder", message, $scope.onecancelactionCallBack);
    }

    $scope.onecancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            //alert("撤单成功");
            $scope.cancellationtsInfo = "撤单发送成功";
        }
        else
        {
            //alert( "撤单失败，原因：" + result.op.info);
            $scope.cancellationtsInfo = "撤单发送失败，原因：" + result.op.info;
        }
        $scope.cxObj = null;
        $scope.cancelMark = true;
        $scope.query();
    }
}

//预埋单
function prepaybgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.prepayMain = true;//操作主界面
    $scope.prepaycdDiv = false;//预埋单撤单
    $scope.dqwtsjh = "";//当前委托随机号
    $scope.wtyxsj = "0";//0：当日；1：次日
    $scope.wtcfj = "";//委托触发价
    $scope.wtcfzt = "0";//0：大于；1：小于等于
    $scope.marketbuyMark = false;//是否市价买入
    $scope.marketsellMark = false;//是否市价卖出
    $scope.buyShow = true;//买入显示
    $scope.sellShow = false;//卖出显示
    $scope.inputstockShow = true;//显示输入框并可操作
    $scope.hq = {};
    $scope.wtjg;
    $scope.wtsl;
    $scope.kysl;
    $scope.mcjg;//卖出价格
    $scope.mcsl;//卖出数量
    $scope.mckysl;//卖出可用数量
    $scope.ddlx = "i";//报价方式
    $scope.buykyzj = 0;//可用资金
    $scope.zdkmShow = false;//最大可买是否显示
    $scope.flashbuyfiveDivShow = false;
    $scope.wtInfo = null;//委托信息
    $scope.sellwtInfo = null;//卖出委托信息
    $scope.stockcodeall = "";
    $scope.buyErrorInfo = "";//买入错误提示
    $scope.sellErrorInfo = "";//卖出错误提示

    $scope.buysellhqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.buysellhqintervalId;

    $scope.buySearchStockListArray = [];
    $scope.buygpssShow = false;

    $scope.sellSearchStockListArray = [];
    $scope.sellgpssShow = false;


    //去除
    $scope.buysellClearInterval = function () {
        if ($scope.buysellhqintervalId != undefined) {
            clearInterval($scope.buysellhqintervalId);
        }
    }

    //买卖切换
    $scope.tradetabClick = function(_str)
    {
        if(_str == "buy")
        {
            $scope.buyShow = true;//买入显示
            $scope.sellShow = false;//卖出显示
        }
        else
        {
            $scope.buyShow = false;//买入显示
            $scope.sellShow = true;//卖出显示

            if($scope.stockcodeall != "")//卖出界面
            {
                $scope.getmckysl();
            }
        }
    }

    //点击不显示手机弹出的键盘
    $scope.buysellClosePopClick = function(){
        $scope.buySearchStockListArray = [];
    };

    $scope.marketbuyChoose = function()
    {
        //console.log($scope.marketbuyMark);
        $scope.marketbuyMark = !$scope.marketbuyMark;
        $scope.kysl = "-";
        if($scope.stockcodeall != "" && $scope.marketbuyMark)
        {
            $scope.wtjg = "";
            $scope.getkysl();
        }
    }

    $scope.marketsellChoose = function()
    {
        //console.log($scope.marketsellMark);
        $scope.marketsellMark = !$scope.marketsellMark;
        if($scope.stockcodeall != "" && $scope.marketsellMark)
        {
            $scope.mcjg = "";
        }

    }

    //有效时间
    $scope.wtyxsjChange = function()
    {
        //console.log($scope.marketbuyMark);
        if($scope.wtyxsj == "0")
        {
            $scope.wtyxsj = "1";
        }
        else
        {
            $scope.wtyxsj = "0";
        }
    }

    $scope.wtcfztChange = function()
    {
        //console.log($scope.marketbuyMark);
        if($scope.wtcfzt == "0")
        {
            $scope.wtcfzt = "1";
        }
        else
        {
            $scope.wtcfzt = "0";
        }
    }

    $scope.selectsecuritymoneyactionCallBack = function(_data)
    {
        var arr = _data.moneylist;
        if(arr.length>0)
        {
            $scope.buykyzj = parseFloat(arr[0].kyzj.toString());
            //console.log("可用资金", $scope.kyzj);
        }
    }

    //最大可用
    $scope.getkyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.kysl  = _data.kmsl;
        }
    }

    $scope.getkysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['exchange'] = $scope.stockcodeall.substring(0,2).toUpperCase();
        message['account'] = $scope.childaccount;
        if($scope.marketbuyMark)//市价
        {
            message['price'] = 0;
            //console.log("price1：", message['price']);
        }
        else
        {
            message['price'] = $scope.wtjg;
            //console.log("price2：", message['price']);
        }
        console.log("委托价格：" ,  message['stockcode'], message['exchange'], message['account'], message['price']);
        ajaxService.sendMessage("sunflower.p_getzdkm", message, $scope.getkyslCallBack);

    }

    //股票搜索返回
    $scope.searchstock = function(_str)
    {

    }

    $scope.openKeyBoard = function()
    {
        var input1 = document.getElementById('mrdmsr');
        var keyBoardObj = new KeyBoard(input1,{"onchangeMethod": $scope.searchstock});
        //$("#text1").addClass("srkbj");
    }

    $scope.wtjgChange = function(_value)
    {
        //console.log("wtjgChange", $scope.wtjg);
        $scope.wtjg = _value;
        if(_value != "" && Number(_value) !=0)
        {
            $scope.getkysl();
        }
        else
        {
            $scope.kysl = "-";
        }
    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        //console.log("11111", stockcode);
        //alert("stockcode"  + stockcode);
        if(stockcode != null && stockcode != "" && stockcode != undefined)
        {
            var message = {};
            if (stockcode.length == 8) stockcode = stockcode.substring(2);
            //if(stockcode.substr(0,2) == "00" || stockcode.substr(0,2) == "30" || stockcode.substr(0,1) == "2")
            //{
            //    message['code'] = "sz"+stockcode;
            //}
            //else
            //{
            //    message['code'] = "sh"+stockcode;
            //}
            message['code'] = $scope.hq.exchange + stockcode;

            //console.log("查询：" + stockcode);
            //ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack);
            $scope.buysellClearInterval();
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;
            $scope.buysellhqintervalId = setInterval($scope.dscl, $scope.buysellhqintervalDuration);
        }
        else
        {
            //alert("2");
            $scope.hq = getEmptyHQ();
            //alert("3");
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.mcjg = "";
            $scope.mckysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    };

    $scope.gpdmchange = function()
    {
        //alert("change");
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.wtjg = "";
        //    $scope.kysl = "-";
        //    $scope.zdkmShow = false;
        //    //$scope.$apply();
        //}
        //if($scope.wtInfo != null)
        //{
        //    $scope.wtInfo = null;
        //}
        //$scope.stockcodeall = "";
        //console.log("$scope.hq.stockcode", $scope.hq.stockcode);
        if($scope.hq.stockcode != "")
        {
            $scope.buygpssShow = true;
            $scope.buycheckContent();
        }
        else
        {
            //console.log(12123);
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            console.log(4243);
        }
        if($scope.wtInfo != null)
        {
            $scope.wtInfo = null;
        }
        $scope.stockcodeall = "";
    }

    $scope.buycheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.buysearchStockCallBack);
    }

    //搜索股票返回
    $scope.buysearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.buySearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.buySearchStockListArray = arr;

                    if($scope.buySearchStockListArray.length == 1)
                    {
                        $scope.setbuyonegp();
                    }
                }
                else {
                    $scope.buySearchStockListArray = [];
                    $scope.buygpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
    }

    $scope.setbuyonegp = function()
    {
        if($scope.buySearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.buySearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.buySearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.buySearchStockListArray[0].exchange).toLowerCase();
                $scope.buygpssShow = false;
                $scope.queryhq($scope.buySearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.buycheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.buygpssShow = false;
        $scope.queryhq(_obj.gpdm);
    }

    //股票行情
    $scope.sshqactionCallBack = function(_data)
    {
        console.log("行情查询返回：" ,_data);
        //alert("查询返回：" + _data.code.toString());
        if (_data.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            //alert("查询返回：" + result.buyv.toString());
            if(_data.datalist.length==0)
            {
                return;
            }
            var result = _data.datalist[0];
            var obj = {};
            var buyvarr = result.bid;
            obj.buyv1 = Math.floor(Number(buyvarr[0].volume)/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1].volume)/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2].volume)/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3].volume)/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4].volume)/100)+'手';

            obj.buyp1 = Number(buyvarr[0].price).toFixed(2);
            obj.buyp2 = Number(buyvarr[1].price).toFixed(2);
            obj.buyp3 = Number(buyvarr[2].price).toFixed(2);
            obj.buyp4 = Number(buyvarr[3].price).toFixed(2);
            obj.buyp5 = Number(buyvarr[4].price).toFixed(2);


            var sellvarr = result.ask;
            obj.sellv1 = Math.floor(Number(sellvarr[0].volume)/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1].volume)/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2].volume)/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3].volume)/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4].volume)/100)+'手';

            obj.sellp1 = Number(sellvarr[0].price).toFixed(2);
            obj.sellp2 = Number(sellvarr[1].price).toFixed(2);
            obj.sellp3 = Number(sellvarr[2].price).toFixed(2);
            obj.sellp4 = Number(sellvarr[3].price).toFixed(2);
            obj.sellp5 = Number(sellvarr[4].price).toFixed(2);

            obj.stockcode = result.stockbasic.stockcode;
            obj.exchange = result.stockbasic.exchange;
            obj.lastprice = result.close;//最新价格
            obj.name = result.stockbasic.stockname;

            //if(obj.name != null && obj.name != "" && obj.name != undefined)
            //{
            //    $scope.inputstockShow = false;
            //}

            //console.log("交易所", obj.exchange);

            $scope.hq = obj;
            $scope.stockcodeall = $scope.hq.exchange + $scope.hq.stockcode;
            //$scope.wtjg = Number($scope.hq.lastprice);

            $scope.zdkmShow = true;
            //取可用数量
            if($scope.marketbuyMark && $scope.buyShow)
            {
                $scope.getkysl();
            }
            if($scope.sellShow)//卖出界面
            {
                $scope.getmckysl();
            }
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    }

    $scope.dscl = function()
    {
        //$scope.buysellClearInterval();
        if($scope.stockcodeall != null && $scope.stockcodeall != "" && $scope.stockcodeall != undefined)
        {
            var message = {};
            message['code'] = $scope.stockcodeall;
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;
        }
    }


    //买入
    $scope.buyClick = function()
    {
        $scope.buyErrorInfo = "";
        if($scope.marketbuyMark)//市价买入
        {
            $scope.marketbuy();
        }
        else
        {
            $scope.limitbuy();
        }
    }

    $scope.limitbuy = function(obj)
    {
        //console.log("委托数量",$scope.wtsl);
        $scope.wtInfo = null;
        //console.log($scope.wtInfo);
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtcfj) == false)
        {
            $scope.buyErrorInfo = "请输入有效的触发价格";
            return;
        }
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        if(r.test($scope.wtjg) == false)
        {
            $scope.buyErrorInfo = "请输入有效的委托价格";
            return;
        }

        //if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        //{
        //    $scope.buyErrorInfo = "请输入有效的委托价格";
        //    return;
        //}
        if(decimaldigitsCheck($scope.wtjg.toString()) == false)
        {
            $scope.buyErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        $scope.buyErrorInfo = "";


        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        // var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定预埋买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        //console.log("买入：" + message["account"],message["stockcode"], message["exchange"], message["ddlx"],message["side"],message["wtsl"],message["wtjg"],message["combPositionId"]);
        //if(confirm(str))//确定买入
        //{
        //    ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        //    {
        //        //console.log("交易", result);
        //        $scope.wtInfo = {};
        //        $scope.wtInfo.code = result.op.code;
        //
        //        if(result.op.code == 'Y')
        //        {
        //            //alert("委托成功，合同编号：" + result.htbh);
        //            $scope.wtInfo.wtsl = 0;//委托数量
        //            $scope.wtInfo.wtsj = "";//委托时间
        //            $scope.wtInfo.cjsl = 0;//成交数量
        //            $scope.wtInfo.cjsj = "";//成交时间
        //            $scope.wtInfo.htbh = result.htbh;
        //            $scope.wtsl = 0;
        //            //$scope.getkysl();
        //        }
        //        else
        //        {
        //            $scope.wtInfo.opwtcode = "N";//委托成功
        //            $scope.wtInfo.info = "委托失败，原因：" + result.op.info;
        //        }
        //    }, false);
        //}
        myConfirm(str, $scope.buyconfirm)//确定买入
    }

    $scope.buyconfirm = function()
    {
        //console.log("buyconfirm");
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();
        message["ddlx"] = 'limit';
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["cfjg"] = $scope.wtcfj;//触发价格
        if($scope.wtcfzt == '0')
        {
            message["cftj"] = "H";//触发条件
        }
        else if($scope.wtcfzt == '1')
        {
            message["cftj"] = "L";//触发条件
        }
        message["yxts"] ="1";//有效天数
        //是否当日生效
        if($scope.wtyxsj == '0')
        {
            message["drsx"] = "T";//触发条件
        }
        else if($scope.wtyxsj == '1')
        {
            message["drsx"] = "F";//触发条件
        }
        message["ip"] = "1";
        //message["mac"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        console.log(message);
        ajaxService.sendMessage("sunflower.p_payinadvance", message, function (result)
        {
            console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtsl = 0;
                $scope.buyErrorInfo = "";
                myAlert("预埋委托成功");
                //$scope.getkysl();
            }
            else
            {
                $scope.wtInfo.opwtcode = "N";//委托成功
                $scope.buyErrorInfo = "";
                myAlert("预埋委托失败，原因：" + result.op.info);
            }
        }, false);

    }

    //买卖五档的显示
    $scope.flashbuyfiveDivShowClick = function()
    {
        $scope.flashbuyfiveDivShow = !$scope.flashbuyfiveDivShow;
    }

    //市价买入
    $scope.marketbuy = function()
    {
        $scope.wtInfo = null;
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtcfj) == false)
        {
            $scope.buyErrorInfo = "请输入有效的触发价格";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        $scope.buyErrorInfo = "";
        var str = "确定预埋买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        //确定买入
        myConfirm(str, $scope.marketbuyconfirm)
    };

    $scope.marketbuyconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = 0;
        message["cfjg"] = $scope.wtcfj;//触发价格
        if($scope.wtcfzt == '0')
        {
            message["cftj"] = "H";//触发条件
        }
        else if($scope.wtcfzt == '1')
        {
            message["cftj"] = "L";//触发条件
        }
        message["yxts"] ="1";//有效天数
        //是否当日生效
        if($scope.wtyxsj == '0')
        {
            message["drsx"] = "T";//触发条件
        }
        else if($scope.wtyxsj == '1')
        {
            message["drsx"] = "F";//触发条件
        }
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];

        //console.log("买入", message)

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"

        ajaxService.sendMessage("sunflower.p_payinadvance", message, function (result)
        {
            console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtInfo.opwtcode = "Y";//委托成功
                $scope.wtsl = 0;
                $scope.buyErrorInfo = "";
                $scope.getkysl();
                myAlert("预埋委托成功");
            }
            else
            {
                $scope.buyErrorInfo = "";
                myAlert("预埋委托失败，原因：" + result.op.info);
            }
        }, false);
    }

    //卖出股票代码change
    $scope.sellgpdmchange = function()
    {
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.mcjg = "";
        //    $scope.mckysl = "-";
        //}

        //console.log("$scope.hq.stockcode", $scope.hq.stockcode);
        if($scope.hq.stockcode != "")
        {
            $scope.sellgpssShow = true;
            $scope.sellcheckContent();
        }
        else
        {
            //console.log(12123);
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.mcjg = "";
            $scope.mckysl = "-";
            //console.log(4243);
        }

        if($scope.sellwtInfo != null)
        {
            $scope.sellwtInfo = null;
        }
        $scope.stockcodeall = "";
    }

    $scope.sellcheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.sellsearchStockCallBack);
    }

    //搜索股票返回
    $scope.sellsearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.sellSearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.sellSearchStockListArray = arr;
                    if($scope.sellSearchStockListArray.length == 1)
                    {
                        $scope.setsellonegp();
                    }
                }
                else {
                    $scope.sellSearchStockListArray = [];
                    $scope.sellgpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
    }

    $scope.setsellonegp = function()
    {
        if($scope.sellSearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.sellSearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.sellSearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.sellSearchStockListArray[0].exchange).toLowerCase();
                $scope.sellgpssShow = false;
                $scope.queryhq($scope.sellSearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.sellcheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.sellgpssShow = false;
        $scope.queryhq(_obj.gpdm);

    }


    //最大可用
    $scope.getmckyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.mckysl  = _data.zdkm;
        }
    }

    $scope.getmckysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmaxcansell", message, $scope.getmckyslCallBack);

    }

    $scope.mcjgChange = function(_value)
    {
        $scope.mcjg = _value;
    }

    $scope.sellClick = function()
    {
        $scope.sellErrorInfo = "";
        if($scope.marketsellMark)//市价卖出
        {
            $scope.marketsell();
        }
        else
        {
            $scope.limitsell();
        }
    }

    $scope.limitsell = function()
    {
        $scope.sellwtInfo = null;
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtcfj) == false)
        {
            $scope.sellErrorInfo = "请输入有效的触发价格";
            return;
        }

        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcjg<=0)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }
        if(r.test($scope.mcjg) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        //if($scope.mcjg.toString().length>0 && $scope.mcjg.toString().substr(0,1) == "0")
        //{
        //    $scope.sellErrorInfo = "请输入有效的卖出价格";
        //    return;
        //}
        if(decimaldigitsCheck($scope.mcjg.toString()) == false)
        {
            $scope.sellErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        $scope.sellErrorInfo = "";
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}


        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定预埋卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.sellconfirm);

    }

    $scope.sellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = $scope.mcjg;
        message["cfjg"] = $scope.wtcfj;//触发价格
        if($scope.wtcfzt == '0')
        {
            message["cftj"] = "H";//触发条件
        }
        else if($scope.wtcfzt == '1')
        {
            message["cftj"] = "L";//触发条件
        }
        message["yxts"] ="1";//有效天数
        //是否当日生效
        if($scope.wtyxsj == '0')
        {
            message["drsx"] = "T";//触发条件
        }
        else if($scope.wtyxsj == '1')
        {
            message["drsx"] = "F";//触发条件
        }
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log(message);

        ajaxService.sendMessage("sunflower.p_payinadvance", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellErrorInfo = "";
                $scope.mcjg = "";
                $scope.mcsl = "";
                $scope.mckysl = "-";
                myAlert("预埋委托成功");
            }
            else
            {
                $scope.sellErrorInfo = "";
                myAlert("预埋委托失败" +  result.op.info);
            }

        }, false);
    }

    //市价卖出
    $scope.marketsell = function()
    {
        $scope.sellwtInfo = null;
        //console.log($scope.excstockcode)
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtcfj) == false)
        {
            $scope.sellErrorInfo = "请输入有效的触发价格";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }

        $scope.sellErrorInfo = "";
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定预埋卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.marketsellconfirm);
    }

    $scope.marketsellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = 0;
        message["cfjg"] = $scope.wtcfj;//触发价格
        if($scope.wtcfzt == '0')
        {
            message["cftj"] = "H";//触发条件
        }
        else if($scope.wtcfzt == '1')
        {
            message["cftj"] = "L";//触发条件
        }
        message["yxts"] ="1";//有效天数
        //是否当日生效
        if($scope.wtyxsj == '0')
        {
            message["drsx"] = "T";//触发条件
        }
        else if($scope.wtyxsj == '1')
        {
            message["drsx"] = "F";//触发条件
        }
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log(message);

        ajaxService.sendMessage("sunflower.p_payinadvance", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.opwtcode = "Y";//委托成功
                $scope.sellErrorInfo = "";

                $scope.mcsl = "";
                $scope.mckysl = "-";
                $scope.getmckysl();

                myAlert("预埋委托成功");
            }
            else
            {
                $scope.sellwtInfo.opwtcode = "N";//委托成功
                $scope.sellErrorInfo = "";
                myAlert("预埋委托失败" +  result.op.info);
            }
        }, false);
    }

    $scope.buysellbacktoParent = function()
    {
        $scope.buysellClearInterval();
        $scope.backtoParent();
    }

    //预埋单撤单查询
    $scope.ymdcdClick = function()
    {
        $scope.prepayMain = false;
        $scope.prepaycdDiv = true;
        $scope.query();
    }

    //返回买卖
    $scope.backtoprepayM = function()
    {
        $scope.prepayMain = true;
        $scope.prepaycdDiv = false;
    }


    //预埋单撤单

    $scope.cxObj = null;//单个选择的撤销
    $scope.cancellationtsInfo = "";
    $scope.cancelMark = true;//是否可以进行撤销操作
    $scope.index = 0;//撤单位置
    var headerArray = [
        {code: 'wtsj', name: '委托时间', desc: '↓', type: 'shorttime'},
//        {code: 'gpwt.htbh', name: '合同编号', desc: ' ', type: 'number'},
//        {code: 'gpwt.productname', name: '产品名称', desc: '　', type: 'string'},
        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'gpwt.side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
//        {code: 'gpwt.wtjg', name: '委托价格', desc: '　', type: 'buypolicy'},
        {code: 'wtsl', name: '委托数量', desc: '　', type: 'number'}
//        {code: 'gpwt.djje', name: '委托金额', desc: ' ', type: 'money'},
//        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
//        {code: 'gpwt.cjsl', name: '成交数量', desc: '　', type: 'number'},
//        {code: 'gpwt.cjje', name: '成交金额', desc: '　', type: 'money'},
//        {code: 'gpwt.cdsl', name: '撤单数量', desc: '　', type: 'number'},
//        {code: 'gpwt.status', name: '委托状态', desc: '　', type: 'wtstatus'},
//        {code: 'gpwt.reason', name: '备注', desc: '　', type: 'string'}
    ];
    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {
        //$scope.cancellationtsInfo = "";
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        ajaxService.sendMessage("sunflower.p_selectpayinadvance", message, function (result) {
            $scope.cancellationtsInfo = "";
            $scope.wtList = [];
            console.log("预埋单撤单查询当日委托",result);
            if (result.op.code == 'Y')
            {
                var arr = result.payinadvancelist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].createtime.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtsl = arr[i].wtsl;
                        obj.extra = arr[i].extra.toString();
                        obj.cdid = arr[i].id;
                        //if(arr[i].status.toString() == "2" || arr[i].status.toString() == "7")
                        //{
                        $scope.wtList.push(obj);
                        //}
                    }

                    if($scope.wtList.length>0)
                    {
                        $scope.showNodata = false;
                        $scope.isLoading = false;
                    }
                    else
                    {
                        $scope.showNodata = true;
                        $scope.isLoading = false;
                    }
                }
                else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

        });
    };

    $scope.selectAllWt = false;
    $scope.chooseAllwt = function () {
        $scope.selectAllWt = !$scope.selectAllWt;

        if ($scope.selectAllWt)
        {
            $scope.htbhlist = [];
            for (var i = 0; i < $scope.wtList.length; i++)
            {
                //$scope.htbhlist.push($scope.wtList[i]['htbh']);
                $scope.htbhlist.push($scope.wtList[i]);
            }
        }
        else
        {
            $scope.htbhlist = [];
        }

    }

    $scope.choosewt = function (_obj) {
//        id = Number(id);
        var id = _obj.extra;
        var idx = $scope.htbhlist.indexOf(id);
        // is currently selected
        if (idx > -1) {
            $scope.htbhlist.splice(idx, 1);
        }
        // is newly selected
        else {
            $scope.htbhlist.push(_obj);
        }
    }

    //撤销
    $scope.cancelWt = function ()
    {
        if($scope.cancelMark)
        {
            $scope.index = 0;
            $scope.Msgarr = [];
            if ($scope.htbhlist.length == 0)
            {
                $scope.cancellationtsInfo = "请选择委托";
                return;
            }
            var str = "确定撤销所选中的委托吗？";
            //console.log($scope.htbhlist.length);
            myConfirm(str, $scope.cancelconfirm);//确定撤销
        }
    }
    $scope.cancelconfirm = function()
    {
        layer.closeAll();
        $scope.cancelMark = false;
        $scope.cancelall();
    }

    $scope.cancelall = function()
    {
        $scope.cancellationtsInfo = "取消中，请稍候...";
        var message = {};
        //message['account'] = $scope.childaccount;
        //message['extra'] = $scope.htbhlist[$scope.index].extra;
        message['id'] = $scope.htbhlist[$scope.index].cdid;
        ajaxService.sendMessage("sunflower.p_payinadvancecancel", message, $scope.cancelactionCallBack);
    }

    $scope.cancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            var obj = {};
            obj.cdid = $scope.htbhlist[$scope.index].cdid;
            obj.info = "取消成功";
            $scope.Msgarr.push(obj);
        }
        else
        {
            var obj = {};
            obj.cdid = $scope.htbhlist[$scope.index].cdid;
            obj.info = "取消失败，" + result.op.info;
            $scope.Msgarr.push(obj);
        }
        $scope.index = $scope.index+1;
        if($scope.index < $scope.htbhlist.length)
        {
            $scope.cancelall();
        }
        else
        {
            var str = "";
            for(var i = 0;i<$scope.Msgarr.length;i++)
            {
                if(i == 0)
                {
                    str = "合约  " + $scope.Msgarr[i].cdid + "  " + $scope.Msgarr[i].info;
                }
                else
                {
                    str = str + "； 合约  " + $scope.Msgarr[i].cdid + "  " + $scope.Msgarr[i].info;
                }
            }
            //alert(str);
            $scope.cancellationtsInfo = str;
            $scope.Msgarr = [];
            $scope.index = 0;
            $scope.query();
            $scope.cancelMark = true;
        }
    }

    $scope.cancelOneWt = function(_obj)
    {
        if($scope.cancelMark)
        {
            var str = "确定撤销此的委托吗？";
            //console.log($scope.htbhlist.length);
            $scope.cxObj = _obj;
            myConfirm(str, $scope.cancelconfirmone);
        }
    }

    $scope.cancelconfirmone = function()
    {
        layer.closeAll();
        $scope.cancelMark = false;
        $scope.cancelOne();
    }

    $scope.cancelOne = function()
    {
        $scope.cancellationtsInfo = "取消中，请稍候...";
        var message = {};
        //message['account'] = $scope.childaccount;
        //message['extra'] = $scope.cxObj.extra;
        message['id'] = $scope.cxObj.cdid;
        //console.log("htbh", _obj.htbh)
        ajaxService.sendMessage("sunflower.p_payinadvancecancel", message, $scope.onecancelactionCallBack);
    }

    $scope.onecancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            //alert("撤单成功");
            $scope.cancellationtsInfo = "取消成功";
        }
        else
        {
            //alert( "撤单失败，原因：" + result.op.info);
            $scope.cancellationtsInfo = "取消失败，原因：" + result.op.info;
        }
        $scope.cxObj = null;
        $scope.cancelMark = true;
        $scope.query();
    }
}



/**银证转账**/
function yzzzCtrl($scope, ajaxService, $cookieStore) {
    $scope.yzzShow = true;//银行转证券
    $scope.zzyShow = false;//证券转银行

    $scope.yzzinfo = "";//银行转证券提示信息
    $scope.zzyinfo = "";//证券转银行提示信息

    $scope.hblxArray = [];//货币类型
    $scope.hblxValue = "";//货币类型
    $scope.yhlistArray = [];//银行列表
    $scope.zzyhxValue = "0";//转账银行
    $scope.zzyhxValueName = "";

    //$scope.yhzzqzjmmShow = false;//银行转证券资金密码
    //$scope.zqzyhyhmmShow = false;//证券转银行银行密码

    $scope.yyzzqje = "";//银行转证券金额
    $scope.yyzzqpassword = "";//银行转证券密码

    $scope.zqzyhje = "";//证券转银行金额
    $scope.zqzyhpassword ="";//证券转银行密码

    $scope.moneypw = "";
    $scope.bankpw = "";

    $scope.zzMark = true;//转账操作
    $scope.yzzztisi = "";//是否显示银行转账提示

    var localStorage = window.localStorage;
    $scope.newflag = localStorage.getItem('newflag');
    //console.log("是否可以转账", $scope.newflag);

    $scope.yzzztabClick = function(_str)
    {
        if(_str == "yzz")
        {
            $scope.yzzShow = true;
            $scope.zzyShow = false;
        }
        else
        {
            $scope.yzzShow = false;
            $scope.zzyShow = true;
        }
    }

    $scope.getyyList = function()
    {
        var message = {};
        //message['account'] = $scope.childaccount;
        message['account'] = $scope.accountShowValue;
        //console.log("账户", $scope.accountShowValue);
        ajaxService.sendMessage("sunflower.p_selectbank", message, $scope.getyyListCallBack);
    }

    //获取银行
    $scope.getyyListCallBack = function(_data)
    {
        //console.log("银行", _data);
        $scope.yhlistArray = [];

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.banklist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.type = arr[i].bankno;
                obj.label = arr[i].bankname;
                obj.bankaccount = arr[i].bankaccount;
                obj.moneytype = arr[i].moneytype;
                if(obj.moneytype == undefined || obj.moneytype == null)
                {
                    obj.moneytype = "";
                }
                $scope.yhlistArray.push(obj);
            }
        }
    }

    $scope.yzzzinit = function()
    {
        //获取银证转账货币类型
        $scope.hblxArray = [];
        //var obj = {};
        //obj.type = "0";//1：人民币，2：美元；3：港币
        //obj.label = "--请选择货币类型--";
        //$scope.hblxArray.push(obj);
        //var obj = {};
        //obj.type = "1";
        //obj.label = "人民币";
        //$scope.hblxArray.push(obj);
        //obj = {};
        //obj.type = "2";
        //obj.label = "美元";
        //$scope.hblxArray.push(obj);
        //obj = {};
        //obj.type = "3";
        //obj.label = "港币";
        //$scope.hblxArray.push(obj);

        if($scope.accountcompany == "dhzq")
        {
            $scope.yhzzqzjmmShow = true;
            $scope.zqzyhyhmmShow = true;
        }
        else
        {
            $scope.yhzzqzjmmShow = false;
            $scope.zqzyhyhmmShow = false;
        }


        //获取转账银行
        $scope.yhlistArray = [];
        $scope.getyyList();
        //var obj = {};
        //obj.type = "1";
        //obj.label = "招商银行";
        //$scope.yhlistArray.push(obj);
        //obj = {};
        //obj.type = "2";
        //obj.label = "平安银行";
        //$scope.yhlistArray.push(obj);
        //obj = {};
        //obj.type = "3";
        //obj.label = "中国农业银行";
        //$scope.yhlistArray.push(obj);

    }

    $scope.yzzzinit();


    //货币类型选择
    $scope.hblxselectChange = function()
    {
        console.log("type", $scope.hblxValue);
    }

    //银行选择
    $scope.zzyhlistselectChange = function()
    {
        //console.log("type", $scope.zzyhxValue);
        //console.log("$scope.accountcompany", $scope.accountcompany);

        if($scope.zzyhxValue != "0")
        {
            if($scope.newflag == "Y")
            {
                for(var i = 0;i<$scope.yhlistArray.length;i++)
                {
                    console.log($scope.zzyhxValue, $scope.yhlistArray[i].type);
                    if($scope.zzyhxValue == $scope.yhlistArray[i].type)
                    {
                        $scope.zzyhxValueName = $scope.yhlistArray[i].label;
                        break;
                    }
                }
                //获取银行提示信息
                var message = {};
                message['company'] = $scope.accountcompany;
                message['bank'] = $scope.zzyhxValueName;
                message['page.size'] = "max";
                message['page.no'] = "";
                //console.log(message);
                ajaxService.sendMessage("counter.selectnewaccounttransferaction", message, $scope.selectnewaccounttransferactionCallBack);
            }
        }
    }

    $scope.selectnewaccounttransferactionCallBack = function(_data)
    {
        //console.log("银行对应提示：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.newaccounttransferlist;
            if(arr.length>0)
            {
                $scope.yzzztisi = arr[0].picpath;
            }
        }
        //console.log($scope.yzzztisi);
    }

    //银行转证券
    $scope.yzzConfirm = function()
    {
        //$scope.yzzinfo = "43243";
        if($scope.zzMark)
        {
            //if($scope.hblxValue == "" || $scope.hblxValue == "0")
            //{
            //    $scope.yzzinfo = "请选择货币类型";
            //    return;
            //}
            if($scope.zzyhxValue == "" || $scope.zzyhxValue == "0")
            {
                $scope.yzzinfo = "请选择转账银行";
                return;
            }
            if($scope.yyzzqje == "" || parseFloat($scope.yyzzqje)<0)
            {
                $scope.yzzinfo = "请输入转账金额";
                return;
            }
            if($scope.yyzzqpassword == "")
            {
                $scope.yzzinfo = "请输入银行密码";
                return;
            }
            if($scope.yhzzqzjmmShow == true)
            {
                if($scope.moneypw == "")
                {
                    $scope.yzzinfo = "请输入资金密码";
                    return;
                }
            }
            var str = "确定转入资金 " + $scope.yyzzqje+" 元吗？";
            myConfirm(str, $scope.yyzzqjeconfirm);

            //if(confirm(str))//确定买入
            //{
            //    $scope.zzMark = false;
            //    $scope.yzzinfo = "转账申请提交中，请稍候...";
            //    $scope.yzzCallBack();
            //}

        }
    }

    $scope.yyzzqjeconfirm = function()
    {
        layer.closeAll();
        $scope.zzMark = false;
        $scope.yzzinfo = "转账申请提交中，请稍候...";
        $scope.yzztj();
    }

    $scope.yzztj = function()
    {
        //$scope.zzMark = true;
        //$scope.yzzinfo = "转账成功";
        var obj = null;
        for(var i = 0;i<$scope.yhlistArray.length;i++)
        {
            if($scope.zzyhxValue == $scope.yhlistArray[i].type)
            {
                obj = $scope.yhlistArray[i];
                break;
            }
        }
        if(obj != null)
        {
            var message = {};
            message['account'] = $scope.accountShowValue;
            message['bankno'] = $scope.zzyhxValue;
            message['moneytype'] = obj.moneytype;
            message['clientaccount'] = "";
            message['transferdirection'] = "1";
            message['money'] = $scope.yyzzqje;
            //message['bankpassword'] = $scope.yyzzqpassword;
            message['bankaccount'] = obj.bankaccount;

            if($scope.yhzzqzjmmShow == false)
            {
                message['bankpassword'] = $scope.yyzzqpassword;
            }
            else
            {
                message['bankpassword'] = $scope.yyzzqpassword;
                message['moneypassword'] = $scope.moneypw;
            }

            //console.log(message['account'], message['bankno'], message['moneytype'],message['clientaccount'],message['transferdirection'],message['bankpassword'], message['bankaccount']);

            ajaxService.sendMessage("sunflower.p_banktransfer", message, $scope.p_banktransferCallBack);
        }
    }

    $scope.p_banktransferCallBack = function(_data)
    {
        //console.log("银行转证券",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.yzzinfo = "转账指令已发出，转账成功后账户资金会相应增加，请在资产页面点击刷新按钮，注意资金变化";
            $scope.yyzzqje = "";
            $scope.yyzzqpassword = "";
            $scope.moneypw = "";
        }
        else
        {
            //$scope.yzzinfo = "转账失败，原因为：" + _data.op.info;
            $scope.yzzinfo = _data.op.info;
        }
        $scope.zzMark = true;
    }

    //$scope.yzzCallBack = function()
    //{
    //    $scope.zzMark = true;
    //    $scope.yzzinfo = "转账成功";
    //}

    //证券转银行
    $scope.zzyConfirm = function()
    {
        //$scope.zzyinfo = "55555";
        if($scope.zzMark)
        {
            //if($scope.hblxValue == "" || $scope.hblxValue == "0")
            //{
            //    $scope.zzyinfo = "请选择货币类型";
            //    return;
            //}
            if($scope.zzyhxValue == "" || $scope.zzyhxValue == "0")
            {
                $scope.zzyinfo = "请选择转账银行";
                return;
            }
            if($scope.zqzyhje == "" || parseFloat($scope.zqzyhje)<0)
            {
                $scope.zzyinfo = "请输入转账金额";
                return;
            }
            if($scope.zqzyhyhmmShow == true)
            {
                if($scope.bankpw == "")
                {
                    $scope.zzyinfo = "请输入银行密码";
                    return;
                }
            }
            if($scope.zqzyhpassword == "")
            {
                $scope.zzyinfo = "请输入资金密码";
                return;
            }
            var str = "确定转入资金  " + $scope.zqzyhje+" 元吗？";
            myConfirm(str, $scope.zqzyhjeconfirm);
        }
    }

    $scope.zqzyhjeconfirm = function()
    {
        layer.closeAll();
        $scope.zzMark = false;
        $scope.zzyinfo = "转账申请提交中，请稍候...";
        $scope.zzyty();
    }

    $scope.zzyty = function()
    {
        //$scope.zzMark = true;
        //$scope.zzyinfo = "转账成功";
        var obj = null;
        for(var i = 0;i<$scope.yhlistArray.length;i++)
        {
            if($scope.zzyhxValue == $scope.yhlistArray[i].type)
            {
                obj = $scope.yhlistArray[i];
                break;
            }
        }
        if(obj != null)
        {
            var message = {};
            message['account'] = $scope.accountShowValue;
            message['bankno'] = $scope.zzyhxValue;
            message['moneytype'] = obj.moneytype;
            message['clientaccount'] = "";
            message['transferdirection'] = "2";
            message['money'] = $scope.zqzyhje;
            //message['bankpassword'] = $scope.zqzyhpassword;
            message['bankaccount'] = obj.bankaccount;
            if($scope.zqzyhyhmmShow == false)
            {
                message['bankpassword'] = $scope.zqzyhpassword;
            }
            else
            {
                message['bankpassword'] = $scope.bankpw;
                message['moneypassword'] = $scope.zqzyhpassword;
            }
            //console.log(message['account'], message['bankno'], message['moneytype'],message['clientaccount'],message['transferdirection'],message['bankpassword'], message['bankaccount']);

            ajaxService.sendMessage("sunflower.p_banktransfer", message, $scope.p_banktransferzzyCallBack);
        }
    }

    $scope.p_banktransferzzyCallBack = function(_data)
    {
        //console.log("证券转银行",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.zzyinfo = _data.op.info;
            $scope.zqzyhje = "";
            $scope.zqzyhpassword = "";
            $scope.bankpw = "";

        }
        else
        {
            //$scope.zzyinfo = "转账失败，原因为：" + _data.op.info;
            $scope.zzyinfo = _data.op.info;
        }

        $scope.zzMark = true;
    }

    //$scope.zzyCallBack = function()
    //{
    //    $scope.zzMark = true;
    //    $scope.zzyinfo = "转账成功";
    //}

}

/**一键清仓**/
function yjqcwgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.qcInfo = "";
    $scope.qcMark = true;//是否可以点击操作
    $scope.tradeallShow = true;//交易界面
    $scope.cjhbDiv = false;//成交回报显示界面
    $scope.cjhbArray = [];//成交回报数组
    $scope.dqwtsjh = "";//当前委托随机号
    $scope.kckcjhb = false;//可查看成交回报

    $scope.yjqchqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.yjqchqintervalId;

    $scope.yjqcquery = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        //$scope.wtList = [];
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            console.log("一键清仓",result)
            $scope.qcInfo = "";
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zs = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//全部数量
                        obj.ky = parseInt(arr[i].kysl);
                        obj.xj = arr[i].dqj;
                        //obj.yk = arr[i].fdyk;
                        obj.zd = parseFloat(arr[i].zdf).toFixed(2);
                        if(obj.ky>0)
                        {
                            obj.qcStatus = true;//清仓：true, false：不清仓
                        }
                        else
                        {
                            obj.qcStatus = false;//清仓：true, false：不清仓
                        }
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    //查询持仓
    $scope.yjqcquery();

    //设置
    $scope.setqcClick = function(obj)
    {
        if(obj.ky>0)
        {
            obj.qcStatus = !obj.qcStatus;
        }

    }

    //清仓
    $scope.qcClick = function()
    {
        if($scope.qcMark)
        {
            var arr = [];
            for(var i = 0;i< $scope.wtList.length;i++)
            {
                console.log($scope.wtList[i].qcStatus);
                if($scope.wtList[i].qcStatus)
                {
                    arr.push($scope.wtList[i]);
                }
            }

            if(arr.length<=0)
            {
                $scope.qcInfo = "请选择可清仓股票";
                return;
            }
            $scope.qcMark = false;
            $scope.qcInfo = "委托提交中，请稍候...";

            console.log(arr.length);

            var obj ={};
            $scope.cjhbArray = [];//成交回报数组
            for(var i = 0;i<arr.length;i++)
            {
                var obj2 = {};
                obj2.id = $scope.userObj.f_id;
                console.log("userid", $scope.userObj.f_id);
                obj2.headurl = decodeURIComponent(localStorage.getItem("iconurl"));
                obj2.name = decodeURIComponent(localStorage.getItem("nickname"));
                obj2.gpdm = arr[i].stockcode;
                obj2.gpmc = arr[i].stockname;
                obj2.tc = arr[i].exchange.toString().toUpperCase() + obj2.gpdm;
                obj2.tradetype = "卖出";
                obj2.xdwtsl = Math.abs(arr[i].ky);

                $scope.cjhbArray.push(obj2);

                if(i == 0)
                {
                    obj.stockcodes = arr[i].stockcode;
                    obj.exchanges = arr[i].exchange.toString().toUpperCase();
                    if(arr[i].exchange.toString().toUpperCase() == "SZ")
                    {
                        obj.ddlxs = "f";
                    }
                    else
                    {
                        obj.ddlxs = "r";
                    }
                    obj.sides = "S";
                    obj.wtsls = arr[i].ky;
                    obj.wtjgs = "0";
                }
                else
                {
                    obj.stockcodes =  obj.stockcodes + "," + arr[i].stockcode;
                    obj.exchanges = obj.exchanges + "," + arr[i].exchange.toString().toUpperCase();
                    if(arr[i].exchange.toString().toUpperCase() == "SZ")
                    {
                        obj.ddlxs = obj.ddlxs + "," + "f";
                    }
                    else
                    {
                        obj.ddlxs = obj.ddlxs + "," +"r";
                    }
                    obj.sides = obj.sides + "," + "S";
                    obj.wtsls = obj.wtsls + "," + arr[i].ky;
                    obj.wtjgs = obj.wtjgs + "," + "0";
                }
            }

            var message = {};
            message['account'] = $scope.childaccount;
            message['stockcodes'] = obj.stockcodes;
            message['exchanges'] =  obj.exchanges;
            message['ddlxs'] =  obj.ddlxs;
            message['sides'] = obj.sides;
            message['wtsls'] = obj.wtsls;
            message['wtjgs'] = obj.wtjgs;
            message["mac"] = $scope.deviceid;
            var newdate = new Date();
            message['extra'] = $scope.childaccount + newdate.getTime();
            $scope.dqwtsjh = message['extra'];

            console.log(message['account'], message['stockcodes'], message['exchanges'],message['ddlxs'],message['sides'],message['wtsls'], message['wtjgs']);

            ajaxService.sendMessage("sunflower.p_batchwt", message, $scope.yjqcCallBack);
        }

    }

    $scope.yjqcCallBack = function(_data)
    {
        console.log("一键清仓", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.qcInfo = "委托提交成功";
            $scope.kckcjhb = true;
            $scope.yjqcquery();
            $scope.yjqcgetcjhb();
        }
        else
        {
            $scope.qcInfo = "委托提交失败，请重试";
        }

        $scope.qcMark = true;
    }

    //查看成交回报
    $scope.gotockcjhb = function()
    {
        $scope.tradeallShow = false;
        $scope.cjhbDiv = true;
    }
    $scope.backtradeClick = function()
    {
        $scope.tradeallShow = true;
        $scope.cjhbDiv = false;
    }

    //获取成交回报
    $scope.yjqcgetcjhb = function()
    {
        var message = {};
        message['account'] = $scope.childaccount;
        message['extra'] =  $scope.dqwtsjh;
        console.log(message['account'],message['extra']);

        ajaxService.sendMessage("sunflower.p_selectbatchorder", message, $scope.yjqcgetcjhbCallBack);
    }

    $scope.yjqcgetcjhbCallBack = function(_data)
    {
        $scope.yjqcClearInterval();
        console.log("一键清仓成交回报", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            for(var i=0;i<arr.length;i++)
            {
                var obj = arr[i].mainorder;
                var tc = obj.exchange.toString().toUpperCase() + obj.code;
                for(var j = 0;j<$scope.cjhbArray.length;j++)
                {
                    if(tc == $scope.cjhbArray[j].tc)
                    {
                        $scope.cjhbArray[j].wtsl = obj.wtsl;
                        $scope.cjhbArray[j].wtsj = obj.wtsj;
                        $scope.cjhbArray[j].wtjg = "市价";//parseFloat(obj.wtjg).toFixed(2);
                        $scope.cjhbArray[j].cjsl = parseFloat(obj.cjsl);
                        if(obj.cjsl == 0)
                        {
                            $scope.cjhbArray[j].cjjg = "0.00元";
                        }
                        else
                        {
                            $scope.cjhbArray[j].cjjg = (parseFloat(obj.cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                        }
                        //break;

                        var arr2 = arr[i].gentouorderlist;
                        //if($scope.cjhbArray[j].gtqkListArray == null || $scope.cjhbArray[j].gtqkListArray == undefined)
                        //{
                        var arr5 = [];
                        for(var k = 0;k<arr2.length;k++)
                        {
                            var obj2 = {};
                            obj2.userid = arr2[k].user.user.f_id;
                            obj2.headurl = arr2[k].user.user.f_head;
                            obj2.name = arr2[k].user.user.f_nickname;
                            obj2.wtsl = arr2[k].wtsl;
                            obj2.wtsj = arr2[k].wtsj.toString().substr(0,10);
                            obj2.cjsl = arr2[k].cjsl;
                            obj2.account = arr2[k].account;
                            obj2.cjje = arr2[k].cjje;
                            if(parseFloat(arr2[k].wtjg) == 0)
                            {
                                obj2.wtjg = "市价";
                            }
                            else
                            {
                                obj2.wtjg = parseFloat(arr2[k].wtjg).toFixed(2)+"元";
                            }

                            if(parseFloat(obj2.cjsl) == 0)
                            {
                                obj2.cjjg = "0.00元";
                            }
                            else
                            {
                                obj2.cjjg = (parseFloat(arr2[k].cjje)/parseFloat(obj2.cjsl)).toFixed(2) + "元";
                            }
                            arr5.push(obj2);
                            //$scope.cjhbArray[j].gtqkListArray.push(obj2);
                        }
                        if($scope.cjhbArray[j].gtqkListArray == null || $scope.cjhbArray[j].gtqkListArray == undefined || $scope.cjhbArray[j].gtqkListArray.length == 0)
                        {
                           $scope.cjhbArray[j].gtqkListArray = arr5;
                        }
                        else
                        {
                            for(var kk = 0;k<arr5.length;k++)
                            {
                                var mark = false;
                                for(var m = 0;m<$scope.cjhbArray[j].gtqkListArray.length;m++)
                                {
                                    if($scope.cjhbArray[j].gtqkListArray[m].account == arr5[kk].account)
                                    {
                                        $scope.cjhbArray[j].gtqkListArray[m].wtsl = arr5[kk].wtsl;
                                        $scope.cjhbArray[j].gtqkListArray[m].wtsj = arr5[kk].wtsj.toString().substr(0,10);
                                        $scope.cjhbArray[j].gtqkListArray[m].cjsl = arr5[kk].cjsl;
                                        $scope.cjhbArray[j].gtqkListArray[m].cjje = arr5[kk].cjje;

                                        if(parseFloat($scope.cjhbArray[j].gtqkListArray[m].cjsl) == 0)
                                        {
                                            $scope.cjhbArray[j].gtqkListArray[m].cjjg = "0.00元";
                                        }
                                        else
                                        {
                                            $scope.cjhbArray[j].gtqkListArray[m].cjjg = (parseFloat($scope.cjhbArray[j].gtqkListArray[m].cjje)/parseFloat(arr5[kk].cjsl)).toFixed(2) + "元";
                                        }
                                        mark = true;
                                        break;
                                    }
                                }
                                if(mark == false)//未找到对应的数据，新的数据
                                {
                                    $scope.cjhbArray[j].gtqkListArray.push(arr5[kk]);
                                }
                            }
                        }
                        break;
                    }
                }
            }
            $scope.yjqcClearInterval();
            $scope.yjqchqintervalId = setInterval($scope.yjqcgetcjhb, $scope.yjqchqintervalDuration);
        }
    }

    $scope.yjqcClearInterval = function()
    {
        if ($scope.yjqchqintervalId != undefined) {
            clearInterval($scope.yjqchqintervalId);
        }
    }

    $scope.yjqcbacktoParent = function()
    {
        $scope.yjqcClearInterval();
        $scope.backtoParent();
    }

}

/**一键建仓/调仓**/
function yjjctcwgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.yjjctcvaluechange = false;//是否已经有仓位股票变化
    $scope.yjjctchomeShow = true;
    $scope.yjjctcinfo = "";//调仓信息
    $scope.yjjctcMark = true;
    $scope.tradeallShow = true;//交易主界面
    $scope.cjhbDiv = false;//成交回报显示界面
    $scope.cjhbArray = [];//成交回报数组
    $scope.dqwtsjh = "";//当前委托随机号

    $scope.stocklistArray = [];//股票池股票，去掉剩余占比
    $scope.oldstocklistArray = [];//原股票池股票部分数据，客户放弃调仓时，数据还原

    $scope.yjjctckyzj = "--";//可用资金
    $scope.yjjctczzc  = 0;//总资产

    $scope.oneStockPoolPercent = 100.00;//当前股票池的剩余总比例，调整后也改变
    $scope.oldStockPoolPercent = 100.00;//当前股票池的剩余总比例，调整不改变，显示用
    $scope.stockPoolPercentChangeShow = false;//是否显示改变
    $scope.stockPoolPercentChangeValue = ""; //股票池的剩余总比例变化区间;

    $scope.addstockInfo = "";//当前添加的股票信息
    $scope.allSearchStockListArray = [];//搜索的股票列表


    $scope.yjjctchqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.yjjctchqintervalId;

    $scope.kckcjhb = false;//可查看成交回报
    //返回可选择的区间
    $scope.getSelectValue = function(_value1, _value2, value3)//原占比，可用占比，新占比
    {
        var arr = [];
        //var nim = Math.ceil(_value1 -  _value2);//最小值
        var nim = Math.ceil(_value2);//最小值
        //console.log("nim", _value1, _value2, nim);
        var max = Math.floor($scope.oneStockPoolPercent + value3);//最大值
        //console.log("$scope.oneStockPoolPercent", _value1, _value2, value3, $scope.oneStockPoolPercent, nim, max);
        for(var i = nim;i<=max;i++)
        {
            var obj = {};
            obj.value = i;
            arr.push(obj);
        }
        return arr;
    };

    $scope.yjqcquery = function ()
    {
        //$scope.stocklistArray = [];
        //$scope.oldstocklistArray = [];

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            console.log("一键建仓、调仓",result);
            var num = 100.00;
            $scope.yjjctcinfo = "";
            //$scope.stocklistArray = [];
            $scope.oldstocklistArray = [];
            if (result.op.code == 'Y')
            {
                var arr = result.securitypositionlist;
                var arr2 = [];
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.gpdm = arr[i].code;
                        obj.gpmc = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.tc = obj.exchange + obj.gpdm;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zs = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//全部数量
                        obj.ky = parseInt(arr[i].kysl);
                        obj.xj = arr[i].dqj;
                        //obj.yk = arr[i].fdyk;
                        var dqjvalue = parseFloat(arr[i].dqj.toString());//当前价
                        var kyslvalue = parseFloat(arr[i].kysl.toString());//可用数量
                        var djslvalue = parseFloat(arr[i].djsl.toString());//冻结数量
                        //console.log("zb", arr[i].djsl.toString());
                        obj.djsl = djslvalue;
                        obj.dqsl = kyslvalue + djslvalue;
                        obj.value = obj.dqsl * dqjvalue / $scope.yjjctczzc*100;//( kysl + djsl ) * dqj / zzc   //占比，zb
                        obj.zbstr = obj.value.toFixed(2);
                        obj.changezbstr = "";
                        obj.changeShow = false;//是否显示调整值;
                        obj.kyzbvalue = djslvalue * dqjvalue / $scope.yjjctczzc;
                        //obj.onepercent = Math.floor(obj.dqsl/obj.value*100);//1%所占的股票数量

                        obj.kyzb = obj.kyzbvalue*100;
                        //obj.kyzb = Math.ceil(obj.kyzbvalue*10000);//(obj.kyzbvalue*100).toFixed(2);//可用占比，可以卖出的
                        //console.log("zb", obj.kyzb, obj.onepercent);
                        obj.newzb = obj.value;//调整后的占比
                        obj.newzbstr = obj.newzb.toFixed(2);

                        obj.newdqsl = 0;
                        obj.newdqslStr = obj.newdqsl.toFixed(0);
                        obj.isnew = false;

                        //num = num - obj.value;
                        //obj.dqj = (parseFloat(element[item]['now'].toString())).toFixed(2);//当前价
                        //obj.zdf = (parseFloat(element[item]['zdf'].toString())).toFixed(2);//涨跌幅
                        arr2.push(obj);
                    }
                    //if($scope.stocklistArray.length == 0)
                    //{
                    //    $scope.stocklistArray = arr2;
                    //}
                    //else
                    //{
                    var arr3 = [];

                    for(var i = 0;i<arr2.length;i++)
                    {
                        var mark = false;
                        for(var j = 0;j<$scope.stocklistArray.length;j++)
                        {
                            if($scope.stocklistArray[j].tc == arr2[i].tc)
                            {
                                mark = true;
                                $scope.stocklistArray[j] = arr2[i];
                                //if($scope.stocklistArray[j].changeShow == false)
                                //{
                                //    $scope.stocklistArray[j] = arr2[i];
                                //}
                                //else
                                //{
                                //    var obj2 = arr2[i];
                                //    obj2.changeShow = true;
                                //    obj2.newzb = $scope.stocklistArray[j].value;//调整后的占比
                                //    obj2.newzbstr = $scope.stocklistArray[j].newzb;
                                //
                                //    obj2.newdqsl = $scope.stocklistArray[j].newdqsl;
                                //    obj2.newdqslStr = $scope.stocklistArray[j].newdqslStr;
                                //    $scope.stocklistArray[j] = obj2;
                                //}
                                break;
                            }
                        }
                        if(mark == false)
                        {
                            arr3.push(arr2[i]);
                        }
                    }
                    $scope.stocklistArray = $scope.stocklistArray.concat(arr3);

                    //}

                    for(var i = 0;i<$scope.stocklistArray.length;i++)
                    {
                        num = num - $scope.stocklistArray[i].value;
                    }

                    //剩余现金
                    $scope.oneStockPoolPercent = num;
                    $scope.oldStockPoolPercent = num;
                    $scope.stockPoolPercentChangeShow = false;
                    $scope.stockPoolPercentChangeValue = "";

                    for(var i = 0;i<$scope.stocklistArray.length;i++)
                    {
                        //console.log($scope.stocklistArray[i].value, $scope.stocklistArray[i].kyzb, $scope.stocklistArray[i].djsl, $scope.stocklistArray[i].newzb);
                        $scope.stocklistArray[i].selectValue = $scope.getSelectValue($scope.stocklistArray[i].value, $scope.stocklistArray[i].kyzb, $scope.stocklistArray[i].newzb)///可选择区间数组

                        var obj = {};
                        obj.tc = $scope.stocklistArray[i].tc;
                        obj.value = $scope.stocklistArray[i].value;//占比，zb
                        obj.zbstr = $scope.stocklistArray[i].zbstr;
                        obj.changezbstr = $scope.stocklistArray[i].changezbstr;
                        obj.changeShow = $scope.stocklistArray[i].changeShow;
                        obj.kyzb = $scope.stocklistArray[i].kyzb;
                        obj.newzb = $scope.stocklistArray[i].newzb;
                        obj.newzbstr = $scope.stocklistArray[i].newzbstr;
                        obj.newdqsl = $scope.stocklistArray[i].newdqsl;
                        obj.newdqslStr = $scope.stocklistArray[i].newdqslStr;

                        //console.log("old", obj.tc, obj.value, obj.newzb, obj.changezbstr, obj.changeShow, obj.kyzb, obj.newzb, obj.newzbstr, obj.newdqsl, obj.newdqslStr);
                        $scope.oldstocklistArray.push(obj);
                    }

                } else {

                    //$scope.stocklistArray = [];
                }
            } else {
                //$scope.stocklistArray = [];
            }
        });
    };

    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("可用资金", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.money;
            $scope.yjjctckyzj = parseFloat(arr.kyzj.toString());//可用资金
            $scope.yjjctczzc = parseFloat(arr.zzc.toString());

            //查询持仓
            $scope.yjqcquery();

        }

    }

    $scope.getzc = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    //查资产
    $scope.getzc();

    //改变占比
    $scope.selectChange = function(_obj)
    {

        $scope.yjjctcvaluechange = true;
        _obj.changeShow = false;//是否显示调整值;
        $scope.oldzb = _obj.newzb;
        var newzb = parseFloat(_obj.newzbstr);
        _obj.newzb = newzb;
        _obj.changezbstr = (parseFloat(_obj.value.toString())).toFixed(2) + "%→"+  newzb.toFixed(2) + "%";
        //console.log(($scope.yjjctczzc * _obj.newzb*1.0/100) / _obj.xj);
        //console.log($scope.yjjctczzc, _obj.newzb, _obj.xj,  _obj.dqsl);
        _obj.newdqsl = Math.ceil((Math.floor(($scope.yjjctczzc * _obj.newzb*1.0/100)/_obj.xj) - _obj.dqsl)/100)*100;
        //console.log("555", _obj.newdqsl);
        //
        //var tzbl = newzb - parseFloat(_obj.value.toString());
        //_obj.newdqsl = Math.ceil(tzbl * _obj.onepercent/10000)*100;
        //console.log("newdqsl",_obj.newdqsl);
        //obj.newdqsl = 0;
        if(_obj.newdqsl > 0)
        {
            _obj.newdqslStr = "+" + _obj.newdqsl;
        }
        else
        {
            _obj.newdqslStr = "" + _obj.newdqsl;
        }
        //_obj.changezbstr = newzb.toFixed(2);
        _obj.changeShow = true;//是否显示调整值;
        var n =  newzb - $scope.oldzb;
        $scope.oneStockPoolPercent = parseFloat(($scope.oneStockPoolPercent - n).toFixed(2));
        $scope.stockPoolPercentChangeValue = $scope.oldStockPoolPercent.toFixed(2)+"% → " + $scope.oneStockPoolPercent.toFixed(2) + "%";
        $scope.stockPoolPercentChangeShow = true;//显示调整状态

        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            $scope.stocklistArray[i].selectValue = $scope.getSelectValue($scope.stocklistArray[i].value, $scope.stocklistArray[i].kyzb, $scope.stocklistArray[i].newzb)///可选择区间数组
        }
    };

    //添加成分股
    $scope.addStockClick = function()
    {
        $scope.yjjctchomeShow = false;
        $scope.stockDiv = true;
        $scope.addstockInfo = "";
    }

    //添加股票返回
    $scope.closeStockSearch = function()
    {
        $scope.yjjctchomeShow = true;
        $scope.stockDiv = false;
        $scope.addstockInfo = "";
        $scope.allSearchStockListArray = [];
        $scope.searchStockValue = "";
    }

    //股票搜索框改变
    $scope.searchinputChange = function()
    {
        if($scope.searchStockValue != "")
        {
            $scope.checkContent();
        }
        else
        {
            $scope.allSearchStockListArray = [];
        }
    }

    //判断并显示搜索股票
    $scope.checkContent = function()
    {
        //匹配
        //ajaxService.searchStock($scope.searchStockValue, $scope.searchStockCallBack);
        var message = {};
        message['key'] = $scope.searchStockValue.toUpperCase();
        message['isprice'] ="price";
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.searchStockCallBack);
    }

    //搜索股票返回
    $scope.searchStockCallBack = function(_data)
    {
        //console.log("搜索");
        //console.log(_data);
        if($scope.searchStockValue == "")
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.searchStockValue.toUpperCase()) {
                var element = _data.data;
                if(element.length>0)
                {
                    var arr = [];
                    for (var item in element)
                    {
                        var obj = {};
                        obj.asset = element[item]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[item]['symbol'];
                        obj.gpmc = element[item]['name'];
                        obj.exchange = element[item]['exchange'].toString().toUpperCase();//交易所
                        obj.label = obj.gpmc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange + obj.gpdm;
                        obj.xj = (parseFloat(element[item]['price'].toString())).toFixed(2);//当前价
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.allSearchStockListArray = arr;
                }
                else
                {
                    $scope.allSearchStockListArray = [];
                    return;
                }
            }
        }
        else
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        for(var i = 0;i<$scope.allSearchStockListArray.length;i++)
        {
            var mark = false;
            for(var j = 0;j<$scope.stocklistArray.length;j++)
            {
                if($scope.stocklistArray[j].tc == $scope.allSearchStockListArray[i].tc)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == true)//已经存在  0：未加，1：已加
            {
                $scope.allSearchStockListArray[i].status = "1";
                $scope.allSearchStockListArray[i].statusstr = "已添加";
            }
            else
            {
                $scope.allSearchStockListArray[i].status = "0";
                $scope.allSearchStockListArray[i].statusstr = " 添加";
            }
        }
    }

    //添加一只股票
    $scope.addOneStockClick = function(_obj)
    {
        //console.log(obj);
        if(_obj.status == "0")
        {
            //在当前股票池列表中添加此股票
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if(_obj.label == $scope.allSearchStockListArray[i].label)
                {
                    //股票池股票更新
                    var obj = new Object();
                    //obj = $scope.allSearchStockListArray[i];
                    obj.gpdm = $scope.allSearchStockListArray[i].gpdm;
                    obj.gpmc = $scope.allSearchStockListArray[i].gpmc;
                    obj.label = $scope.allSearchStockListArray[i].label;
                    obj.exchange = $scope.allSearchStockListArray[i].exchange;
                    obj.tc = $scope.allSearchStockListArray[i].tc;
                    obj.zs = 0;
                    obj.ky = 0;
                    obj.xj = $scope.allSearchStockListArray[i].xj;//当前价
                    //obj.zdf = $scope.allSearchStockListArray[i].zdf;//涨跌幅


                    obj.djsl = 0;
                    obj.dqsl = 0;
                    obj.value = 0.00;//占比
                    obj.zbstr = obj.value.toFixed(2);
                    obj.changezbstr = "";
                    obj.changeShow = false;//是否显示调整值;
                    obj.kyzbvalue = 0;
                    //obj.onepercent = Math.floor(obj.dqsl/obj.value*100);//1%所占的股票数量
                    obj.kyzb = obj.kyzbvalue*100;
                    obj.newzb = 0.00;//调整后的占比
                    obj.newzbstr = "0.00";
                    obj.newdqsl = 0;
                    obj.newdqslStr = obj.newdqsl.toFixed(0);
                    obj.selectValue = $scope.getSelectValue(obj.value, obj.kyzb, obj.newzb);//可选择区间数组
                    obj.isnew = true;//是否是新加

                    $scope.allSearchStockListArray[i].status = "1";
                    $scope.allSearchStockListArray[i].statusstr = "已添加";

                    $scope.stocklistArray.push(obj);

                    break;
                }
            }
        }
    };

    //取消操作
    $scope.yjjctccancelClick = function()
    {
        if($scope.yjjctcMark)//可操作状态
        {
            console.log("判断是否有改动", $scope.isChanged())
            //判断是否有改动//true:已经改动，false：未改动
            if($scope.isChanged())//已经改动，还原
            {
                var arr5 = [];
                for(var i = 0;i<$scope.stocklistArray.length;i++)
                {
                    if($scope.stocklistArray[i].isnew)
                    {
                        arr5.push($scope.stocklistArray[i]);
                    }
                }
                for(var i = 0;i<arr5.length;i++)
                {
                    for(var j = 0;j<$scope.stocklistArray.length;j++)
                    {
                        if(arr5[i].tc == $scope.stocklistArray[j].tc)
                        {
                            $scope.stocklistArray.splice(j,1);
                            break;
                        }
                    }
                }

                var arr = [];
                for(var i = 0;i<$scope.oldstocklistArray.length;i++)
                {
                    for(var j = 0;j<$scope.stocklistArray.length;j++)
                    {
                        if($scope.oldstocklistArray[i].tc == $scope.stocklistArray[j].tc)
                        {
                            //console.log("same", $scope.oldstocklistArray[i].tc);
                            $scope.stocklistArray[j].value = $scope.oldstocklistArray[i].value;//占比，zb
                            $scope.stocklistArray[j].zbstr = $scope.oldstocklistArray[i].zbstr;
                            $scope.stocklistArray[j].changezbstr = $scope.oldstocklistArray[i].changezbstr;
                            $scope.stocklistArray[j].changeShow = $scope.oldstocklistArray[i].changeShow;
                            //console.log("old", $scope.oldstocklistArray[i].changeShow);
                            $scope.stocklistArray[j].kyzb = $scope.oldstocklistArray[i].kyzb;
                            $scope.stocklistArray[j].newzb = $scope.oldstocklistArray[i].newzb;
                            $scope.stocklistArray[j].newzbstr = $scope.oldstocklistArray[i].newzbstr;
                            $scope.stocklistArray[j].newdqsl = $scope.oldstocklistArray[i].newdqsl;
                            $scope.stocklistArray[j].newdqslStr = $scope.oldstocklistArray[i].newdqslStr;

                            arr.push($scope.stocklistArray[j]);
                            break;
                        }
                    }
                }
                $scope.stocklistArray = arr;

                //剩余现金
                $scope.oneStockPoolPercent = $scope.oldStockPoolPercent;
                $scope.stockPoolPercentChangeShow = false;
                $scope.stockPoolPercentChangeValue = "";

            }
            $scope.yjjctcvaluechange = false;
        }
    }

    $scope.tcjcClick = function()
    {
        $scope.yjjctcinfo = "";//调仓信息
        //$scope.yjjctcMark = true;
        if($scope.yjjctcMark)
        {
            if($scope.stocklistArray.length<=0)
            {
                $scope.yjjctcinfo = "请调入股票";
                return;
            }
            if($scope.isChanged())//有改动
            {
                $scope.yjjctcClearInterval();
                $scope.cjhbArray = [];
                $scope.kckcjhb = false;
                $scope.yjjctcMark = false;
                $scope.updateStockList();
            }
            else
            {
                $scope.yjjctcinfo = "持仓无修改，请重新调仓";
                return;
            }
        }

    }

    $scope.updateStockList = function()
    {
        var mark = false;
        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            //console.log($scope.stocklistArray[i].newzbstr, $scope.stocklistArray[i].zbstr , $scope.stocklistArray[i].newzbstr);
            //if($scope.stocklistArray[i].newzbstr == $scope.stocklistArray[i].zbstr && $scope.stocklistArray[i].newzbstr == "0.00")
            //if($scope.stocklistArray[i].newdqsl == 0)
            //if($scope.stocklistArray[i].newzbstr == $scope.stocklistArray[i].zbstr && $scope.stocklistArray[i].newzbstr == "0.00")
            if($scope.stocklistArray[i].newdqsl == $scope.stocklistArray[i].dqsl && $scope.stocklistArray[i].newdqsl == 0 && $scope.stocklistArray[i].isnew == true)
            {
                mark = true;
                break;
            }
        }
        //console.log(mark);
        if(mark)//有为0的
        {
            var str = "持仓中调仓数量为0的股票将被移除，确定继续吗？";
            myConfirm(str, $scope.yjtcjcconfirm, $scope.yjtcjcancel, $scope.yjtcjcancel);


            //if(confirm(str))//确定创建
            //{
            //    //去掉占比为0的股票，去掉调整前后一样的股票
            //    for (var i = 0; i < $scope.stocklistArray.length; i++)
            //    {
            //        if ($scope.stocklistArray[i].value != $scope.stocklistArray[i].newzb)//原占比不为现占比
            //        {
            //            arr.push($scope.stocklistArray[i]);
            //        }
            //    }
            //}
            //else
            //{
            //    $scope.yjjctcMark = true;
            //    return;
            //}
        }
        else//没有为占比为
        {
            //去掉调整前后一样的股票
            //for (var i = 0; i < $scope.stocklistArray.length; i++)
            //{
            //    if ($scope.stocklistArray[i].value != $scope.stocklistArray[i].newzb)//原占比不为现占比
            //    {
            //        arr.push($scope.stocklistArray[i]);
            //    }
            //}
            $scope.yjtcjcgoto();
        }

    }

    $scope.yjtcjcconfirm = function()
    {
        layer.closeAll();
        var arr = [];
        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            //console.log(1232132,$scope.stocklistArray[i].newdqsl , $scope.stocklistArray[i].dqsl);
            if($scope.stocklistArray[i].newdqsl == $scope.stocklistArray[i].dqsl && $scope.stocklistArray[i].newdqsl == 0)
            {
                arr.push($scope.stocklistArray[i]);
            }
        }
        //console.log("arr", arr.length);
        for(var i = 0;i<arr.length;i++)
        {
            for(var j = 0;j<$scope.stocklistArray.length;j++)
            {
                if(arr[i].tc == $scope.stocklistArray[j].tc)
                {
                    $scope.stocklistArray.splice(j,1);
                    break;
                }
            }
        }

        $scope.yjtcjcgoto();
    }

    $scope.yjtcjcancel = function()
    {
        layer.closeAll();
        $scope.yjjctcMark = true;
    }

    $scope.yjtcjcgoto = function()
    {
        var arr = [];
        for (var i = 0; i < $scope.stocklistArray.length; i++)
        {
            if ($scope.stocklistArray[i].value != $scope.stocklistArray[i].newzb)//原占比不为现占比
            {
                arr.push($scope.stocklistArray[i]);
            }
            $scope.stocklistArray[i].isnew = false;//全不是新加
        }

        if(arr.length>0)
        {
            $scope.yjjctcinfo = "提交中，请稍候...";
            //var str2 = "";
            //for(var i = 0;i<arr.length;i++)
            //{
            //    if(i == 0)
            //    {
            //        str2 = arr[i].gpdm + "," + (arr[i].newzb/100).toFixed(2);
            //    }
            //    else
            //    {
            //        str2 = str2 + ";" + arr[i].gpdm + "," + (arr[i].newzb/100).toFixed(2);
            //    }
            //}

            var obj ={};
            $scope.cjhbArray = [];//成交回报数组
            //$scope.$apply();
            for(var i = 0;i<arr.length;i++)
            {
                var obj2 = {};
                obj2.id = $scope.userObj.f_id;
                console.log("userid", $scope.userObj.f_id);
                obj2.headurl = decodeURIComponent(localStorage.getItem("iconurl"));
                obj2.name = decodeURIComponent(localStorage.getItem("nickname"));
                obj2.gpdm = arr[i].gpdm;
                obj2.gpmc = arr[i].gpmc;
                obj2.tc = arr[i].exchange.toString().toUpperCase() + obj2.gpdm;
                obj2.xdwtsl = Math.abs(arr[i].newdqsl);
                if(arr[i].newdqsl > 0)
                {
                    obj2.tradetype = "买入";
                    obj2.side = "B";
                }
                else
                {
                    obj2.tradetype = "卖出";
                    obj2.side = "S";
                }
                $scope.cjhbArray.push(obj2);


                if(i == 0)
                {
                    obj.stockcodes = arr[i].gpdm;
                    obj.exchanges = arr[i].exchange.toString().toUpperCase();
                    if(arr[i].exchange.toString().toUpperCase() == "SZ")
                    {
                        obj.ddlxs = "f";
                    }
                    else
                    {
                        obj.ddlxs = "r";
                    }
                    if(arr[i].newdqsl > 0)
                    {
                        obj.sides = "B";
                    }
                    else
                    {
                        obj.sides = "S";
                    }
                    obj.wtsls = Math.abs(arr[i].newdqsl);

                    obj.wtjgs = "0";
                }
                else
                {
                    obj.stockcodes =  obj.stockcodes + "," + arr[i].gpdm;
                    obj.exchanges = obj.exchanges + "," + arr[i].exchange.toString().toUpperCase();
                    if(arr[i].exchange.toString().toUpperCase() == "SZ")
                    {
                        obj.ddlxs = obj.ddlxs + "," + "f";
                    }
                    else
                    {
                        obj.ddlxs = obj.ddlxs + "," +"r";
                    }
                    if(arr[i].newdqsl > 0)
                    {
                        obj.sides = obj.sides + "," + "B";
                    }
                    else
                    {
                        obj.sides = obj.sides + "," + "S";
                    }
                    obj.wtsls = obj.wtsls + "," + Math.abs(arr[i].newdqsl);
                    obj.wtjgs = obj.wtjgs + "," + "0";
                }
            }

            $scope.dqwtsjh = "";
            var message = {};
            message['account'] = $scope.childaccount;
            message['stockcodes'] = obj.stockcodes;
            message['exchanges'] =  obj.exchanges;
            message['ddlxs'] =  obj.ddlxs;
            message['sides'] = obj.sides;
            message['wtsls'] = obj.wtsls;
            message['wtjgs'] = obj.wtjgs;
            message["mac"] = $scope.deviceid;
            var newdate = new Date();
            message['extra'] = $scope.childaccount + newdate.getTime();
            $scope.dqwtsjh = message['extra'];
            console.log(message['account'], message['stockcodes'], message['exchanges'],message['ddlxs'],message['sides'],message['wtsls'], message['wtjgs'],message['extra']);

            ajaxService.sendMessage("sunflower.p_batchwt", message, $scope.yjtcjcCallBack);
        }
        else
        {
            $scope.yjjctcMark = true;
            $scope.$apply();
            //$scope.yjjctcinfo = "移除持仓中占比为0的股票后持仓为空，请重新添加";
        }

    }


    $scope.yjtcjcCallBack = function(_data)
    {
        console.log("一键调仓建仓", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.yjjctcinfo = "委托提交成功";
            $scope.yjjctcvaluechange = false;
            $scope.kckcjhb = true;
            $scope.yjjctcgetcjhb();

        }
        else
        {
            $scope.yjjctcinfo = "委托提交失败，请重试";
        }

        $scope.yjjctcMark = true;
    }

    //是否改变
    $scope.isChanged = function()
    {
        var mark = false;//未改动
        //if($scope.stocklistArray.length == $scope.oldstocklistArray.length)//未有新加股票
        //{
        //    for(var i = 0;i<$scope.stocklistArray.length;i++)//判断是否有改动
        //    {
        //        if($scope.stocklistArray[i].value != $scope.stocklistArray[i].newzb)//原占比不为现占比，有改动
        //        {
        //            mark = true;
        //            break;
        //        }
        //    }
        //}
        if($scope.stocklistArray.length == $scope.oldstocklistArray.length)//未有新加股票
        {
            for(var i = 0;i<$scope.stocklistArray.length;i++)//判断是否有改动
            {
                if($scope.stocklistArray[i].isnew)//有新加股票
                {
                    mark = true;
                    break;
                }
                else if($scope.stocklistArray[i].value != $scope.stocklistArray[i].newzb)//原占比不为现占比，有改动WW
                {
                    mark = true;
                    break;
                }
            }
        }
        else//有新加股票，有改动
        {
            mark = true;
        }
        return mark;

    }

    //查看成交回报
    $scope.gotockcjhb = function()
    {
        $scope.yjjctchomeShow = false;
        $scope.cjhbDiv = true;
    }
    $scope.backtradeClick = function()
    {
        $scope.yjjctchomeShow = true;
        $scope.cjhbDiv = false;
    }
    //获取成交回报
    $scope.yjjctcgetcjhb = function()
    {
        console.log("获取成交回报");
        var message = {};
        message['account'] = $scope.childaccount;
        message['extra'] =  $scope.dqwtsjh;
        console.log(message['account'],message['extra']);

        ajaxService.sendMessage("sunflower.p_selectbatchorder", message, $scope.yjjctcgetcjhbCallBack);

        $scope.getzc();
    }

    $scope.yjjctcgetcjhbCallBack = function(_data)
    {
        $scope.yjjctcClearInterval();
        console.log("一键建仓/调仓成交回报", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            for(var i=0;i<arr.length;i++)
            {
                var obj = arr[i].mainorder;
                var tc = obj.exchange.toString().toUpperCase() + obj.code;
                for(var j = 0;j<$scope.cjhbArray.length;j++)
                {
                    if(tc == $scope.cjhbArray[j].tc)
                    {
                        $scope.cjhbArray[j].wtsl = obj.wtsl;
                        $scope.cjhbArray[j].wtsj = obj.wtsj;
                        $scope.cjhbArray[j].wtjg = "市价";//parseFloat(obj.wtjg).toFixed(2);
                        $scope.cjhbArray[j].cjsl = parseFloat(obj.cjsl);
                        if (obj.cjsl == 0) {
                            $scope.cjhbArray[j].cjjg = "0.00元";
                        }
                        else {
                            $scope.cjhbArray[j].cjjg = (parseFloat(obj.cjje) / parseFloat(obj.cjsl)).toFixed(2) + "元";
                        }


                        var arr2 = arr[i].gentouorderlist;

                        //if($scope.cjhbArray[j].gtqkListArray == null || $scope.cjhbArray[j].gtqkListArray == undefined || $scope.cjhbArray[j].gtqkListArray.length == 0)
                        //{
                        var arr5 = [];
                        for (var k = 0; k < arr2.length; k++) {
                            var obj2 = {};
                            obj2.userid = arr2[k].user.user.f_id;
                            obj2.headurl = arr2[k].user.user.f_head;
                            obj2.name = arr2[k].user.user.f_nickname;
                            obj2.wtsl = arr2[k].wtsl;
                            obj2.wtsj = arr2[k].wtsj.toString().substr(0, 10);
                            obj2.cjsl = arr2[k].cjsl;
                            obj2.account = arr2[k].account;
                            obj2.cjje = arr2[k].cjje;
                            if (parseFloat(arr2[k].wtjg) == 0) {
                                obj2.wtjg = "市价";
                            }
                            else {
                                obj2.wtjg = parseFloat(arr2[k].wtjg).toFixed(2) + "元";
                            }

                            if (parseFloat(obj2.cjsl) == 0) {
                                obj2.cjjg = "0.00元";
                            }
                            else {
                                obj2.cjjg = (parseFloat(arr2[k].cjje) / parseFloat(obj2.cjsl)).toFixed(2) + "元";
                            }

                            //console.log("成交金额2222222222",obj2.cjje, obj2.cjsl);
                            arr5.push(obj2);
                        }
                        //console.log("跟投者数量", arr5.length);
                        if ($scope.cjhbArray[j].gtqkListArray == null || $scope.cjhbArray[j].gtqkListArray == undefined || $scope.cjhbArray[j].gtqkListArray.length == 0) {
                            $scope.cjhbArray[j].gtqkListArray = arr5;
                        }
                        else {
                            for (var kk = 0; kk < arr5.length; kk++) {
                                var mark = false;
                                for (var m = 0; m < $scope.cjhbArray[j].gtqkListArray.length; m++) {
                                    if ($scope.cjhbArray[j].gtqkListArray[m].account == arr5[kk].account) {
                                        $scope.cjhbArray[j].gtqkListArray[m].wtsl = arr5[kk].wtsl;
                                        $scope.cjhbArray[j].gtqkListArray[m].wtsj = arr5[kk].wtsj.toString().substr(0, 10);
                                        $scope.cjhbArray[j].gtqkListArray[m].cjsl = arr5[kk].cjsl;
                                        $scope.cjhbArray[j].gtqkListArray[m].cjje = arr5[kk].cjje;

                                        //console.log("成交金额",$scope.cjhbArray[j].gtqkListArray[m].cjje, $scope.cjhbArray[j].gtqkListArray[m].cjsl);
                                        if (parseFloat($scope.cjhbArray[j].gtqkListArray[m].cjsl) == 0) {
                                            $scope.cjhbArray[j].gtqkListArray[m].cjjg = "0.00元";
                                        }
                                        else {
                                            $scope.cjhbArray[j].gtqkListArray[m].cjjg = (parseFloat($scope.cjhbArray[j].gtqkListArray[m].cjje) / parseFloat($scope.cjhbArray[j].gtqkListArray[m].cjsl)).toFixed(2) + "元";
                                        }
                                        mark = true;//找到对应的数据
                                        break;
                                    }
                                }
                                if (mark == false)//未找到对应的数据，新的数据
                                {
                                    $scope.cjhbArray[j].gtqkListArray.push(arr5[kk]);
                                }
                            }
                            //console.log("跟投者数量22222", arr5.length);
                        }
                        break;
                    }
                }
            }
            $scope.yjjctcClearInterval();
            $scope.yjjctchqintervalId = setInterval($scope.yjjctcgetcjhb, $scope.yjjctchqintervalDuration);
        }
    }

    $scope.yjjctcClearInterval = function()
    {
        if ($scope.yjjctchqintervalId != undefined) {
            clearInterval($scope.yjjctchqintervalId);
        }
    }

    $scope.yjjctcbacktoParent = function()
    {
        $scope.yjjctcClearInterval();
        $scope.backtoParent();
    }
}