function gtsykykwcc()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_sy_kykwcc.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsykykwccCtrl($scope, ajaxService, $cookieStore) {
    //console.log("5345");
    $scope.zhInfo = {};
    $scope.childaccount = "";

    //$scope.account = getParameter("account");

    //console.log("查询持仓");

    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志
    $scope.drjyjlArray = [];//当日交易记录

    //侦听获取参数，并请求数据
    //console.log("侦听");

    $scope.ccrefreshintervalDuration = 5000;//间隔时间，5000毫秒;
    $scope.ccrefreshID;

    //去除
    $scope.ccrefreshClearInterval = function () {
        if ($scope.ccrefreshID != undefined) {
            clearInterval($scope.ccrefreshID);
        }
    }

    $scope.ccselectsecuritymoneyactionCallBack2 = function(_data)
    {
        //console.log("可用资金", _data);
        var arr = _data.money;
        $scope.cckyzj = parseFloat(arr.kyzj.toString());
        $scope.cczzc = parseFloat(arr.zzc.toString());
        $scope.cczsz = parseFloat(arr.zsz.toString());
        //$scope.ccljyk = parseFloat(arr.zzc.toString()) - parseFloat(arr.ljcrj.toString());
        //$scope.ccljyk = parseFloat(arr.ccyk.toString());
    }

    $scope.getccinfo2 = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack2) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;

    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            //console.log("持仓",result)
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                $scope.ccljyk = parseFloat(result.ccyk.toString());
                if($scope.ccljyk >0)
                {
                    $scope.flag = "1";
                }
                else if($scope.ccljyk <0)
                {
                    $scope.flag = "-1";
                }
                else
                {
                    $scope.flag = "0";
                }
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = parseFloat(arr[i].dqj).toFixed(2);
                        obj.cbj = parseFloat(arr[i].cbj);
                        obj.yk = arr[i].fdyk;
                        obj.zdf = parseFloat(arr[i].zdf).toFixed(2) + "%";
                        var zdfv = parseFloat(parseFloat(arr[i].zdf).toFixed(2));
                        if(zdfv >0)
                        {
                            obj.zdfflag = "1";
                        }
                        else if(zdfv <0)
                        {
                            obj.zdfflag = "-1";
                        }
                        else
                        {
                            obj.zdfflag = "0";
                        }
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        obj.asset = getzqStatus(arr[i].basetype);
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

            $scope.ccrefreshClearInterval();
            //console.log("状态：", $scope.tabOneShow);
            if($scope.wtList.length>0 && $scope.tabTwoShow)
            {
                $scope.ccrefreshID = setInterval($scope.zhqueryall, $scope.ccrefreshintervalDuration);
            }
        });
    };

    //产品盈亏
    $scope.p_getykCallBack = function(_data) {
        //console.log("产品2222：" + _data);
        if (_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            //$scope.productname = product.name;
            //$scope.dqgtInfo = {};
            //$scope.dqgtInfo.productname = product.name;
            //$scope.dqgtInfo.productid = $scope.productid;//产品id
            //$scope.dqgtInfo.zq = product.gentouperiod;
            //$scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.ccljyk = parseFloat(product.ljyk);
            if($scope.ccljyk >0)
            {
                $scope.flag = "1";
            }
            else if($scope.ccljyk <0)
            {
                $scope.flag = "-1";
            }
            else
            {
                $scope.flag = "0";
            }
        }
    }

    $scope.getcpyk = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getykCallBack);
    }

    //当日交易记录
    $scope.getdrjyjlCallBack = function(_data)
    {
        $scope.drjyjlArray = [];
        //console.log("今日交易记录", _data)
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.changepositionlist;
            var arr2 = [];
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.time = arr[i].wtsj.toString().substr(11,8);
                obj.gpdm = arr[i].code;
                obj.exchange = arr[i].exchange;
                obj.gpmc = arr[i].name;
                obj.side = arr[i].side.toString();
                if(obj.side == "B")
                {
                    obj.sideStr = "买入";
                }
                else
                {
                    obj.sideStr = "卖出";
                }
                obj.wtsl = arr[i].wtsl + "股";//成交数量。原先是显示委托数量，后改成显示成交数量，前端未动，后端将成交数量命名为wtsl
                obj.wtjg = parseFloat(arr[i].wtjg).toFixed(2) + "元";//成交价格，原因同上。
                obj.asset = getzqStatus(arr[i].basetype);
                arr2.push(obj);
            }

            for(var i = 0;i<arr2.length;i++)
            {
                var mark = false;//是否已经处理
                for(var k = 0;k<$scope.drjyjlArray.length;k++)
                {
                    if($scope.drjyjlArray[k].time == arr2[i].time)
                    {
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    var obj = {};
                    obj.time = arr2[i].time;
                    obj.yfshow = true;//是否展开 0：展开，1：不展开 ，界面显示用
                    var arr3 = [];
                    for(var j = i;j<arr2.length;j++)
                    {
                        if(arr2[j].time == obj.time)
                        {
                            arr3.push(arr2[j]);
                        }
                    }
                    obj.dataArr = arr3;
                    $scope.drjyjlArray.push(obj);
                }
            }
        }
    }

    $scope.getdrjyjl = function()
    {
        var message = {};
        message['account'] = $scope.childaccount;
        var str = gettodayno();
        message['kssj'] = str;
        message['jssj'] = str;
        //console.log("调仓记录222", message['kssj'], message['jssj']);
        ajaxService.sendMessage("sunflower.p_selectaccountpositionchangerecord", message, $scope.getdrjyjlCallBack) ;
    }

    $scope.zhqueryall = function()
    {
        $scope.getccinfo2();
        $scope.query();
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsycc")
        {
            $scope.childaccount = _data.account;
            //获取资产信息
            $scope.getccinfo2();
            $scope.query();
            $scope.getdrjyjl();
            //$scope.getcpyk();
        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsycc"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);


    //查看行情
    $scope.hqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        obj.account = $scope.childaccount;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //window.location.href = "tradinglive_info.html";
        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            xinyuNewBrowser("tradinglive_info.html?opentype=newwebview");
        }

    }

    //查看行情
    $scope.drjyjlhqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.gpmc);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        }

    }
}
