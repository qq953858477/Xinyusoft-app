function gtplinput()
{
	return {
		restrict: 'E',
		templateUrl: 'html/gt_pl_input.html',
		//template: '<span>Hi there</span>',
		replace: true,
		transclude: true
	};
}
function gtplinputCtrl($scope, ajaxService, $cookieStore) {
    $scope.plListArray = [];
    $scope.plcontent = "";
    $scope.plingMark = true;//评论中
	$scope.plcontentstr = "";//当前在发送的评论内容
    $scope.length = $scope.plListArray.length;
	$scope.curLcsid = "";//当前产品的理财师id;
	$scope.lasttime = "20151101000000";//上一次显示的时间;
    $scope.isFlower = false;
    $scope.imgSrc = "";
    //$scope.whichClick = "";//发送图片或者文字
    $scope.plcharacterDiv = true;//文字
    $scope.plvoiceDiv = false;//语音
    $scope.beginaudio = false;//开始录音
    $scope.voiceArray = [];//语音数组

    $scope.delwfbvoice = null;//当前选择需删除的语音

    $scope.voiceintervalDuration = 1000;//间隔时间，8000毫秒
    $scope.voiceintervalId;

    $scope.plwcintervalDuration = 1000;//评论完成
    $scope.plwcintervalId;

    //var obj = {};
    //obj.status = "wfb";//未发表
    //obj.c = "";
    //obj.lastmsgid = "chartid" + new Date().getTime();
    //obj.duration = "12";
    //$scope.voiceArray.push(obj);
    //
    //var obj = {};
    //obj.status = "lsb";//未发表
    //obj.c = "";
    //obj.lastmsgid = "chartid" + new Date().getTime();
    //obj.duration = "13";
    //$scope.voiceArray.push(obj);
    //
    //var obj = {};
    //obj.status = "yfb";//未发表
    //obj.c = "";
    //obj.lastmsgid = "chartid" + new Date().getTime();
    //obj.duration = "13";
    //$scope.voiceArray.push(obj);


    //去除
    $scope.voiceClearInterval = function () {
        if ($scope.voiceintervalId != undefined) {
            clearInterval($scope.voiceintervalId);
        }
    }

    //去除
    $scope.plwcClearInterval = function () {
        if ($scope.plwcintervalId != undefined) {
            clearInterval($scope.plwcintervalId);
        }
    }


    //发送消息
    $scope.sendplClick = function(param)
    {
    	//$scope.whichClick = param;
        if($scope.plingMark)
        {
        	if(param == "notflower"){
        		if($scope.plcontent == "")
                {
                    myAlert("请输入评论内容");
                    return;
                }
        	}
            $scope.plingMark = false;
            var message = {};
            //message['contenttype'] = "text";
            if(param == "flower"){
            	//alert("flower");
            	message['cnt'] = "//flower//";
            }else{
            	message['cnt'] = $scope.plcontent;
            }
			$scope.plcontentstr = message['cnt'];
            //message['content'] = $scope.plcontent;
            message['subjectid'] = $scope.productid;
            message['subjecttype'] = "product";
			message['subjectuserid'] = $scope.curLcsid;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendplCallBack);
        }
        else
        {
            //myAlert("评论提交中，请稍候");
        }
    }

    $scope.sendplCallBack = function(_data)
    {
        //console.log("发送消息",_data)
        if(_data.op.code.toString() == "Y")
        {
            //myAlert("评论成功");
			if(checkisFlower($scope.plcontentstr) == true)//不是花等图标
			{
				$scope.plcontent = "";
			}
            $scope.getpl();
            $scope.plwcClearInterval();
            myMsg("评论成功");
            $scope.plwcintervalId = setInterval($scope.cancelplinfo, $scope.plwcintervalDuration);
        }
        else
        {
            myAlert("评论发送失败");
        }
        $scope.plingMark = true;
		$scope.plcontentstr = "";
    }

    $scope.cancelplinfo = function()
    {
        try{
            layer.closeAll();
        }
        catch (e){}
        $scope.plwcClearInterval();
    }
	
	//点击评论关闭键盘
    function closePopClick (id){
    	if(id!="foot"){
    		document.getElementById("inputview").blur();
    	}
    };

	$scope.gtplinputbackClick = function()
	{
		$scope.plinputbackto();
	}

    //文字和语音切换
    $scope.plchangeTab = function(_str)
    {
        if(_str == "1")//文字
        {
            $scope.plcharacterDiv = true;
            $scope.plvoiceDiv = false;
        }
        else//语音
        {
            $scope.plcharacterDiv = false;
            $scope.plvoiceDiv = true;
        }
    }

    //$scope.plcontent2 = "";
    $scope.audioOnMouseDown = function(event)
    {
        //console.log("按下22");
        //开始录音
        $scope.beginaudio = true;
        try
        {
            navigator.recordplugin.startRecord("startAudioCallBack");
        }
        catch(e){
        }
        //event.preventDefault();
        //event.stopPropagation();
    }

    startAudioCallBack = function(_data)
    {
        //alert("开始录音：" + _data);
        $scope.voiceClearInterval();
        $scope.voiceintervalId = setInterval($scope.setvoiceduration, $scope.voiceintervalDuration);
            //$scope.$apply(function(){
            //        var obj = {};
            //        obj.status = "lyz";//录音中
            //        obj.c = "";//录音地址
            //        obj.duration = 0;//录音时间
            //        obj.lastmsgid = "chartid" + new Date().getTime();
            //        $scope.voiceArray.push(obj);
            //    }
            //);
        var obj = {};
        obj.status = "lyz";//录音中
        obj.c = "";//录音地址
        obj.duration = 0;//录音时间
        obj.lastmsgid = "chartid" + new Date().getTime();
        $scope.voiceArray.push(obj);
        $scope.$apply();

    }

    $scope.setvoiceduration = function()
    {
        $scope.$apply(function ()
        {
            var t = $scope.voiceArray.length;
            if(t>0) {
                $scope.voiceArray[t - 1].duration = $scope.voiceArray[t - 1].duration + 1;//录音时间
            }
        });

    }

    $scope.audioTouchCancel = function(event)
    {
        //event.preventDefault();
        //event.stopPropagation();
    }

    //弹起
    $scope.audioOnMouseUp = function(event)
    {
        //console.log("up");
        $scope.voiceClearInterval();
        $scope.beginaudio = false;
        try
        {
            navigator.recordplugin.endRecord("stopAudioCallBack","http://121.40.148.145:8080/uploadVoice");
        }
        catch(e){
            // console.log("弹起onError:" +  e.toString());
        }
        //录音结束并上传，获取url地址，并发送
        //$scope.sendAudioMessageClick();
    }

    stopAudioCallBack = function(_data)
    {
        //alert("录音结束，返回：" + _data);
        var t = $scope.voiceArray.length;
        var da = JSON.parse(_data);
        if(da["op.code"].toString() == "Y")
        {
            var str = da.src.toString();
            //var obj = {};
            //obj.status = "wfb";//未发表
            //obj.c = str;
            //obj.lastmsgid = "chartid" + new Date().getTime();
            //$scope.voiceArray.push(obj);
            //$scope.$apply();
            $scope.$apply(function (){
                if(t>0)
                {
                    $scope.voiceArray[t-1].status = "wfb";
                    $scope.voiceArray[t-1].c = str;//录音地址
                    //$scope.voiceArray[t-1].duration = $scope.voiceArray[t-1].duration + 1;//录音时间
                }
            })
        }
        else
        {
            $scope.$apply(function (){
                if(t>0)
                {
                    $scope.voiceArray[t-1].status = "lsb";
                    $scope.voiceArray[t-1].duration = 0;//录音时间
                    //myAlert("录音失败！");
                }
            })
        }

    }

    $scope.sendAudioMessageClick = function(_obj)
    {
        if(_obj.c != "")
        {
            if($scope.plingMark)
            {
                $scope.plingMark = false;
                var message = {};
                message['cnt'] = _obj.c;
                message['cnttype'] = "3";//1：文字评论；2：花；3：语音
                message['subjectid'] = $scope.productid;
                message['subjecttype'] = "product";
                message['subjectuserid'] = $scope.curLcsid;
                message['userid'] = $scope.userObj.f_id;
                message['voicetime'] = _obj.duration;
                //alert("message="+angular.toJson(message));
                ajaxService.sendMessage("user.addcommentaction", message, function (_data)
                    {
                        if(_data.op.code.toString() == "Y")//提交成功
                        {
                            _obj.status = "yfb";
                            $scope.getpl();
                        }
                        else
                        {
                            myAlert("发表失败！");
                        }
                        $scope.plingMark = true;
                    }
                );
            }
        }
    }

    //删除
    $scope.deleteplvoicewfb = function(_obj)
    {
        $scope.delwfbvoice = _obj;
        var str = "确定删除这段语音吗？";
        myConfirm(str, $scope.voicewfbdelfirm);
    }
    $scope.voicewfbdelfirm = function()
    {
        layer.closeAll();
        $scope.$apply(function(){
            if($scope.delwfbvoice != null)
            {
                for(var i = 0;i<$scope.voiceArray.length;i++)
                {
                    if($scope.voiceArray[i].lastmsgid == $scope.delwfbvoice.lastmsgid)
                    {
                        $scope.voiceArray.splice(i,1);
                        break;
                    }
                }
            }
        });
        $scope.delwfbvoice = null;
    }

    //当前聊天音频点击
    $scope.chartlistaudioClick = function(obj)
    {
        //有正在播放的录音暂停播放并回到开始
        var chartaudio = document.getElementById(obj.lastmsgid);
        var mark = false;
        for(var i=0;i<$scope.voiceArray.length;i++)
        {
            try
            {
                var chartaudio2 = document.getElementById($scope.voiceArray[i].lastmsgid);
                if(chartaudio2!=null)
                {
                    if (!chartaudio2.paused)//播放中
                    {
                        chartaudio2.pause();// 暂停
                        if(obj.lastmsgid != $scope.voiceArray[i].lastmsgid)//不是同一个
                        {
                            chartaudio.play();
                        }
                        mark = true;
                        break;
                    }
                }
            }
            catch(e){
            }
        }
        if(mark == false)
        {
            chartaudio.play();
        }
    }
}
