/**
 * Created by qw1 on 2014/12/7.
 */
var oneStockHQHtmlModule = angular.module('oneStockHQHtmlApp',['ngCookies','ngTouch']);
oneStockHQHtmlModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
oneStockHQHtmlModule.controller('oneStockHQHtmlCtrl',['$scope','ajaxService', '$cookieStore','$sce', oneStockHQHtmlCtrl]);

/**过滤器*/
oneStockHQHtmlModule.filter('numberFormatFilter', numberFormatFilter);

oneStockHQHtmlModule.run(function() {
    document.getElementById("oneStockHQHtmlMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['oneStockHQHtmlApp']);
});
