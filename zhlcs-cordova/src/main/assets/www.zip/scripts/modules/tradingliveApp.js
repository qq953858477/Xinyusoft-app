/**
 * Created by qw1 on 2014/12/7.
 */
var tradingliveModule = angular.module('tradingliveApp',['ngCookies']);
tradingliveModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
tradingliveModule.controller('tradingliveCtrl',['$scope','ajaxService', '$cookieStore', tradingliveCtrl]);


/**过滤器*/
tradingliveModule.filter('numberFormatFilter', numberFormatFilter);

tradingliveModule.run(function() {
    document.getElementById("tradingliveMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradingliveApp']);
});
