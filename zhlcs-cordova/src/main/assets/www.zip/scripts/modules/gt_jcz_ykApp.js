/**
 * Created by qw1 on 2014/12/7.
 */
var gt_jcz_ykModule = angular.module('gt_jcz_ykApp',['ngCookies','ngTouch']);
gt_jcz_ykModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

gt_jcz_ykModule.directive('gtsyntheticalwcc', gtsyntheticalwcc);
gt_jcz_ykModule.directive('gtsykykwcc', gtsykykwcc);
gt_jcz_ykModule.directive('gtsyjyjl', gtsyjyjl);
gt_jcz_ykModule.directive('gtsypl', gtsypl);
gt_jcz_ykModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
/** 控制器*/
gt_jcz_ykModule.controller('gtsykykwccCtrl',['$scope','ajaxService', '$cookieStore', gtsykykwccCtrl]);
gt_jcz_ykModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_jcz_ykModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);
gt_jcz_ykModule.controller('gtsyntheticalwccCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalwccCtrl]);
gt_jcz_ykModule.controller('gt_jcz_ykCtrl',['$scope','ajaxService', '$cookieStore', gt_jcz_ykCtrl]);

/**过滤器*/
gt_jcz_ykModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_jcz_ykMain").style.display = "";
}

gt_jcz_ykModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_jcz_ykApp']);
});
