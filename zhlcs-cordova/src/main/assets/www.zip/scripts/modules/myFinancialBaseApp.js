/**
 * Created by qw1 on 2014/12/7.
 */
var myFinancialBaseModule = angular.module('myFinancialBaseApp',['ngCookies']);
myFinancialBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
myFinancialBaseModule.controller('myFinancialBaseCtrl',['$scope','ajaxService', '$cookieStore', myFinancialBaseCtrl]);


/**过滤器*/
myFinancialBaseModule.filter('numberFormatFilter', numberFormatFilter);

myFinancialBaseModule.run(function() {
    document.getElementById("myFinancialBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['myFinancialBaseApp']);
});
