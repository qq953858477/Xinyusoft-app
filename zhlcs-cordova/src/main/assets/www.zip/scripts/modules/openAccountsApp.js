/**
 * Created by qw1 on 2014/12/7.
 */
var openAccountsModule = angular.module('openAccountsApp',['ngCookies']);
openAccountsModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
openAccountsModule.controller('openAccountsCtrl',['$scope','ajaxService', '$cookieStore', openAccountsCtrl]);


/**过滤器*/
openAccountsModule.filter('numberFormatFilter', numberFormatFilter);

openAccountsModule.run(function() {
    document.getElementById("openAccountsMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['openAccountsApp']);
});
