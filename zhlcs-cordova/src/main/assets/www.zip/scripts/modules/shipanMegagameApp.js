/**
 * Created by qw1 on 2014/12/7.
 */
var shipanMegagameModule = angular.module('shipanMegagameApp',['ngCookies']);
shipanMegagameModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
shipanMegagameModule.controller('shipanMegagameCtrl',['$scope','ajaxService', '$cookieStore', shipanMegagameCtrl]);

/**过滤器*/
shipanMegagameModule.filter('numberFormatFilter', numberFormatFilter);

shipanMegagameModule.run(function() {
    document.getElementById("shipanMegagameMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['shipanMegagameApp']);
});
