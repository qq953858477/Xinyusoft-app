/**
 * Created by qw1 on 2014/12/7.
 */
var myModelBaseModule = angular.module('myModelBaseApp',['ngCookies','ngTouch']);
myModelBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
myModelBaseModule.controller('myModelBaseCtrl',['$scope','ajaxService', '$cookieStore',myModelBaseCtrl]);

/**过滤器*/
myModelBaseModule.filter('numberFormatFilter', numberFormatFilter);


myModelBaseModule.run(function() {
    document.getElementById("myModelBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['myModelBaseApp']);
});
