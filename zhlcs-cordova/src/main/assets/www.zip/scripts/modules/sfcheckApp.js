/**
 * Created by qw1 on 2014/12/7.
 */
var sfcheckModule = angular.module('sfcheckApp',['ngCookies']);
sfcheckModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
sfcheckModule.controller('sfcheckCtrl',['$scope','ajaxService', '$cookieStore',sfcheckCtrl]);


optionalBaseModule.run(function() {
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['sfcheckApp']);
});
