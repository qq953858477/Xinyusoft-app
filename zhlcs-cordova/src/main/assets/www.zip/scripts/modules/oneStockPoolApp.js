/**
 * Created by qw1 on 2015/4/17.
 */
var oneStockPoolModule = angular.module('oneStockPoolApp',['ngCookies','ngTouch']);
oneStockPoolModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
oneStockPoolModule.controller('oneStockPoolCtrl',['$scope','ajaxService', '$cookieStore', oneStockPoolCtrl]);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("oneStockPoolmain").style.display = "";
}


oneStockPoolModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['oneStockPoolApp']);
});