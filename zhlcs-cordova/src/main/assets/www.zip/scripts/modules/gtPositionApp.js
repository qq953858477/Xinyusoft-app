/**
 * Created by qw1 on 2014/12/7.
 */
var gtgtPositionModule = angular.module('gtPositionApp',['ngCookies', 'ngRoute','ngTouch']);
gtgtPositionModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gtgtPositionModule.directive('autohq', autohq);

/** 控制器*/
gtgtPositionModule.controller('gtPositionCtrl',['$scope','ajaxService', '$cookieStore',gtPositionCtrl]);

/**过滤器*/
gtgtPositionModule.filter('numberFormatFilter',numberFormatFilter);


gtgtPositionModule.run(function() {
    document.getElementById("gtPositionMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtPositionApp']);
});
