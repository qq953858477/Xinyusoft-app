/**
 * Created by qw1 on 2014/12/7.
 */
var benefitsListModule = angular.module('benefitsListApp',['ngCookies', 'ngRoute','ngTouch']);
benefitsListModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
benefitsListModule.directive('autohq', autohq);


/** 控制器*/
benefitsListModule.controller('benefitsListCtrl',['$scope','ajaxService', '$cookieStore',benefitsListCtrl]);

/**过滤器*/
benefitsListModule.filter('numberFormatFilter',numberFormatFilter);


benefitsListModule.run(function() {
    document.getElementById("benefitsListMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['benefitsListApp']);
});
