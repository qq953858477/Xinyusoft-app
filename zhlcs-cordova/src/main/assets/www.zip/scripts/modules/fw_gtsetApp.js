/**
 * Created by qw1 on 2014/12/7.
 */
var fw_gtsetModule = angular.module('fw_gtsetApp',['ngCookies', 'ngRoute','ngTouch']);
fw_gtsetModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
fw_gtsetModule.directive('autohq', autohq);
/** 控制器*/
fw_gtsetModule.controller('fw_gtsetCtrl',['$scope','ajaxService', '$cookieStore',fw_gtsetCtrl]);

/**过滤器*/
fw_gtsetModule.filter('numberFormatFilter',numberFormatFilter);


fw_gtsetModule.run(function() {
    document.getElementById("fw_gtsetMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['fw_gtsetApp']);
});
