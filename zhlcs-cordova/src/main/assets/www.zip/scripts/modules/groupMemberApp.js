/**
 * Created by killua
 */
var groupMemberModule = angular.module('groupMemberApp',['ngCookies','ngTouch']);
groupMemberModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** ������*/
groupMemberModule.controller('groupMemberCtrl',['$scope','ajaxService', '$cookieStore',groupMemberCtrl]);

groupMemberModule.run(function() {
    document.getElementById("groupMemberMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['groupMemberApp']);
});