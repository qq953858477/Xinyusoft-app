/**
 * Created by qw1 on 2014/12/7.
 */
var gt_jcz_fbzModule = angular.module('gt_jcz_fbzApp',['ngCookies']);
gt_jcz_fbzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

gt_jcz_fbzModule.directive('gtsyntheticalycc', gtsyntheticalycc);
gt_jcz_fbzModule.directive('gtsycc', gtsycc);
gt_jcz_fbzModule.directive('gtsyjyjl', gtsyjyjl);
gt_jcz_fbzModule.directive('gtsypl', gtsypl);
gt_jcz_fbzModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);

/** 控制器*/
gt_jcz_fbzModule.controller('gtsyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyccCtrl]);
gt_jcz_fbzModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_jcz_fbzModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);
gt_jcz_fbzModule.controller('gtsyntheticalyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalyccCtrl]);
gt_jcz_fbzModule.controller('gt_jcz_fbzCtrl',['$scope','ajaxService', '$cookieStore', gt_jcz_fbzCtrl]);

/**过滤器*/
gt_jcz_fbzModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_jcz_fbzMain").style.display = "";
}

gt_jcz_fbzModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_jcz_fbzApp']);
});
