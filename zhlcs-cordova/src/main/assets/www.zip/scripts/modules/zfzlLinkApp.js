/**
 * Created by qw1 on 2014/12/7.
 */
var zfzlLinkModule = angular.module('zfzlLinkApp',['ngCookies','ngTouch']);
zfzlLinkModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
zfzlLinkModule.controller('zfzlLinkCtrl',['$scope','ajaxService', '$cookieStore', zfzlLinkCtrl]);


zfzlLinkModule.run(function() {
    document.getElementById("zfzlLinkMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['zfzlLinkApp']);
});
