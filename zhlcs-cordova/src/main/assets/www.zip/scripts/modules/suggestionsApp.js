/**
 * Created by qw1 on 2014/12/7.
 */
var suggestionsModule = angular.module('suggestionsApp',['ngCookies']);
suggestionsModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
suggestionsModule.controller('suggestionsCtrl',['$scope','ajaxService', '$cookieStore', suggestionsCtrl]);


/**过滤器*/
suggestionsModule.filter('numberFormatFilter', numberFormatFilter);

suggestionsModule.run(function() {
    document.getElementById("suggestionsMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['suggestionsApp']);
});
