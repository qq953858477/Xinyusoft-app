/**
 * Created by qw1 on 2014/12/7.
 */
var tradeBase_gameModule = angular.module('tradeBase_gameApp',['ngCookies', 'ngRoute','ngTouch']);
tradeBase_gameModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
tradeBase_gameModule.directive('autohq', autohq);
tradeBase_gameModule.directive('zhassetwgt', zhassetwgt);
tradeBase_gameModule.directive('tradeinfowgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_info_game.html',
        controller:['$scope','ajaxService','$cookieStore',tradeinfowgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});
tradeBase_gameModule.directive('tradequerywgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_query_wgt.html',
        controller:['$scope','ajaxService','$cookieStore', tradequerywgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});

tradeBase_gameModule.controller('zh_asset_wgtCtrl',['$scope','ajaxService', '$cookieStore', zh_asset_wgtCtrl]);
tradeBase_gameModule.controller('tradeinfowgtCtrl',['$scope','ajaxService', '$cookieStore', tradeinfowgtCtrl]);
tradeBase_gameModule.controller('tradequerywgtCtrl',['$scope','ajaxService', '$cookieStore', tradequerywgtCtrl]);

/** 控制器*/
tradeBase_gameModule.controller('tradeBase_gameCtrl',['$scope','ajaxService', '$cookieStore',tradeBase_gameCtrl]);
/**空白 控制器*/
tradeBase_gameModule.controller('emptyCtrl',['$scope', 'ajaxService', '$cookieStore', emptyCtrl]);
/** 控制器*/
tradeBase_gameModule.controller('buysellwgtCtrl',['$scope','ajaxService', '$cookieStore', buysellwgtCtrl]);
/**撤单 控制器*/
tradeBase_gameModule.controller('cancellationCtrl',['$scope', 'ajaxService', '$cookieStore', cancellationCtrl]);
/**预埋单 控制器*/
tradeBase_gameModule.controller('prepaywgtCtrl',['$scope', 'ajaxService', '$cookieStore', prepaywgtCtrl]);

/**银证转账 控制器*/
tradeBase_gameModule.controller('yzzzCtrl',['$scope', 'ajaxService', '$cookieStore', yzzzCtrl]);

tradeBase_gameModule.controller('cccxwgtCtrl',['$scope', 'ajaxService', '$cookieStore', cccxwgtCtrl]);
/**当日成交 控制器*/
tradeBase_gameModule.controller('drcjCtrl',['$scope', 'ajaxService', '$cookieStore', drcjCtrl]);
/**当日委托 控制器*/
tradeBase_gameModule.controller('drwtCtrl',['$scope', 'ajaxService', '$cookieStore', drwtCtrl]);
/**历史成交 控制器*/
tradeBase_gameModule.controller('lscjCtrl',['$scope', 'ajaxService', '$cookieStore', lscjCtrl]);
/**历史委托 控制器*/
tradeBase_gameModule.controller('lswtCtrl',['$scope', 'ajaxService', '$cookieStore', lswtCtrl]);
/**历史资金流水 控制器*/
tradeBase_gameModule.controller('lszjlsCtrl',['$scope', 'ajaxService', '$cookieStore', lszjlsCtrl]);




/**过滤器*/
tradeBase_gameModule.filter('numberFormatFilter',numberFormatFilter);

/**路由管理器*/
tradeBase_gameModule.
    config(['$routeProvider', function($routeProvider) {
        $routeProvider.
            when('/buysell', {templateUrl: 'views/buysell_wgt.html', controller: 'buysellwgtCtrl'}).
            when('/cancellation', {templateUrl: 'views/cancellation.html', controller: 'cancellationCtrl'}).
            when('/prepay', {templateUrl: 'views/prepay_wgt.html', controller: 'prepaywgtCtrl'}).
            when('/yzzz', {templateUrl: 'views/yzzz.html', controller: 'yzzzCtrl'}).

            when('/cccx', {templateUrl: 'views/cccx_wgt.html', controller: 'cccxwgtCtrl'}).
            when('/drcj', {templateUrl: 'views/drcj.html', controller: 'drcjCtrl'}).
            when('/drwt', {templateUrl: 'views/drwt.html', controller: 'drwtCtrl'}).
            when('/lscj', {templateUrl: 'views/lscj.html', controller: 'lscjCtrl'}).
            when('/lswt', {templateUrl: 'views/lswt.html', controller: 'lswtCtrl'}).
            when('/lszjls', {templateUrl: 'views/lszjls.html', controller: 'lszjlsCtrl'}).
            otherwise({redirectTo: '/empty'});
    }]);


tradeBase_gameModule.run(function() {
    document.getElementById("tradeBase_gameMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradeBase_gameApp']);
});
