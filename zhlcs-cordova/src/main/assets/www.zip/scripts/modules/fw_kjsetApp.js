/**
 * Created by qw1 on 2014/12/7.
 */
var fw_kjsetModule = angular.module('fw_kjsetzhApp',['ngCookies', 'ngRoute','ngTouch']);
fw_kjsetModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
fw_kjsetModule.directive('autohq', autohq);
/** 控制器*/
fw_kjsetModule.controller('fw_kjsetCtrl',['$scope','ajaxService', '$cookieStore',fw_kjsetCtrl]);

/**过滤器*/
fw_kjsetModule.filter('numberFormatFilter',numberFormatFilter);


fw_kjsetModule.run(function() {
    document.getElementById("fw_kjsetMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['fw_kjsetzhApp']);
});
