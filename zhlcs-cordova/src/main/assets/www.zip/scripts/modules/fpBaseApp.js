/**
 * Created by qw1 on 2014/12/7.
 */
var fpBaseModule = angular.module('fpBaseApp',['ngCookies','ngTouch']);
fpBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
fpBaseModule.controller('fpBaseCtrl',['$scope','ajaxService', '$cookieStore',fpBaseCtrl]);


fpBaseModule.run(function() {
    document.getElementById("fpBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['fpBaseApp']);
});
