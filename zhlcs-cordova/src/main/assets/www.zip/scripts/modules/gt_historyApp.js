/**
 * Created by qw1 on 2014/12/7.
 */
var gt_historyModule = angular.module('gt_historyApp',['ngCookies']);
gt_historyModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

/** 控制器*/
gt_historyModule.controller('gt_historyCtrl',['$scope','ajaxService', '$cookieStore', gt_historyCtrl]);

/**过滤器*/
gt_historyModule.filter('numberFormatFilter', numberFormatFilter);

gt_historyModule.run(function() {
    document.getElementById("gt_historyMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_historyApp']);
});
