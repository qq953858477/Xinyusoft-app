/**
 * Created by qw1 on 2014/12/7.
 * 跟投者历史跟投信息
 */
var gt_history_gtzModule = angular.module('gt_history_gtzApp',['ngCookies']);
gt_history_gtzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_history_gtzModule.directive('gtsyntheticalhistory', gtsyntheticalhistory);
gt_history_gtzModule.directive('gtsyjyjl', gtsyjyjl);
gt_history_gtzModule.directive('gtsypl', gtsypl);;
gt_history_gtzModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
/** 控制器*/
gt_history_gtzModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_history_gtzModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);
gt_history_gtzModule.controller('gtsyntheticalhistoryCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalhistoryCtrl]);
gt_history_gtzModule.controller('gt_history_gtzCtrl',['$scope','ajaxService', '$cookieStore', gt_history_gtzCtrl]);

/**过滤器*/
gt_history_gtzModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_history_gtzMain").style.display = "";
}

gt_history_gtzModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_history_gtzApp']);
});
