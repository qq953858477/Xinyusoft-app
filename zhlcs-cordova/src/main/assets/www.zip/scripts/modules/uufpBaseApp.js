/**
 * Created by qw1 on 2014/12/7.
 */
var uufpBaseModule = angular.module('uufpBaseApp',['ui.router','infinite-scroll','ngCookies','ngTouch']);

uufpBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

uufpBaseModule.factory('marketTabService', ['$rootScope', marketTabService]);
uufpBaseModule.controller('marketController', ['$scope', 'ajaxService', 'marketTabService', marketController]);
uufpBaseModule.directive('marketsurvey', market);
//
//uufpBaseModule.controller('activityController', ['$scope', 'ajaxService', activityController]);
//uufpBaseModule.directive('activity', activity);

uufpBaseModule.factory('gtTabService', ['$rootScope', gtTabService]);
uufpBaseModule.controller('gtController', ['$scope', 'ajaxService', 'gtTabService', gtController]);
uufpBaseModule.directive('gt', gt);

uufpBaseModule.filter('periodfilter', function () {
    return function (period) {
        var result = period.toString().replace('w', '周').replace('m', '个月');
        return result;
    }
});
uufpBaseModule.filter('enddayfilter', function () {
    return function (period) {
        var month = period.toString().substr(4, 2);
        var day = period.toString().substr(6, 2);
        return month + "月" + day + "日";
    }
});

uufpBaseModule.filter('percent', function () {
    return function (percent) {
        var result = (Number(percent.toString())*100).toFixed(2)+"%";
        return result;
    }
});

//uufpBaseModule.directive('myFinancialBase', myFinancialBase);
//uufpBaseModule.directive('myhome', function(){
//    return{
//        restrict: 'E',
//        templateUrl: 'home.html',
//        //template: '<div>Hi mybase5555</div>',
//        //replace: true,
//        transclude: true
//    }
//});
uufpBaseModule.directive('indexbase', indexbase);
uufpBaseModule.directive('onestockhqbase', onestockhqbase);
uufpBaseModule.directive('myhome', myhome);

uufpBaseModule.directive('mygroup', function(){
    return{
        restrict: 'E',
        templateUrl: 'myGroupBase.html',
        //template: '<div>Hi mybase5555</div>',
        //replace: true,
        transclude: true,
        controller: myGroupBaseCtrl
    }
});

uufpBaseModule.directive('discoverbase', discoverBase);
uufpBaseModule.directive('gtbdirective', function(){
    return{
        restrict: 'E',
        templateUrl: 'gtb_directive.html',
        transclude: true
    }
});
uufpBaseModule.directive('me', me);


/** 控制器*/
uufpBaseModule.controller('uufpBaseCtrl',['$scope','ajaxService', '$cookieStore',uufpBaseCtrl]);

uufpBaseModule.controller('myhomeCtrl',['$scope','ajaxService', '$cookieStore',myhomeCtrl]);

uufpBaseModule.controller('myGroupBaseCtrl',['$scope','ajaxService', '$cookieStore',myGroupBaseCtrl]);

uufpBaseModule.controller('discoverBaseCtrl',['$scope','ajaxService', '$cookieStore',discoverBaseCtrl]);

uufpBaseModule.controller('gtbdetectiveCtrl',['$scope','ajaxService', '$cookieStore',gtbdetectiveCtrl]);
uufpBaseModule.controller('meCtrl',['$scope','ajaxService', '$cookieStore',meCtrl]);


/**过滤器*/
uufpBaseModule.filter('numberFormatFilter', numberFormatFilter);


uufpBaseModule.run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            //document.getElementById("jiepanApp").style.display = "";
            //FastClick.attach(document.body);
            document.getElementById("uufpBaseMain").style.display = "";
        }
    ]

);

angular.element(document).ready(function() {
    angular.bootstrap(document, ['uufpBaseApp']);
});


uufpBaseModule.factory('jpajaxService', ['$http', jpajaxService]);
uufpBaseModule.factory('tabService', ['$stateParams', '$location', '$state', tabService]);
/** 控制器*/
uufpBaseModule.controller('jiepanMainCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanMainCtrl]);
uufpBaseModule.controller('jiepanListCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanListCtrl]);

uufpBaseModule.directive('jiepan', function () {
    return {
        restrict: 'E',
        templateUrl: 'template/jiepanTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: jiepanMainCtrl
    }
});
uufpBaseModule.directive('relative', function () {
    return {
        restrict: 'E',
        templateUrl: 'template/relativeTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: jiepanMainCtrl
    }
})

uufpBaseModule.directive("ggjp", ggJpDirective);
uufpBaseModule.directive("dpjp", dpJpDirective);
uufpBaseModule.directive("gnjp", gnJpDirective);
uufpBaseModule.directive("jrgd", gnGdDirective);

//行情
uufpBaseModule.directive('jponestockhqbase', jponestockhqbase);

uufpBaseModule.filter('dateFilter', function () {
    return function (dateInput) {
        //2015-08-21 15:06:59.0
        var returndate = '';
        returndate = dateInput.substr(0, dateInput.length - 5);
        return returndate;

    }

});
