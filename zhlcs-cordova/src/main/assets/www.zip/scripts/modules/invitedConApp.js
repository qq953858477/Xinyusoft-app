/**
 * Created by qw1 on 2015/4/17.
 */
var invitedConModule = angular.module('invitedConApp',['ngCookies','ngTouch']);
invitedConModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
invitedConModule.controller('invitedConCtrl',['$scope','ajaxService', '$cookieStore',invitedConCtrl]);

invitedConModule.run(function() {
    document.getElementById("invitedConmain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['invitedConApp']);
});
