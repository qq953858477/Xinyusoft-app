/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function updownBaseCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("首页", $scope.cesxinxi);
    $scope.ggfhParent = "";//个股返回父对象 首页：home；涨幅榜列表：morezfb；跌幅榜列表:moredfb；行业：hy
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.homebaseShow = true;//主界面
    $scope.hqbaseoneStockHQBaseShow = false;//个股行情
    $scope.zfbtop10DivShow = false;//涨幅榜前10
    $scope.dfbtop10DivShow = false;//跌幅榜前10
    $scope.zfbstocklist = [];//涨幅榜
    $scope.dfbstocklist = [];//跌幅榜
    $scope.zfbDivShow = true;//涨幅榜显示
    $scope.dfbDivShow = true;//跌幅榜显示
    $scope.order = "2";//0-不排序 1-升序 2-降序
    $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

    $scope.zfbmorestockListDivShow = false;//涨幅榜
    $scope.zfbmorelistArray = [];//涨幅榜更多
    $scope.dfbmorestockListDivShow = false;//跌幅榜
    $scope.dfbmorelistArray = [];//涨幅榜更多

    $scope.sshqintervalDuration = 5000;//间隔时间，8000毫秒
    $scope.sshqintervalId;

    $scope.cookiezxgList = [];//存放入cookie的自选股列表
    $scope.zdftype = "jrzfb"; //显示涨幅榜或者跌幅榜  涨幅榜：jrzfb； 跌幅榜：jrdfb
    $scope.parentIndex = "5";//返回页面位置

    //去除
    $scope.myhomeClearInterval = function () {
        if ($scope.sshqintervalId != undefined) {
            clearInterval($scope.sshqintervalId);
        }
    }


    $scope.zfbdfbstocklistCallBack = function(_data)
    {
        //console.log("涨幅榜", _data);
        $scope.zfbstocklist = [];
        $scope.dfbstocklist = []
        if(_data.op.code.toString() == "Y")
        {
            if($scope.zdftype == "jrzfb")
            {
                var arr = _data.risedata;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.gpdm = arr[i].stockcode;
                    obj.zqjc = arr[i].stockname;
                    obj.exchange = arr[i].exchange.toString();
                    obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                    obj.zxj = parseFloat(arr[i].price.toString());
                    obj.status = arr[i].stockstatus.toString();
                    //console.log("状态：" + arr[i].stockstatus.toString())
                    obj.xzzt = "1";//选中状态，样式更改
                    obj.zd = parseFloat(parseFloat(arr[i].netchange.toString()).toFixed(2));
                    obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                    $scope.zfbstocklist.push(obj);
                }
            }
            else
            {
                var arr2 = _data.downdata;
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.gpdm = arr2[i].stockcode;
                    obj.zqjc = arr2[i].stockname;
                    obj.exchange = arr2[i].exchange.toString();
                    obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                    obj.zxj = parseFloat(arr2[i].price.toString());
                    obj.status = arr2[i].stockstatus.toString();
                    //console.log("状态：" + arr2[i].stockstatus.toString())
                    obj.xzzt = "1";//选中状态，样式更改
                    obj.zd = parseFloat(parseFloat(arr2[i].netchange.toString()).toFixed(2));
                    obj.zdf = parseFloat(parseFloat(arr2[i].netchangeratio.toString()).toFixed(2));
                    $scope.dfbstocklist.push(obj);
                }
            }
        }
    }


    $scope.getSSHQ = function()
    {
        //涨幅榜//跌幅榜
        console.log("涨幅榜")
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 10;
        if($scope.zdftype == "jrzfb") {
            message["type"] = "rise";
        }
        else
        {
            message["type"] = "down";
        }
        ajaxService.sendMessage("hq.getranklist",message, $scope.zfbdfbstocklistCallBack);

    }

    //自选股
    $scope.getzxglist =function()
    {
        //console.log("自选股列表：", $scope.userObj.f_id);
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        message["ordeCol"] = "";
        message["ordeBy"] = "";

        ajaxService.sendMessage("hq.getzxghqaction",message,function(_data)
        {
            //console.log("自选股列表：" + _data);
            $scope.cookiezxgList = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.data;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj2 = {};
                    obj2.tc =  arr[i].exchange.toString().toUpperCase() + arr[i].symbol;
                    $scope.cookiezxgList.push(obj2);
                }
            }
            //$cookieStore.put('cookiezxgList', $scope.cookiezxgList);

            var localStorage = window.localStorage;
            localStorage.setItem("cookiezxgList", JSON.stringify($scope.cookiezxgList));
        })
    }


    $scope.init = function()
    {
        $scope.userObj = {};
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        //$scope.userObj = $cookieStore.get('user');

        $scope.zdftype = getParameter("type");
        $scope.parentIndex = getParameter("parentIndex");

        if($scope.zdftype == "jrzfb")
        {
            $scope.zfbtop10DivShow = true;
            $scope.dfbtop10DivShow = false;
        }
        else
        {
            $scope.zfbtop10DivShow = false;
            $scope.dfbtop10DivShow = true;
        }


        //获取行情
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);

        $scope.getzxglist();//存cookie
    }

     $scope.init();

    //个股
    $scope.ggClick = function(_obj, _str)
    {
        $scope.ggfhParent = _str;
        $scope.myhomeClearInterval();
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = "0";

        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //$cookieStore.put('stockInfo', obj);

        $scope.hqbaseoneStockHQBaseShow = true;
        $scope.homebaseShow = false;
        $scope.zfbmorestockListDivShow = false;
        $scope.dfbmorestockListDivShow = false;
        $scope.hynstockListDivShow = false;
        gotoUp();

    }

    //涨幅榜显示隐藏
    $scope.zfbShowClcik = function()
    {
        $scope.zfbDivShow = !$scope.zfbDivShow;
    }
    //跌幅榜显示隐藏
    $scope.dfbShowClcik = function()
    {
        $scope.dfbDivShow = !$scope.dfbDivShow;
    }

    //大盘指数返回
    $scope.indexbaseBackto = function()
    {
        $scope.indexbaseShow = false;
        $scope.homebaseShow = true;

        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);

    }

    //个股返回
    $scope.oneStockHQBaseBackto = function()
    {
        if($scope.ggfhParent == "home") {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.homebaseShow = true;
        }else if($scope.ggfhParent == "morezfb"){
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.zfbmorestockListDivShow = true;

        }else if($scope.ggfhParent == "moredfb"){
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.dfbmorestockListDivShow = true;
        }

        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
    }

    $scope.sortStock = function (obj)
    {
        var str = obj.substr(0,1);//取出符号 ：+ ，-
        obj = obj.substr(1, obj.length-1);
        if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
        {
            if($scope.order == "2")
            {
                $scope.orderobj = "+" + obj;
                $scope.order = "1";//升序
            }
            else
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        }
        else//不同排序字段
        {
            $scope.orderobj = "-" + obj;
            $scope.order = "2";//降序
        }

    }

    //涨幅榜更多
    $scope.zfbMore = function()
    {
        $scope.zfbmorestockListDivShow = true;
        $scope.homebaseShow = false;
        gotoUp();

        $scope.zfbMoreRefresh();
    }

    $scope.zfbMoreRefresh = function()
    {
        $scope.zfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

        //涨幅榜//跌幅榜
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 100;
        message["type"] = "rise";
        ajaxService.sendMessage("hq.getranklist",message, $scope.zfbmorelistCallBack);
    }

    $scope.zfbmorelistCallBack = function(_data)
    {
        //console.log("涨幅榜", _data);
        $scope.zfbmorelistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.risedata;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.gpdm = arr[i].stockcode;
                obj.zqjc = arr[i].stockname;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                $scope.zfbmorelistArray.push(obj);
            }
        }
    }

    //涨幅榜返回
    $scope.zfbmoreBackto = function()
    {
        $scope.zfbmorestockListDivShow = false;
        $scope.homebaseShow = true;
        $scope.zfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
    }

    //跌幅榜更多
    $scope.dfbMore = function()
    {
        $scope.dfbmorestockListDivShow = true;
        $scope.homebaseShow = false;
        gotoUp();
        $scope.dfbMoreRefresh();

    }

    $scope.dfbMoreRefresh = function()
    {
        $scope.dfbmorelistArray = [];

        $scope.order = "1";//0-不排序 1-升序 2-降序
        $scope.orderobj = "+zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

        //涨幅榜//跌幅榜
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 100;
        message["type"] = "down";
        ajaxService.sendMessage("hq.getranklist",message, $scope.dfbmorelistCallBack);
    }

    $scope.dfbmorelistCallBack = function(_data)
    {
        //console.log("跌幅榜", _data);
        $scope.dfbmorelistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.downdata;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.gpdm = arr[i].stockcode;
                obj.zqjc = arr[i].stockname;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                $scope.dfbmorelistArray.push(obj);
            }
        }
    }

    //跌幅榜返回
    $scope.dfbmoreBackto = function()
    {
        $scope.dfbmorestockListDivShow = false;
        $scope.homebaseShow = true;
        $scope.dfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
    }


    //返回上个界面
    $scope.zdfbBackto = function()
    {
        window.location.href = "uufpBase.html?baseindex=" + $scope.parentIndex;
    }
}



