/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function benefitsListCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.tabOneShow = true;//综合
    $scope.tabTwoShow = false;//交易
    $scope.tabFourShow = false;//查询
    $scope.backtitle = "";

    var localStorage = window.localStorage;
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));

    var ind = getParameter("index");

    if(ind != "")
    {
       // $scope.index = ind;
    }
    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title


    $scope.stocklist = [];
    $scope.order = "0";//0-不排序 1-升序 2-降序
    $scope.orderobj = "";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
    $scope.ccylintervalId;
    $scope.ccylintervalDuration = 5000;//间隔时间，3000毫秒

    //去除
    $scope.ccylthisClearInterval = function () {
        if ($scope.ccylintervalId != undefined) {
            clearInterval($scope.ccylintervalId);
        }
    }

    $scope.lcscchqCallBack = function(_data)
    {
        //console.log("hq", _data);
        $scope.stocklist = [];

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.asset = arr[i].asset;//类型
                obj.gpdm = arr[i].symbol;
                obj.zqjc = arr[i].name;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                //obj.xzzt = "1";//选中状态，样式更改
                obj.zd = parseFloat(arr[i].zd.toString());
                obj.zdf = parseFloat(arr[i].zdf.toString());
                //if (obj.status == '3')
                //{
                //    obj.zdf = -10000;
                //    obj.zd = -10000;
                //}
                $scope.stocklist.push(obj);
            }
        }
    }

    $scope.getlcsccCallBack = function(_data)
    {
        $scope.ccylArray = [];
        var str = "";
        //console.log("持仓一览",_data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.stocklist;
            for(var i = 0;i<arr.length;i++)
            {
                if(i == 0)
                {
                    str = arr[i];
                }
                else
                {
                    str = str + "|" + arr[i];
                }
            }
        }

        if(str != "")
        {
            str = str.toLowerCase();
            //console.log("12", str);
            var message = {};
            message['symbols'] = str;
            ajaxService.sendMessage('hq.getselfrecard', message, $scope.lcscchqCallBack);
        }

    }

    //理财师持仓一览
    $scope.getlcscc = function()
    {
        var message = {};
        ajaxService.sendMessage('sunflower.getLcsPositionAction', message, $scope.getlcsccCallBack);
    }


    //今日收益榜
    $scope.lcsjrsyb = function()
    {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductjrsyrank', message, function (data) {
            //console.log("收益",data);
            if (data.op.code.toString() == 'Y')
            {
                $scope.lcsjrsybList = [];
                //$scope.lcsjrsybList = data['gentouproductlist'];
                //for(var i = 0;i<$scope.lcsjrsybList.length;i++)
                //{
                //    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                //    //console.log("ff", ff);
                //    $scope.lcsjrsybList[i].jrsy= parseFloat($scope.lcsjrsybList[i].jrsy);
                //    $scope.lcsjrsybList[i].ljsy= parseFloat($scope.lcsjrsybList[i].ljsy);
                //
                //    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                //    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                //}

                var arr = data.gentouproductlist;
                for(var i = 0;i<arr.length;i++)
                {
                    if(arr[i].status.toString() == "B")//被跟投中
                    {
                        var obj = {};
                        obj.status = "cp2";
                        obj.account = arr[i].account;//当前被跟投的账户
                        var bgtuser = arr[i].user.user;
                        obj.hearurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.fbzuserid = bgtuser.f_id;
                        obj.productname = arr[i].name;
                        obj.productid = arr[i].id;
                        //obj.zq = arr[i].gentouperiod;//周期
                        obj.gentoucount = arr[i].gentoucount;
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        var str = arr[i].gentouday.toString();
                        //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                        obj.gentouday = str;
                        var str2 = arr[i].endgentouday.toString();
                        //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                        obj.endgentouday = str2;
                        obj.rundays = arr[i].rundays;
                        var cwstr = arr[i].cw;
                        if(parseFloat(cwstr) == 0)
                        {
                            obj.cw = "空仓";//当前仓位
                        }
                        else if(parseFloat(cwstr) == 100)
                        {
                            obj.cw = "满仓";//当前仓位
                        }
                        else
                        {
                            obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                        }

                        $scope.lcsjrsybList.push(obj);
                    }
                    else if(arr[i].status.toString() == "D")//解除中
                    {
                        var obj = {};
                        obj.status = "cp3";
                        obj.account = arr[i].account;//当前被跟投的账户
                        var bgtuser = arr[i].user.user;
                        obj.hearurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.fbzuserid = bgtuser.f_id;
                        obj.productname = arr[i].name;
                        obj.productid = arr[i].id;
                        obj.zq = arr[i].gentouperiod;//周期
                        obj.gentoucount = arr[i].gentoucount;
                        obj.endgentoutime = arr[i].endgentoutime + "解除";//多久前解除跟投
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.mbsy = arr[i].targetprofit;
                        obj.rundays = arr[i].rundays;
                        $scope.lcsjrsybList.push(obj);
                    }
                    else if(arr[i].status.toString() == "C")//结束
                    {
                        var obj = {};
                        obj.status = "cp5";
                        obj.username = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                        obj.headurl = arr[i].user.user.f_head;
                        obj.fbzuserid = arr[i].user.user.f_id;
                        obj.productid = arr[i].id;
                        obj.productname = arr[i].name;
                        obj.account = arr[i].account;
                        obj.zq = arr[i].gentouperiod;//周期
                        obj.bmrs = arr[i].gentoucount;//跟投人数
                        obj.mbsy = arr[i].targetprofit;//目标收益
                        var str = arr[i].actualendgentouday.toString();
                        obj.endgentoudaystr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                        if(arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null)
                        {
                            obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                        }
                        else
                        {
                            obj.endgentoutime = "";
                        }
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.rundays = arr[i].rundays;
                        $scope.lcsjrsybList.push(obj);
                    }
                }
            }
        });
    }

    $scope.ljsyb = function () {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductljsyrank', message, function (data) {
            //console.log("收益",data);
            if (data.op.code.toString() == "Y") {
                $scope.gtljsybList = [];
                var arr = data.gentouproductlist;
                //for(var i = 0;i<$scope.gtjrsybList.length;i++)
                //{
                //    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                //    //console.log("ff", ff);
                //    $scope.gtjrsybList[i].jrsy= parseFloat($scope.gtjrsybList[i].jrsy);
                //    $scope.gtjrsybList[i].ljsy= parseFloat($scope.gtjrsybList[i].ljsy);
                //
                //    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                //    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                //}

                for(var i = 0;i<arr.length;i++)
                {
                    if(arr[i].status.toString() == "B")//被跟投中
                    {
                        var obj = {};
                        obj.status = "cp2";
                        obj.account = arr[i].account;//当前被跟投的账户
                        var bgtuser = arr[i].user.user;
                        obj.hearurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.fbzuserid = bgtuser.f_id;
                        obj.productname = arr[i].name;
                        obj.productid = arr[i].id;
                        //obj.zq = arr[i].gentouperiod;//周期
                        obj.gentoucount = arr[i].gentoucount;
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        var str = arr[i].gentouday.toString();
                        //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                        obj.gentouday = str;
                        var str2 = arr[i].endgentouday.toString();
                        //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                        obj.endgentouday = str2;
                        obj.rundays = arr[i].rundays;
                        var cwstr = arr[i].cw;
                        if(parseFloat(cwstr) == 0)
                        {
                            obj.cw = "空仓";//当前仓位
                        }
                        else if(parseFloat(cwstr) == 100)
                        {
                            obj.cw = "满仓";//当前仓位
                        }
                        else
                        {
                            obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                        }
                        $scope.gtljsybList.push(obj);
                    }
                    else if(arr[i].status.toString() == "D")//解除中
                    {
                        var obj = {};
                        obj.status = "cp3";
                        obj.account = arr[i].account;//当前被跟投的账户
                        var bgtuser = arr[i].user.user;
                        obj.hearurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.fbzuserid = bgtuser.f_id;
                        obj.productname = arr[i].name;
                        obj.productid = arr[i].id;
                        obj.zq = arr[i].gentouperiod;//周期
                        obj.gentoucount = arr[i].gentoucount;
                        obj.endgentoutime = arr[i].endgentoutime + "解除";//多久前解除跟投
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.mbsy = arr[i].targetprofit;
                        obj.rundays = arr[i].rundays;
                        $scope.gtljsybList.push(obj);
                    }
                    else if(arr[i].status.toString() == "C")//结束
                    {
                        var obj = {};
                        obj.status = "cp5";
                        obj.username = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                        obj.headurl = arr[i].user.user.f_head;
                        obj.fbzuserid = arr[i].user.user.f_id;
                        obj.productid = arr[i].id;
                        obj.productname = arr[i].name;
                        obj.account = arr[i].account;
                        obj.zq = arr[i].gentouperiod;//周期
                        obj.bmrs = arr[i].gentoucount;//跟投人数
                        obj.mbsy = arr[i].targetprofit;//目标收益
                        var str = arr[i].actualendgentouday.toString();
                        obj.endgentoudaystr = str.substr(0, 4) + "-" + str.substr(4, 2) + "-" + str.substr(6, 2);
                        if (arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null) {
                            obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                        }
                        else {
                            obj.endgentoutime = "";
                        }
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.rundays = arr[i].rundays;
                        $scope.gtljsybList.push(obj);
                    }
                }
            }
        });
    };


    //综合、交易/查询、关联切换
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//交易
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = false;
            $scope.lcsjrsyb();
        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabFourShow = false;
            $scope.ljsyb();
        }
        else//查询
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = true;
            $scope.getlcscc();
        }

    }


    $scope.blinit = function()
    {
        $scope.changeTab($scope.index);
    }

    $scope.blinit();


    //排行榜
    $scope.gtsyphbItemClick = function(_obj)
    {
        //console.log($scope.userObj.f_id, _obj.fbzuserid);
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview");
        }
        else
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            xinyuNewBrowser("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid + "&&opentype=newwebview");
        }
    }

    //解除中
    $scope.gtlistItemClick = function(_obj)
    {
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //window.location = "gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview");

        }
        else
        {
            //window.location = "gt_jcz_yk.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&bgtuserid=" + _obj.fbzuserid ;
            xinyuNewBrowser("gt_jcz_yk.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&bgtuserid=" + _obj.fbzuserid  + "&&opentype=newwebview");
        }
    }

    //历史中
    $scope.hisItemClick = function(_obj)
    {
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //window.location = "gt_history_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_history_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview");

        }
        else
        {
            //window.location = "gt_sy_history.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            xinyuNewBrowser("gt_sy_history.html?account=" + _obj.account + "&&productid=" + _obj.productid + "&&bgtuserid=" + _obj.fbzuserid  + "&&opentype=newwebview");
        }
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList("uufpBase.html?baseindex=3");
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview");
    }


    $scope.ggClick = function(_obj)
    {
        if(_obj.asset == "0"|| _obj.asset == "5")//股票和基金
        {
            var obj = {};
            obj.stockcode = _obj.gpdm;
            obj.stockname = encodeURIComponent(_obj.zqjc);
            obj.exchange = _obj.exchange.toLowerCase();
            obj.asset = _obj.asset;
            var localStorage = window.localStorage;
            localStorage.setItem("stockInfo", JSON.stringify(obj));
            //window.location.href = "onestockHQHtml.html";
            xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        }

    }

    $scope.sortStock = function (obj)
    {
        if($scope.orderobj == "")//初始化，未排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else if($scope.orderobj == "+index")//回复原数据排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else
        {
            var str = obj.substr(0,1);//取出符号 ：+ ，-
            obj = obj.substr(1, obj.length-1);
            if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
            {
                if($scope.order == "1")//升序
                {
                    $scope.orderobj = "+index"; //下标升序
                    $scope.order = "0";//回复原序列
                }
                else if($scope.order == "2")
                {
                    $scope.orderobj = "+" + obj;
                    $scope.order = "1";//升序
                }
                else
                {
                    $scope.orderobj = "-" + obj;
                    $scope.order = "2";//降序
                }
            }
            else//不同排序字段
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        }

    }

    //返回
    $scope.sybbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}




