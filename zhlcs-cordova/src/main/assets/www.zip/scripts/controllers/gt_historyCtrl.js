
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_historyCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.lsgtlistArray = [];//历史跟投
    $scope.lsfwlistArray = [];//历史服务
    $scope.backtitle = "";
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.histype = "1";//1:用户自己的理财包；2：跟投理财师的

    var str = getParameter("type");
    if(str != "" && str != undefined)
    {
        $scope.histype = str;
    }

    $scope.linkedhisgentouCallBack = function(_data)
    {
        console.log("历史被跟投", _data);
        $scope.lsfwlistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].user.user.f_head;
                obj.bgtuserid = arr[i].user.user.f_id;
                obj.productid = arr[i].id;
                obj.productname = arr[i].name;
                obj.account = arr[i].account;
                obj.zq = arr[i].gentouperiod;//周期
                obj.bmrs = arr[i].gentoucount;//跟投人数
                obj.mbsy = arr[i].targetprofit;//目标收益
                var str = arr[i].actualendgentouday.toString();
                obj.endgentoudaystr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                if(arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null)
                {
                    obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                }
                else
                {
                    obj.endgentoutime = "";
                }

                obj.ljsyl = parseFloat(arr[i].ljsy);
                obj.gtstatus = "1";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                //console.log("累计收益率：" + obj.ljsyl);
                $scope.lsfwlistArray.push(obj);
            }
        }
    }

    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        //var message = {};
        //message['linkeduserid'] =  $scope.userObj.f_id;
        //message['page.size'] =  "max";
        //message['page.no'] =  "";
        //ajaxService.sendMessage("gentou.p_selecthisgentou", message, $scope.linkedhisgentouCallBack);
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);

    }

    $scope.p_selecthisgentouCallBack = function(_data)
    {
        $scope.lsgtlistArray = [];
        console.log("历史跟投其他人", _data)
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.hisaccountlinklist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].linkeduser.user.f_head;
                obj.bgtuserid = arr[i].linkeduser.user.f_id;
                obj.gtstatus = "0";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                obj.linkaccount = arr[i].linkaccount;//跟投的账户
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.linkid = arr[i].id;
                obj.zq = arr[i].gentouperiod;//周期
                obj.mbsy = arr[i].targetprofit;//目标收益
                obj.ljsyl = parseFloat(arr[i].linkaccountmoney.ljsy);//累计收益
                obj.status = arr[i].status.toString();
                if(obj.status == "D")
                {
                    obj.statusstr = "未支付";
                }
                else if(obj.status == "E")
                {
                    obj.statusstr = "已结束";
                }
                //console.log(obj.zj, arr[i].expirezc);
                $scope.lsgtlistArray.push(obj);
            }

        }
    }

    //跟投其他人
    $scope.getlsgtList = function()
    {
        $scope.lsgtlistArray = [];
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("gentou.p_selecthisgentou", message, $scope.p_selecthisgentouCallBack);
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.lsgtlistArray = [];

            if($scope.histype == "1")
            {
                $scope.getlsbgtList();//历史理财包
            }
            else
            {
                $scope.getlsgtList();//历史跟投的理财
            }


        }catch (e){}
    }

    $scope.fbzInit();

    //进入某个历史信息
    $scope.hisItemClick = function(_obj)
    {
        _obj.xzzt = "0";
        if(_obj.gtstatus == "0")
        {
            setbackList(window.location.href);
            window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
        }
        else
        {
            setbackList(window.location.href);
            window.location = "gt_history_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }

    }

    $scope.gthistoryBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }





}



