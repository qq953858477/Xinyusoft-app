/**
 * Created by wangtao on 2015/8/21 0021.
 */
function fabuController($scope, jpajaxService) {

    $scope.jrgdcontent = "";//今日观点内容
    $scope.isApp = true; // 是否在APP 中使用，控制头显示标记
    $scope.userInfo = {};
    $scope.userInfo['f_id'] = !!$scope.jp_userid ? $scope.jp_userid : getParameter('userid');
    $scope.userInfo['f_openid'] =!!$scope.jp_openid ? $scope.jp_openid : getParameter('openid');
    $scope.showStock = false;
    $scope.currentStock = {};
    $scope.currentTag = {};
    $scope.searchStockValue = "";
    $scope.allSearchStockListArray = [];
    $scope.fbgtimgstr = "";//观点发布的图片

    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = "";
    $scope.opentype = getParameter("opentype");
    $scope.fbzMark = false;//发布中
    $scope.tsInfo = "";//发布提示
    $scope.isjrgd = false;

    $scope.dqhtml = window.location.href.toString();
    if($scope.dqhtml.indexOf("jiepan-fabu-gd.html", 0) != -1)
    {
        $scope.isjrgd = true;
    }
    else
    {
        $scope.isjrgd = false;
    }


    $scope.clear = function () {
        $scope.content = '';
        $scope.showStock = false;
        $scope.currentStock = {};
        $scope.currentTag['isActive'] = false;
        $scope.currentTag = {};
        $scope.searchStockValue = "";
        $scope.effectdays = '';
        $scope.sourceurl = '';
        $scope.allSearchStockListArray = [];
    }


    jpajaxService.sendESBReq('user.UserCheck', {'User.id': $scope.userInfo['f_id']}, function (data) {
        if (data['op']['code'] == 'Y') {
            $scope.userInfo = data['user'];
        }
    });
    $scope.contentTypes = [
        {
            id: 'jrgd',
            name: '今日观点',
            icon: 'images/fbico_08.png',
            available: true,
            redrictUrl: 'jiepan-fabu-gd.html?userid='+$scope.userInfo['f_id']+'&rmd='+new Date().getTime()
        },
        {
            id: 'ggjp',
            name: '个股解盘',
            icon: 'images/fbico_01n.png',
            available: false,
            redrictUrl: 'jiepan-fabu-gg.html?userid='+$scope.userInfo['f_id']+'&rmd='+new Date().getTime()
        }, {
            id: 'dpjp',
            name: '市场分析',
            icon: 'images/fbico_02n.png',
            available: false,
            redrictUrl: 'jiepan-fabu-dp.html?userid='+$scope.userInfo['f_id']+'&rmd='+new Date().getTime()
        }, {
            id: 'hyjp',
            name: '概念解盘',
            icon: 'images/fbico_04n.png',
            available: false,
            redrictUrl: 'jiepan-fabu-gn.html?userid='+$scope.userInfo['f_id']+'&rmd='+new Date().getTime()
        }
        /*, {
         id: 'bkfx',
         name: '板块分析',
         icon: 'images/fbico_03.png',
         available: true,
         redrictUrl: 'jiepan-fabu-neirong.html'
         },{
         id:'ggjp',
         name:'个股解盘',
         icon:'images/fbico_05n.png',
         available:true
         }*/, {
            id: 'sjjd',
            name: '事件解读',
            icon: 'images/fbico_05n.png',
            available: false,
            redrictUrl: 'jiepan-fabu-neirong.html'
        }, {
            id: 'spjpgg',
            name: '视频解盘公告',
            icon: 'images/fbico_06n.png',
            available: false,
            redrictUrl: 'jiepan-fabu-neirong.html'
        }
        //}, {
        //    id: 'ggjp',
        //    name: '个股解盘',
        //    icon: 'images/fbico_07n.png',
        //    available: true,
        //    redrictUrl: 'jiepan-fabu-neirong.html'
        //}
    ];

    //股票搜索框改变
    $scope.searchinputChange = function () {
        //alert($scope.searchStockValue)
        if ($scope.searchStockValue != "") {
            $scope.checkContent();
        }
        else {
            $scope.allSearchStockListArray = [];
        }
    }

    //判断并显示搜索股票
    $scope.checkContent = function () {
        var message = {};
        message['key'] = $scope.searchStockValue;//encodeURI(encodeURI($scope.searchStockValue));
        jpajaxService.sendESBReq('hq.searchstockbykeywords', message, searchStockBack);
    }

    $scope.changeView = function (obj) {
        //$rootScope.$state.go(obj['id']);
        if (obj['available'] == true) {
            window.location.href = obj.redrictUrl;
        }
    }

    function searchStockBack(_data) {
        $scope.allSearchStockListArray = [];
        if ($scope.searchStockValue == "") {
            $scope.allSearchStockListArray = [];
            return;
        }
        if (_data.op.code.toString() == "Y") {
            var element = _data.data;
            if (element.length > 0) {
                var arr = [];
                for (var i = 0; i < element.length; i++) {
                    var obj = {};
                    obj.gpdm = element[i]['symbol'].toString();
                    //var p = /\s+/g;
                    //var namestr = element[i]['name'].toString();
                    //namestr = namestr.replace(p, "");

                    obj.zqjc = element[i]['name'].toString();
                    obj.exchange = element[i]['exchange'].toString();//交易所
                    obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                    obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                    //obj.dqj = (parseFloat(element[i]['now'].toString())).toFixed(2);//当前价
                    //obj.zdf = (parseFloat(element[i]['zdf'].toString())).toFixed(2);//涨跌幅
                    //obj.zxj = "0";
                    //obj.status = "";
                    //obj.xzzt = "1";//选中状态，样式更改
                    //obj.zd = "0";
                    //obj.zdf = "0";
                    arr.push(obj);
                }
                $scope.allSearchStockListArray = arr;
            }
            else {
                $scope.allSearchStockListArray = [];
                return;
            }
        }
        else {
            $scope.allSearchStockListArray = [];
            return;
        }
    }

    $scope.choosed = function (stock) {
        console.log("============");
        console.log(stock);
        //$scope.choose($scope.tags[0]);
        $scope.currentStock = stock;
        $scope.currentStock['type'] = 0;
        var message = {
            code: stock['exchange'] + stock['gpdm']
        };
        jpajaxService.sendESBReq('hq.getsnapshot', message, function (data) {
            console.log(data);
            if (data['op']['code'] == 'Y') {
                var snapshot = data['datalist'][0];
                $scope.currentStock['dqj'] = snapshot['close'];
                $scope.currentStock['zdf'] = snapshot['netchangeratio'];
            }
            $scope.showStock = true;
        })
    }

    $scope.typeStock = function () {
        $scope.currentStock = {};
        $scope.showStock = false;
    }

    //个股解盘
    $scope.showrelated = function (jptype)
    {
        var str = 'jiepan_relative.html?type=' + jptype + '&stockcode=' + $scope.currentStock['gpdm'] + '&stockname=' + $scope.currentStock['zqjc'] + '&userid=' + $scope.userInfo['f_id'] + "&title=" + encodeURI(stockname) + "&abletofb=false" + '&rmd=' + new Date().getTime();
        var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //window.location.href = 'jiepan_relative.html?type=' + jptype + '&stockcode=' + $scope.currentStock['gpdm'] + '&stockname=' + $scope.currentStock['zqjc'] + '&userid=' + $scope.userInfo['f_id'] + "&title=" + encodeURI(stockname) + '&rmd=' + new Date().getTime();
    }

    $scope.tags = [
        {
            id: '重大利好',
            class: 'big',
            isActive: false
        }, {
            id: '重大利空',
            class: 'big',
            isActive: false
        }, {
            id: '利好',
            class: '',
            isActive: false
        }, {
            id: '中性',
            class: '',
            isActive: false
        }, {
            id: '利空',
            class: '',
            isActive: false
        }
    ];


// 概念解盘
    $scope.gntags = [
        {
            id: '看涨',
            class: '',
            isActive: false
        }, {
            id: '看平',
            class: '',
            isActive: false
        }, {
            id: '看跌',
            class: '',
            isActive: false
        }
    ];

    /*
     '':jp['f_tag']=='重仓',
     'jp_zdlh':jp['f_tag']=='满仓',
     'jp_zhongxing':jp['f_tag']=='半仓',
     'jp_likong':jp['f_tag']=='轻仓',
     'jp_zhongdalikong':jp['f_tag']=='空仓'}
     */
    // 大盘解盘
    $scope.dptags = [
        {
            id: '满仓',
            class: 'big',
            isActive: false
        }, {
            id: '空仓',
            class: 'big',
            isActive: false
        }, {
            id: '重仓',
            class: '',
            isActive: false
        }, {
            id: '半仓',
            class: '',
            isActive: false
        }, {
            id: '轻仓',
            class: '',
            isActive: false
        }
    ];
    $scope.showGnSearch = true;
    $scope.chooseGn = function (gn, type) {
        //$scope.choose($scope.gntags[0]);
        $scope.showGnSearch = false;
        $scope.currentStock = {
            gpdm: gn['hycode'],
            zqjc: gn['hyname'],
            type: type
        };
        console.log($scope.currentStock);
    }

    /*
     * 获取行业列表
     */
    $scope.getHYList = function () {
        var message = {
            stockCode: 'A',
            marketCode: 'Concept_',
            num: 10000,
            type: 'gn'
        };
        jpajaxService.sendESBReq('hq.getIndexRankList', message, function (data) {
            if (data['op']['code'] == 'Y') {
                $scope.gnList = data['data'];
            }
        })
    };
    $scope.getHYList();

    $scope.dpList = [
        {
            hycode: 'ag',
            hyname: 'A股'
        }, {
            hycode: 'cyb',
            hyname: '创业板'
        }, {
            hycode: 'mg',
            hyname: '美股'
        }, {
            hycode: 'gg',
            hyname: '港股'
        }
    ];

    //公共方法

    $scope.choose = function (_tag) {
        for (var i = 0; i < $scope.tags.length; i++) {
            var tempTag = $scope.tags[i];
            if (tempTag['id'] == _tag['id']) {
                tempTag['isActive'] = true;
                $scope.currentTag = tempTag;
            } else {
                tempTag['isActive'] = false;
            }
        }
        for (var i = 0; i < $scope.gntags.length; i++) {
            var tempTag = $scope.gntags[i];
            if (tempTag['id'] == _tag['id']) {
                tempTag['isActive'] = true;
                $scope.currentTag = tempTag;
            } else {
                tempTag['isActive'] = false;
            }
        }

        for (var i = 0; i < $scope.dptags.length; i++) {
            var tempTag = $scope.dptags[i];
            if (tempTag['id'] == _tag['id']) {
                tempTag['isActive'] = true;
                $scope.currentTag = tempTag;
            } else {
                tempTag['isActive'] = false;
            }
        }
    };
    $scope.effectdays = '';
    $scope.content = '';
    $scope.sourceurl = '';
    $scope.submitJP = function () {
        if (!$scope.currentStock['gpdm']) {
            myAlert('请选择解盘对象');
            return;
        }
        if ($scope.content.length > 300) {
            myAlert("内容不可超过300");
            return;
        } else if (!$scope.content || $scope.content.length <= 0) {
            myAlert('请输入内容');
            return;
        }
        if (!$scope.currentTag['id']) {
            myAlert("请选择标签");
            return;
        }
        if ($scope.currentStock['type'] < 3 && (!$scope.effectdays || $scope.effectdays <= 0)) {
            myAlert("请输入窗口期");
            return;
        }
        var message = {
            "Jiepan.userid": $scope.userInfo['f_id'],
            "Jiepan.type": $scope.currentStock['type'],
            "Jiepan.code": $scope.currentStock['gpdm'],
            "Jiepan.name": $scope.currentStock['zqjc'],
            "Jiepan.exchange": !$scope.currentStock['exchange'] ? '' : $scope.currentStock['exchange'],
            "Jiepan.contenttype": 0,
            "Jiepan.content": $scope.content,
            "Jiepan.price": !$scope.currentStock['dqj'] ? '' : $scope.currentStock['dqj'],//$scope.currentStock['price'],
            "Jiepan.effectdays": !$scope.effectdays ? 0 : $scope.effectdays,
            "Jiepan.tag": $scope.currentTag['id'],
            'jiepan.url': $scope.sourceurl ? $scope.sourceurl : ""
        };
        //console.log("=====2=======");
        //console.log($scope.currentStock);
        jpajaxService.sendESBReq('user.addjiepan', message, function (data) {
            if (data['op']['code'] == 'Y') {
                myAlert('发布成功');
                $scope.clear();
            } else {
                myAlert('发布失败');
                console.log(data);
            }
        });
    }

    //$scope.gnjpBack = function()
    //{
    //    window.location.href = "back";
    //}
    //$scope.ggjpBack = function()
    //{
    //    window.location.href = "back";
    //}
    //$scope.dpjpBack = function()
    //{
    //    window.location.href = "back";
    //}

    $scope.fbjrgd = function()
    {
        if($scope.fbzMark == false)
        {
            console.log($scope.jrgdcontent);
            if (!$scope.jrgdcontent || $scope.jrgdcontent.length <= 0) {
                $scope.tsInfo = '请输入内容';
                return;
            }
            $scope.tsInfo = "发布中...";
            //if ($scope.jrgdcontent.length > 300) {
            //    myAlert("内容不可超过300");
            //    return;
            //}
            $scope.fbzMark = true;//表示发布中
            var message = {};
            message['userid'] = $scope.userInfo['f_id'];
            message['cnt'] = $scope.jrgdcontent;
            if($scope.fbgtimgstr != "")
            {
                message['imgurl'] = $scope.fbgtimgstr;
            }
            jpajaxService.sendESBReq("user.addviewpointaction", message, $scope.fbjrgdCallBack) ;
        }
    }

    $scope.fbjrgdCallBack = function(_data)
    {
        //console.log("发布观点", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jrgdcontent = "";
            $scope.fbgtimgstr = "";
            $scope.tsInfo = '发布成功';
            document.getElementById("fbgtimg").src = "images/imgsc.png";
        }
        else
        {
            $scope.tsInfo = '发布失败，请重试';
        }
        $scope.fbzMark = false;
    }

    $scope.textChange = function()
    {
        $scope.tsInfo = "";
    }


    $scope.jrgdBack = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            history.go(-1);
        }
    }

    $scope.fbinit = function()
    {
        if($scope.isjrgd == true)
        {
            //file 对象
            var file2 = document.getElementById('fbgdimginput'),
            //不支持File API的浏览器调用该接口，预览上传文件信息
                validUrl = urlHeader+'/fileMessage',
            //上传文件处理接口
                uploadUrl = urlHeader+'/upload',
            //不支持File API的浏览器调用该接口，显示文件上传进度
                progressUrl = urlHeader+'/uploadProgress',
                jsUpload = new JsUpload({name:'__jsupload__',file:file2,validUrl:validUrl,uploadUrl:uploadUrl,progressUrl:progressUrl});
            console.log(12132);
            JsUpload.bind(file2,'change',function(event){
                myMsg("正在上传，请稍后...");
                jsUpload.change(this,function(name,size,type){
                });
            });

            //上传文件
            JsUpload.bind(file2,'change',function(event){
                jsUpload.upload(this,file2,function(cur,args1,args2){
                    switch(cur){
                        case 'progress':
                            layer.closeAll();
                            break;
                        case 'complete':
                            layer.closeAll();
                            break;
                        case 'fail':
                            layer.closeAll();
                        case 'load':
                            layer.closeAll();
                        case 'error':
                            layer.closeAll();
                        case 'abort':
                            layer.closeAll();

                            var index1 = args1.indexOf("src=",0);
                            index1 = index1+5;
                            var index11 = args1.indexOf('"',index1);

                            $scope.fbgtimgstr = args1.substring(index1,index11);
                            document.getElementById("fbgtimg").src = $scope.fbgtimgstr;
//                        var imgHtml = "<img onclick='showBigImage(\""+imgurl+"\")' onload='relaceImg(this)' src='"+imgurl+"' style='position:inherit;border-radius:5px;box-shadow: 0px 0px 5px #888888'>";
//                        console.log("头像地址", $scope.imgurl);
//                        $scope.updatelcsheadurl();
                            break;
                        default:
                            break;
                    }
                });
            });
        }
    }

    $scope.fbinit();

}