
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function moniMegagameCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.dsbmDiv = false;//报名界面
    $scope.bmsuccessDiv = false;//报名成功界面
    $scope.phbDivShow = false;//排行榜
    $scope.allpmdivShow = false;//所有排名
    $scope.searchpmDivshow = false;//搜索显示
    //$scope.ybminDiv = false;//已报名
    $scope.userName = "";
    $scope.backtitle = "";
    $scope.phbArray = [];//排行榜
    $scope.searchpmvalue = "";//排名搜索
    $scope.searchpmArray = [];//搜索返回数据
    $scope.bmsuccesscangotophb = false;//报名成功是否可以进入排行榜
    $scope.isbmMark = false;//是否已经报名
    $scope.sxdssfsybmMark = false;//所选大赛是否是已经报名的

    $scope.schoolArray = [];//学校
    $scope.errorInfo = "";//报错信息
    $scope.bmmark = true;//是否可以点击报名
    $scope.name = "";//姓名
    $scope.mobile = "";//电话

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
    $scope.bcid = localStorage.getItem('bcid')

    $scope.gxbgImg = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/gxbg.jpg?20160316";
    $scope.selectschoolObj = {};//所选择报名的学校
    $scope.yjbmschoolObj = {};//已经报名的大赛

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.inprevhome = "1";//高校显示页：1；报名成功页面：2

    $scope.dqgamemyinfo = {};

    //$scope.dqgame = {};//当前大赛

    $scope.getschoolInfoCallBack = function(_data)
    {
        $scope.schoolArray = [];
        //console.log("模拟", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gamelist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.id = arr[i].id;//id
                obj.name = arr[i].name;
                obj.src = arr[i].logo;
                var str = arr[i].beginday;
                obj.beginday = str.substr(0,4) + "." + str.substr(4,2) + "." + str.substr(6,2);
                var str2= arr[i].endday;
                obj.endday = str2.substr(0,4) + "." + str2.substr(4,2) + "." + str2.substr(6,2);
                obj.money = arr[i].money;
                obj.status = arr[i].status.toString();//A，报名中；B，实盘中；C，已结束； D，大赛准备中
                $scope.schoolArray.push(obj);
            }
        }
    }

    $scope.getschoolInfo = function()
    {
        //$scope.schoolArray = [];
        //var obj = {};
        //obj.id = "1";
        //obj.name = "复旦大学";
        //obj.src = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/gx_scion01.png";
        //$scope.schoolArray.push(obj);
        //
        //obj = {};
        //obj.id = "2";
        //obj.name = "同济大学";
        //obj.src = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/gx_scion02.png";
        //$scope.schoolArray.push(obj);
        //
        //obj = {};
        //obj.id = "3";
        //obj.name = "上海财经大学";
        //obj.src = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/gx_scion03.png";
        //$scope.schoolArray.push(obj);

        var message = {};
        message['userid'] = $scope.bcid;
        message['page.size'] = "max";
        message['page.no'] = "1";
        message['type'] = "M";
        //console.log("入参",message);
        ajaxService.sendMessage("tradegame.selectgameaction", message, $scope.getschoolInfoCallBack);
    }

    $scope.getisjoinganme = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['gametype'] = "M";//M，模拟大赛；R，实盘大赛
        message['status'] = "A,B,D";//A，报名中；B，实盘中；C，已结束； D，大赛准备中
        ajaxService.sendMessage("tradegame.selectjoingameaction", message, $scope.getisjoinganmeCallBack);
    }

    $scope.getisjoinganmeCallBack = function(_data)
    {
        //console.log("是否报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gamelist;
            if(arr.length == 0)//未报名
            {
                $scope.isbmMark = false;
            }
            else
            {
                $scope.isbmMark = true;

                var obj = {};
                obj.id = arr[0].id;//id
                obj.name = arr[0].name;
                obj.src = arr[0].logo;
                var str = arr[0].beginday;
                obj.beginday = str.substr(0,4) + "." + str.substr(4,2) + "." + str.substr(6,2);
                var str2= arr[0].endday;
                obj.endday = str2.substr(0,4) + "." + str2.substr(4,2) + "." + str2.substr(6,2);
                obj.money = arr[0].money;
                obj.status = arr[0].status.toString();
                $scope.yjbmschoolObj = obj;

                //if($scope.selectschoolObj.status == "A" || $scope.selectschoolObj.status == "D")
                //{
                //    $scope.mainShow = false;
                //    $scope.bmsuccessDiv = true;
                //    $scope.inprevhome = "2";
                //}
                //else if($scope.selectschoolObj.status == "B")
                //{
                //    $scope.gotophb();
                //}

            }
        }
        else
        {
        }
    }


    //初始相关操作界面
    $scope.myfinInit = function()
    {
        //学校信息
        $scope.getschoolInfo();
        $scope.getisjoinganme();
        $scope.inprevhome = "1";
    }

    $scope.myfinInit();

    //报名
    $scope.gotobmClick = function()
    {
        //console.log("bm", $scope.selectschoolObj);
        $scope.mainShow = false;
        $scope.dsbmDiv = true;
        $scope.phbDivShow = false;
    }

    //进入界面
    $scope.gotooneschool = function(_obj)
    {
        $scope.selectschoolObj = _obj;
        //获取是否报名的信息

        $scope.gotophb();
    }

    $scope.gotophb = function()
    {
        $scope.mainShow = false;
        $scope.phbDivShow = true;
        $scope.allpmdivShow = true;//所有排名
        $scope.searchpmDivshow = false;//搜索显示
        $scope.inprevhome = "3";//排行榜
        if($scope.isbmMark == true)//已经报名
        {
            if($scope.yjbmschoolObj.id == $scope.selectschoolObj.id)
            {
                $scope.sxdssfsybmMark = true;
                $scope.getmypm();
            }
            else
            {
                $scope.sxdssfsybmMark = false;
            }
        }
        $scope.getotherpm();
    }

    //刷新数据
    $scope.refreshClick = function()
    {
        $scope.searchpmArray = [];
        $scope.allpmdivShow = true;
        $scope.searchpmDivshow = false;
        $scope.searchpmvalue = "";
        $scope.getotherpm();
    }

    $scope.getmypm = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['gameid'] = $scope.yjbmschoolObj.id;
        //console.log("fdsafd", message);
        ajaxService.sendMessage("tradegame.getgamememberaction", message, $scope.getmypmCallBack);
    }

    $scope.getmypmCallBack = function(_data)
    {
        //console.log("当前用户排名", _data);
        $scope.dqgamemyinfo = {};
        if(_data.op.code.toString() == "Y")
        {
            var obj = {};
            obj.zqgs = _data.securitycompany;
            obj.zqgsname = _data.getsecuritycompanyname;
            obj.account = _data.account;
            obj.tradeaccount = _data.account;
            obj.newflag = "Y";
            obj.accountstatus = "a";
            obj.username = _data.username;
            obj.userhead = _data.userhead;
            obj.rank = _data.rank;//排名

            $scope.dqgamemyinfo = obj;
        }
    }

    $scope.getotherpm = function()
    {
        var message = {};
        message['gameid'] = $scope.selectschoolObj.id;
        message['page.size'] = "20";
        message['page.no'] = "1";
        //console.log("排行榜", message);
        ajaxService.sendMessage("tradegame.getgameranklistaction", message, $scope.getotherCallBack);
    }

    $scope.getotherCallBack = function(_data)
    {
        $scope.phbArray = []
        //console.log("排行榜", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.ranklist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.account = arr[i].account;
                obj.zqgs = arr[i].securitycompany;
                obj.zqgsname = arr[i].getsecuritycompanyname;
                obj.buycount = arr[i].buycount;
                obj.sellcount = arr[i].sellcount;//排名
                obj.cw = arr[i].cw;
                if(parseFloat(obj.cw) == 0)
                {
                    obj.cwvalue = "空仓";//当前仓位
                }
                else if(parseFloat(obj.cw) == 1)
                {
                    obj.cwvalue = "满仓";//当前仓位
                }
                else
                {
                    obj.cwvalue = (parseFloat(obj.cw)*100).toFixed(0) + "%";//当前仓位
                }
                obj.drsyl = parseFloat(arr[i].drsyl);
                obj.ljsyl = parseFloat(arr[i].ljsyl);//排名
                obj.username = arr[i].username;
                obj.userhead = arr[i].userhead;
                obj.rank = arr[i].rank;//排名
                obj.marketchange = parseFloat((parseFloat(arr[i].marketchange)*100).toFixed(2));//大盘涨跌幅
                $scope.phbArray.push(obj);
            }
        }
    }

    $scope.searchpmvalueChange = function()
    {
        if($scope.searchpmvalue != "")
        {
            $scope.checkContent();
        }
        else
        {
            $scope.searchpmArray = [];
            $scope.allpmdivShow = true;
            $scope.searchpmDivshow = false;
        }
    }

    $scope.checkContent = function()
    {
        $scope.searchpmArray = [];
        $scope.allpmdivShow = false;
        $scope.searchpmDivshow = true;
        var message = {};
        message['gameid'] = $scope.selectschoolObj.id;
        message['name'] = $scope.searchpmvalue;
        //console.log("搜索", message);
        ajaxService.sendMessage("tradegame.searchgamememberaction", message, $scope.checkContentCallBack);
    }

    $scope.checkContentCallBack = function(_data)
    {
        //console.log("搜索", _data);
        $scope.searchpmArray = [];
        if(_data.op.code.toString())
        {
            var arr = _data.searchlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.account = arr[i].account;
                obj.zqgs = arr[i].securitycompany;
                obj.zqgsname = arr[i].getsecuritycompanyname;
                obj.buycount = arr[i].buycount;
                obj.sellcount = arr[i].sellcount;//排名
                obj.cw = arr[i].cw;
                if(parseFloat(obj.cw) == 0)
                {
                    obj.cwvalue = "空仓";//当前仓位
                }
                else if(parseFloat(obj.cw) == 1)
                {
                    obj.cwvalue = "满仓";//当前仓位
                }
                else
                {
                    obj.cwvalue = (parseFloat(obj.cw)*100).toFixed(0) + "%";//当前仓位
                }
                obj.drsyl = parseFloat(arr[i].drsyl);
                obj.ljsyl = parseFloat(arr[i].ljsyl);//排名
                obj.username = arr[i].username;
                obj.userhead = arr[i].userhead;
                obj.rank = arr[i].rank;//排名
                obj.marketchange = parseFloat((parseFloat(arr[i].marketchange)*100).toFixed(2));//大盘涨跌幅
                $scope.searchpmArray.push(obj);
            }
        }
    }

    $scope.gototrade = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", $scope.dqgamemyinfo.tradeaccount);
        localStorage.setItem("accountcompany", $scope.dqgamemyinfo.zqgs);//证券公司id
        localStorage.setItem("accountName", encodeURIComponent($scope.dqgamemyinfo.zqgsname));
        localStorage.setItem("accountShow", encodeURIComponent($scope.dqgamemyinfo.account));
        localStorage.setItem("newflag", encodeURIComponent($scope.dqgamemyinfo.newflag));

        //console.log(_obj.tradeaccount, _obj.account);
        //console.log(_obj.tradeaccount, _obj.zqgs, _obj.zqgsname, _obj.account, _obj.newflag);
        openNewInterface("tradeBase_game.html?opentype=newwebview");
    }

    $scope.bmackto = function()
    {
        $scope.mainShow = false;
        $scope.dsbmDiv = false;
        $scope.phbDivShow = true;
    }

    $scope.phbackto = function()
    {
        $scope.mainShow = true;
        $scope.phbDivShow = false;
        $scope.allpmdivShow = false;
        $scope.searchpmDivshow = false;
        $scope.inprevhome = "1";
        $scope.searchpmvalue = "";
        $scope.sxdssfsybmMark = false;
        $scope.selectschoolObj = {};
        $scope.phbArray = [];
        $scope.searchpmArray = [];
    }

    //报名
    $scope.bmclick = function()
    {
        if($scope.name == "")
        {
            $scope.errorInfo = "请先输入您的姓名";
            return;
        }
        if($scope.mobile == "")
        {
            $scope.errorInfo = "请先输入您的联系电话";
            return;
        }
        if($scope.bmmark)
        {
            $scope.errorInfo = "";
            $scope.bmmark = false;

            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['gameid'] = $scope.selectschoolObj.id;
            message['name'] = $scope.name;
            message['telephone'] = $scope.mobile;
            message['account'] = "0";
            //console.log("message", message);
            ajaxService.sendMessage("tradegame.p_applygame", message, $scope.bmCallBack);
        }
    }
    $scope.bmCallBack = function(_data)
    {
        //console.log("报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isbmMark = true
            $scope.sxdssfsybmMark = true;
            $scope.yjbmschoolObj =  $scope.selectschoolObj;
            $scope.bmsuccess();
        }
        else
        {
            $scope.errorInfo = "报名失败，原因：" + _data.op.info;
        }

        $scope.bmmark = true;
    }

    //报名成功
    $scope.bmsuccess = function()
    {
        //赛程中
        //if($scope.selectschoolObj.status == "B")
        //{
        //    $scope.bmsuccesscangotophb = true;
        //}
        //else
        //{
        //    $scope.bmsuccesscangotophb = false;
        //}
        $scope.dsbmDiv = false;
        $scope.bmsuccessDiv = true;
        $scope.inprevhome = "2";
    }

    $scope.bmsuccessgotophbClick = function()
    {
        $scope.bmsuccessDiv = false;
        $scope.gotophb();
    }

    $scope.bmsuccessackto = function()
    {
        $scope.inprevhome = "1";
        $scope.bmsuccessDiv = false;
        $scope.dsbmDiv = false;
        $scope.mainShow = true;
    }

    //分享
    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);


        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/monigame_index.html");
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = '股市三国演义 "芯与国金杯"高校炒股大赛';
        var desc = '股市风起云涌、战火纷纷、硝烟滚滚。群雄割据，胜负仍未见分晓。。。';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/monigame_index.html";
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    $scope.pyqfx = function()
    {
        var title = '股市三国演义 "芯与国金杯"高校炒股大赛';
        var desc = '股市风起云涌、战火纷纷、硝烟滚滚。群雄割据，胜负仍未见分晓。。。';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/monigame_index.html";
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        //alert("$scope.inprevhome：" + $scope.inprevhome);
        if($scope.inprevhome == "2")
        {
            $scope.bmsuccessDiv = false;
        }
        else if($scope.inprevhome == "1")
        {
            $scope.mainShow = false;
        }
        else if($scope.inprevhome == "3")
        {
            $scope.phbDivShow = false;
        }
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/monigame_index.html";
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        if($scope.inprevhome == "2")
        {
            $scope.bmsuccessDiv = true;
        }
        else if($scope.inprevhome == "1")
        {
            $scope.mainShow = true;
        }
        else if($scope.inprevhome == "3")
        {
            $scope.phbDivShow = true;
        }
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    //开户返回
    $scope.mndsBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    //大赛规则
    $scope.dsgzclick = function()
    {
        openNewInterface("moni_dasaiguize.html?opentype=newwebview");
    }
    //大赛奖品
    $scope.dsjpClick = function()
    {
        openNewInterface("moni_dasaijp.html?opentype=newwebview");
    }

}



