
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function suggestionsCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";

    $scope.tsInfo = "";//提示信息
    $scope.fbzMark = false;//发布中
    $scope.mobilestr = "";//电话号码
    $scope.jrgdcontent = "";//内容
    $scope.fbgtimgstr = "";//图
    $scope.backtitle = "";

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.imginit = function()
    {
        //file 对象
        var file2 = document.getElementById('fbgdimginput'),
        //不支持File API的浏览器调用该接口，预览上传文件信息
            validUrl = urlHeader+'/fileMessage',
        //上传文件处理接口
            uploadUrl = urlHeader+'/upload',
        //不支持File API的浏览器调用该接口，显示文件上传进度
            progressUrl = urlHeader+'/uploadProgress',
            jsUpload = new JsUpload({name:'__jsupload__',file:file2,validUrl:validUrl,uploadUrl:uploadUrl,progressUrl:progressUrl});
        console.log(12132);
        JsUpload.bind(file2,'change',function(event){
            myMsg("正在上传，请稍后...");
            jsUpload.change(this,function(name,size,type){
            });
        });

        //上传文件
        JsUpload.bind(file2,'change',function(event){
            jsUpload.upload(this,file2,function(cur,args1,args2){
                switch(cur){
                    case 'progress':
                        layer.closeAll();
                        break;
                    case 'complete':
                        layer.closeAll();
                        break;
                    case 'fail':
                        layer.closeAll();
                    case 'load':
                        layer.closeAll();
                    case 'error':
                        layer.closeAll();
                    case 'abort':
                        layer.closeAll();

                        var index1 = args1.indexOf("src=",0);
                        index1 = index1+5;
                        var index11 = args1.indexOf('"',index1);

                        $scope.fbgtimgstr = args1.substring(index1,index11);
                        document.getElementById("fbgtimg").src = $scope.fbgtimgstr;
                        break;
                    default:
                        break;
                }
            });
        });
    }


    //初始相关操作界面
    $scope.myfinInit = function()
    {
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }

        $scope.imginit();

    }

    $scope.myfinInit();


    $scope.fbjrgd = function()
    {
        if($scope.fbzMark == false)
        {
            if (!$scope.jrgdcontent || $scope.jrgdcontent.length <= 0) {
                $scope.tsInfo = '请输入内容';
                return;
            }
            if($scope.mobilestr != "")
            {
                if($scope.mobilestr.length != 11)
                {
                    $scope.tsInfo = '请输入正确的手机号';
                    return;
                }
                if($scope.checkValue($scope.mobilestr) == false)
                {
                    $scope.tsInfo = "请输入正确的手机号";
                    return;
                }
            }
            $scope.tsInfo = "提交中，请稍候...";
            $scope.fbzMark = true;//表示发布中
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['cnt'] = $scope.jrgdcontent;
            if($scope.fbgtimgstr != "")
            {
                message['imgurl'] = $scope.fbgtimgstr;
            }
            if($scope.mobilestr != "")
            {
                message['mobile'] = $scope.mobilestr;
            }
            ajaxService.sendMessage("user.addfeedbackaction", message, $scope.fbjrgdCallBack) ;
        }
    }

    $scope.fbjrgdCallBack = function(_data)
    {
        //console.log("发布观点", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jrgdcontent = "";
            $scope.fbgtimgstr = "";
            $scope.mobilestr = "";
            $scope.tsInfo = '提交成功';
            document.getElementById("fbgtimg").src = "images/imgsc.png";
        }
        else
        {
            $scope.tsInfo = '提交失败，请重试';
        }
        $scope.fbzMark = false;
    }

    $scope.textChange = function()
    {
        $scope.tsInfo = "";
    }

    //开户返回
    $scope.yjyfkback = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                //alert("含有非数字字符");
                if(_str.charAt(i) != ".")
                {
                    return false;
                }
            }
        }
        return true;
    }

}



