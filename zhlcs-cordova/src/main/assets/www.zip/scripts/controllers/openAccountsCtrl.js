
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function openAccountsCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面
    $scope.backtitle = "";

    $scope.khurl = "";//开户地址
    $scope.selectkh = "";
    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.sftype = "";

    //初始相关操作界面
    $scope.myfinInit = function()
    {
        var localStorage = window.localStorage;
        $scope.sftype = localStorage.getItem("lcsstatus");
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }

    }

    $scope.myfinInit();


    //开户
    $scope.khItemClick = function(_str)
    {
        if(_str == "gh")//国海
        {
            try
            {
                var str = "http://cl.ghzq.cn/yykh/m?channel=XYKJ01";
                var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
            }
            catch (e){
            }
        }
        else if(_str == "gj")
        {
            try
            {
                var str = "https://webkh.yongjinbao.com.cn/index.php?channel_type=900067&page_nav=1";
                var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
            }
            catch (e){
            }
        }
        if(_str == "db")//东北
        {
            try
            {
                var str = "https://xsjkh.nesc.cn/p/99930505";
                var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
            }
            catch (e){
            }
        }
    }
    //分享
    $scope.fxItemClick = function(_str)
    {
        $scope.selectkh = _str;
    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);


        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr));
        //console.log("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr));
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        if($scope.selectkh == "gh")
        {
            var title = $scope.userName + ' 邀请您开通国海证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
        else if($scope.selectkh == "gj")
        {
            var title = $scope.userName + ' 邀请您开通国金证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
        else if($scope.selectkh == "db")
        {
            var title = $scope.userName + ' 邀请您开通东北证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
    }

    $scope.pyqfx = function()
    {
        if($scope.selectkh == "gh")
        {
            var title = $scope.userName + ' 邀请您开通国海证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToFriend(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("朋友圈分享失败");
            })
        }
        else if($scope.selectkh == "gj")
        {
            var title = $scope.userName + ' 邀请您开通国金证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToFriend(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("朋友圈分享失败");
            })
        }
        else if($scope.selectkh == "db")
        {
            var title = $scope.userName + ' 邀请您开通东北证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToFriend(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("朋友圈分享失败");
            })
        }

    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    //开户返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



