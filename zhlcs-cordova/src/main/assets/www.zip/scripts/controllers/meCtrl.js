/**
 * Created by Administrator on 2015/7/10.
 */
function me()
{
    return {
        restrict: 'E',
        //templateUrl: 'index.html',
        templateUrl: 'me.html',
        controller:['$scope','ajaxService','$cookieStore',meCtrl],
        //template: '<span>Hi there444</span>',
        //replace: true,
        transclude: true
    };
}

function meCtrl($scope, ajaxService, $cookieStore) {
    $scope.isgtbShow = false;//跟投宝信息是否显示
    $scope.gtbinfoShow = false;//跟投宝相关内容
    $scope.meMainShow = false;//主界面
    $scope.zlxgDivShow = false;//资料修改
    $scope.modifyIntroduce = false;
    $scope.accountCount = "-";
    $scope.friendCount = "-";
    $scope.combCount = "-";
    $scope.totalCount = 0;

    $scope.lcsdjArray = [];//理财师等级图片数组
    //console.log($scope.head);

    //$scope.isxrklcs = false;
    //$scope.lcssqz = false;//理财师申请中

    $scope.ptpeopleObj = {};
    $scope.ptpeopleObj.headurl = 'images/ico02_1.png';
    $scope.ptpeopleObj.name = "";
    $scope.ptpeopleObj.wxh = "";
    $scope.ptpeopleObj.qq = "";
    $scope.ptpeopleObj.dq = "";//地区


    $scope.lcsObj = {};
    $scope.lcsObj.headurl = 'images/ico02_1.png';
    $scope.lcsObj.name = "";
    $scope.lcsObj.wxh = "";
    $scope.lcsObj.qq = "";
    $scope.lcsObj.mobilephone = "";//手机号
    $scope.lcsObj.lcstzsc = "";//投资时长
    $scope.lcsObj.lcstzln = "";//投资理念
    $scope.lcsObj.lcsscly = "";//历史战绩
    $scope.lcsObj.dq = "";//地区

    $scope.oldInfo = {};
    $scope.oldInfo.headurl = 'images/ico02_1.png';
    $scope.oldInfo.name = "";
    $scope.oldInfo.wxh = "";
    $scope.oldInfo.qq = "";
    $scope.oldInfo.mobilephone = "";
    $scope.oldInfo.lcstzsc = "";//投资时长
    $scope.oldInfo.lcstzln = "";//投资理念
    $scope.oldInfo.lcsscly = "";//历史战绩

    $scope.tzlnDivShow = false;
    $scope.lizjDivShow = false;

    $scope.imgurl = "";

    $scope.gtjjobj = {};
    $scope.gtjjobj.ggjjje = "--";
    $scope.gtjjobj.account = "";//跟投基金账户
    $scope.gtbky = "";

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
    });

    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    $scope.getFriendList = function () {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("user.getfriendnumbyuseridaction", message, function (data) {
            //console.log("好友：" + data);
            if (data.op.code.toString() == "Y")
            {
                //$scope.friendCount = data.friendlist.length;
                //var arr = data.friendlist;
                //var arr2=[];
                //for(var i=0;i<arr.length;i++)
                //{
                //    if(arr[i]['f_friend_id'].toString() != $scope.userObj.f_id)
                //    {
                //        arr2.push(arr[i]);
                //    }
                //}
                $scope.friendCount = data.friendcount;
                //var element = data.friendlist;
                //for (var item in element)
                //{
                //    $scope.totalCount += element[item]['newmsgcount'];
                //}
            }
        });
    }


    $scope.getzhmxCount = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log($scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getmyinfo", message, function (data) {
            //console.log("账户个数",data);
            if (data.op.code.toString() == "Y") {
                $scope.accountCount = data.myinfo.bindaccountcount;//账户个数
                if($scope.accountCount >0)
                {
                    $scope.accountCount = $scope.accountCount - 1;
                }
                $scope.combCount = data.myinfo.modelcount;//模型个数
            }
        });
    }

    //理财师评级
    $scope.setlcspj = function()
    {
        //console.log("评级", $scope.lcspj);
        //$scope.lcspj = "0.8";
        $scope.lcsdjArray = [];
        if($scope.lcspj != null && $scope.lcspj != undefined && $scope.lcspj != "" && $scope.lcspj !="0" && $scope.lcspj !="0.0")
        {
            var pointindex = $scope.lcspj.indexOf(".",0);
            if(pointindex == -1 || (pointindex != -1 && $scope.lcspj.substr(pointindex+1,1)=="0"))//无小数点，整数，有小数点，小数点后为0
            {
                var num = parseFloat($scope.lcspj);
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                for(var i = num+1;i<6;i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star2.png";
                    $scope.lcsdjArray.push(obj);
                }
            }
            else//有小数点
            {
                var num = Math.floor(parseFloat($scope.lcspj));
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num<5)
                {
                    var obj = {};
                    obj.value = $scope.lcsdjArray.length+1;
                    obj.djsrc = "images/star3.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num+1<5)
                {
                    for(var i = num+2;i<6;i++)
                    {
                        var obj = {};
                        obj.value = i;
                        obj.djsrc = "images/star2.png";
                        $scope.lcsdjArray.push(obj);
                    }
                }
            }
            //for(var i = 0;i<parseFloat($scope.lcspj);i++)
            //{
            //    var obj = {};
            //    obj.value = i;
            //    $scope.lcsdjArray.push(obj);
            //}
        }
        else
        {
            for(var i = 1;i<6;i++)
            {
                var obj = {};
                obj.value = i;
                obj.djsrc = "images/star2.png";
                $scope.lcsdjArray.push(obj);
            }
        }
    }

    $scope.getLastest3ProductAvgScoreActionCallBack = function(_data)
    {
        console.log("理财师评级",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.lcspj = _data.avg.toString();
            var localStorage = window.localStorage;
            localStorage.setItem("lcspj", $scope.lcspj);
            $scope.setlcspj();
        }
    }

    $scope.getlcspj = function()
    {
        //$scope.lcspj = _data.lcsapplyinfo.level;

        var message = {};
        message['userid'] = $scope.userObj.f_id;//理财师id
        //console.log("用户id", $scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.getLastest3ProductAvgScoreAction", message, $scope.getLastest3ProductAvgScoreActionCallBack);
    }

    imginit = function()
    {
        //console.log("imginit");
        if($scope.isxrklcs == true && $scope.lcssqz == false)//理财师
        {
            //file 对象
            var file2 = document.getElementById('lcsimginput'),
            //不支持File API的浏览器调用该接口，预览上传文件信息
                validUrl = urlHeader+'/fileMessage',
            //上传文件处理接口
                uploadUrl = urlHeader+'/upload',
            //不支持File API的浏览器调用该接口，显示文件上传进度
                progressUrl = urlHeader+'/uploadProgress',
                jsUpload = new JsUpload({name:'__jsupload__',file:file2,validUrl:validUrl,uploadUrl:uploadUrl,progressUrl:progressUrl});
            JsUpload.bind(file2,'change',function(event){
                myMsg("正在上传，请稍后...");

                jsUpload.change(this,function(name,size,type){
                });
            });

            //上传文件
            JsUpload.bind(file2,'change',function(event){
                jsUpload.upload(this,file2,function(cur,args1,args2){
                    switch(cur){
                        case 'progress':
                            layer.closeAll();
                            break;
                        case 'complete':
                            layer.closeAll();
                            break;
                        case 'fail':
                            layer.closeAll();
                        case 'load':
                            layer.closeAll();
                        case 'error':
                            layer.closeAll();
                        case 'abort':
                            layer.closeAll();

                            var index1 = args1.indexOf("src=",0);
                            index1 = index1+5;
                            var index11 = args1.indexOf('"',index1);

                            $scope.imgurl = args1.substring(index1,index11);
//                        var imgHtml = "<img onclick='showBigImage(\""+imgurl+"\")' onload='relaceImg(this)' src='"+imgurl+"' style='position:inherit;border-radius:5px;box-shadow: 0px 0px 5px #888888'>";
//                        console.log("头像地址", $scope.imgurl);
                            $scope.updatelcsheadurl();
                            break;
                        default:
                            break;
                    }
                });
            });
        }
        else//普通用户
        {
            //alert("1");
            //alert("1111");
            //file 对象
            try{
                var file = document.getElementById('flcsimginput'),
                //不支持File API的浏览器调用该接口，预览上传文件信息
                    validUrl = urlHeader+'/fileMessage',
                //上传文件处理接口
                    uploadUrl = urlHeader+'/upload',
                //不支持File API的浏览器调用该接口，显示文件上传进度
                    progressUrl = urlHeader+'/uploadProgress',
                    jsUpload = new JsUpload({name:'__jsupload__',file:file,validUrl:validUrl,uploadUrl:uploadUrl,progressUrl:progressUrl});
            }
            catch (e){
                //alert(e.toString());
            }
            //alert("2");
            JsUpload.bind(file,'change',function(event){
                myMsg("正在上传，请稍后...");

                jsUpload.change(this,function(name,size,type){
                });
            });
            //上传文件
            JsUpload.bind(file,'change',function(event){
                jsUpload.upload(this,file,function(cur,args1,args2){
                    switch(cur){
                        case 'progress':
                            layer.closeAll();
                            break;
                        case 'complete':
                            layer.closeAll();
                            break;
                        case 'fail':
                            layer.closeAll();
                        case 'load':
                            layer.closeAll();
                        case 'error':
                            layer.closeAll();
                        case 'abort':
                            layer.closeAll();

                            var index1 = args1.indexOf("src=",0);
                            index1 = index1+5;
                            var index11 = args1.indexOf('"',index1);

                            $scope.imgurl = args1.substring(index1,index11);
//                        var imgHtml = "<img onclick='showBigImage(\""+imgurl+"\")' onload='relaceImg(this)' src='"+imgurl+"' style='position:inherit;border-radius:5px;box-shadow: 0px 0px 5px #888888'>";
//                        console.log("头像地址", $scope.imgurl);
                            $scope.updateptyhheadurl();
                            break;
                        default:
                            break;
                    }
                });
            });
        }

    }

    //理财师状态
    $scope.megetlcsStatus = function () {
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, function (_data)
        {
            //console.log("理财师：" + _data);
            //for(var k in _data)
            //{
            //    console.log("key: " + k + "；value: " + _data[k]);
            //}
            //var lcspj = "0";
            $scope.lcsstatus = "0";
            if (_data.op.code.toString() == "Y")
            {
                if (_data.lcsapplyinfo.isexist.toString() == "false") {
                    $scope.lcsstatus = "0";//0：未申请
                }
                else {
                    if (_data.lcsapplyinfo.status.toString() == "A") {
                        $scope.lcsstatus = "1";//1：申请中
                    }
                    else if (_data.lcsapplyinfo.status.toString() == "Y") {
                        $scope.lcsstatus = "2";//1：申请通过，已是理财师
                        //lcspj = _data.lcsapplyinfo.level;
                    }
                    else//N，申请未通过
                    {
                        $scope.lcsstatus = "0";//0：未申请
                    }
                }
                if ($scope.lcsstatus == "2") {
                    $scope.abletofb = 'true';//是理财师，可以发布解盘
                }
                else {
                    $scope.abletofb = 'false';
                }
                //console.log("lcsstatus", $scope.lcsstatus);
            }
            if($scope.lcsstatus == "2")//是理财师
            {
                $scope.isxrklcs = true;//是理财师
                $scope.lcssqz = false;
                $scope.getlcspj();
            }
            else
            {
                if($scope.lcsstatus == "1")//申请中
                {
                    $scope.lcssqz = true;
                    $scope.isxrklcs = false;//不是理财师
                }
                else
                {
                    $scope.isxrklcs = false;//不是理财师
                    $scope.lcssqz = false;
                }
            }
            var localStorage = window.localStorage;
            localStorage.setItem("lcsstatus", $scope.lcsstatus);
            imginit();

        })
    }

    $scope.setgtbinfo = function()
    {

        var cstr  = {"caption": "gtbdirective"};
        $scope.$broadcast("setParameters", cstr);

        $scope.isgtbShow = true;

        if($scope.baseindex == "42")
        {
            $scope.gtbinfoShow = false;//跟投宝相关内容
            $scope.meMainShow = true;//主界面
            $scope.baseBottomVisible(false);
        }
        else
        {
            $scope.gtbinfoShow = true;//跟投宝相关内容
            $scope.meMainShow = false;//主界面
            $scope.baseBottomVisible(true);
        }
    }

    //获取跟投宝状态，判断跟投宝是否显示
    $scope.getgtbstatus = function()
    {
        //是否有跟投（实盘中、解除中、历史、报名中），是否有服务（实盘中、解除中、历史、报名中）
        //var message = {};
        //message['userid'] = $scope.userObj.f_id;//getParameter('userid');
        //message['page.size'] = 'max';
        //message['page.no'] = 1;
        //ajaxService.sendMessage('sunflower.p_selectrelativeproducts', message, function (_data) {
        //    if(_data.op.code.toString() == "Y")
        //    {
        //        if(_data.gentoulist.length>0 || _data.applylist.length >0 || _data.productlist.length>0)
        //        {
        //            $scope.isgtbShow = true;
        //            $scope.setgtbinfo();
        //        }
        //    }
        //    if($scope.isgtbShow != true)
        //    {
        //        var message = {};
        //        message['userid'] =  $scope.userObj.f_id;
        //        message['page.size'] =  "max";
        //        message['page.no'] =  "";
        //        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, function(_data)
        //        {
        //            if(_data.op.code.toString() == "Y")
        //            {
        //                if(_data.gentouproductlist.length>0)//历史被跟投
        //                {
        //                    $scope.isgtbShow = true;
        //                    $scope.setgtbinfo();
        //                }
        //            }
        //            if($scope.isgtbShow != true)
        //            {
        //                var message = {};
        //                message['userid'] =  $scope.userObj.f_id;
        //                message['page.size'] =  "max";
        //                message['page.no'] =  "";
        //                ajaxService.sendMessage("gentou.p_selecthisgentou", message, function(_data){
        //                    if(_data.op.code.toString() == "Y")
        //                    {
        //                        if(_data.hisaccountlinklist.length>0)//历史被跟投
        //                        {
        //                            $scope.isgtbShow = true;
        //                        }
        //                        if($scope.isgtbShow == true)
        //                        {
        //                            $scope.setgtbinfo();
        //                        }
        //                        else
        //                        {
        //                            $scope.isgtbShow = false;
        //                            $scope.gtbinfoShow = false;//跟投宝相关内容
        //                            $scope.meMainShow = true;//主界面
        //                        }
        //                    }
        //                });
        //            }
        //        });
        //    }
        //});



        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getmyinfo", message, function (data)
        {
            //console.log("账户个数",data);
            if (data.op.code.toString() == "Y")
            {
                $scope.accountCount = data.myinfo.bindaccountcount;//账户个数
                if($scope.accountCount>0)
                {
                    $scope.accountCount = $scope.accountCount -1;
                }
                //console.log("账户个数", $scope.accountCount);
                if($scope.accountCount>0)
                {
                    //$scope.isgtbShow = true;
                    $scope.setgtbinfo();
                }
                else
                {
                    $scope.isgtbShow = false;
                    $scope.gtbinfoShow = false;//跟投宝相关内容
                    $scope.meMainShow = true;//主界面
                }
            }
            else
            {
                $scope.isgtbShow = false;
                $scope.gtbinfoShow = false;//跟投宝相关内容
                $scope.meMainShow = true;//主界面
            }
        });

    }

    $scope.getgtjjCallBack = function(_data)
    {
        //console.log("333", _data);
        $scope.gtjjobj.ggjjje = parseFloat(_data.money)-parseFloat(_data.applymoney);
        $scope.gtjjobj.account = _data.account;//跟投基金账户
    }


    $scope.getgtjj = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.getexperienceaccountaction", message, $scope.getgtjjCallBack);
    }

    $scope.meinit = function(newValue, oldValue, scope)
    {
        //console.log("me", newValue, oldValue);
        if(newValue)
        {
            $scope.getgtbstatus();
            $scope.getgtjj();
            //$scope.isgtbShow = true;
            //$scope.setgtbinfo();
            $scope.megetlcsStatus();
            $scope.getzhmxCount();
            //$scope.getFriendList();
            //$scope.getzhmxCount();
        }
    }
    $scope.$watch('basetabFourShow', $scope.meinit);

    $scope.showMyInfo = function () {
        $scope.modifyIntroduce = !$scope.modifyIntroduce;
    }


    //进入个人空间
    $scope.woClick = function()
    {
        $scope.gtbinfoShow = false;
        $scope.meMainShow = true;
        window.location.href = "#baseindex=42";
        $scope.baseindex = "42";
        gotoUp();
        $scope.baseBottomVisible(false);

    }
    //个人返回
    $scope.wobackto = function()
    {
        $scope.gtbinfoShow = true;
        $scope.meMainShow = false;
        window.location.href = "#baseindex=4";
        $scope.baseindex = "4";
        gotoUp();
        $scope.baseBottomVisible(true);
    }

    $scope.me_myFriend = function () {

        //try
        //{
        //    var str = "myGroupBase.html"+"?backtitle=" + encodeURI("我") +"&&rmd=" + new Date().getTime();
        //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //}
        //catch (e){
        //    window.location = "myGroupBase.html"+"?backtitle=" + encodeURI("我") +"&&rmd=" + new Date().getTime();
        //}
        //xinyuNewBrowser("myGroupBase.html"+"?backtitle=" + encodeURI("我") +"&&rmd=" + new Date().getTime());
    }

    //账户
    $scope.me_zhClick = function()
    {
        //deleteback();
        //try
        //{
        //    var str = "myFinancialBase.html" + "?backtitle=" + encodeURI("我");
        //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    ref.addEventListener("exit", $scope.zhmxupdateCallBack);
        //
        //}
        //catch (e){
        //    setbackList("uufpBase.html?baseindex=4");
        //    window.location = "myFinancialBase.html" + "?backtitle=" + encodeURI("我");
        //}

        xinyuNewBrowser("myFinancialBase.html"+"?opentype=newwebview&&backtitle=" + encodeURI("我"), "updatezh");
    }

    //我的跟投基金
    $scope.me_gtjj = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", $scope.gtjjobj.account);
        localStorage.setItem("accountcompany", "");//证券公司id
        localStorage.setItem("accountName", "");
        localStorage.setItem("accountShow", $scope.gtjjobj.account);
        localStorage.setItem("newflag", "");
        //window.location.href = "tradeBase_gtjj.html"+ "?backtitle=" + encodeURI("我");
        xinyuNewBrowser("tradeBase_gtjj.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview", "updategtjj");
    }

    updatezh = function()
    {
        $scope.getzhmxCount();
    }

    updategtjj = function()
    {
        $scope.getgtjj();
    }


    //跟投宝
    $scope.me_gtbClick = function()
    {
        //window.location = "gtb/gtb-index.html?backurl=../uufpBase.html?baseindex=4";
        //deleteback();
        //try
        //{
        //    var str = "gtbBase.html" + "?backtitle=" + encodeURI("我");
        //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    ref.addEventListener("exit", $scope.zxgupdateCallBack);
        //}
        //catch (e){
        //    setbackList("uufpBase.html?baseindex=4");
        //    window.location = "gtbBase.html" + "?backtitle=" + encodeURI("我");
        //}
        xinyuNewBrowser("gtbBase.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview");
    }

    //进入可跟投的股票池（好友）
    $scope.stockPoolListItemClick = function(_obj)
    {
        //_obj.xzzt = "0";

        //window.location.href = "oneStockPool.html?oneStockPoolID=" + _obj.modelid + "&oneStockPoolName=" + encodeURI(_obj.name) + "&back=myspace";
    }


    //理财师申请
    $scope.me_lcssqClick = function()
    {
        setbackList(window.location.href);
        window.location.href = "gtb/lcs-shenqing.html?" + "&backtitle=" + encodeURI("我");
        //setbackList(window.location.href);
        //window.location.href = "activitydh/lcssqdh.html" + "?backtitle=" + encodeURI("我");
    }

    //帮助（手册）
    $scope.me_helpClick = function()
    {
        //$scope.homebaseShow = false;//主界面
        //$scope.funintShow = true;//功能介绍
        //gotoUp();
        //$scope.baseBottomVisible(false);
        //window.location.href = "shouce/gongneng-jieshao3.html";
        xinyuNewBrowser("shouce/gongneng-jieshao3.html");

    }

    //建议与反馈
    $scope.me_suggestionClick = function()
    {
        //xinyuNewBrowser("suggestions.html?opentype=newwebview");
        setbackList(window.location.href);
        window.location.href = "suggestions.html"+"?backtitle=" + encodeURI("我");
    }

    //微信邀请好友
    $scope.me_wxyqhyClick = function()
    {
        //$scope.getLink();
        //var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        ////var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        //setUrl(_str);
    }

    //生成链接
    $scope.getLink = function()
    {
        var path = location.href;
        //console.log(path);
        $scope.invitePath = "";
        if(path != "")
        {
            var index = path.lastIndexOf("/", path.length);
            //console.log("121321", index);
            //pathstr = http://127.0.0.1:8080/uuFinancialPlanner/myGroupBase.html;
            //$scope.invitePath = path.substr(0,index+1);
            //$scope.invitePath = "http://www.xinyusoft.com:8085/uuFinancialPlanner/";
            //$scope.invitePath = $scope.invitePath + "invitedConnectionsBase.html?inviterName=" + $cookieStore.get('nickname') + "&inviterID=" + $scope.userObj.f_id + "&systemID=1";
            //$scope.invitePath = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx4fbfd12de50a98c7&redirect_uri=http://www.xinyusoft.com:8085/weixin/GetUserInfoServlet?btntype=addfriend%26";
            //$scope.invitePath = $scope.invitePath + "inviterName=" + $cookieStore.get('nickname') + "%26inviterID=" +  $scope.userObj.f_id + "&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
            var message = {};
            message['inviterID'] = $scope.userObj.f_id;
            //message['userName'] = $cookieStore.get('nickname');
            var localStorage = window.localStorage;
            message['userName'] = encodeURI(decodeURIComponent(localStorage.getItem('nickname')));
            message['bcid'] = $scope.bcidstr;
            //console.log(message);
            ajaxService.sendMessage("user.getShortInviteUrlByUser", message, $scope.getShortInviteUrlByUserCallBack) ;
        }
    }

    $scope.getShortInviteUrlByUserCallBack = function(_data)
    {
        //alert("_data地址：" + _data.tos);
        //console.log("_data地址：", _data);
        if(_data.op.code.toString() == "Y")
        {
            //$scope.invitePath = _data.shorturl.toString();
            //alert("地址：" + _data);
            //console.log("地址",_data);
            setUrl(_data.shorturl.toString());
        }
        else
        {
            //alert("邀请链接获取失败");
            //alert("微信邀请好友失败，请重试");
            myAlert("微信邀请好友失败，请重试");
        }
    }

    setUrl  = function(_content)
    {
        //console.log(_content);
        var title = $scope.userName + '邀请您使用“专户理财师”';
        var desc = '专户理财师，您的私人理财师～～';

        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信邀请好友失败，请重试");
        })
    }

    $scope.me_yqhy_wxhy = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.userName + '邀请您使用“专户理财师”';
        var desc = '专户理财师，您的私人理财师～～';

        shareUrlToDialog(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("微信邀请好友失败，请重试");
        })
    }

    $scope.me_yqhy_pyq = function()
    {
        //console.log("朋友圈");
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.userName + '邀请您使用“专户理财师”';
        var desc = '专户理财师，您的私人理财师～～';

        shareUrlToFriend(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("朋友圈分享失败");
        })
    }

    //模型
    $scope.me_mxClick = function()
    {
        //try
        //{
        //    var str = "myModelBase.html?backtitle=" + encodeURI("我");
        //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    ref.addEventListener("exit", $scope.zhmxupdateCallBack);
        //}
        //catch (e){
        //    setbackList("uufpBase.html?baseindex=4");
        //    window.location.href = "myModelBase.html?backtitle=" + encodeURI("我");
        //}
    }

    $scope.zhmxupdateCallBack = function()
    {
        $scope.getzhmxCount();
    }



    //资料修改
    $scope.zlxgClick = function()
    {
        $scope.meMainShow = false;
        $scope.zlxgDivShow = true;
        $scope.baseBottomVisible(false);
        gotoUp();

        //alert("$scope.lcsstatus" + $scope.lcsstatus);
        if($scope.lcsstatus!='2')
        {
            $scope.setgrzl();
        }
        else
        {
            $scope.getlcsInfo();
        }
    }

    $scope.zlxgback = function()
    {
        $scope.meMainShow = true;
        $scope.zlxgDivShow = false;
        $scope.baseBottomVisible(true);
        gotoUp();
    }
    $scope.setgrzl = function()
    {
        //alert("setgrzl");
        $scope.ptpeopleObj.headurl = decodeURIComponent(localStorage.getItem('iconurl'));
        $scope.ptpeopleObj.name = decodeURIComponent(localStorage.getItem('nickname'));
        //alert($scope.ptpeopleObj.headurl);

        document.getElementById("flcsheadImg").src = $scope.ptpeopleObj.headurl;

        //alert($scope.userObj.f_weixinhao + " " +  $scope.userObj.f_qq);

        if($scope.userObj.f_weixinhao != undefined)
        {
            $scope.ptpeopleObj.wxh = $scope.userObj.f_weixinhao;
        }
        if($scope.userObj.f_qq != undefined)
        {
            $scope.ptpeopleObj.qq = $scope.userObj.f_qq;
        }
        if($scope.userObj.f_province == undefined && $scope.userObj.f_city == undefined)
        {
            $scope.ptpeopleObj.dq = "";
        }
        else if($scope.userObj.f_province != undefined && $scope.userObj.f_city != undefined)
        {
            $scope.ptpeopleObj.dq = $scope.userObj.f_province + $scope.userObj.f_city;
        }
        else if($scope.userObj.f_province == undefined && $scope.userObj.f_city != undefined)
        {
            $scope.ptpeopleObj.dq = $scope.userObj.f_city;
        }
        else
        {
            $scope.ptpeopleObj.dq = $scope.userObj.f_province;
        }
        $scope.oldInfo = {};
        $scope.oldInfo.headurl = $scope.ptpeopleObj.headurl;
        $scope.oldInfo.name = $scope.ptpeopleObj.name;
        $scope.oldInfo.wxh = $scope.ptpeopleObj.wxh;
        $scope.oldInfo.qq = $scope.ptpeopleObj.qq;

        //alert($scope.ptpeopleObj.wxh + $scope.ptpeopleObj.qq);

    }

    //获取理财师资料
    $scope.getlcsInfo = function()
    {
        //alert("getlcsInfo");
        $scope.lcsObj.headurl = decodeURIComponent(localStorage.getItem('iconurl'));
        document.getElementById("lcsheadImg").src = $scope.lcsObj.headurl;
        $scope.lcsObj.name = decodeURIComponent(localStorage.getItem('nickname'));
        if($scope.userObj.f_weixinhao != undefined)
        {
            $scope.lcsObj.wxh = $scope.userObj.f_weixinhao;
        }
        if($scope.userObj.f_qq != undefined)
        {
            $scope.lcsObj.qq = $scope.userObj.f_qq;
        }
        if($scope.userObj.f_province == undefined && $scope.userObj.f_city == undefined)
        {
            $scope.lcsObj.dq = "";
        }
        else if($scope.userObj.f_province != undefined && $scope.userObj.f_city != undefined)
        {
            $scope.lcsObj.dq = $scope.userObj.f_province + $scope.userObj.f_city;
        }
        else if($scope.userObj.f_province == undefined && $scope.userObj.f_city != undefined)
        {
            $scope.lcsObj.dq = $scope.userObj.f_city;
        }
        else
        {
            $scope.lcsObj.dq = $scope.userObj.f_province;
        }
        $scope.oldInfo = {};
        $scope.oldInfo.headurl = $scope.lcsObj.headurl;
        $scope.oldInfo.name = $scope.lcsObj.name;
        $scope.oldInfo.wxh = $scope.lcsObj.wxh;
        $scope.oldInfo.qq = $scope.lcsObj.qq;

        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, $scope.p_getlcsapplyinfoCallBack);
    }

    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        //console.log("理财师", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.lcsapplyinfo.isexist.toString() == "true")
            {
                if(_data.lcsapplyinfo.tzsc != undefined)
                {
                    $scope.lcsObj.lcstzsc = _data.lcsapplyinfo.tzsc;//投资时长
                }
                if(_data.lcsapplyinfo.tzln != undefined)
                {
                    $scope.lcsObj.lcstzln = _data.lcsapplyinfo.tzln;//投资理念
                }
                if(_data.lcsapplyinfo.lszj != undefined)
                {
                    $scope.lcsObj.lcsscly = _data.lcsapplyinfo.lszj;//历史战绩
                }
                if(_data.lcsapplyinfo.lszj != undefined)
                {
                    $scope.lcsObj.mobilephone = _data.lcsapplyinfo.mobilephone;//投资理念
                }

                $scope.oldInfo.lcstzsc = $scope.lcsObj.lcstzsc;
                $scope.oldInfo.lcstzln = $scope.lcsObj.lcstzln;
                $scope.oldInfo.lcsscly = $scope.lcsObj.lcsscly;
                $scope.oldInfo.mobilephone = $scope.lcsObj.mobilephone;
            }
        }
    }

    //提交
    $scope.tjClick = function()
    {
        //普通用户
        if($scope.lcsstatus!='2')
        {
            //无更改
            if($scope.checkptyhzlxg() == false)
            {
                myAlert("无资料修改！");
                return;
            }
            else
            {
                $scope.updateptyh();
            }
        }
        else
        {
            if($scope.checklcszlxg() == false)
            {
                myAlert("无资料修改！");
                return;
            }
            else
            {
                $scope.updatelcs();
            }
        }
    }

    //普通用户信息提交
    $scope.updateptyh = function()
    {
        if(numericCheck($scope.ptpeopleObj.qq) == false)
        {
            myAlert("QQ号只能是数字");
            return;
        }
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        message['user.head'] = $scope.ptpeopleObj.headurl;
        message['user.weixinhao'] = $scope.ptpeopleObj.wxh;
        message['user.qq'] = $scope.ptpeopleObj.qq;
        message['user.nickname'] = $scope.ptpeopleObj.name;

        ajaxService.sendMessage("user.updateuser", message, $scope.updateuserCallBack) ;
    }

    $scope.updateuserCallBack = function(_data)
    {
        //console.log("修改资料", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getptyhNewInfo();
            $scope.zlxgback();//返回
            //console.log("更新成功");
        }
        else
        {
            myAlert("资料修改失败，请重试！")
        }
    }

    $scope.updatelcs = function()
    {
        //console.log("理财师信息修改");
        if(numericCheck($scope.lcsObj.qq) == false)
        {
            myAlert("QQ号只能是数字");
            return;
        }
        if(numericCheck($scope.lcsObj.mobilephone) == false)
        {
            myAlert("手机号只能是数字");
            return;
        }
        if($scope.lcsObj.mobilephone.length  != 11)
        {
            myAlert("请输入正确的手机号");
            return;
        }
        if($scope.lcsObj.lcstzsc == "")
        {
            myAlert("请输入投资时长");
            return;
        }
        if(numericCheck($scope.lcsObj.lcstzsc) == false)
        {
            myAlert("投资时长只能是数字");
            return;
        }
        if($scope.lcsObj.lcstzln == "")
        {
            myAlert("请输入投资理念");
            return;
        }
        if($scope.lcsObj.lcsscly == "")
        {
            myAlert("请输入历史战绩");
            return;
        }
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['head'] = $scope.lcsObj.headurl;
        message['nickname'] = $scope.lcsObj.name;
        message['weixinhao'] = $scope.lcsObj.wxh;
        message['qq'] = $scope.lcsObj.qq;
        message['mobilephone'] = $scope.lcsObj.mobilephone;
        message['tzln'] = $scope.lcsObj.lcstzln;
        message['tzsc'] = $scope.lcsObj.lcstzsc;
        message['lszj'] = $scope.lcsObj.lcsscly;
        //console.log("理财师", message);

        ajaxService.sendMessage("sunflower.p_updatelcs", message, $scope.updatelcsCallBack) ;
    }

    $scope.updatelcsCallBack = function(_data)
    {
        //console.log("理财师修改资料", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getptyhNewInfo();
            $scope.zlxgback();//返回
            //console.log("更新成功");
        }
        else
        {
            myAlert("资料修改失败，请重试！")
        }
    }

    $scope.updateptyhheadurl = function ()
    {
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        message['user.head'] = $scope.imgurl;

        ajaxService.sendMessage("user.updateuser", message, $scope.updateptyhheadurlCallBack) ;
    }

    $scope.updateptyhheadurlCallBack = function(_data)
    {
        //console.log("修改资料", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getptyhNewInfo();
            document.getElementById("flcsheadImg").src = $scope.imgurl;
            $scope.ptpeopleObj.headurl = document.getElementById("flcsheadImg").src;
            $scope.oldInfo.headurl = document.getElementById("flcsheadImg").src;
            //console.log("更新成功");
        }
        else
        {
            myAlert("修改头像失败，请重试！");
            $scope.imgurl = "";
        }
    }

    $scope.updatelcsheadurl = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['head'] = $scope.imgurl;

        ajaxService.sendMessage("sunflower.p_updatelcs", message, $scope.updatelcsheadurlCallBack) ;
    }

    $scope.updatelcsheadurlCallBack = function(_data)
    {
        //console.log("理财师修改资料", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getptyhNewInfo();
            document.getElementById("lcsheadImg").src = $scope.imgurl;
            $scope.lcsObj.headurl = document.getElementById("lcsheadImg").src;
            $scope.oldInfo.headurl = document.getElementById("lcsheadImg").src;
        }
        else
        {
            myAlert("修改头像失败，请重试！")
        }
    }

    //投资理念
    $scope.lcstzlnClick = function()
    {
        $scope.tzlnDivShow = true;
        $scope.zlxgDivShow = false;
    }
    $scope.tzlnBackto = function()
    {
        $scope.tzlnDivShow = false;
        $scope.zlxgDivShow = true;
    }


    $scope.lcslszjClick = function()
    {
        $scope.lizjDivShow = true;
        $scope.zlxgDivShow = false;

    }

    $scope.lszjBackto = function()
    {
        $scope.lizjDivShow = false;
        $scope.zlxgDivShow = true;
    }

    //判断理财师资料是否修改
    $scope.checklcszlxg = function()
    {
        var mark = true;
        var num = 0;
        //if($scope.lcsObj.headurl == decodeURIComponent(localStorage.getItem('iconurl')))
        //{
        //    num +=1;
        //}
        if($scope.lcsObj.name == decodeURIComponent(localStorage.getItem('nickname')))
        {
            num +=1;
        }
        if( $scope.lcsObj.wxh == $scope.userObj.f_weixinhao)
        {
            num +=1;
        }
        if($scope.lcsObj.qq == $scope.userObj.f_qq)
        {
            num +=1;
        }
        if($scope.lcsObj.lcstzsc == $scope.oldInfo.lcstzsc)
        {
            num +=1;
        }
        if($scope.lcsObj.lcstzln == $scope.oldInfo.lcstzln)
        {
            num +=1;
        }
        if($scope.lcsObj.lcsscly == $scope.oldInfo.lcsscly)
        {
            num +=1;
        }
        if($scope.lcsObj.mobilephone == $scope.oldInfo.mobilephone)
        {
            num +=1;
        }
        //console.log(num);
        if(num == 7)
        {
            mark = false;
        }
        return mark;
    }

    //判断普通用户资料是否修改
    $scope.checkptyhzlxg = function()
    {
        var mark = true;
        var num = 0;
        //if($scope.ptpeopleObj.headurl == $scope.oldInfo.headurl)
        //{
        //    num +=1;
        //}
        if($scope.ptpeopleObj.name == $scope.oldInfo.name)
        {
            num +=1;
        }
        if( $scope.ptpeopleObj.wxh == $scope.oldInfo.wxh)
        {
            num +=1;
        }
        if($scope.ptpeopleObj.qq == $scope.oldInfo.qq)
        {
            num +=1;
        }
        if(num == 3)
        {
            mark = false;
        }
        return mark;
    }

    //退出
    $scope.loginOut = function()
    {
        $scope.baseLoginOut();
    }

}