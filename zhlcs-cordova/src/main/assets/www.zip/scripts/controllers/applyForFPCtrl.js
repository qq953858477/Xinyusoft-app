/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */

var urlHeader = "http://121.40.148.145:8080";

function applyForFPCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.firstshow = true;//第一步
    $scope.secondshow = false;//第二步
    $scope.thirdshow = false;
    $scope.sfzzmurl = "";//身份证正面
    $scope.sfzfmurl = "";//身份证背面

    $scope.fileValue = "";//上传图片的值

    //$scope.userObj = $cookieStore.get('user');
    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    //返回组合列表
    $scope.addNewBack = function()
    {
        window.location.href = "uufpBase.html";
    }

    $scope.confirm = function()
    {
        var message = {};
        message['lcsapply.userid'] = $scope.userObj.f_id;
        message['lcsapply.applytime'] = "";
        message['lcsapply.sfzzm'] = $scope.sfzzmurl;
        message['lcsapply.sfzfm'] = $scope.sfzfmurl;
        message['lcsapply.zslx'] = "";
        message['lcsapply.cyzurl '] = "";
        message['lcsapply.company'] = "";
        message['lcsapply.specialindustry'] = "";
        message['lcsapply.auditresult'] = "";
        message['lcsapply.auditreson'] = "";
        message['lcsapply.audittime'] = "";
        //console.log($scope.userObj.f_id);
        ajaxService.sendMessage('user.addlcsapply', message, $scope.addlcsapplyCallBack);
    }

    $scope.addlcsapplyCallBack = function(_data)
    {
        console.log(_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.addNewBack();
            alert("申请提交成功！");
        }
    }


    //上传图片
    //$scope.uploadFile = function()
    //{
    //    console.log(232132);
    //    console.log($scope.fileValue)
    //}

    //进入第二步
    $scope.gotosecond = function()
    {
        $scope.firstshow = false;
        $scope.secondshow = true;
        $scope.thirdshow = false;
    }

    //返回第一步
    $scope.backtofirst = function()
    {
        $scope.firstshow = true;
        $scope.secondshow = false;
        $scope.thirdshow = false;
    }

    //进入第三步
    $scope.gotothird = function()
    {
        var str1 = document.getElementById('uploadResponse').innerHTML;
        var str2 = document.getElementById('uploadResponse2').innerHTML;
        if(str1.indexOf("<img", 0) == -1)
        {
            alert("请上传您的身份证正面和背面！");
            return;
        }
        if(str2.indexOf("<img", 0) == -1)
        {
            alert("请上传您的身份证正面和背面！");
            return;
        }
        var index1 = str1.indexOf("src=",0);
        index1 = index1+5;
        var index11 = str1.indexOf('"',index1);
        var index2 = str2.indexOf("src=",0);
        index2 = index2+5;
        var index22 = str2.indexOf('"',index2);
        $scope.sfzzmurl = str1.substring(index1,index11);
        $scope.sfzfmurl = str2.substring(index2,index22);
        //console.log(document.getElementById('uploadResponse').innerHTML);
        //console.log(document.getElementById('uploadResponse2').innerHTML);
        //console.log($scope.sfzzmurl);
        //console.log($scope.sfzfmurl);
        if($scope.sfzzmurl == "" || $scope.sfzfmurl == "")
        {
            alert("请上传您的身份证正面和背面！");
        }
        else
        {
            $scope.firstshow = false;
            $scope.secondshow = false;
            $scope.thirdshow = true;
        }
    }

    //返回第二步
    $scope.backtosecond = function()
    {
        $scope.firstshow = false;
        $scope.secondshow = true;
        $scope.thirdshow = false;
    }
}