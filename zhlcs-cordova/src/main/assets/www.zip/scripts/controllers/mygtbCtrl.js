/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function mygtbCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.username = "";
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.backtitle = "";
    $scope.gtbky = "--";//余额
    $scope.ktxzk = "--";//可体现资金
    $scope.djzj = "--";//冻结资金

    $scope.gtLcsCPlist = [];//好友发布中的
    $scope.gethyspz = [];//好友实盘中的

    //$scope.ykhbdMark = true;//银行卡是否绑定 false：未绑定，true：绑定
    $scope.mybank = "";//银行名称
    $scope.mycardno = "";//银行卡尾号
    $scope.dzfjsdArray = [];//待支付结算单

    var ind = getParameter("index");
    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));


    $scope.gtbjeCallBack = function(_data)
    {
        //console.log("跟投宝", _data)
        if(_data.op.code.toString() == "Y")
        {
            $scope.gtbky = _data.moneyinfo.zzj;
            $scope.ktxzk = _data.moneyinfo.ktxzj;
            $scope.djzj = _data.moneyinfo.djzj;
        }
    }

    $scope.gtbje = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getgentoubaomoney", message, $scope.gtbjeCallBack);
    }

    $scope.getbdyhkCallBack = function(_data)
    {
        //console.log("银行卡", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.isexist == "true")//已经有
            {
                $scope.ykhbdMark = true;

                $scope.mybank = _data.bank;
                var str = _data.cardno;
                if(str.length > 4)
                {
                    $scope.mycardno = str.substring(_data.cardno.length-4,_data.cardno.length);
                }
            }
            else
            {
                $scope.ykhbdMark = false;
            }
        }
    }

    $scope.getbdyhk = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.getbankcardbyuseridaction", message, $scope.getbdyhkCallBack);
    }

    $scope.dzfjsdCallBack = function(_data)
    {
        //console.log("待支付结算单", _data);
        $scope.dzfjsdArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.linksettlelist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.ljsy = arr[i].profit;
                obj.paymoney = arr[i].paymoney;
                obj.settleid = arr[i].id;
                obj.productname = arr[i].productname;
                obj.gentouproductid = arr[i].gentouproductid;
                obj.accountlinkid = arr[i].accountlinkid;
                var str = arr[i].day;
                obj.date = str.substring(0,4)+"年"+str.substring(4,6)+"月"+str.substring(6,8);
                var statusstr = arr[i].paystatus;
                obj.status = statusstr;
                if(statusstr =="Y")
                {
                    obj.statusstr ="已支付";
                }
                else if (statusstr =="N")
                {
                    obj.statusstr ="未支付";
                }
                else if (statusstr =="I")
                {
                    obj.statusstr ="部分支付";
                }
                else if (statusstr =="O")
                {
                    obj.statusstr ="延期(未支付)";
                }
                obj.lastpayday = arr[i].lastpayday;
                if(statusstr =="N")
                {
                    $scope.dzfjsdArray.push(obj);
                }
            }
        }
    }

    //待支付结算单
    $scope.dzfjsd = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['page.size'] = "max";
        message['paystatus'] = 'N';
        ajaxService.sendMessage("gentou.p_selectlinksettlebylinkuserid", message, $scope.dzfjsdCallBack);
    }

    $scope.gtbtinit = function()
    {
        $scope.gtbje();
        $scope.getbdyhk();
        //$scope.dzfjsd();
    }

    $scope.gtbtinit();

    //充值
    $scope.czClick = function()
    {
        //window.location.href = "gtb/gtb-czindex.html";
        //xinyuNewBrowser("gtb/gtb-czindex.html" + "?opentype=newwebview", "updatethis");

        setbackList(window.location.href);
        window.location.href = "gtb/gtb-chongzhi.html?backurl=getbackList";
    }

    //充值记录
    $scope.czjlClick = function()
    {
        window.location.href = "gtb/gtd-czjl.html";
    }

    //取现
    $scope.txClick = function()
    {
        //window.location.href = "gtb/gtb-index.html";
        //xinyuNewBrowser("gtb/gtb-index.html" + "?opentype=newwebview", "updatethis");

        if($scope.ykhbdMark == false)
        {
            myAlert("请先绑定银行卡！")
        }
        else
        {
            setbackList(window.location.href);
            window.location.href = "gtb/gtb-tixian.html";
        }
    }

    //updatethis = function()
    //{
    //    $scope.gtbje();
    //}

    //取现记录
    $scope.qxjlClick = function()
    {
        window.location.href = "gtb/gtd-myjl.html";
    }

    //绑定银行卡
    $scope.bdyhkClick = function()
    {
        window.location.href = "gtb/gtb-add-yinhangka.html";
    }

    $scope.ljzfClick = function(_obj)
    {
        setbackList(window.location.href);
        window.location.href="gtb/jiesuandan-pay.html?settleno=" + _obj.settleid + "&paymoney=" + Number(_obj.paymoney).toFixed(2) + "&productid=" + _obj.gentouproductid  + "&linkid=" + _obj.accountlinkid +  "&backurl=getbackList";
    }

    //返回
    $scope.qzgtbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }
}




