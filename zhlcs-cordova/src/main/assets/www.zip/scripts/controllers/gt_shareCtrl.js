
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_shareCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.mainShow = false;//主界面
    $scope.productname = "";//产品名
    $scope.productid = "";//产品id
    $scope.account = "";//账户
    $scope.canadddel = false;

    $scope.tabOneShow = false;//收益
    $scope.tabTwoShow = false;//持仓
    $scope.tabThreeShow = false;//交易记录
    $scope.tabFourShow = false;//理财师
    $scope.tabFiveShow = false;//历史可看交易记录时
    $scope.shareindex = "1";//默认显示报名
    $scope.shareproduct = "true";//分享
    $scope.jrsyShow = '0';//显示今日收益   0：都不显示，1：今日收益；2：累计收益

    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "--";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.beginzc = "--";//初始资金
    $scope.dqgtInfo.rundays = "--";//实盘天数



    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，服务结束时间
    $scope.jssjstrsy = "";//8位，日收益分析之类的用

    $scope.gtztString = "";//产品状态
    $scope.cpzt = "C";

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通
    $scope.fcfsArray = [];//分成方式

    //服务设置
    $scope.assetopenflagall = "N"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "N";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "N"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "N";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "N";//对大众，交易指令公开

    $scope.isyk = true;//是否是游客


    $scope.islcs = false;//是否是理财师
    $scope.lcsInformation = {};
    $scope.lcsInformation.lcshearurl = "";
    $scope.lcsInformation.lcsname = "--";
    $scope.lcsInformation.lcsid = "";
    $scope.lcsInformation.lcstzsc = "--";
    $scope.lcsInformation.lcstzln = "--";
    $scope.lcsInformation.lcsscly = "--";
    $scope.lcsstatus = "0";//0：未申请，且不是理财师或者申请不通过；1：申请中；2：申请通过，已是理财师
    $scope.bgtz = {};
    $scope.bgtz.hearurl = "";
    $scope.bgtz.name = "--";
    $scope.lcslsbgtAccount = "--";
    $scope.lcsdjArray = [];//理财师等级图片数组
    $scope.lcspj = "0";//理财师评级
    $scope.bgtAccount = "--";//理财包个数

    $scope.htmlType = "share";


    //$scope.ztcaption = "";
    $scope.productid = getParameter("productid");
    //$scope.account = getParameter("account");
    //$scope.bgtuserid = getParameter("bgtuserid");
    $scope.backtitle = "";//返回的title
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.shareindex = index2;
    }

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        //$scope.ztcaption = _data.caption;
        //var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        //$scope.$broadcast("setParameters", cstr);
    });

    //理财师评级
    $scope.setlcspj = function()
    {
        $scope.lcsdjArray = [];
        if($scope.lcspj != null && $scope.lcspj != undefined && $scope.lcspj != "" && $scope.lcspj !="0" && $scope.lcspj !="0.0")
        {
            var pointindex = $scope.lcspj.indexOf(".",0);
            if(pointindex == -1 || (pointindex != -1 && $scope.lcspj.substr(pointindex+1,1)=="0"))//无小数点，整数，有小数点，小数点后为0
            {
                var num = parseFloat($scope.lcspj);
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                for(var i = num+1;i<6;i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star2.png";
                    $scope.lcsdjArray.push(obj);
                }
            }
            else//有小数点
            {
                var num = Math.floor(parseFloat($scope.lcspj));
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num<5)
                {
                    var obj = {};
                    obj.value = $scope.lcsdjArray.length+1;
                    obj.djsrc = "images/star3.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num+1<5)
                {
                    for(var i = num+2;i<6;i++)
                    {
                        var obj = {};
                        obj.value = i;
                        obj.djsrc = "images/star2.png";
                        $scope.lcsdjArray.push(obj);
                    }
                }
            }
            //for(var i = 0;i<parseFloat($scope.lcspj);i++)
            //{
            //    var obj = {};
            //    obj.value = i;
            //    $scope.lcsdjArray.push(obj);
            //}
        }
        else
        {
            for(var i = 1;i<6;i++)
            {
                var obj = {};
                obj.value = i;
                obj.djsrc = "images/star2.png";
                $scope.lcsdjArray.push(obj);
            }
        }
    }

    $scope.getLastest3ProductAvgScoreActionCallBack = function(_data)
    {
        console.log("理财师评级",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.lcspj = _data.avg.toString();
            $scope.setlcspj();
        }
    }

    $scope.getlcspj = function()
    {
        //$scope.lcspj = _data.lcsapplyinfo.level;
        //
        //$scope.setlcspj();

        var message = {};
        message['userid'] = $scope.bgtuserid;//理财师id
        console.log("用户id", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.getLastest3ProductAvgScoreAction", message, $scope.getLastest3ProductAvgScoreActionCallBack);
    }


    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        console.log("理财师",_data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.lcsapplyinfo.isexist.toString() == "true")
            {
                if (_data.lcsapplyinfo.status.toString() == "Y") {
                    $scope.islcs = true;
                    $scope.lcsInformation = {};
                    $scope.lcsInformation.lcshearurl = _data.lcsapplyinfo.user.user.f_head;
                    $scope.lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname;
                    $scope.lcsInformation.lcsid = _data.lcsapplyinfo.userid;
                    $scope.lcsInformation.lcstzsc = _data.lcsapplyinfo.tzsc;
                    $scope.lcsInformation.lcstzln = _data.lcsapplyinfo.tzln;
                    $scope.lcsInformation.lcslszj = _data.lcsapplyinfo.lszj;
                    //$scope.lcsInformation.lcsscly = _data.lcsapplyinfo.scly;

                    var sclystr = _data.lcsapplyinfo.scly;
                    console.log("sclystr",sclystr);
                    var ind = sclystr.indexOf("|",0);
                    if(ind == -1)//无|
                    {
                        $scope.lcsInformation.lcsscly = sclystr;
                    }
                    else//有|
                    {
                        var sclyarr = sclystr.split("|");
                        var str2 = "";
                        for(var i = 0;i<sclyarr.length;i++)
                        {
                            if(str2 == "")
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = sclyarr[i];
                                }

                            }
                            else
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = str2 + "," + sclyarr[i];
                                }
                            }
                        }
                        $scope.lcsInformation.lcsscly = str2;
                    }

                    if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city == undefined)
                    {
                        $scope.lcsInformation.dq = "";
                    }
                    else if(_data.lcsapplyinfo.user.user.f_province != undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                    {
                        $scope.lcsInformation.dq = _data.lcsapplyinfo.user.user.f_province + _data.lcsapplyinfo.user.user.f_city;
                    }
                    else if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                    {
                        $scope.lcsInformation.dq = _data.lcsapplyinfo.user.user.f_city;
                    }
                    else
                    {
                        $scope.lcsInformation.dq = $scope.peopleInfo.f_province;
                    }

                    $scope.getlcspj();
                }
                else
                {
                    $scope.islcs = false;
                }

                //if (_data.lcsapplyinfo.status.toString() == "Y")
                //{
                //    $scope.lcspj = _data.lcsapplyinfo.level;
                //
                //    $scope.setlcspj();
                //}
            }
            else
            {
                $scope.islcs = false;
            }
        }
    }

    $scope.getlcs = function()
    {
        var message = {};
        message['userid'] = $scope.bgtuserid;
        console.log("理财师idididi",$scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, $scope.p_getlcsapplyinfoCallBack);
    }

    $scope.getuserCallBack = function(_data)
    {
        console.log("用户", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.bgtz = {};
            $scope.bgtz.hearurl = _data.user.f_head;
            $scope.bgtz.name = _data.user.f_nickname;

            if(_data.user.f_province == undefined && _data.user.f_city == undefined)
            {
                $scope.bgtz.dq = "";
            }
            else if(_data.user.f_province != undefined && _data.user.f_city != undefined)
            {
                $scope.bgtz.dq = _data.user.f_province + _data.user.f_city;
            }
            else if(_data.user.f_province == undefined && _data.user.f_city != undefined)
            {
                $scope.bgtz.dq = _data.user.f_city;
            }
            else
            {
                $scope.bgtz.dq = _data.user.f_province;
            }
            console.log("drdag", $scope.bgtz.dq);
        }
    }

    //普通用户
    $scope.getptyh = function()
    {
        var message = {};
        message['user.id'] = $scope.bgtuserid;//理财师id
        console.log("用户id", $scope.bgtuserid);
        ajaxService.sendMessage("user.getuser", message, $scope.getuserCallBack);
    }

    //判断当前被跟投对象是否是理财师
    $scope.checklcs = function()
    {
        var message = {};
        message["userid"] = $scope.bgtuserid;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo",message,function(_data)
        {
            console.log("checklcs理财师：" + _data);
            if (_data.op.code.toString() == "Y")
            {
                if(_data.lcsapplyinfo.isexist.toString() == "false")
                {
                    $scope.lcsstatus = "0";//0：未申请
                }
                else
                {
                    if(_data.lcsapplyinfo.status.toString() == "A")
                    {
                        $scope.lcsstatus = "1";//1：申请中
                    }
                    else if(_data.lcsapplyinfo.status.toString() == "Y")
                    {
                        $scope.lcsstatus = "2";//1：申请通过，已是理财师
                    }
                    else//N，申请未通过
                    {
                        $scope.lcsstatus = "0";//0：未申请
                    }
                }
                if($scope.lcsstatus == "2")
                {
                    $scope.getlcs();
                }
                else
                {
                    $scope.islcs = false;
                    $scope.getptyh();
                }
            }
        })
    }

    //理财师跟投包
    $scope.p_getgentoustatisticsCallBack = function(_data)
    {
        //console.log("累计数据：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.bgtAccount = _data.gentoustatistic.bgtcount + "单";//理财包个数
        }
    }

    $scope.getgtbInfo = function()
    {
        //console.log("累计");
        var message = {};
        message['userid'] = $scope.bgtuserid;
        ajaxService.sendMessage("gentou.p_getgentoustatistics", message, $scope.p_getgentoustatisticsCallBack);

    }


    $scope.getallInfo = function()
    {
        $scope.checklcs();
        //理财包个数
        $scope.getgtbInfo();
    }

    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        //console.log("产品3",_data.op.code.toString());
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.account = product.account;//产品账户
            $scope.bgtuserid = product.userid;//理财师id

            $scope.getallInfo();

            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            $scope.dqgtInfo.zq = product.gentouperiod;
            $scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.dqgtInfo.zxgtje = product.minmoney;
            $scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            $scope.dqgtInfo.beginzc = product.beginzc;//初始资金
            //$scope.dqgtInfo.rundays = product.rundays;//实盘天数
            var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
            $scope.dqgtInfo.bmjzsj = str;//报名截止日期
            var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//服务结束时间
            $scope.dqgtInfo.fwjssj = str2;//服务结束时间
            //$scope.jssjstr = $scope.dqgtInfo.fwjssj.toString().substr(0,8);
            //console.log("$scope.jssjstr", $scope.jssjstr);
            var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3.substr(0,4) + "-" + str3.substr(4,2) + "-" + str3.substr(6,2);//服务开始时间
            $scope.dqgtInfo.fwkssj = str3;//服务开始时间
            var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4.substr(0,10);//服务发布时间
            $scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            $scope.cpzt = product.status.toString();
            console.log("状态", $scope.cpzt);
            if($scope.cpzt == "A")
            {
                $scope.gtztString = "报名中";
                $scope.jssjstr = getyesterdayno();
                $scope.jssjstrsy = "";
                $scope.jrsyShow = "1";
            }
            else if($scope.cpzt == "G")
            {
                $scope.gtztString = "延期中";
                $scope.jssjstr = getyesterdayno();
                $scope.jssjstrsy = "";
                $scope.jrsyShow = "1";
            }
            else if($scope.cpzt == "B")
            {
                $scope.gtztString = "实盘中";
                $scope.jssjstr = getyesterdayno();
                $scope.jssjstrsy = "";
                $scope.jrsyShow = "1";
            }
            else if($scope.cpzt == "D")
            {
                $scope.gtztString = "解除中";
                $scope.jssjstr = getyesterdayno();
                $scope.jssjstrsy = "";
                $scope.jrsyShow = "1";
            }
            else
            {
                //console.log("结束日期");
                $scope.gtztString = "已结束";
                var str2 = product.endgentoutime.toString();
                str2 = str2.substr(0,4) + str2.substr(5,2) + str2.substr(8,2) + str2.substr(11,2) + str2.substr(14,2) + str2.substr(17,2);
                $scope.dqgtInfo.fwjssj = str2;
                $scope.jssjstr = $scope.dqgtInfo.fwjssj.toString().substr(0,8);
                $scope.jssjstrsy = $scope.jssjstr;
                $scope.jrsyShow = "2";
                //console.log("结束日期",$scope.jssjstr);
            }

            $scope.kssjstr = $scope.dqgtInfo.fwkssj.toString().substr(0,8);

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }

            var sharearr = product.share;
            //console.log("分成比例" +product.share);
            for(var i = 0;i<sharearr.length;i++)
            {
                var obj = {};
                obj.downprofit = sharearr[i].downprofit;//目标收益
                obj.share = sharearr[i].share;
                var fc = parseInt(obj.share)/10;
                obj.label = fc +":" +(10-fc) ;
                //obj.desc = "目标收益" +  sharearr[i].downprofit + "%后，跟投收益部分按照" + obj.label + "分成";\
                if(fc == 2)
                {
                    obj.desc = "跟投用户实际收益超出平台基准收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；没有超出平台基准收益，理财师不分成";
                }
                else
                {
                    obj.desc = "跟投用户实际收益超出理财包目标收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；若未达到目标收益，按二八分成方式结算";
                }
                obj.status = true;
                $scope.fcfsArray.push(obj);
            }

            $scope.changeTab($scope.shareindex);

        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1" || _str == "5")
        {
            $scope.mainShow = true;
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
            $scope.$broadcast("setParameters", cstr);
            window.location.href = "#index=1";

        }
        else if(_str == "2")
        {
            $scope.mainShow = true;
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsycc"};
            $scope.$broadcast("setParameters", cstr);
            window.location.href = "#index=2";

        }
        else if(_str == "3")
        {
            $scope.mainShow = true;
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;
            window.location.href = "#index=3";
        }
        else if(_str == "4")
        {
            $scope.mainShow = true;
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;
            $scope.tabFiveShow = false;
            window.location.href = "#index=4";
        }
        else if(_str == "6")
        {
            $scope.mainShow = true;
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = true;
            window.location.href = "#index=6";

            var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
            $scope.$broadcast("setParameters", cstr);
        }


    }

    //$scope.p_getgentouproductCallBack = function(_data)
    //{
    //    console.log("产品关系", _data);
    //}

    //$scope.getInfo = function()
    //{
    //    var message = {};
    //
    //    message['productid'] = $scope.productid;
    //    message['userid'] = $scope.userObj.f_id;
    //    console.log("产品关系",$scope.productid);
    //    ajaxService.sendMessage("gentou.getUserProductRelationAction", message, $scope.p_getgentouproductCallBack);
    //}

    $scope.getcpszCallBack = function(_data)
    {
        console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflagall = _data.assetopenflagall.toString();
            $scope.clearpositionopenflagall = _data.clearpositionopenflagall.toString();
            $scope.positionamountopenflagall = _data.positionamountopenflagall.toString();
            $scope.positionvarietyopenflagall = _data.positionvarietyopenflagall.toString();
            $scope.tradecommandopenflagall = _data.tradecommandopenflagall.toString();
        }
        $scope.getdqgtInfo();
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
        console.log("333");
        try
        {
            if (window.location.hash == "#index=1")
            {
                $scope.shareindex = '1';
            }
            else if (window.location.hash == "#index=2") {
                $scope.shareindex = '2';
            }
            else if (window.location.hash == "#index=3") {
                $scope.shareindex = '3';
            }
            else if (window.location.hash == "#index=4") {
                $scope.shareindex = '4';
            }
            else if (window.location.hash == "#index=5") {
                $scope.shareindex = '5';
            }
            $scope.getcpsz();
        }catch (e){}
    }

    $scope.fbzInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        //xinyuNewBrowser("gt_fcfs.html?opentype=newwebview");
        setbackList(window.location.href);
        window.location.href ="gt_fcfs.html";
    }

    //历史交易记录
    $scope.gotolsjy = function()
    {
        $scope.mainShow = false;
        $scope.lsjyjlDivShow = true;

        var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
        $scope.$broadcast("setParameters", cstr);
    }

    $scope.lsjyjlBackto = function()
    {
        $scope.mainShow = true;
        $scope.lsjyjlDivShow = false;
    }

    $scope.sharebackto = function()
    {
        window.location.href = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
    }
}



