﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function peopleSpaceBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.peopleName = "";//用户名
    $scope.peoplehead = "";//用户头像
    $scope.peopleInfo = null;
    $scope.peopleID = "";//用户id
    $scope.userObj = {};
    $scope.zjmxsShow = true;
    $scope.mainShow = true;//主界面
    //$scope.chartShow = false;//聊天界面
    $scope.peoplezxgListShow = false;//自选股
    $scope.isxrklcs = false;//是否是理财师，是则有解盘
    $scope.zxggksetStatus = false ;//自选股是否公开
    $scope.gtfwisShow = false;//跟投服务是否显示
    $scope.kgtzhList = [];//可跟投的账户
    $scope.gkmxList = [];//公开的模型
    $scope.opentype = "";//打开方式
    $scope.page = "";//是否从好友页面进入
    $scope.isFriend = false;
    $scope.friendicon = false;
    $scope.ppBtnShow = true;//下方btn是否显示
    $scope.peopelezxgAccount = "--";//自选股个数
    $scope.lcsjyInfoArray = [];//理财师服务交易信息

    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    $scope.peopleallInfo = {};
    $scope.peopleallInfo.dq = "";//地区
    $scope.peopleallInfo.lcslszj = "";
    $scope.peopleallInfo.lcstzsc = "";
    $scope.peopleallInfo.lcstzln = "";
    $scope.peopleallInfo.lcsscly = "";
    $scope.peopleallInfo.zfzlurl = "";//理财师专访资料地址

    $scope.tabOneShow = false;
    $scope.tabTwoShow = false;
    $scope.tabThreeShow = false;
    $scope.tabFourShow = false;
    $scope.tabFiveShow = false;
	
	$scope.newmsgcount = "";
    $scope.historylcfwAccount = "--";//历史被跟投次数

    $scope.index = "5";

    $scope.newViewPoint;//最新观点

    //$scope.peopleID = $cookieStore.get('peopleID');
    var localStorage = window.localStorage;
    $scope.peopleID = localStorage.getItem('peopleID');
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    $scope.page = getParameter("page");
    //alert($scope.page);

    //console.log($scope.peopleID);
    if(getParameter("index") != null && getParameter("index") != undefined && getParameter("index")!="")
    {
        $scope.index = getParameter("index");
    }
    else
    {
        $scope.index = "5";
    }

    //设置跟投列表是否显示
    $scope.setgtfwisShow = function(_value)
    {
        $scope.gtfwisShow = _value;
        //console.log("跟投列表",$scope.gtfwisShow);
    }

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
    });

    $scope.getnewViewPointCallBack = function(_data)
    {
        //console.log("最新观点：" + _data);
        var arr = _data.list;
        //console.log("arr：" + arr.length);
        if(arr.length>0)
        {
            $scope.newViewPoint = {};
            $scope.newViewPoint.content = arr[0].f_cnt;
            $scope.newViewPoint.time = arr[0].f_createtime;
            //console.log(newViewPoint.content);
        }
    }

    $scope.getnewViewPoint = function()
    {
        var message = {};
        message["userid"] = $scope.peopleID;
        message["page.pagesize"] = "1";
        message["page.pageno"] = "1";
        ajaxService.sendMessage("user.getviewpointaction", message, $scope.getnewViewPointCallBack);
    }

    //获取理财师信息
    $scope.getlcsinfo = function()
    {
        //$scope.getnewViewPoint();
    }

    $scope.getPeopleInfoCallBack = function(_data)
    {
        //console.log("个人信息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.peopleInfo = _data.user;

            $scope.peopleName = $scope.peopleInfo.f_nickname;
            $scope.peoplehead = $scope.peopleInfo.f_head;
            $scope.peopleallInfo.dq = $scope.peopleInfo.f_head;

            if($scope.peopleInfo.f_province == undefined && $scope.peopleInfo.f_city == undefined)
            {
                $scope.peopleallInfo.dq = "";
            }
            else if($scope.peopleInfo.f_province != undefined && $scope.peopleInfo.f_city != undefined)
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_province + $scope.peopleInfo.f_city;
            }
            else if($scope.peopleInfo.f_province == undefined && $scope.peopleInfo.f_city != undefined)
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_city;
            }
            else
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_province;
            }

            //$scope.repeatingFunction();
            //if($scope.peopleInfo.f_role.toString() == "V")
            //{
            //    $scope.isxrklcs = true;
            //}
            //else
            //{
            //    $scope.isxrklcs = false;
            //}
            //
        }
        //$scope.changeTab($scope.index);
    }

    $scope.getlcsjyInfoCallBack = function(_data)
    {
        $scope.lcsjyInfoArray = [];
        //console.log("交易信息", _data);
        if(_data.op.code.toString() == "Y") {
            var arr = _data.gentouproductlist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                //obj.status = "cp2";
                obj.account = arr[i].account;//当前被跟投的账户
                var bgtuser = arr[i].user.user;
                obj.headurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.fbzuserid = bgtuser.f_id;
                obj.productname = arr[i].name;
                if (obj.productname.length > 5) {
                    obj.productnamestr = obj.productname.substr(0, 5);
                }
                else {
                    obj.productnamestr = obj.productname;
                }
                obj.productid = arr[i].id;
                obj.gentoucount = arr[i].gentoucount;
                obj.drsyl = parseFloat(arr[i].jrsy);
                obj.ljsyl = parseFloat(arr[i].ljsy);
                obj.drsy = parseFloat(arr[i].dqyk);
                obj.rundays = arr[i].rundays;
                obj.cjcount = arr[i].cjcount;
                obj.cw = arr[i].cw;
                if (parseFloat(obj.cw) == 0) {
                    obj.cwvalue = "空仓";//当前仓位
                }
                else if (parseFloat(obj.cw) == 1) {
                    obj.cwvalue = "满仓";//当前仓位
                }
                else {
                    obj.cwvalue = (parseFloat(obj.cw) * 100).toFixed(0) + "%";//当前仓位
                }
                obj.buycount = arr[i].buycount;
                obj.sellcount = arr[i].sellcount;
                $scope.lcsjyInfoArray.push(obj);

            }
        }
    }

    //服务交易信息
    $scope.getlcsjyInfo = function()
    {
        //var message = {};
        //message['userid'] = $scope.peopleID;
        //ajaxService.sendMessage("gentou.getuserproductscurrenttradeaction", message, $scope.getlcsjyInfoCallBack) ;
        var message = {};
        message['userid'] = $scope.peopleID;
        message['status'] = "Y";
        //message['property'] = "public";
        message['page.size'] = "max";
        message['page.no'] = "1";
        ajaxService.sendMessage("sunflower.p_selectgentouproduct", message, $scope.getlcsjyInfoCallBack);
    }

    //历史被跟投
    $scope.linkedhisgentouCallBack = function(_data)
    {
        //console.log("历史被跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            $scope.historylcfwAccount = arr.length;
        }
    }
    $scope.getlsbgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.peopleID;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);

    }

    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        //console.log("理财师资料", _data);
        if (_data.op.code.toString() == "Y") {
            if (_data.lcsapplyinfo.isexist.toString() == "false") {
                $scope.isxrklcs = false;//未申请
            }
            else {
                if (_data.lcsapplyinfo.status.toString() == "A") {
                    $scope.isxrklcs = false;//1：申请中
                }
                else if (_data.lcsapplyinfo.status.toString() == "Y")
                {
                    $scope.isxrklcs = true;//1：申请通过，已是理财师

                    $scope.peopleallInfo.lcslszj = _data.lcsapplyinfo.lszj;
                    $scope.peopleallInfo.lcstzsc = _data.lcsapplyinfo.tzsc;
                    $scope.peopleallInfo.lcstzln = _data.lcsapplyinfo.tzln;

                    if(_data.lcsapplyinfo.interviewrecord != null && _data.lcsapplyinfo.interviewrecord != undefined && _data.lcsapplyinfo.interviewrecord != "")
                    {
                        $scope.peopleallInfo.zfzlurl =  _data.lcsapplyinfo.interviewrecord;//专访资料
                    }
                    else
                    {
                        $scope.peopleallInfo.zfzlurl = "";//"lcszfzl/interview_question1.html";
                    }
                    //console.log($scope.peopleallInfo.zfzlurl);
                    var sclystr = _data.lcsapplyinfo.scly;
                    //console.log("sclystr",sclystr);
                    var ind = sclystr.indexOf("|",0);
                    if(ind == -1)//无|
                    {
                        $scope.peopleallInfo.lcsscly = sclystr;
                    }
                    else//有|
                    {
                        var sclyarr = sclystr.split("|");
                        var str2 = "";
                        for(var i = 0;i<sclyarr.length;i++)
                        {
                            if(str2 == "")
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = sclyarr[i];
                                }

                            }
                            else
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = str2 + "," + sclyarr[i];
                                }
                            }
                        }
                        $scope.peopleallInfo.lcsscly = str2;
                    }
                }
                else//N，申请未通过
                {
                    $scope.isxrklcs = false;//0：未申请
                }
            }
        }
        if($scope.isxrklcs == true)
        {
            //$scope.getlcsinfo();//理财师信息
            $scope.getlcsjyInfo();//获取理财师服务交易相关信息
            //$scope.getlsbgtList();//历史被跟投

        }
        else
        {
            $scope.getgzall();
        }
    }

    $scope.getPeopleInfo = function()
    {
        var message = {};
        message['user.id'] = $scope.peopleID;
        //console.log($scope.peopleID);
        ajaxService.sendMessage("user.usercheck", message, $scope.getPeopleInfoCallBack) ;

        var message2 = {};
        message2["userid"] = $scope.peopleID;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message2, $scope.p_getlcsapplyinfoCallBack);

    }


    $scope.getzxgszztCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            if(_data.gkzxg.toString() == "Y")//自选股是否公开 公开：Y；不公开：N
            {
                $scope.zxggksetStatus = true;
            }
            else
            {
                $scope.zxggksetStatus = false;
            }
        }
    }

    $scope.getzxgszzt = function()
    {
        $scope.kgtzhList = [];
        var message = {};
        message['userid'] = $scope.peopleID;
        ajaxService.sendMessage("sunflower.p_getzxggkset", message, $scope.getzxgszztCallBack) ;
    }

    $scope.getgkmxCallBack = function(_data)
    {
        $scope.gkmxList = [];
        //console.log("公开的模型：" , _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.modelgksetlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.modelid = arr[i].model.id;
                obj.name = arr[i].model.name;;
                obj.ljsyl = parseFloat((parseFloat(arr[i].model.zsy)*100).toFixed(2));
                if(obj.ljsyl >0)
                {
                    obj.status = "1";//1:红，2：绿，3：白
                }
                else if(obj.ljsyl<0)
                {
                    obj.status = "2";
                }
                else
                {
                    obj.status = "3";
                }
                $scope.gkmxList.push(obj);
            }

        }
    }

    //公开的模型
    $scope.getgkmx = function()
    {
        var message = {};
        message['userid'] = $scope.peopleID;
        //console.log($scope.peopleID);
        ajaxService.sendMessage("sunflower.p_selectygkmodel", message, $scope.getgkmxCallBack) ;
    }

    $scope.changeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;

            var cstr  = {"personid": $scope.peopleID, "caption": "persongtinfo"};
            //console.log("index1", cstr);
            $scope.$broadcast("setParameters", cstr);

            window.location.href = "#index=1";
        }
        else if(_str == "2")
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;
            window.location.href = "#index=2";
        }
        else if(_str == "3")
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = false;
            window.location.href = "#index=3";
        }
        else if(_str == "4")
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;
            $scope.tabFiveShow = false;
            window.location.href = "#index=4";
        }
        else if(_str == "5")
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            $scope.tabFiveShow = true;
            window.location.href = "#index=5";
        }
    }


    $scope.getgzfwCallBack = function(_data)
    {
        //console.log("关注的服务", _data);
        $scope.gzfwArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            for(var i = 0;i<arr.length;i++)
            {
                if(arr[i].status.toString() == "A")
                {
                    var obj = {};
                    obj.status = "cp1";
                    var bgtuser = arr[i].user.user;
                    obj.headurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    if(obj.productname.length>5)
                    {
                        obj.productnamestr = obj.productname.substr(0,5);
                    }
                    else
                    {
                        obj.productnamestr = obj.productname;
                    }

                    obj.productid = arr[i].id;
                    obj.zq = arr[i].gentouperiod;//周期
                    obj.bmrs = arr[i].applycount;//报名人数
                    obj.mbsy = arr[i].targetprofit;
                    obj.beginapplytime = arr[i].beginapplytime;

                    var str = arr[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr[i].endapplytimedesc;//报名截止日期

                    $scope.gzfwArray.push(obj);
                }
                else if(arr[i].status.toString() == "G")
                {
                    var obj = {};
                    obj.status = "cp4";
                    var bgtuser = arr[i].user.user;
                    obj.headurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    if(obj.productname.length>5)
                    {
                        obj.productnamestr = obj.productname.substr(0,5);
                    }
                    else
                    {
                        obj.productnamestr = obj.productname;
                    }

                    obj.productid = arr[i].id;
                    obj.zq = arr[i].gentouperiod;//周期
                    obj.bmrs = arr[i].applycount;//报名人数
                    obj.mbsy = arr[i].targetprofit;
                    obj.beginapplytime = arr[i].beginapplytime;

                    var str = arr[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr[i].endapplytimedesc;//报名截止日期
                    $scope.gzfwArray.push(obj);
                }
                else if(arr[i].status.toString() == "B")//被跟投中
                {
                    var obj = {};
                    obj.status = "cp2";
                    obj.account = arr[i].account;//当前被跟投的账户
                    var bgtuser = arr[i].user.user;
                    obj.headurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    if(obj.productname.length>5)
                    {
                        obj.productnamestr = obj.productname.substr(0,5);
                    }
                    else
                    {
                        obj.productnamestr = obj.productname;
                    }
                    obj.productid = arr[i].id;
                    //obj.zq = arr[i].gentouperiod;//周期
                    obj.gentoucount = arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.rundays = arr[i].rundays;
                    var str = arr[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;
                    obj.cjcount = arr[i].cjcount;
                    obj.cw = arr[i].cw;
                    if(parseFloat(obj.cw) == 0)
                    {
                        obj.cwvalue = "空仓";//当前仓位
                    }
                    else if(parseFloat(obj.cw) == 1)
                    {
                        obj.cwvalue = "满仓";//当前仓位
                    }
                    else
                    {
                        obj.cwvalue = (parseFloat(obj.cw)*100).toFixed(0) + "%";//当前仓位
                    }
                    $scope.gzfwArray.push(obj);
                }
                else if(arr[i].status.toString() == "D")//解除中
                {
                    var obj = {};
                    obj.status = "cp3";
                    obj.account = arr[i].account;//当前被跟投的账户
                    var bgtuser = arr[i].user.user;
                    obj.headurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    if(obj.productname.length>5)
                    {
                        obj.productnamestr = obj.productname.substr(0,5);
                    }
                    else
                    {
                        obj.productnamestr = obj.productname;
                    }
                    obj.productid = arr[i].id;
                    obj.zq = arr[i].gentouperiod;//周期
                    obj.gentoucount = arr[i].gentoucount;
                    obj.endgentoutime = arr[i].endgentoutime + "解除";//多久前解除跟投
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.mbsy = arr[i].targetprofit;
                    obj.rundays = arr[i].rundays;
                    obj.cjcount = arr[i].cjcount;
                    obj.cw = arr[i].cw;
                    if(parseFloat(obj.cw) == 0)
                    {
                        obj.cwvalue = "空仓";//当前仓位
                    }
                    else if(parseFloat(obj.cw) == 1)
                    {
                        obj.cwvalue = "满仓";//当前仓位
                    }
                    else
                    {
                        obj.cwvalue = (parseFloat(obj.cw)*100).toFixed(0) + "%";//当前仓位
                    }
                    $scope.gzfwArray.push(obj);
                }
                else if(arr[i].status.toString() == "C")//结束
                {
                    var obj = {};
                    obj.status = "cp5";
                    obj.username = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                    obj.headurl = arr[i].user.user.f_head;
                    obj.fbzuserid = arr[i].user.user.f_id;
                    obj.productid = arr[i].id;
                    obj.productname = arr[i].name;
                    if(obj.productname.length>5)
                    {
                        obj.productnamestr = obj.productname.substr(0,5);
                    }
                    else
                    {
                        obj.productnamestr = obj.productname;
                    }
                    obj.account = arr[i].account;
                    obj.zq = arr[i].gentouperiod;//周期
                    obj.bmrs = arr[i].gentoucount;//跟投人数
                    obj.mbsy = arr[i].targetprofit;//目标收益
                    var str = arr[i].actualendgentouday.toString();
                    obj.endgentoudaystr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    if(arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null)
                    {
                        obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                    }
                    else
                    {
                        obj.endgentoutime = "";
                    }
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.rundays = arr[i].rundays;
                    $scope.gzfwArray.push(obj);
                }
            }
        }
    }

    //查询关注的产品
    $scope.getgzfw = function()
    {
        var message = {};
        message['userid'] = $scope.peopleID;
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectfocusedproduct', message, $scope.getgzfwCallBack);
    }

    $scope.getpeoplezxgaccountCallBack = function(_data)
    {
        //console.log("自选股个数", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.peopelezxgAccount = _data.zxgcount;
        }
    }

    //获取自选股个数
    $scope.getpeoplezxgaccount = function()
    {
        var message = {};
        message['userid'] = $scope.peopleID;
        ajaxService.sendMessage('hq.getzxgcountbyuseridaction', message, $scope.getpeoplezxgaccountCallBack);
    }

    $scope.getgzallCallback = function(_data)
    {
        //console.log("关注", _data);
        $scope.gzAllArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.datalist;
            for(var i = 0;i<arr.length;i++)
            {
                //if(arr[i].f_concernttype == "1")//自选股
                //{
                //    var obj = {};
                //    obj.concernttype = "1";
                //    obj.zxgcount = 0;
                //    if(!!arr[i].f_lastmsg)
                //    {
                //        obj.zxgcount = arr[i].f_lastmsg.zxgcount;
                //        obj.lastcontent = arr[i].f_lastmsg.optmsg + "股票" + arr[i].f_lastmsg.stockname;
                //    }
                //    if(!!arr[i].f_lastmsgtime)
                //    {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0,10);
                //    }
                //    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                //    if(!!arr[i].userinfo)
                //    {
                //        obj.username = arr[i].userinfo.f_nickname;//自选股所属的用户
                //    }
                //    obj.title = obj.username +"的自选股";
                //    //console.log("obj.belonguserid", obj.belonguserid);
                //    $scope.gzAllArray.push(obj);
                //}
                //else if(arr[i].f_concernttype == "2")//解盘
                //{
                //    var obj = {};
                //    obj.concernttype = "2";
                //    if(!!arr[i].f_lastmsgtime) {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                //    }
                //    obj.lastcontent = arr[i].f_lastmsg;
                //    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                //    if(!!arr[i].userinfo) {
                //        obj.username = arr[i].userinfo.f_nickname;//解盘所属的用户
                //    }
                //    //console.log(obj.belonguserid , $scope.userid);
                //    obj.title = obj.username + "的解盘";
                //    $scope.gzAllArray.push(obj);
                //}
                //else if(arr[i].f_concernttype == "4")//理财师
                //{
                //    var obj = {};
                //    obj.concernttype = "4";
                //    if(!!arr[i].f_lastmsgtime) {
                //        obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0, 10);
                //    }
                //    obj.lastcontent = arr[i].f_lastmsg;
                //    obj.belonguserid = arr[i].f_belonguserid;//所属的用户id
                //    if(!!arr[i].showdata)
                //    {
                //        //console.log("333", obj.username);
                //        obj.username = arr[i].showdata.user.user.f_nickname;//所属的用户
                //        //console.log("333", obj.username);
                //        obj.usernamestr = obj.username;
                //        //console.log(obj.usernamestr);
                //        obj.head = arr[i].showdata.user.user.f_head;
                //        obj.tzln = arr[i].showdata.tzln;
                //    }
                //    $scope.gzAllArray.push(obj);
                //}
                if(arr[i].f_concernttype == "3")
                {
                    var obj = {};
                    obj.concernttype = "3";
                    //obj.lastmsgtime = arr[i].f_lastmsgtime.substr(0,10);
                    //obj.lastcontent = arr[i].f_lastmsg;
                    obj.belonguserid = arr[i].f_belonguserid;//自选股所属的用户id
                    var arr2 = arr[i].showdata;//服务用户等信息
                    if(!!arr2) {
                        var obj2 = {};
                        //obj2.status = "cp2";
                        obj2.account = arr2.account;//当前被跟投的账户
                        var bgtuser = arr2.user.user;
                        obj2.headurl = bgtuser.f_head;
                        obj2.username = bgtuser.f_nickname;
                        obj2.fbzuserid = bgtuser.f_id;
                        obj2.productname = arr2.name;
                        if (obj2.productname.length > 5) {
                            obj2.productnamestr = obj2.productname.substr(0, 5);
                        }
                        else {
                            obj2.productnamestr = obj2.productname;
                        }
                        obj2.productid = arr2.id;
                        //obj.zq = arr2.gentouperiod;//周期
                        obj2.gentoucount = arr2.gentoucount;
                        obj2.drsyl = parseFloat(arr2.jrsy);
                        obj2.ljsyl = parseFloat(arr2.ljsy);
                        obj2.rundays = arr2.rundays;
                        obj2.cjcount = arr2.cjcount;
                        obj2.cw = arr2.cw;
                        if (parseFloat(obj2.cw) == 0) {
                            obj2.cwvalue = "空仓";//当前仓位
                        }
                        else if (parseFloat(obj2.cw) == 1) {
                            obj2.cwvalue = "满仓";//当前仓位
                        }
                        else {
                            obj2.cwvalue = (parseFloat(obj2.cw) * 100).toFixed(0) + "%";//当前仓位
                        }
                        obj.fwinfo = obj2;
                        $scope.gzAllArray.push(obj);
                    }
                }
            }
        }
    }

    //所有关注的信息
    $scope.getgzall = function()
    {
        var message = {};
        message['userid'] = $scope.peopleID;//getParameter('userid');
        //console.log("关注的", message);
        ajaxService.sendMessage('user.getconcerntbyuseridaction', message, $scope.getgzallCallback);
    }

    $scope.init = function()
    {
        if($scope.peopleID != null && $scope.peopleID != "" && $scope.peopleID != undefined)
        {
            //理财师是当前用户
            $scope.getPeopleInfo();
            //$scope.getgzfw();
            //自选股设置的状态
            $scope.getzxgszzt();
            $scope.getpeoplezxgaccount();
            //$scope.isguanzhuget();

            //公开的模型
            //$scope.getgkmx();

            //if (window.location.hash == "#/index=1") {
            //    $scope.index = '1';
            //}
            //else if (window.location.hash == "#/index=2") {
            //    $scope.index = '2';
            //}
            //else if (window.location.hash == "#/index=3") {
            //    $scope.index = '3';
            //}
            //else if (window.location.hash == "#/index=4") {
            //    $scope.index = '4';
            //}
            //else if (window.location.hash == "#/index=5") {
            //    $scope.index = '5';
            //}

            //$scope.jp_userid = $scope.userObj.f_id;
            //$scope.jp_fbuser = $scope.peopleID;
        }
    }
    $scope.init();

    //历史服务
    $scope.people_hisfw = function()
    {
        if($scope.peopleID == $scope.userObj.f_id)
        {
            //window.location = "gt_history.html?type=1";
            openNewInterface("gt_history.html?type=1" + "&&opentype=newwebview");
        }
        else
        {
            //window.location = "gt_lcs_history.html?lcsuserid=" + $scope.peopleID;
            openNewInterface("gt_lcs_history.html?lcsuserid=" + $scope.peopleID + "&&opentype=newwebview");
        }
    }

    $scope.yhjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //加关注
    $scope.yhjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "4";
            message['belonguserid'] = $scope.peopleID;
            message['concerntid'] = $scope.peopleID;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.yhjgzCallBack);
        }
    }
    $scope.qxgzzxgCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.qxgzzxg = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "4";
            message['belonguserid'] = $scope.peopleID;
            message['concerntid'] = $scope.peopleID;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.qxgzzxgCallback);
        }
    }


    //可跟投组合详情
    $scope.kgtzhItemClick = function(_obj)
    {
        //$cookieStore.put('account',_obj.account);
        //$cookieStore.put('accountName', encodeURIComponent(_obj.companyname));

        //localStorage.setItem("account", _obj.account);
        //localStorage.setItem("accountName", encodeURIComponent(_obj.companyname));
        //
        //window.location = "tradeBase_sy.html?rmd=" + new Date().getTime();
    }

    //公开的组合加关注
    $scope.gkmxItemClick = function(_obj)
    {
        setbackList(window.location.href);
        window.location.href = "oneStockPool.html?oneStockPoolID=" + _obj.modelid + "&oneStockPoolName=" + encodeURI(_obj.name) + "&back=peoplespace";

    }

    //理财师个人空间
    $scope.gt_lcsspaceClick = function(_obj)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _obj.belonguserid);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
    }

    //自选股
    $scope.people_zxgClick = function()
    {
        //$scope.mainShow = false;
        //$scope.peoplezxgListShow = true;
        //setbackList(window.location.href);
        //window.location.href = "peopleoptionalBase.html?peopleID=" + _obj.belonguserid;
        openNewInterface("peopleoptionalBase.html?peopleID=" + $scope.peopleID + "&&opentype=newwebview");

    }

    //自选股返回
    $scope.zxListBack = function()
    {
        $scope.mainShow = true;
        $scope.peoplezxgListShow = false;
    }

    //自选股显示行情，当前页面隐藏和显示
    $scope.parentDivShow = function(_value)
    {
        //console.log("主界面", _value);
        $scope.zjmxsShow = _value;
    }

    $scope.setppBtnShow = function(_value)
    {
        $scope.ppBtnShow  = _value;
    }

    //解盘
    $scope.people_jpClick = function(_obj)
    {
        //console.log($scope.userObj.f_id , $scope.peopleID);
        //window.location.href = "jiepan_relative.html?userid=" + $scope.userObj.f_id +"&&abletofb=false&&fbuser="+$scope.peopleID + "&title=" + encodeURI("解盘");
        openNewInterface("jiepan_relative.html?userid=" + $scope.userObj.f_id +"&&abletofb=false&&fbuser="+$scope.peopleID + "&title=" + encodeURI("解盘") + "&&opentype=newwebview");
    }

    //发消息
    $scope.fxxClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "onePersonWin.html?id=" + $scope.peopleID + "&name=" + encodeURI($scope.peopleName) + "&headurl=" + encodeURIComponent($scope.peoplehead)+"&type=person";
        //$scope.mainShow = false;
        //$scope.chartShow = true;
        //updatePage($scope.peopleID,"2");
    }

    $scope.peoplespaceBackto = function()
    {
        //window.location = "myGroupBase.html?rmd=" + new Date().getTime();
        //window.location = getbackList();
        if($scope.backtitle == "跟投" || $scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    $scope.chartspaseChange = function()
    {
        //$scope.mainShow = true;
        //$scope.chartShow = false;
		//updatePage($scope.peopleID,"1");
    }
	$scope.repeatingFunction = function()
    {
        //console.log("定时执行，获取未读取的信息");
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        message['friendinfo'] = "";
        ajaxService.sendMessage("user.selectfriendinfo", message, $scope.getfriendwdCallBack) ;
    }

    //获取未读消息个数
    $scope.getfriendwdCallBack = function(_data)
    {
		var arr = [];
        //console.log("列表未读信息更新",_data);
		//alert(_data.op.code);
        if(_data.op.code.toString() == "Y")
        {
			obj = {};
            var element = _data.friendlist;
            for (var item in element) {
                var obj = {};
                obj.id = element[item]['f_friend_id'];//element[item]['f_friend_id'];
                obj.infoNum = element[item]['newmsgcount'];//有多少未读消息
                if(obj.id != $scope.userObj.f_id)
                {
                    arr.push(obj);
                }
			}
			for(var i = 0;i<arr.length;i++)
            {
                    if($scope.peopleID == arr[i].id)
                    {
                        $scope.newmsgcount = arr[i].infoNum;
                        $scope.isFriend = true;
                    }
            }
			//alert("newsmsg");
			if($scope.page == "list"){
	        	//alert("truelist");
	    		selectPage($scope.peopleID);
	    	}else{
	    		//alert("space");
		            if($scope.isFriend){
		    			$scope.mainShow = true;
		    			$scope.chartShow = false;
		    			$scope.$apply();
		    		}else{
		    			$scope.mainShow = true;
		    			$scope.chartShow = false;
		    			$scope.friendicon = false;
		    			$scope.$apply();
		    		}
	    	}
			//$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
		
        }
    }
    //查看专访资料
    $scope.ckzfzlClick = function()
    {
        var url = $scope.peopleallInfo.zfzlurl;
        //？ 用： 替换   &用，替换
        //console.log("kk");
        if($scope.peopleallInfo.zfzlurl.indexOf("?", 0) == -1)
        {
            url = url + ";lcshead=" + $scope.peoplehead + ",lcssc=" + $scope.peopleallInfo.lcstzsc + ",lcsname=" + $scope.peopleName;
        }
        else
        {
            url = url + ",lcshead=" + $scope.peoplehead + ",lcssc=" + $scope.peopleallInfo.lcstzsc + ",lcsname=" + $scope.peopleName;
        }

        //window.location.href = "zfzlLink.html?peopleName=" + encodeURI($scope.peopleName) +"&url="+encodeURI(url);
        openNewInterface("zfzlLink.html?peopleName=" + encodeURI($scope.peopleName) +"&url="+encodeURI(url));

    }

    //跟投list点击
    $scope.gtlistItemClick = function(_obj)
    {
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            openNewInterface("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview");
        }
        else
        {
            //setbackList(window.location.href);
            //    window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            openNewInterface("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid +"&&opentype=newwebview");
        }
    }

	
	//查询是否已经保存跳转页面
	function selectPage(friendid){
		//alert("select");
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1 
			});
		//alert(db);
		db.transaction(function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS space (friend text, page text)");
					tx.executeSql("SELECT * FROM space WHERE friend = "+friendid,[],
							function(tx,res){
								if($scope.newmsgcount == 0)
                                {
									if(res.rows.length == 0)
                                    {
										insertPage($scope.peopleID,"1");
										$scope.mainShow = true;
										$scope.chartShow = false;
									}else{
										if(res.rows.item(0).page==1)
                                        {
											$scope.mainShow = true;
											$scope.chartShow = false;
										}else{
											$scope.mainShow = false;
											$scope.chartShow = true;
										}
									}
                                    $scope.$apply();
								}else
                                {
									$scope.mainShow = false;
									$scope.chartShow = true;
									if(res.rows.length == 0){
										insertPage($scope.peopleID,"2");
									}else{
										updatePage($scope.peopleID,"2");
									}
                                    $scope.$apply();
								}
								
							});
		})
	}
	
	//插入跳转页面信息
	function insertPage(friend,page) {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS space (friend text, page text)");
					tx.executeSql(
							"INSERT INTO space (friend, page) VALUES (?,?)",
							[friend,page],function(tx,res){
							});
				});
	}
	
	//更新跳转页面
	function updatePage(friendid,page){
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx){
					tx.executeSql(
					"UPDATE space SET page = "+page+" WHERE friend = "+friendid,[],
					function(tx,res){
					});
		})
	}
}


