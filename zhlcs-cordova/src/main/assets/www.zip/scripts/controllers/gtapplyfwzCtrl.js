
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gtapplyfwzCtrl($scope, ajaxService, $cookieStore)
{
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.productid = "";//产品id
    $scope.mainShow = true;//主界面
    $scope.bmCvsShow = false;//报名操作开始
    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.bmjzsjstr = "--";//截止时间具体值
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.yjtrzj = "--";//预计投入资金
    $scope.lcsInfo = {};//理财师信息
    $scope.lcsInfo.headurl = "images/wutouxian.png";
    $scope.lcsInfo.name = "--";
    $scope.ybdzhListArray = [];//已经被绑定账户，发布：被跟投账户不可用
    $scope.plCount = "--";

    $scope.addSecurityAccountShow = false;//添加账号界面显示
    $scope.zqgsItemShow = false;//证券公司列表
    $scope.zszhShow = false;//真实账户
    $scope.monizhshow = false;//模拟账户
    $scope.zqgsArray = [];//证券公司
    $scope.selectedzqgs = {};//证券公司id
    $scope.newzqzh = "";//新的证券账号
    $scope.newzqzhpassword = "";//新的证券账号密码
    $scope.newzqyj = "0.0003";//新的证券账号佣金
    $scope.newxm = "";//新的张清账户姓名
    $scope.mnnewzhzdje = "";
    $scope.mnnewzqyj = "0.0008";
    $scope.zsaddinfo = "";//真实账户添加操作中提示信息;
    $scope.moniaddinfo = "";//模拟账户添加操作中提示信息
    $scope.addnewzqzhMark = true;

    $scope.ljsyshow = "";//累计收益

    $scope.tabOneShow = true;//报名
    $scope.tabTwoShow = false;//理财师
    $scope.index = "1";//默认显示报名

    $scope.xyDivShow = false;//协议
    $scope.bmfirstShow = true;//报名第一步
    $scope.bmsecondShow = false;//第二步
    $scope.bmthirdShow = false;//第三步
    $scope.bmfourthShow = false;//第四步

    //$scope.secondErrorInfo = "";//第二步错误提示
    $scope.thirdErrorInfo = "";//第三步错误提示

    //$scope.bmjzsj = "";//报名截止时间
    $scope.lcsstatus = "0";//是否是理财师 2：理财师，非2：不是理财师
    $scope.zhListArray = [];//可发布用的账户
    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.gtcpszInfo = null;//跟投理财师设置的信息
    $scope.cpqbMark = false;//账户金额全部
    $scope.kgtzj = "--";//可跟投资金
    $scope.gtMark = true;//可操作

    $scope.fcfsArray = [];//分成方式
    $scope.fcfs = null;//选择的分成方式
    $scope.dqxzaccount = null;//当前选择的账户

    $scope.bgtuserid = "";//理财师id
    $scope.setzyzsShow = false;//设置止盈止损

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");//打开方式
    //console.log($scope.backtitle);
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }
    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });

    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            $scope.dqgtInfo.zq = product.gentouperiod;
            $scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.dqgtInfo.zxgtje = product.minmoney;
            $scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            $scope.dqgtInfo.yjtrzj = product.planmoney;//预计投入资金
            var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
            $scope.dqgtInfo.bmjzsj = str;//报名截止日期
            var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//服务结束时间
            $scope.dqgtInfo.fwjssj = str2;//服务结束时间
            var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3.substr(0,4) + "-" + str3.substr(4,2) + "-" + str3.substr(6,2);//服务开始时间
            $scope.dqgtInfo.fwkssj = str3;//服务开始时间
            var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4.substr(0,10);//服务发布时间
            $scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            $scope.dqgtInfo.bmjzsjstr = product.endapplytimedesc;

            $scope.dqgtInfo.productfbzname = product.user.user.f_nickname;//产品发布者name
            $scope.ljsyshow = (parseFloat(product.ljsy)*100).toFixed(2) + "%";//累计收益率

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }
            var sharearr = product.share;
            console.log("分成比例" +product.share)
            for(var i = 0;i<sharearr.length;i++)
            {
                var obj = {};
                obj.downprofit = sharearr[i].downprofit;//目标收益
                obj.share = sharearr[i].share;
                var fc = parseInt(obj.share)/10;
                obj.label = fc +":" +(10-fc) ;
                //obj.desc = "目标收益" +  sharearr[i].downprofit + "%后，跟投收益部分按照" + obj.label + "分成";\
                if(fc == 2)
                {
                    obj.desc = "跟投用户实际收益超出平台基准收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；没有超出平台基准收益，理财师不分成";
                }
                else
                {
                    obj.desc = "跟投用户实际收益超出理财包目标收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；若未达到目标收益，按二八分成方式结算";
                }

                //obj.desc = sharearr[i].desc;
                //if(fc == 5)
                //{
                //    obj.desc = "实际收益大于理财包目标收益部分，理财师50%，跟投用户50%分成；没有超出目标收益，理财师不分成";
                //}
                //else
                //{
                //    obj.desc = "实际收益超出平台基准收益部分，理财师20%，跟投用户80%分成；没有超出平台基准收益，理财师不分成"
                //}
                obj.status = true;
                $scope.fcfsArray.push(obj);
            }

            if($scope.fcfsArray.length>0)
            {
                $scope.fcfs = $scope.fcfsArray[0];
            }
            var headastr = product.user.user.f_head;
            if(headastr != "" && headastr != undefined && headastr!= undefined)
            {
                $scope.lcsInfo.headurl = headastr;
            }

            $scope.lcsInfo.name = product.user.user.f_nickname;

            //$scope.dqgtInfo.xktyw = "2,3" ;//需开通业务  开通沪深：1；开通创业板：2；开通港股通：3
            //
            //if($scope.dqgtInfo.xktyw.indexOf("1",0) != -1)
            //{
            //    $scope.hscheck = true;
            //}
            //if($scope.dqgtInfo.xktyw.indexOf("2",0) != -1)
            //{
            //    $scope.cybcheck = true;
            //}
            //if($scope.dqgtInfo.xktyw.indexOf("3",0) != -1)
            //{
            //    $scope.ggtcheck = true;
            //}
        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.p_getaccountlistCallBack = function(_data)
    {
        console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.check = false;
                obj.experience = element[item].experience.toString();
                if(obj.experience == "Y")
                {
                    obj.zqgsname = "跟投基金";
                }
                if(element[item].accountstatus.toString() != "c")//非绑定账户
                {
                    obj.gtlist = [];
                    if(element[item].accountstatus.toString() == "b")//普通用户
                    {
                        if(element[item].linkapplylist != undefined && element[item].linkapplylist != null)
                        {
                            //已报名
                            var arr1 = element[item].linkapplylist;
                            for(var i = 0;i<arr1.length;i++)
                            {
                                var obj2 = {};
                                obj2.bgtheadurl = arr1[i].linkuser.user.f_head;
                                obj2.bgtuserid = arr1[i].linkuser.user.f_id;
                                obj2.bgtusername = arr1[i].linkuser.user.f_nickname;
                                obj2.productid = arr1[i].productid;
                                obj2.productname = arr1[i].productname;
                                obj2.zq = arr1[i].gentouperiod;
                                obj2.mbsy = arr1[i].targetprofit + "%";//目标收益
                                var str = arr1[i].endapplytime.toString();
                                //obj2.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止时间
                                obj2.bmjzsj = str;//报名截止时间
                                obj2.status = "1";//已报名：1；跟投中(跟投)：3
                                obj.gtlist.push(obj2);
                            }
                        }
                        if(element[item].linklist != undefined && element[item].linklist != null)
                        {
                            //跟投他人
                            var arr2 = element[item].linklist;
                            for(var i = 0;i<arr2.length;i++)
                            {
                                var obj2 = {};
                                obj2.bgtheadurl = arr2[i].linkeduser.user.f_head;
                                obj2.bgtuserid = arr2[i].linkeduser.user.f_id;
                                obj2.bgtusername = arr2[i].linkeduser.user.f_nickname;
                                obj2.productid = arr2[i].productid;
                                obj2.productname = arr2[i].productname;
                                obj2.drsy = parseFloat(arr2[i].linkaccountmoney.jrsy);//当日收益
                                obj2.ljsy = parseFloat(arr2[i].linkaccountmoney.ljsy);//累计收益
                                var str = arr2[i].endgentoutime.toString();
                                //obj2.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);;//结束时间
                                obj2.jssj = str;//结束时间
                                obj2.status = "3";//已报名：1；跟投中(跟投)：3
                                obj.gtlist.push(obj2);
                            }
                        }
                    }
                    $scope.zhListArray.push(obj);
                }
                else
                {
                    obj.productid = element[item].product.id;
                    obj.productname = element[item].product.name;
                    $scope.ybdzhListArray.push(obj);
                }
            }
        }
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }


    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;

        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            //var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            //$scope.$broadcast("setParameters", cstr);

        }
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    //初始相关操作界面
    $scope.bmfbInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            //$scope.lcsstatus = "2";//localStorage.getItem("lcsstatus");
            $scope.lcsstatus = localStorage.getItem("lcsstatus");
            $scope.productid = getParameter("productid");
            $scope.bgtuserid = getParameter("bgtuserid");//被跟投id

            $scope.getdqgtInfo();
            $scope.getzhlb();
            $scope.changeTab($scope.index);
            $scope.getplcount();
            $scope.isguanzhuget();

        }catch (e){}
    }

    $scope.bmfbInit();


    //查看分成方式
    $scope.gotofcfs = function()
    {
        xinyuNewBrowser("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }


    $scope.gotoxyClick = function()
    {
        //$scope.bmfirstShow = false;
        $scope.mainShow = false;
        $scope.bmCvsShow = true;
        $scope.xyDivShow = true;
        //gotoUp();
    }

    //取消报名回到tab切换界面
    $scope.bmCancel = function()
    {
        $scope.mainShow = true;
        $scope.bmCvsShow = false;
        $scope.xyDivShow = false;
        $scope.bmsecondShow = false;
        $scope.bmthirdShow = false;
        $scope.bmfourthShow = false;

        $scope.dqxzaccount = null //选中的账户
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }

        $scope.thirdErrorInfo = "";
        $scope.kgtzj = "--";//可跟投资金
        $scope.gtcpszInfo = {};//跟投设置的信息
        $scope.gtcpszInfo.gtje = "";//跟投金额
        $scope.gtcpszInfo.zybfb = "";//止盈百分比
        $scope.gtcpszInfo.zsbfb = "";//止损百分比
        //$scope.fcfs = null;
        //for(var i = 0;i<$scope.fcfsArray.length;i++)
        //{
        //    if($scope.fcfsArray[i].status)
        //    {
        //        $scope.fcfsArray[i].status = false;
        //        break;
        //    }
        //}

        gotoUp();
    }

    $scope.gotosecondClick = function()
    {
        $scope.xyDivShow = false;
        $scope.bmsecondShow = true;
        gotoUp();
    }

    //返回协议界面
    $scope.backtoxyClick = function()
    {
        $scope.xyDivShow = true;
        $scope.bmsecondShow = false;
        gotoUp();
    }

    $scope.gotothirdClick = function()
    {
        //var mark = false;
        //for(var i = 0;i<$scope.zhListArray.length;i++)
        //{
        //    if($scope.zhListArray[i].check)
        //    {
        //        mark = true;
        //    }
        //}
        //
        if($scope.dqxzaccount == null)
        {
            //$scope.secondErrorInfo = "请选择账户";
            return;
        }

        //$scope.secondErrorInfo = "";
        $scope.thirdErrorInfo = "";
        $scope.kgtzj = "--";//可跟投资金
        $scope.gtcpszInfo = {};//跟投设置的信息
        $scope.gtcpszInfo.gtje = "";//跟投金额
        $scope.gtcpszInfo.zybfb = "";//止盈百分比
        $scope.gtcpszInfo.zsbfb = "";//止损百分比

        $scope.getkyzj();

        $scope.bmsecondShow = false;
        $scope.bmthirdShow = true;
        gotoUp();
    }

    //设置止盈止损
    $scope.setzyzsClick = function()
    {
        $scope.setzyzsShow = !$scope.setzyzsShow;
        if($scope.setzyzsShow == false)
        {
            $scope.gtcpszInfo.zybfb = "";//止盈百分比
            $scope.gtcpszInfo.zsbfb = "";//止损百分比
        }
    }

    $scope.p_kgtzjCallBack = function(_data)
    {
        //console.log("可用资金：", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.kgtzj = parseFloat(parseFloat(_data.kyzj).toFixed(2));
        }
    }

    //获取当前选择账户的可用资金
    $scope.getkyzj = function()
    {
        //$scope.kgtzj = 1000000;
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['account'] = $scope.dqxzaccount.account;
        //console.log("可用资金获取",$scope.userObj.f_id, message['account']);
        ajaxService.sendMessage("gentou.p_kgtzj", message, $scope.p_kgtzjCallBack);
    }

    //选中全部金额
    $scope.gtcpzjqbClick = function()
    {
        //$scope.cpqbMark = !$scope.cpqbMark;
        //alert( $scope.lcsqbMark )
        //if($scope.cpqbMark)
        //{
            //可用资金小于最小可跟投资金
            if(parseFloat($scope.kgtzj) < parseFloat($scope.dqgtInfo.zxgtje))
            {
                $scope.gtcpszInfo.gtje = "0.00";
            }
            else if(parseFloat($scope.kgtzj) > parseFloat($scope.dqgtInfo.zdgtje))
            {
                $scope.gtcpszInfo.gtje = (parseFloat($scope.dqgtInfo.zdgtje)).toFixed(2);
            }
            else
            {
                $scope.gtcpszInfo.gtje = (parseFloat($scope.kgtzj)).toFixed(2);
            }
        //}
        //else
        //{
        //    $scope.gtcpszInfo.gtje = "";
        //}
    }
    $scope.zxgtjeClick = function()
    {
        //if(parseFloat($scope.kgtzj) < parseFloat($scope.dqgtInfo.zxgtje))
        //{
        //    $scope.gtcpszInfo.gtje = "0.00";
        //}
        //else
        //{
            $scope.gtcpszInfo.gtje = parseFloat($scope.dqgtInfo.zxgtje).toFixed(2);
        //}

    }

    $scope.zdgtjeClick = function()
    {
        //if(parseFloat($scope.kgtzj) < parseFloat($scope.dqgtInfo.zdgtje))
        //{
        //    $scope.gtcpszInfo.gtje = "0.00";
        //}
        //else
        //{
            $scope.gtcpszInfo.gtje = parseFloat($scope.dqgtInfo.zdgtje).toFixed(2);
        //}
    }


    $scope.gtjeChange = function()
    {
        $scope.cpqbMark = false;
    }

    $scope.backtosecondClick = function()
    {
        $scope.bmsecondShow = true;
        $scope.bmthirdShow = false;
        $scope.thirdErrorInfo = "";
        gotoUp();
    }

    $scope.gotofourthClick = function()
    {
        if($scope.gtMark) {
            if ($scope.gtcpszInfo.gtje == "") {
                //$scope.thirdErrorInfo = "请输入跟投金额";
                return;
            }
            if ($scope.kgtzj <= 0 || $scope.kgtzj == "--") {
                $scope.thirdErrorInfo = "可跟投资金不足";
                return;
            }
            //|| $scope.gtcpszInfo.zybfb == "" || $scope.gtcpszInfo.zsbfb == ""
            if (valueCheck($scope.gtcpszInfo.gtje) == false) {
                $scope.thirdErrorInfo = "跟投金额含有特殊字符，请输入有效值";
                return;
            }
            //if (parseFloat($scope.gtcpszInfo.gtje) > $scope.kgtzj) {
            //    $scope.thirdErrorInfo = "可跟投资金不足";
            //    return;
            //}
            //console.log($scope.gtszInfo.gtje, $scope.cpbgtAccountInfo.maxmoney, $scope.cpbgtAccountInfo.minmoney)

            if (parseFloat($scope.gtcpszInfo.gtje) > $scope.dqgtInfo.zdgtje) {
                $scope.thirdErrorInfo = "跟投金额大于可最大可跟投金额";
                return;
            }
            if (parseFloat($scope.gtcpszInfo.gtje) < $scope.dqgtInfo.zxgtje) {
                $scope.thirdErrorInfo = "跟投金额小于可最小可跟投金额";
                return;
            }

            if ($scope.gtcpszInfo.zybfb != "") {
                if (valueCheck($scope.gtcpszInfo.zybfb) == false) {
                    $scope.thirdErrorInfo = "止盈线含有特殊字符，请输入有效值";
                    return;
                }
            }
            if ($scope.gtcpszInfo.zsbfb != "") {
                if (valueCheck($scope.gtcpszInfo.zsbfb) == false) {
                    $scope.thirdErrorInfo = "止损线含有特殊字符，请输入有效值";
                    return;
                }
            }

            $scope.thirdErrorInfo = "";
            //$scope.bmthirdShow = false;
            //$scope.bmfourthShow = true;
            $scope.gtMark = false;
            $scope.gtbmcomfirm();
        }
    }

    $scope.backtothirdClick = function()
    {
        $scope.bmthirdShow = true;
        $scope.bmfourthShow = false;
    }

    $scope.fcfsClick = function(_obj)
    {
        for(var i = 0;i<$scope.fcfsArray.length;i++)
        {
            if($scope.fcfsArray[i].status)
            {
                $scope.fcfsArray[i].status = false;
                break;
            }
        }
        _obj.status = true;
        $scope.fcfs = _obj;
    }

    $scope.gtbmcomfirm = function()
    {
        var message = {};
        message['applyuserid'] = $scope.userObj.f_id;
        message['applyaccount'] = $scope.dqxzaccount.account;
        message['stopprofit'] = $scope.gtcpszInfo.zybfb;//止盈线
        message['stoploss'] = $scope.gtcpszInfo.zsbfb//止损线
        message['money'] = $scope.gtcpszInfo.gtje;
        message['productid'] = $scope.productid;
        message['sharedownprofit'] = $scope.fcfs.downprofit;
        message['share'] = $scope.fcfs.share;

        //console.log("跟投报名",message);
        ajaxService.sendMessage("sunflower.p_gentouapply", message, $scope.p_gentouapplyCallBack);
    }

    $scope.p_gentouapplyCallBack = function(_data)
    {
        //console.log("报名返回", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.gotofinished();
        }
        else
        {
            $scope.thirdErrorInfo = "跟投失败，原因：" + _data.op.info;
        }
        $scope.gtMark = true;
    }

    //账户选择，单一
    $scope.zhcheckClick = function (_obj)
    {
        //console.log("check");
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }
        _obj.check = true;
        $scope.dqxzaccount = _obj;
    }

    //进入完成提示界面
    $scope.gotofinished = function()
    {
        $scope.bmthirdShow = false;
        $scope.bmfourthShow = true;
        gotoUp();
    }


    //添加账户
    $scope.tjzhClick = function()
    {
        $scope.bmCvsShow = false;
        $scope.addSecurityAccountShow = true;//添加账号界面显示
        $scope.zqgsItemShow = false;//证券公司列表
        $scope.zszhShow = false;//真实账户
        $scope.monizhshow = false;//模拟账户

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";

        $scope.getzqgs();
    }

    //返回home
    $scope.addzhBackto = function()
    {
        $scope.bmCvsShow = true;
        $scope.addSecurityAccountShow = false;//添加账号界面显示
        $scope.zszhShow = false;
        $scope.monizhshow = false;

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";
    }

    //获取证券公司
    $scope.getzqgs = function()
    {
        //console.log("证券公司");
        $scope.zqgsArray = [];
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['company'] = "";
        message['name'] = "";
        message['desc'] = "";
        message['market'] = "";
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getsecuritycompany", message, $scope.selectsecuritycompanyactionCallBack);
    }

    //获取证券公司
    $scope.selectsecuritycompanyactionCallBack = function(_data)
    {
        //console.log("证券公司", _data);
        if(_data.op.code.toString() == "Y") {
            var element = _data.securitycompanylist;
            console.log(element.length);
            for (var item = 0;item < element.length; item++){
                var obj = {};
                obj.id = element[item]['company'];
                obj.name = element[item]['name'];
                //if(obj.id != "moni")
                //{
                $scope.zqgsArray.push(obj);
                //}
            }
        }
    }

    //进入添加界面
    $scope.zqgsItemClick = function(_obj)
    {
        $scope.zqgsItemShow = true;
        $scope.selectedzqgs = _obj;

        if(_obj.id == "moni")
        {
            $scope.zszhShow = false;
            $scope.monizhshow = true;
        }
        else
        {
            $scope.zszhShow = true;
            $scope.monizhshow = false;
        }

    }

    //返回证券公司列表
    $scope.backtozqgslist = function()
    {
        $scope.zqgsItemShow = false;
        $scope.selectedzqgs = {};

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";
        $scope.addnewzqzhMark = true;
        $scope.zsaddinfo = "";
        $scope.moniaddinfo = "";
    }

    //确定增加关联账号
    $scope.addnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.newzqzh == "")
            {
                $scope.zsaddinfo = "请输入证券账号";
                return;
            }
            if($scope.newzqzhpassword == "")
            {
                $scope.zsaddinfo = "请输入交易密码";
                return;
            }
            //if($scope.newxm == "")
            //{
            //    $scope.zsaddinfo = "请输入姓名";
            //    return;
            //}
            $scope.zsaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['account'] = $scope.newzqzh;//当前账号
            message['password'] = $scope.newzqzhpassword;
            message['company'] = $scope.selectedzqgs.id;
            //onsole.log($scope.selectedzqgs.id)
            message['source'] = "A";
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.newzqyj;
            //message['name'] = $scope.newxm;//姓名
            console.log("增加证券账户");
            $scope.zsaddinfo = "添加账户中，请稍候...";
            ajaxService.sendMessage("counter.p_bindsecurityaccount", message, $scope.p_bindsecurityaccountCallBack);
        }
    }

    $scope.p_bindsecurityaccountCallBack = function(_data)
    {
        //console.log("增加证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            //查询证券账号列表
            $scope.getzhlb2();

            //返回账号列表
            $scope.bmCvsShow = true;
            $scope.addSecurityAccountShow = false;
            $scope.zqgsItemShow = false;
            $scope.zszhShow = false;
            $scope.newzqzh = "";
            $scope.newzqzhpassword = "";
            $scope.newzqyj = "0.0003";
            //$scope.newxm = "";
            $scope.selectedzqgs = {};
            $scope.zsaddinfo = "";
        }
        else
        {
            //alert("添加账号失败，原因：" + _data.op.info);
            $scope.zsaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }


    //确定增加关联模拟账号
    $scope.moniaddnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.checkValue($scope.mnnewzhzdje) == false)
            {
                $scope.moniaddinfo = "含有特殊字符，请输入有效值";
                return;
            }
            if($scope.mnnewzhzdje == "0" || $scope.mnnewzhzdje == "")
            {
                $scope.moniaddinfo = "请输入指定金额";
                return;
            }
            if(parseFloat($scope.mnnewzhzdje) < 10000)
            {
                $scope.moniaddinfo = "指定金额不能小于1万元";
                return;
            }
            if(parseFloat($scope.mnnewzhzdje) >10000000)
            {
                $scope.moniaddinfo = "指定金额不能大于1000万元";
                return;
            }
            $scope.moniaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.mnnewzqyj;
            message['money'] = $scope.mnnewzhzdje;
            //console.log("增加模拟账户");
            ajaxService.sendMessage("counter.p_bindmoniaccount", message, $scope.bindmoniaccountCallBack);
        }
    }

    $scope.bindmoniaccountCallBack = function(_data)
    {
        //console.log("增加模拟证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            //查询证券账号列表
            $scope.getzhlb2();

            //返回账号列表
            $scope.bmCvsShow = true;
            $scope.addSecurityAccountShow = false;
            $scope.zqgsItemShow = false;
            $scope.monizhshow = false;
            $scope.mnnewzhzdje = "";
            $scope.mnnewzqyj = "0.0008";
            $scope.selectedzqgs = {};
            $scope.moniaddinfo = "";
            $scope.gotoTop();
        }
        else
        {
            $scope.moniaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }

    $scope.getzhlb2 = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack2);

    }

    $scope.p_getaccountlistCallBack2 = function(_data)
    {
        //console.log("获取账户列表", _data);
        var arr = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.experience = element[item].experience.toString();
                if(obj.experience == "Y")
                {
                    obj.zqgsname = "跟投基金";
                }
                //obj.check = false;
                if(element[item].accountstatus.toString() != "c")//非绑定账户
                {
                    arr.push(obj);
                }
            }
        }

        for(var j = 0;j<$scope.zhListArray.length;j++)
        {
            $scope.zhListArray[j].check = false;
        }

        for(var i = 0;i<arr.length;i++)
        {
            var mark = false;
            for(var j = 0;j<$scope.zhListArray.length;j++)
            {
                if($scope.zhListArray[j].account == arr[i].account)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)//新加的
            {
                arr[i].check = true;
                $scope.zhListArray.push(arr[i]);
                $scope.dqxzaccount = arr[i];
                break;
            }
        }
    }

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }

    $scope.fwqxgzCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.fwqxgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.fwqxgzCallback);
        }
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.dqgtInfo.productname +'" 累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname +'，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //alert("分享地址： " + _content);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.dqgtInfo.productname +'" 累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname + '，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })
    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    //点击不显示手机弹出的键盘
    $scope.closePopClick = function()
    {}

    $scope.backtoP = function()
    {
        $scope.fbgtBackto();
    }

    $scope.fbgtBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
        //JumpS(function(data){
        //    //alert(JSON.stringify(data));
        //},function(){
        //    alert("关闭网页失败，请重试");
        //})
    }

    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                //alert("含有非数字字符");
                if(_str.charAt(i) != ".")
                {
                    return false;
                }
            }
        }
        return true;
    }


    //开户
    $scope.khClick = function()
    {
        //setbackList("myFinancialBase.html");
        //window.location = "openAccounts.html";
        xinyuNewBrowser("openAccounts.html?opentype=newwebview");

    }


}



