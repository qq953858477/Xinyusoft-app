/**
 * 控制器
 */
function oneStockPoolCtrl($scope, ajaxService, $cookieStore) {
    //console.log($location.url());
    //console.log($location.search()['oneStockPoolName']);
    $scope.sessionID = "";//session
    $scope.oneStockPoolName = "";//股票池名称
    $scope.oneStockPoolID = "";//股票池代码
    $scope.runningTime = "-";//运行时间
    $scope.ptitleShow = true;//主界面头部
    $scope.tabOneShow = true;//标签显示
    $scope.tabTwoShow = false;//标签显示
    $scope.tabThreeShow = false;//标签显示
    $scope.sylListShow = false;//收益率列表显示
    $scope.positionShow = false;//详细仓位
    $scope.changeRecordHistoryShow = false; //调仓记录
    $scope.onemoniShow = false;//显示一个模拟跟盘相关信息
    $scope.onemoniTitle = "";//模拟跟盘title30
    $scope.onemoniccArray = [];//一个模拟跟盘持仓
    $scope.onemonisylArray = {};//一个模拟跟盘收益率
    $scope.onemonisylscaleSteps = 4;//Y轴刻度个数
    $scope.onemonisylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.onemonisylscaleStartValue = -20;//y轴的起始值
    $scope.onemonisylstep = 10;//计算步长

    $scope.changeRecordArray = [];//调仓记录
    $scope.moniInfoArray = [];//模拟跟盘信息
    $scope.stockArray = [];//股票池股票列表(详细仓位)
    $scope.industryArray = [];//行业占比数据
    $scope.sylArray = [];//收益率
    $scope.sylshowmaxlen = 30;//判断显示的最大个数，大于此值，则处理显示
    $scope.sylChartArray = new Object();//收益率图
    $scope.sylscaleSteps = 4;//Y轴刻度个数
    $scope.sylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.sylscaleStartValue = -20;//y轴的起始值
    $scope.sylstep = 10;//计算步长

    $scope.stocklistArray = []; //股票池股票，去掉剩余占比
    $scope.totalYield = "--";//总收益率
    $scope.dayYield = "--";//日收益率
    $scope.monthYield = "--";//月收益率
    $scope.dayIncomeRanked = "--";//日收益排名
    $scope.monthIncomeRanked = "--";//月收益排名

    $scope.oneStockPoolPercent = 0.00;//当前股票池的剩余总比例，调整后也改变

    $scope.gzMark = true;//是否可以操作
    $scope.isgzMark = false;//是否已经关注
    $scope.gzDivShow = false;//是否显示关注、取消关注操作
    $scope.backurl = "";//peoplespace:他人空间；myspace：自己空间

    $scope.userObj = {};//客户信息


    //$scope.sessionID = $cookieStore.get('sessionid');
    //$scope.userObj = $cookieStore.get('user');

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));

    $scope.oneStockPoolName = decodeURI(getParameter("oneStockPoolName"));
    $scope.oneStockPoolID = getParameter("oneStockPoolID");
    $scope.backurl = getParameter("back");
    //console.log($scope.oneStockPoolID)

    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    //获取股票池信息
    $scope.getstockpoolCallBack = function(_data)
    {
        console.log("获取股票池信息", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.runningTime = _data.runinfo;
            if(_data.zjyrsylpm !== "" && _data.zjyrsylpm != null && _data.zjyrsylpm != undefined)
            {
                $scope.dayIncomeRanked = _data.zjyrsylpm;
            }
            if(_data.zjyysylpm !== "" && _data.zjyysylpm != null && _data.zjyysylpm != undefined)
            {
                $scope.monthIncomeRanked = _data.zjyysylpm;
            }
            $scope.totalYield = $scope.changeValue((_data.zsy*100).toFixed(2));

            $scope.dayYield = $scope.changeValue((_data.zjyrsyl*100).toFixed(2)) + " %";//日收益率
            $scope.monthYield = $scope.changeValue((_data.zjyysyl*100).toFixed(2)) + " %";//月收益率
        }
    }

    //获取股票池信息
    var message = {};
    message['id'] = $scope.oneStockPoolID;
    ajaxService.sendMessage('model.getmodelaction', message, $scope.getstockpoolCallBack);

    //颜色转成十进制
    $scope.getRandomColorDecimalism = function(_str)
    {
        var rgb = "RGBA(220,220,220,1)";//#a6a6a6
        var arr = [];
        if(_str.length == 6)
        {
            rgb = "RGBA(";
            for(var i = 0;i<6;i++)
            {
                arr.push($scope.afValue(_str.substr(i,1)));
            }

            for(var i = 0;i<3;i++)
            {
                var str = "";
                str = (arr[i*2]*16+arr[i*2+1]).toFixed(0) + ",";
                rgb = rgb +str;
            }
            rgb = rgb + "1)";
        }
        return rgb;

    }

    //判断是a-f之间
    $scope.afValue = function(_str)
    {
        var n = 0;
        if(_str == "a" || _str == "A")
        {
            n = 10;
        }
        else if(_str == "b" || _str == "B")
        {
            n = 11;
        }
        else if(_str == "c" || _str == "C")
        {
            n = 12;
        }
        else if(_str == "d" || _str == "D")
        {
            n = 13;
        }
        else if(_str == "e" || _str == "E")
        {
            n = 14;
        }
        else if(_str == "f" || _str == "F")
        {
            n = 15;
        }
        else
        {
            n = parseInt(_str);
        }
        return n;
    }

    //随机生成颜色
    $scope.getRandomColor = function(){
        var str = "";
        while (str == "54BC7F" || str == "")//不与现金的颜色重合
        {
            str = '' +
            (function(color){
                return (color +=  '0123456789abcdef'[Math.floor(Math.random()*16)])
                && (color.length == 6) ?  color : arguments.callee(color);
            })('');
        }
        return str;
    }

    //返回可选择的区间
    $scope.getSelectValue = function(_value1, _value2, value3)//原占比，可用占比，新占比
    {
        var arr = [];
        var nim = Math.ceil(_value1 -  _value2);//最小值
        var max = Math.floor($scope.oneStockPoolPercent + value3);//最大值
        for(var i = nim;i<=max;i++)
        {
            var obj = {};
            obj.value = i;
            arr.push(obj);
        }
        return arr;
    };

    //降序排序
    $scope.descendingSort = function(_arr)
    {
        var temp;
        for (var i = 0; i < _arr.length; i++)
        {
            for (var j = _arr.length - 1; j > i; j--)
            {
                if (_arr[j].value > _arr[j - 1].value)
                {
                    temp = _arr[j];
                    _arr[j] = _arr[j - 1];
                    _arr[j - 1] = temp;
                }
            }
        }
        return _arr;
    }


    //获取股票池股票列表
    $scope.selectstockpoolmemberCallBack = function(_data)
    {
        $scope.stockArray = [];
        $scope.stocklistArray = [];
        $scope.industryArray = [];
        var num = 100.00;
        console.log("股票配置",_data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.modelpositionlist;
            for (var item in element)
            {
                obj = {};
                obj.gpdm= element[item]['symbol'];
                obj.gpmc = element[item]['stockname'];
                obj.label = obj.gpmc + "(" + obj.gpdm +")";
                obj.industry = element[item]['industry'];//行业
                obj.market = element[item]['exchange'];//交易所
                obj.tc = obj.market + obj.gpdm;
                obj.value = parseFloat((element[item]['bl']*100).toFixed(2));//占比，zb
                obj.zbstr = (element[item]['bl']*100).toFixed(2);
                obj.changezbstr = "";
                obj.changeShow = false;//是否显示调整值;
                obj.kyzb = parseFloat((element[item]['kybl']*100).toFixed(2));//可用占比，可以卖出的
                obj.newzb = obj.value;//调整后的占比
                obj.newzbstr = obj.newzb.toFixed(2);
                obj.dqj = (parseFloat(element[item]['now'].toString())).toFixed(2);//当前价
                obj.zdf = (parseFloat(element[item]['zdf'].toString())).toFixed(2);//涨跌幅
                $scope.stocklistArray.push(obj);

                num = num - obj.value;
                //obj.color2 = $scope.getRandomColor();//十六进制
                //obj.color = $scope.getRandomColorDecimalism(obj.color2);//转成10进制
                $scope.stockArray.push(obj);
            }

            var element2 = _data.industrylist;
            for (var item in element2)
            {
                obj = {};
                obj.value= parseFloat((element2[item]['percent']*100).toFixed(2));//占比，zb
                obj.industry = element2[item]['industry'];//行业
                obj.color = element2[item]['color'];//颜色
                obj.label = obj.industry + "：" + obj.value + "%";
                $scope.industryArray.push(obj);
            }
            //$scope.industryArray.sort(function(a, b){return a-b});
            //行业降序排序
            $scope.industryArray = $scope.descendingSort($scope.industryArray);
        }
        var obj = {};
        obj.value = parseFloat(num.toFixed(2));
        obj.color = "#F39814"; //$scope.getRandomColor();
        obj.industry = "现金";
        obj.label = obj.industry + "：" + obj.value + "%";
        $scope.industryArray.push(obj);

        //剩余现金
        $scope.oneStockPoolPercent = num;
        $scope.stockPoolPercentChangeShow = false;
        //环形图
        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            $scope.stocklistArray[i].selectValue = $scope.getSelectValue($scope.stocklistArray[i].value, $scope.stocklistArray[i].kyzb, $scope.stocklistArray[i].newzb)///可选择区间数组
        }

    }

    //获取股票池股票列表
    var message = {};
    message['modelid'] = $scope.oneStockPoolID;
    ajaxService.sendMessage('model.selectmodelpositionaction', message, $scope.selectstockpoolmemberCallBack);

    //查询收益率
    $scope.selectstockpoolprofitdayactionCallBack = function(_data)
    {
        console.log("收益率",_data);
        $scope.sylArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.modeldayqslist;
            for (var item in element)
            {
                var obj = {};
                var str = element[item]['qsday'].toString();
                obj.label= str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.value = parseFloat((element[item]['profit']*100).toFixed(2));//收益率
                //console.log(obj.value);
                obj.zzc = (parseFloat(element[item]['net'])).toFixed(4);//净值
                obj.ny = str.substr(0,6);//年月
                obj.status = "0";//0：显示，1：不显示，界面显示用处理
                obj.ym = "1";//是否是月末 0：是，1：不是，界面显示处理
                obj.ymshow = "1";//是否展开 0：展开，1：没有展开 ，界面显示用
                //console.log("ny", obj.ny);
                $scope.sylArray.push(obj);
            }
        }

        //var obj = {}
        //obj.label= "2015-07-11";
        //obj.value = "54.44";//收益率
        ////console.log(obj.value);
        //obj.zzc = "0.9999";//净值
        //obj.ny = "2015-07";//年月
        //obj.status = "0";//0：显示，1：不显示，界面显示用处理
        //obj.ym = "1";//是否是月末 0：是，1：不是，界面显示处理
        //obj.ymshow = "1";//是否展开 0：展开，1：没有展开 ，界面显示用
        ////console.log("ny", obj.ny);
        //$scope.sylArray.push(obj);

        var labarr = [];//收益率图label
        var dataarr = [];//收益率图data
        var sylmax = 0;//最大值
        //var sylmin = 0//最小值
        if($scope.sylArray.length>0)
        {
            sylmax = Math.abs($scope.sylArray[0].value);
            //sylmin = $scope.sylArray[0].value;
        }

        for(var i = 0;i<$scope.sylArray.length;i++)
        {
            labarr.push($scope.sylArray[i].label);
            dataarr.push($scope.sylArray[i].value);
            sylmax = Math.max(sylmax, Math.abs($scope.sylArray[i].value));
            //sylmin = Math.min(sylmin, Math.abs($scope.sylArray[i].value));
        }
        //console.log(sylmax);
        if((sylmax.toString()).indexOf(".",0) != -1)
        {
            //console.log((sylmax.toString()).indexOf(".",0));
            $scope.sylstep = (sylmax.toString()).indexOf(".",0) *10;
        }
        else
        {
            $scope.sylstep = sylmax.toString().length * 10;
        }
        //console.log($scope.sylstep);
        var max = (Math.floor(sylmax/$scope.sylstep) + 1)*$scope.sylstep;
        // console.log(max)
        $scope.sylscaleStepWidth = max/2;
        $scope.sylscaleStartValue = -1*max;

        $scope.sylChartArray = new Object();

        var valueObj = new Object();
        valueObj.fillColor = "rgba(220,220,220,0.5)";
        valueObj.strokeColor = "rgba(220,220,220,0.8)";
        valueObj.highlightFill = "rgba(220,220,220,0.75)";
        valueObj.highlightFill = "rgba(220,220,220,1)";
        valueObj.data = dataarr;

        var datasetsArr = [];
        datasetsArr.push(valueObj);
        $scope.sylChartArray.labels = labarr;
        $scope.sylChartArray.datasets = datasetsArr;

        //曲线图
        var ctx = document.getElementById("chart_line").getContext("2d");
        var myNewChart = new Chart(ctx).Line($scope.sylChartArray, {
            //scaleShowLabels: false, //纵坐标是否显示
            //scaleOverride :true ,   //是否用硬编码重写y轴网格线
            //scaleSteps : 4,        //y轴刻度的个数
            //scaleStepWidth : 300,   //y轴每个刻度的宽度
            //scaleStartValue : 0,    //y轴的起始值
            responsive : false,//是否响应，移动到图形上，出现相应的点值
            animation: false ,//是否有动画效果
            scaleLabel : "<%=value%>%",//显示百分比
            showTooltips: false,
            pointDot : false,      //是否显示点
            scaleOverride :true ,   //是否用硬编码重写y轴网格线
            scaleSteps : $scope.sylscaleSteps,       //y轴刻度的个数
            scaleStepWidth : $scope.sylscaleStepWidth,   //y轴每个刻度的宽度
            scaleStartValue : $scope.sylscaleStartValue   //y轴的起始值
            //animationSteps : 60    //动画的步数
            //pointDot : true,        //是否显示点
            //pointDotRadius : 5,     //点的半径
            //pointDotStrokeWidth : 1,//点的线宽
            //datasetStrokeWidth : 3 //数据线的线宽

        });


        //处理是否显示
        if($scope.sylArray.length > $scope.sylshowmaxlen)//一个月内，全部显示<=30则不处理
        {
            for(var i = 0;i<$scope.sylArray.length-1; i++)
            {
                if($scope.sylArray[i].ny == $scope.sylArray[i+1].ny)//与下一个日期的年月相同，表示不是月最后一天，不显示
                {
                    $scope.sylArray[i].status = "1";//不显示
                }
                else
                {
                    $scope.sylArray[i].ym = "0";//月末
                }
            }
            //第一天和最后一天显示
            $scope.sylArray[0].status = "0";
            $scope.sylArray[$scope.sylArray.length - 1].status = "0";
            //最后一天作为月末数据，点击显示相同月份其他数据
            $scope.sylArray[$scope.sylArray.length - 1].ym = "0";
        }
    }

    //查询收益率
    var message = {};
    message['modelid'] = $scope.oneStockPoolID;
    message['page.size'] = "max";
    message['page.no'] = "";
    ajaxService.sendMessage('model.selectmodeldayqsaction', message, $scope.selectstockpoolprofitdayactionCallBack);

    //历史净值点击显示
    $scope.sylItemClick = function(_obj)
    {
        //console.log("月份", _obj.ym);
        if(_obj.ym == "0")//为月末，点击后显示对应月全部
        {
            for(var i = 1;i<$scope.sylArray.length;i++)//第一个无需处理，一直显示
            {
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "1")//同一月份且不为月末的状态切换
                {
                    if($scope.sylArray[i].status == "0")
                    {
                        $scope.sylArray[i].status = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].status = "0";
                    }
                }
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "0")//月末
                {
                    if($scope.sylArray[i].ymshow == "0")
                    {
                        $scope.sylArray[i].ymshow = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].ymshow = "0";
                    }
                }
            }
        }
    }

    //获取跟投模拟收益
    $scope.getgentoumonisyCallBack = function(_data)
    {
        $scope.moniInfoArray = [];
        console.log("模拟跟投",_data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.monilist;
            for (var item in element)
            {
                obj = {};
                obj.label = ((element[item]['cszj'])/10000).toFixed(0) + "万";//初始资金//element[item]['cszj'] + "元";
                obj.zsy = parseFloat(element[item]['sy']).toFixed(2) + "元";//总收益
                obj.syl = element[item]['syl'];//总收益率
                obj.zzc = element[item]['zzc'];//总资产
                obj.account = element[item]['account'];//跟投账号
                $scope.moniInfoArray.push(obj);
            }
        }

    }


    //获取跟投模拟收益
    var message = {};
    message['modelid'] = $scope.oneStockPoolID;
    ajaxService.sendMessage('gentou.getgentoumonisyaction', message, $scope.getgentoumonisyCallBack);



    $scope.p_selectfocusedmodelCallBack = function(_data)
    {
        $scope.ygzmxArray = [];
        console.log("关注的组合", _data)
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.modellist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.modelid = arr[i].modelid;
                $scope.ygzmxArray.push(obj);
            }

            for(var j = 0;j<$scope.ygzmxArray.length;j++)
            {
                if($scope.ygzmxArray[j].modelid == $scope.oneStockPoolID)
                {
                    $scope.isgzMark = true;
                    break;
                }
            }

            $scope.gzDivShow = true;
        }
    }

    $scope.ygzmxArray = [];//已经关注的模型
    //查询关注的组合，用来对比当前组合是不是已经关注
    var message = {};
    message['userid'] = $scope.userObj.f_id;
    message['page.size'] = "max";
    message['page.no'] = "";
    ajaxService.sendMessage('sunflower.p_selectfocusedmodel', message, $scope.p_selectfocusedmodelCallBack);


    //返回上一层
    $scope.backStockList = function()
    {
        //peoplespace:他人空间；myspace：自己空间

        //if($scope.backurl == "peoplespace")
        //{
        //    //window.location.href="peopleSpaceBase.html?index=4&&opentype=newwebview";
        //    window.location.href="peopleSpaceBase.html?index=4";
        //}
        //else if($scope.backurl == "myspace")
        //{
        //    window.location.href="uufpBase.html?baseindex=4&more=zxmx";
        //}
        window.location.href= getbackList();
    }

    //changeTab
    $scope.changeTab = function(_str)
    {
        if(_str == "1") {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
        }
        else if(_str == "2"){
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
        }
        else
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
        }
    }

    //显示收益率列表
    $scope.gotoYield = function()
    {
        $scope.sylListShow = true;
        $scope.ptitleShow = false;
        $scope.tabOneShow = false;
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    //返回股票池主页面
    $scope.backto = function()
    {
        $scope.sylListShow = false;//历史净值
        $scope.ptitleShow = true;
        $scope.tabOneShow = true;
        $scope.positionShow = false;
    }

    $scope.xxcwbackto = function()
    {
        $scope.positionShow = false;//详细持仓
        $scope.ptitleShow = true;
        $scope.tabThreeShow = true;
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    //显示持仓
    $scope.goPosition = function()
    {
        $scope.positionShow = true;//详细持仓
        $scope.ptitleShow = false;
        $scope.tabThreeShow = false;
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    //显示调仓记录
    $scope.changeRecordHistory = function()
    {
        $scope.positionShow = false;
        $scope.changeRecordHistoryShow = true;
        $scope.changeRecordArray = [];

        //查询调仓历史
        var message = {};
        message['modelid'] = $scope.oneStockPoolID;
        message['page.no'] = "";
        message['page.size'] = "max";
        ajaxService.sendMessage('model.selectmodelchangerecordaction', message, $scope.selectstockpoolchangerecordCallBack);

    }

    //查询调仓历史
    $scope.selectstockpoolchangerecordCallBack = function(_data)
    {
        console.log("调仓记录",_data)
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.modelchangerecordlist;
            var i = 0;
            for (var item in element)
            {
                var obj = {};
                var str = element[item]['createtime'].toString();//创建时间
                obj.datetime = str;
                obj.date = str.substr(0,10);//"2015-04-09";
                obj.time = str.substr(11,8);//"12:09:31";
                /*if(i%2 == 0)
                 {
                 obj.tcsm = "调仓说明：" + "54350495说明";
                 }
                 else if(i%3 == 0)
                 {
                 obj.tcsm = "调仓说明：" + "54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明54350495说明";
                 }
                 else
                 {
                 obj.tcsm = "";
                 }*/
                obj.tcsm = element[item]['desc'];//调仓说明
                if(obj.tcsm == undefined || obj.tcsm == "")
                {
                    obj.tcsm = "";
                }
                else
                {
                    obj.tcsm = "调仓说明：" + obj.tcsm;
                }
                //console.log(obj.tcsm);
                var arr = [];
                var childelement = element[item]['detaillist'];
                for (var item2 in childelement)
                {
                    var obj2 = {};
                    obj2.gpdm = childelement[item2]['stockcode'];//股票代码
                    obj2.gpmc = childelement[item2]['stockname'];//股票名称
                    obj2.before = (childelement[item2]['tcqbl'] * 100).toFixed(2) + "%";//调仓前比例
                    obj2.after = (childelement[item2]['tchbl'] * 100).toFixed(2) + "%";//调仓后比例
                    obj2.tc = obj2.before + " → " + obj2.after;
                    arr.push(obj2);
                }
                obj.data = arr;
                if(i == 0)
                {
                    obj.status = '0';
                }
                else
                {
                    obj.status = '1';
                }
                i = i+1;
                $scope.changeRecordArray.push(obj);
            }
        }
    }

    //打开某一个调仓记录
    $scope.openchangeRecordItem = function(_obj)
    {
        //当前只显示一个
        /*for(var i = 0;i<$scope.changeRecordArray.length;i++)
         {
         if($scope.changeRecordArray[i].status == "0") //0：显示，1;隐藏
         {
         if($scope.changeRecordArray[i].datetime == _obj.datetime)//当前需打开的为之前打开的，则不操作
         {
         return;
         }
         else
         {
         $scope.changeRecordArray[i].status = "1";
         break;
         }
         }
         }
         _obj.status = "0";*/

        //两个状态切换
        if(_obj.status == "0")
        {
            _obj.status = "1";
        }
        else
        {
            _obj.status = "0";
        }

    }

    //关闭调仓记录
    $scope.closeRecordHistory = function()
    {
        $scope.positionShow = true;
        $scope.changeRecordHistoryShow = false;
    }


    //显示一个模拟跟盘
    $scope.onemoniClick = function(_obj)
    {
        $scope.ptitleShow = false;
        $scope.tabTwoShow = false;
        $scope.onemoniShow = true;
        $scope.onemoniTitle = _obj.label;
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶

        //一个模拟跟盘收益率
        $scope.onemonisylArray = {};
        var message = {};
        message['account'] = _obj.account;
        message['kssj'] = "";
        message['jssj'] = "";
        ajaxService.sendMessage('counter.getsecurityhisnetaction', message, $scope.getsecurityhisnetactionCallBack);


        //一个模拟跟盘持仓
        $scope.onemoniccArray = [];
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['account'] = _obj.account;
        message['combpositionid'] = "default";
        //console.log("模拟跟盘持仓", _obj.account);
        ajaxService.sendMessage('counter.selectsecuritypositionaction', message, $scope.selectsecuritypositionationCallBack);
    }

    //跟投收益率
    $scope.getsecurityhisnetactionCallBack = function(_data)
    {
        console.log("一个模拟跟投收益率",_data);
        var syldata = [];
        if(_data.op.code.toString() == "Y") {
            var element = _data.netlist;
            for (var item in element)
            {
                var obj = {};
                var str = element[item]['day'].toString();
                obj.label= str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                var va = parseFloat(element[item]['net']) -1;
                obj.value = parseFloat(va*100).toFixed(2);//收益率
                //console.log(obj.value);
                syldata.push(obj);
            }
        }

        var labarr = [];//收益率图label
        var dataarr = [];//收益率图data

        var sylmax = 0;//最大值
        if(syldata.length>0)
        {
            sylmax = Math.abs(syldata[0].value);
        }

        for(var i = 0;i<syldata.length;i++)
        {
            labarr.push(syldata[i].label);
            dataarr.push(syldata[i].value);
            sylmax = Math.max(sylmax, Math.abs(syldata[i].value));
        }
        if((sylmax.toString()).indexOf(".",0) != -1)
        {
            $scope.onemonisylstep = (sylmax.toString()).indexOf(".",0) *10;
        }
        else
        {
            $scope.onemonisylstep = sylmax.toString().length * 10;
        }
        var max = (Math.floor(sylmax/$scope.onemonisylstep) + 1)*$scope.onemonisylstep;
        // console.log(max)
        $scope.onemonisylscaleStepWidth = max/2;
        $scope.onemonisylscaleStartValue = -1*max;

        $scope.onemonisylArray = {};

        var valueObj = new Object();
        valueObj.fillColor = "rgba(220,220,220,0.5)";
        valueObj.strokeColor = "rgba(220,220,220,0.8)";
        valueObj.highlightFill = "rgba(220,220,220,0.75)";
        valueObj.highlightFill = "rgba(220,220,220,1)";
        valueObj.data = dataarr;

        var datasetsArr = [];
        datasetsArr.push(valueObj);
        $scope.onemonisylArray.labels = labarr;
        $scope.onemonisylArray.datasets = datasetsArr;

        //曲线图
        var ctx2 = document.getElementById("gtchart_line").getContext("2d");
        var myNewChart2 = new Chart(ctx2).Line($scope.onemonisylArray, {
            responsive : false,//是否响应，移动到图形上，出现相应的点值
            animation: false ,//是否有动画效果
            scaleLabel : "<%=value%>%",//显示百分比
            showTooltips: false,
            pointDot : false,      //是否显示点
            scaleOverride :true ,   //是否用硬编码重写y轴网格线
            scaleSteps : $scope.onemonisylscaleSteps,       //y轴刻度的个数
            scaleStepWidth : $scope.onemonisylscaleStepWidth,   //y轴每个刻度的宽度
            scaleStartValue : $scope.onemonisylscaleStartValue   //y轴的起始值
        });

    }

    //跟投持仓
    $scope.selectsecuritypositionationCallBack = function(_data)
    {
        console.log("一个模拟跟投持仓",_data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.securitypositionlist;
            for (var item in element)
            {
                var obj = {};
                obj.account= element[item]['account'];//账号
                obj.gpdm = element[item]['code'];
                obj.gpmc = element[item]['name'];
                obj.market = element[item]['exchange'].toUpperCase();//交易所
                obj.tc = obj.market + obj.gpdm;
                obj.sz = (parseFloat(element[item]['sz'].toString())).toFixed(2);//市值
                obj.zd = (parseFloat(element[item]['fdyk'].toString())).toFixed(2);//浮动盈亏,涨跌
                if(obj.zd == "-0.00")
                {
                    obj.zd = "0.00";
                }
                obj.zdf = (parseFloat(element[item]['fdyk'].toString())/parseFloat(element[item]['zcb'].toString())).toFixed(2);//涨跌幅
                if(obj.zdf == "-0.00")
                {
                    obj.zdf = "0.00";
                }
                obj.cc = (parseFloat(element[item]['kysl'].toString()) + parseFloat(element[item]['djsl'].toString())).toFixed(0);//持仓= 可用数量+冻结数量
                obj.kysl = (parseFloat(element[item]['kysl'].toString())).toFixed(0);//可用数量
                obj.dqj = (parseFloat(element[item]['dqj'].toString())).toFixed(2);//当前价
                obj.cbj = (parseFloat(element[item]['cbj'].toString())).toFixed(2);//成本价

                //颜色
                if(parseFloat(obj.zd)>=0)
                {
                    obj.color = "#ff0000";
                }
                else
                {
                    obj.color = "#00853E";
                }
                $scope.onemoniccArray.push(obj);
            }
        }
    }

    $scope.gzClick = function()
    {
        if($scope.gzMark)
        {
            $scope.gzMark = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['modelid'] = $scope.oneStockPoolID;
            ajaxService.sendMessage('sunflower.p_focusmodel', message, $scope.p_focusmodelCallBack);
        }

    }

    $scope.p_focusmodelCallBack = function(_data)
    {
        console.log("关注", _data)
        if(_data.op.code.toString() == "Y")
        {
            $scope.isgzMark = true;

            var obj = {};
            obj.modelid = $scope.oneStockPoolID;
            $scope.ygzmxArray.push(obj);
        }
        $scope.gzMark = true;
    }

    //取消关注
    $scope.qxgzClick = function()
    {
        if($scope.gzMark)
        {
            $scope.gzMark = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['modelid'] = $scope.oneStockPoolID;
            ajaxService.sendMessage('sunflower.p_unfocusmodel', message, $scope.p_unfocusmodelCallBack);
        }
    }

    $scope.p_unfocusmodelCallBack = function(_data)
    {
        console.log("取消关注", _data)
        if(_data.op.code.toString() == "Y")
        {
            $scope.isgzMark = false;

            for(var i = 0;i<$scope.ygzmxArray.length;i++)
            {
                if($scope.ygzmxArray[i].modelid == $scope.oneStockPoolID)
                {
                    $scope.ygzmxArray.splice(i,1);
                    break;
                }
            }
        }
        $scope.gzMark = true;
    }


    //从单个模拟跟盘界面返回
    $scope.onemoniBack = function()
    {
        $scope.ptitleShow = true;
        $scope.tabTwoShow = true;
        $scope.onemoniShow = false;
        $scope.onemoniTitle = "";
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                //alert("含有非数字字符");
                if(_str.charAt(i) != ".")
                {
                    return false;
                }
            }
        }
        return true;
    }
    //判断是否全为数值
    $scope.checkNumeric = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                //alert("含有非数字字符");
                return false;
            }
        }
        return true;
    }
}

