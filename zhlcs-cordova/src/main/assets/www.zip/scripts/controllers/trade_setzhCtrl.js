/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function trade_setzhCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.account = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.homeDivShow = true;//主界面信息
    $scope.deviceid = "";//设备号
    $scope.dzgkcheck = false;//是否大众公开
    $scope.hygkcheck = false;//是否好友公开
    $scope.szxyShow = false;//协议
    $scope.szsjyzShow = false;//手机验证
    $scope.firstszShow = false;//账户公开第一步
    $scope.secondseShow = false;//账户公开第二步
    $scope.firstErrorInfo = "";//第一步提示
    $scope.lastErrorInfo = "";
    $scope.finisheddivShow = false;//最后结束的界面
    $scope.sharepositon = "1";//1：专户发布成功；2：跟投设置成功

    $scope.zhfbsuccess = false;//账户发布成功
    $scope.gtszsuccess = false;//跟投设置成功

    $scope.sjyzError = "";//手机验证提示信息
    $scope.sjhm = "";//手机号
    $scope.sjyzm = "";//手机验证码
    $scope.syyzmhqz = false;//手机验证码获取中
    $scope.sjyzMark = true;//手机验证中
    $scope.kjszDivShow = false;//可见内容设置
    $scope.finishedzhfbdivShow = false;//专户发布
    $scope.gtszDivShow = false;//跟投设置
    $scope.sztabOneShow = false;//跟投设置第一步
    $scope.sztabTwoShow = false;
    $scope.sztabThreeShow = false;
    $scope.checkzxgtjeValue = 1;//最小跟投金额 万元
    $scope.setgtfcfs = "1";//分成方式 1：平台分成；2：免费
    $scope.gtfbMark = true;//跟投发布
    $scope.finishedgtszdivShow = false;//跟投设置成功界面

    $scope.settype = "";//1:初始公开操作，2：修改
    $scope.productid = "";//产品id
    //$scope.firstcanclick = false;//第一步能点击

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.gtname = "";//服务名称
    $scope.gtdesc = "";//理财计划
    $scope.gtminmoney = "";//最小跟投金额
    $scope.addMark = true;

    $scope.assetopenflaggentou = "Y";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "Y";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "Y";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "Y";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "Y";//对跟投者，交易指令公开

    $scope.assetopenflagall = "Y"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "Y";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "Y"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "Y";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "Y";//对大众，交易指令公开


    var localStorage = window.localStorage;
    //$scope.sessionID = localStorage.getItem('sessionid');
    $scope.account = localStorage.getItem('account');
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem("nickname"));
    $scope.accountzqgs = decodeURIComponent(localStorage.getItem('accountName'));
    $scope.accountShowValue = localStorage.getItem('accountShow');//界面显示用
    //alert("设备号   " + localStorage.getItem("deviceid"));
    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid") != undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }
    //alert("设备号   "+ $scope.deviceid);

    $scope.accountcompany = localStorage.getItem('accountcompany');//证券公司
    $scope.lcsstatus = localStorage.getItem("lcsstatus");

    $scope.settype = getParameter('type');
    $scope.productid = getParameter('productid');

    $scope.yzmintervalDuration = 1000;//间隔时间 1秒
    $scope.yzmintervalId;
    $scope.yzmdjsbegin = 180;//定时180秒
    $scope.yzmdjs;//定时值

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.yzmintervalIdClearInterval = function () {
        if ($scope.yzmintervalId != undefined) {
            clearInterval($scope.yzmintervalId);
        }
    }


    $scope.zhsetinit = function()
    {
        //if($scope.settype == '1')
        //{
            $scope.szxyShow = true;
            $scope.szsjyzShow = false;
            $scope.firstszShow = false;
            $scope.secondseShow = false;
            $scope.firstErrorInfo = "";
            //$scope.firstcanclick = false;
        //}

    }
    $scope.zhsetinit();

    //手机验证界面
    $scope.gotosjyzClick = function()
    {
        $scope.szxyShow = false;
        $scope.szsjyzShow = true;
        $scope.sjyzError = "";
        $scope.sjhm = "";
        $scope.sjyzm = "";
        $scope.syyzmhqz = false;
        $scope.sjyzMark = true;

        if(!!$scope.userObj.f_mobile)
        {
            $scope.sjhm = $scope.userObj.f_mobile;
        }
        else
        {
            $scope.sjhm = "";
        }
    }

    //获取手机验证码
    $scope.hqyzmClick = function()
    {
        if($scope.syyzmhqz == false)
        {
            var r = /^\d+(\.\d+)?$/;
            if(r.test($scope.sjhm) == false)
            {
                $scope.sjyzError = "请输入有效的手机号码";
                return;
            }
            if($scope.sjhm.length != 11)//11位手机号
            {
                $scope.sjyzError = "请输入有效的手机号码";
                return;
            }
            $scope.sjyzError = "";
            $scope.getsjyzm();
        }
    }

    //获取验证码
    $scope.getsjyzm = function()
    {
        var message = {};
        message['f_mobile'] = $scope.sjhm;
        //console.log("手机号码", message);
        ajaxService.sendMessage("user.sendVerifySMS", message, $scope.getsjyzmCallBack);
    }

    $scope.getsjyzmCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.sjyzError = "";
            $scope.syyzmhqz = true;
            $scope.yzmdjs = $scope.yzmdjsbegin;
            $scope.yzmintervalId = setInterval($scope.setyzminterval, $scope.yzmintervalDuration);
        }
        else
        {
            $scope.sjyzError = _data.op.info;
        }
    }

    //修改定时
    $scope.setyzminterval = function()
    {
        //console.log("333", $scope.yzmdjs);
        $scope.$apply(
            function(){
                $scope.yzmdjs = $scope.yzmdjs - 1;
            }
        );
        if($scope.yzmdjs == 0)
        {
            $scope.$apply(
                function(){
                    $scope.syyzmhqz = false;
                }
            );
            $scope.yzmintervalIdClearInterval();
        }
    }

    //手机验证
    $scope.sjyzclick = function()
    {
        if($scope.sjyzMark)
        {
            if($scope.sjyzm == "")
            {
                $scope.sjyzError = "请输入验证码";
                return;
            }
            else
            {
                $scope.sjyzMark = false;
                //手机验证
                var message = {};
                message['f_mobile'] = $scope.sjhm;
                message['f_content'] = $scope.sjyzm;
                //console.log("手机号码", message);
                ajaxService.sendMessage("user.verifySMS", message, $scope.sjyzmyzCallBack);
            }
        }
        //$scope.gotosz();
    }

    $scope.sjyzmyzCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            //console.log("验证通过");
            $scope.sjyzError = "";
            $scope.yzmintervalIdClearInterval();
            $scope.gotosz();
            $scope.changesjhm();

        }
        else
        {
            $scope.sjyzError = "验证码不正确";
        }
        $scope.sjyzMark = true;
    }

    $scope.gotosz = function()
    {
        $scope.szsjyzShow = false;
        $scope.firstszShow = true;
    }

    //可见的设置
    $scope.kjnrset = function()
    {
        $scope.homeDivShow = false;
        $scope.kjszDivShow = true;
    }
    $scope.kjszbackto = function()
    {
        $scope.homeDivShow = true;
        $scope.kjszDivShow = false;
    }

    //发布专户
    $scope.fbzhClick = function()
    {
        if($scope.gtname == "")
        {
            $scope.firstErrorInfo = "请先输入专户名称";
            return;
        }
        if($scope.gtname.length >8)
        {
            $scope.firstErrorInfo = "专户不超过8个字，请重新输入";
            return;
        }
        if($scope.gtdesc.length>30)
        {
            $scope.firstErrorInfo = "理财说明不超过30个字，请重新输入";
        }
        if($scope.hscheck == false && $scope.cybcheck == false &&  $scope.ggtcheck == false)
        {
            $scope.firstErrorInfo = "请选择需开通的业务";
            return;
        }
        if($scope.hygkcheck == false && $scope.dzgkcheck == false)
        {
            $scope.firstErrorInfo = "请确定谁可以看";
            return;
        }
        $scope.firstErrorInfo = "";
        if($scope.addMark)
        {
            $scope.firstErrorInfo = "专户发布中，请稍候...";
            $scope.addMark = false;
            var message = {};
            message['account'] = $scope.account;
            message['userid'] = $scope.userObj.f_id;
            message['name'] = $scope.gtname;
            if($scope.dzgkcheck)
            {
                message['property'] = "public";
            }
            else if($scope.hygkcheck)
            {
                message['property'] = "private";
            }
            message['desc'] = $scope.gtdesc;//描述
            message['bussiness'] = $scope.getktyw();
            message['assetopenflagall'] = $scope.assetopenflagall;
            message['clearpositionopenflagall'] = $scope.clearpositionopenflagall;
            message['positionamountopenflagall'] = $scope.positionamountopenflagall;
            message['positionvarietyopenflagall'] = $scope.positionvarietyopenflagall;
            message['tradecommandopenflagall'] = $scope.tradecommandopenflagall;
            //console.log("发布跟投",message);
            //$scope.gotofbzhfinished();
            ajaxService.sendMessage("sunflower.p_addproduct", message, $scope.p_addproductCallBack);
        }
    }

    $scope.p_addproductCallBack = function(_data)
    {
        //console.log("发布成功",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.productid = _data.productid;
            $scope.firstErrorInfo = "";
            $scope.gotofbzhfinished();
        }
        else
        {
            $scope.lastErrorInfo = "专户发布失败，原因：" + _data.op.info;
        }
        $scope.addMark = true;
    }

    //发布专户结束
    $scope.gotofbzhfinished = function()
    {
        $scope.homeDivShow = false;
        $scope.finishedzhfbdivShow = true;
        $scope.zhfbsuccess = true;
        $scope.sharepositon = "1";
    }

    //跟投设置
    $scope.gotogtsz = function()
    {
        $scope.finishedzhfbdivShow = false;
        $scope.gtszDivShow = true;
        $scope.sztabOneShow = true;//跟投设置第一步
        $scope.checkzxgtjeValue = 1;
        $scope.sztabTwoShow = false;
        $scope.sztabThreeShow = false;

        $scope.setgtfcfs = "1";
        $scope.szgtdesc = "";
        $scope.szsecondErrorInfo = "";
        $scope.gtszlastErrorInfo = "";
    }

    //设置最小跟投金额
    $scope.checkzxgtje = function(_value)
    {
        $scope.checkzxgtjeValue = _value;
    }

    //第二步
    $scope.szgotosecond = function()
    {
        $scope.sztabOneShow = false;
        $scope.sztabTwoShow = true;
        $scope.sztabThreeShow = false;
    }

    //设置分成方式
    $scope.szfcfsClick = function(_str)
    {
        $scope.setgtfcfs = _str;
    }

    $scope.szgotofirst = function()
    {
        $scope.sztabOneShow = true;
        $scope.sztabTwoShow = false;
        $scope.sztabThreeShow = false;
    }

    //第三步
    $scope.szgotothird = function()
    {
        if($scope.szgtdesc == "")
        {
            $scope.szsecondErrorInfo = "请输入跟投说明";
            return;
        }
        $scope.szsecondErrorInfo = "";

        $scope.sztabOneShow = false;
        $scope.sztabTwoShow = false;
        $scope.sztabThreeShow = true;

    }

    //确认发布跟投
    $scope.gtszqrClick = function()
    {
        if($scope.gtfbMark)
        {
            $scope.gtfbMark = false;
            var message = {};
            message['productid'] = $scope.productid;
            message['userid'] = $scope.userObj.f_id;
            message['minmoney'] = $scope.checkzxgtjeValue * 10000;
            message['assetopenflaggentou'] = $scope.assetopenflaggentou;
            message['clearpositionopenflaggentou'] = $scope.clearpositionopenflaggentou;
            message['positionamountopenflaggentou'] = $scope.positionamountopenflaggentou;
            message['positionvarietyopenflaggentou'] = $scope.positionvarietyopenflaggentou;
            message['tradecommandopenflaggentou'] = $scope.tradecommandopenflaggentou;
            if($scope.setgtfcfs == "1")
            {
                message['settletype'] = "P";
            }
            else if($scope.setgtfcfs == "2")
            {
                message['settletype'] = "N";
            }
            message['gentoudesc'] = $scope.szgtdesc;
            message['gentouconfirm'] = "N";//需确认：Y；不需确认：N
            //$scope.gotogtszfinished();
            ajaxService.sendMessage("sunflower.p_updateproduct", message, $scope.gtszqrCallBack);
        }
    }

    $scope.gtszqrCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.gotogtszfinished();
        }
        else
        {
            $scope.gtszlastErrorInfo = "跟投设置失败，原因：" + _data.op.info;
        }

        $scope.gtfbMark = true;
    }

    $scope.gotogtszfinished = function()
    {
        $scope.finishedgtszdivShow = true;
        $scope.gtszDivShow = false;
        $scope.gtszsuccess = true;
        $scope.sharepositon = "2";
    }

    //修改手机号码
    $scope.changesjhm = function()
    {
        if($scope.sjhm != $scope.userObj.f_mobile)//两者不同则提交
        {
            var message = {};
            message['user.id'] = $scope.userObj.f_id;
            message['user.mobile'] = $scope.sjhm;
            ajaxService.sendMessage("user.updateuser", message, $scope.updateuserCallBack) ;
        }
    }

    $scope.updateuserCallBack = function(_data)
    {
        //console.log("修改资料", _data);
        if(_data.op.code.toString() == "Y")
        {
            var localStorage = window.localStorage;
            $scope.userObj.f_mobile = $scope.sjhm;
            localStorage.setItem("user", JSON.stringify($scope.userObj));
        }
        else
        {
            //console.log("手机号修改失败，原因：" + _data.op.info);
        }
    }

    //查看平台分成条款
    $scope.ckptfctk = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
    }


    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI($scope.userName) + encodeURI('邀请您关注专户 "' + $scope.gtname + '"');
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        if($scope.gtdesc != "")
        {
            var desc = encodeURI("理财说明：" + $scope.gtdesc);
        }
        else
        {
            var desc = "";
        }
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = encodeURI($scope.userName) + encodeURI('邀请您关注专户 "' + $scope.gtname + '"');
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        if($scope.gtdesc != "")
        {
            var desc = encodeURI("理财说明：" + $scope.gtdesc);
        }
        else
        {
            var desc = "";
        }
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        if($scope.sharepositon == "1")//专户发布成功
        {
            $scope.finishedzhfbdivShow = false;
        }
        else if($scope.sharepositon == "2")//跟投设置成功
        {
            $scope.finishedgtszdivShow = false;
        }
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        if($scope.sharepositon == "1")//专户发布成功
        {
            $scope.finishedzhfbdivShow = true;
        }
        else if($scope.sharepositon == "2")//跟投设置成功
        {
            $scope.finishedgtszdivShow = true;
        }
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    //大众公开设置
    $scope.dzgkcheckClick = function()
    {
        $scope.dzgkcheck = !$scope.dzgkcheck;
        if($scope.lcsstatus == '2')//是理财师
        {
            if($scope.hygkcheck)
            {
                $scope.hygkcheck = false;
            }
        }
    }
    //大众公开设置
    $scope.hygkcheckClick = function()
    {
        $scope.hygkcheck = !$scope.hygkcheck;
        if($scope.lcsstatus == '2')//是理财师
        {
            if($scope.dzgkcheck)
            {
                $scope.dzgkcheck = false;
            }
        }
    }

    //针对大众的设置
    $scope.cpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflagall = $scope.sztrueValue($scope.assetopenflagall);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflagall = $scope.sztrueValue($scope.positionvarietyopenflagall);
            if($scope.positionvarietyopenflagall == "N")
            {
                $scope.positionamountopenflagall = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflagall == "Y")
            {
                $scope.positionamountopenflagall = $scope.sztrueValue($scope.positionamountopenflagall);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflagall = $scope.sztrueValue($scope.clearpositionopenflagall);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflagall = $scope.sztrueValue($scope.tradecommandopenflagall);
        }
    }

    //针对跟投者的设置
    $scope.gtzcpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflaggentou = $scope.sztrueValue($scope.assetopenflaggentou);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflaggentou = $scope.sztrueValue($scope.positionvarietyopenflaggentou);
            if($scope.positionvarietyopenflaggentou == "N")
            {
                $scope.positionamountopenflaggentou = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflaggentou == "Y")
            {
                $scope.positionamountopenflaggentou = $scope.sztrueValue($scope.positionamountopenflaggentou);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflaggentou = $scope.sztrueValue($scope.clearpositionopenflaggentou);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflaggentou = $scope.sztrueValue($scope.tradecommandopenflaggentou);
        }
    }

    //沪深
    $scope.hscheckClick = function()
    {
        $scope.hscheck = !$scope.hscheck;
    }
    //创业板
    $scope.cybcheckClick = function()
    {
        $scope.cybcheck = !$scope.cybcheck;
    }
    //港股通
    $scope.ggtcheckClick = function()
    {
        $scope.ggtcheck = !$scope.ggtcheck;
    }

    $scope.sztrueValue = function(_str)
    {
        var str ="";
        if(_str == "Y")
        {
            str = "N";
        }
        else
        {
            str = "Y";
        }
        return str;
    }

    $scope.getktyw = function()
    {
        var str = "";
        if($scope.hscheck)
        {
            str = "A";
        }
        if($scope.cybcheck)
        {
            if(str == "")
            {
                str = "C";
            }
            else
            {
                str = str + ",C";
            }
        }
        if($scope.ggtcheck)
        {
            if(str == "")
            {
                str = "H";
            }
            else
            {
                str = str + ",H";
            }
        }
        return str;
    }

    //返回
    $scope.gkszbackto = function()
    {
        //if($scope.settype == "1")
        //{
            if($scope.zhfbsuccess)//专户发布成功
            {
                window.location.href = "tradeBase_bgt.html";
            }
            else
            {
                window.location.href = "tradeBase_wgt.html";
            }
        //}
        //else
        //{
        //    window.location.href = getbackList();
        //}

    }

    $scope.backtoP = function()
    {
        $scope.gkszbackto();
    }
}




