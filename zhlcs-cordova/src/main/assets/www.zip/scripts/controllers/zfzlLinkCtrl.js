﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */


function zfzlLinkCtrl($scope, ajaxService, $cookieStore)
{
    //$scope.title = decodeURIComponent(getParameter("title"));

    //$scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    //$scope.peopleID = getParameter("fid");
    $scope.peopleName = decodeURI(getParameter("peopleName"));

    $scope.mainShow = true;
    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.openurlstr = decodeURI(getParameter("url"));

    $scope.setopenurlstr = "";
    $scope.seturlbeforestr= "";

    $scope.init = function()
    {
        console.log("init", $scope.openurlstr);
        if($scope.openurlstr != "")
        {
            var ind = $scope.openurlstr.indexOf(";",0);
            var beforestr = $scope.openurlstr.substring(0, ind);
            console.log("前",beforestr);
            var index1 = beforestr.indexOf("/",0);
            var index2 = beforestr.indexOf(".",0);
            beforestr = beforestr.substring(index1+1, index2);
            $scope.seturlbeforestr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/" + beforestr +  "_share.html";
            console.log("前",beforestr);


            $scope.openurlstr = $scope.openurlstr.replace(/;/,"?");
            $scope.openurlstr = $scope.openurlstr.replace(/,/g,"&");
            $scope.setopenurlstr = $scope.openurlstr.substr(ind);
            console.log($scope.setopenurlstr);
            console.log($scope.openurlstr);
            document.getElementById("urlIframe").src = $scope.openurlstr;


        }
    }

    $scope.init();

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = $scope.peopleName + "的专访";
        var desc = '专户理财师，人人都有自己的专户理财师～～';
        var _content = $scope.seturlbeforestr + $scope.setopenurlstr;
        //console.log(_content);

        //console.log(_content);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {

        var title = $scope.peopleName + "的专访";
        var desc = '专户理财师，人人都有自己的专户理财师～～';
        var _content = $scope.seturlbeforestr + $scope.setopenurlstr;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard($scope.seturlbeforestr+$scope.setopenurlstr);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var str = $scope.setopenurlstr;
        var index1 = str.indexOf("lcsname=", 0);
        var str2 = $scope.setopenurlstr.substr(index1);
        var index2 = str2.indexOf("=", 0);
        var str3 = str2.substr(index2+1);

        var str4 = str.substring(0,index1-1) + "&lcsname=" + encodeURI(str3) + str.substr(index1 + 8 + str3.length+1);
        //var dzstr = $scope.seturlbeforestr+$scope.setopenurlstr;
        var dzstr = $scope.seturlbeforestr + str4;
        //console.log("二维码", dzstr);
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:250,height:250});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    $scope.backClick = function()
    {
        //window.location.href = "back";
        closeNewBrowser();
    }

}







