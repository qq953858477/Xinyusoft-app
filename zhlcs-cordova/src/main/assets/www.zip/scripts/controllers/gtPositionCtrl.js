/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function gtPositionCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.username = "";
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.backtitle = "";

    $scope.gtLcsCPlist = [];//好友发布中的
    $scope.gethyspz = [];//好友实盘中的

    var ind = getParameter("index");
    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));

    $scope.ccylArray = [];
    $scope.stocklist = [];
    $scope.order = "0";//0-不排序 1-升序 2-降序
    $scope.orderobj = "";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

    $scope.gtccylCallBack = function(_data)
    {
        //console.log("hq", _data);
        $scope.stocklist = [];

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.asset = arr[i].asset;//类型
                obj.gpdm = arr[i].symbol;
                obj.zqjc = arr[i].name;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                //obj.xzzt = "1";//选中状态，样式更改
                obj.zd = parseFloat(arr[i].zd.toString());
                obj.zdf = parseFloat(arr[i].zdf.toString());
                //if (obj.status == '3')
                //{
                //    obj.zdf = -10000;
                //    obj.zd = -10000;
                //}
                $scope.stocklist.push(obj);
            }
        }
    }

    $scope.getuserpositionactionCallBack = function(_data)
    {
        //console.log("跟投持仓一览", _data);
        $scope.ccylArray = [];
        if(_data.op.code.toString()== 'Y')
        {
            var str = "";
            //console.log("持仓一览",_data);
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.stocklist;
                for(var i = 0;i<arr.length;i++)
                {
                    if(i == 0)
                    {
                        str = arr[i];
                    }
                    else
                    {
                        str = str + "|" + arr[i];
                    }
                }
            }

            if(str != "")
            {
                str = str.toLowerCase();
                //console.log("12", str);
                var message = {};
                message['symbols'] = str;
                ajaxService.sendMessage('hq.getselfrecard', message, $scope.gtccylCallBack);
            }
        }
    }

    $scope.getqzcp = function()
    {
        //可跟投好友，可报名、可查看的实盘中的
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage('sunflower.getuserpositionaction', message, $scope.getuserpositionactionCallBack)
    }

    $scope.qzgtinit = function()
    {
        $scope.getqzcp();
    }

    $scope.qzgtinit();


    $scope.sortStock = function (obj)
    {
        if($scope.orderobj == "")//初始化，未排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else if($scope.orderobj == "+index")//回复原数据排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else
        {
            var str = obj.substr(0,1);//取出符号 ：+ ，-
            obj = obj.substr(1, obj.length-1);
            if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
            {
                if($scope.order == "1")//升序
                {
                    $scope.orderobj = "+index"; //下标升序
                    $scope.order = "0";//回复原序列
                }
                else if($scope.order == "2")
                {
                    $scope.orderobj = "+" + obj;
                    $scope.order = "1";//升序
                }
                else
                {
                    $scope.orderobj = "-" + obj;
                    $scope.order = "2";//降序
                }
            }
            else//不同排序字段
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        }

    }

    $scope.ggClick = function(_obj)
    {
        if(_obj.asset == "0" || _obj.asset == "5")//股票和基金
        {
            var obj = {};
            obj.stockcode = _obj.gpdm;
            obj.stockname = encodeURIComponent(_obj.zqjc);
            obj.exchange = _obj.exchange.toLowerCase();
            obj.asset = _obj.asset;
            var localStorage = window.localStorage;
            localStorage.setItem("stockInfo", JSON.stringify(obj));
            //window.location.href = "onestockHQHtml.html";
            xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        }

    }

    //返回
    $scope.qzgtbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }
}




