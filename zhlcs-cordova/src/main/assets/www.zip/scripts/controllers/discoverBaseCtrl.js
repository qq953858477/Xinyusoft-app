function discoverBase()
{
    return {
        restrict: 'E',
        //templateUrl: 'index.html',
        templateUrl: 'discoverBase.html',
        //controller:['$scope','ajaxService','$cookieStore',myFinancialBaseCtrl],
        //template: '<span>Hi there444</span>',
        //replace: true,
        transclude: true
    };
}


/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function discoverBaseCtrl($scope, ajaxService, $cookieStore) {

    $scope.sessionID = "";//session
    //$scope.userObj = {};//客户信息
    $scope.index = "2";//跳转至当前页面时的位置
    $scope.fxListshow = false;
    $scope.splistShow = false;//理财师列表
    $scope.onepersonsplistDivShow = false;//单个理财师视频列表
    $scope.onespDivShow = false;//单个视频界面
    $scope.hdlistShow = false;//活动列表
    $scope.hdDivshow = false;//活动
    $scope.kbDivshow = false;//快报
    $scope.onehdsrc = "";//选中活动的图片
    $scope.hdindex = "1";//当前活动
    $scope.hdtitle = "";//当前活动标题
    $scope.hdfxintervalId;//定时

    $scope.ljsypjlistShow = false;//累计收益榜
    $scope.jrsypjlistShow = false;
    $scope.jpDivshow = false;//解盘


    $scope.selectpersonObj = {};//被选中的理财师视频列表
    $scope.selectspTitle = "";

    $scope.splistArray = [];//发现功能列表数组
    $scope.lcskbList = [];//快报

    $scope.spObj = {};//被选中的视频
    $scope.spObj.desc = "";
    $scope.spObj.src = "";

    var obj = {};
    obj.desc = "";
    obj.title = "廖英强老师解盘";
    obj.id = "1";
    obj.iconurl = "images/video006.png";

    var arr = [];
    var obj2 = {};
    obj2.sptitle = "廖英强老师1027《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1487";
    arr.push(obj2);
	
    obj2 = {};
    obj2.sptitle = "廖英强老师1026《晚间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1473";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1026《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1466";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1023《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1440";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1022《晚间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1419";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1022《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1408";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1021《晚间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1388";
    arr.push(obj2);
	obj2 = {};
    obj2.sptitle = "廖英强老师1021《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1377";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1020《晚间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1359";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1020《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1339";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1019《晚间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1328";
    arr.push(obj2);
	
	obj2 = {};
    obj2.sptitle = "廖英强老师1019《午间解盘》";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1319";
    arr.push(obj2);
	
    obj.splist = arr;
    $scope.splistArray.push(obj);

    var obj = {};
    obj.desc = "";
    obj.title = "张清华老师解盘";
    obj.id = "2";
    obj.iconurl = "images/video002.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "张清华解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1481";
	arr.push(obj2);
	
    var obj2 = {};
    obj2.sptitle = "张清华解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1453";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151022";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1426";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1394";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1367";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1333";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1304";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1280";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1252";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151013";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1227";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1202";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "张清华解盘151009";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1174";
	arr.push(obj2);
	
    obj.splist = arr;
    $scope.splistArray.push(obj);

    var obj = {};
    obj.desc = "";
    obj.title = "毛鹏皓老师解盘";
    obj.id = "3";
    obj.iconurl = "images/video009.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1482";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1455";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1396";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1369";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1335";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1305";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1282";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1254";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151013";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1228";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1204";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151010";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1175";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "毛鹏皓解盘151008";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1171";
	arr.push(obj2);
	
	obj.splist = arr;
    $scope.splistArray.push(obj);

    var obj = {};
    obj.desc = "";
    obj.title = "郑凯元老师解盘";
    obj.id = "4";
    obj.iconurl = "images/video005.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "郑凯元解盘151027";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1488";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1468";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1446";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151022";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1421";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1387";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1360";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1327";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1301";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1275";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1248";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151013";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1224";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "郑凯元解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1197";
	arr.push(obj2);
	
	obj.splist = arr;
    $scope.splistArray.push(obj);

    var obj = {};
    obj.desc = "";
    obj.title = "刘军老师解盘";
    obj.id = "5";
    obj.iconurl = "images/video007.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "刘军解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1472";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1444";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151022";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1417";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1386";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1358";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1325";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1296";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1273";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1244";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1195";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘150925";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1085";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "刘军解盘150924";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1055";
	arr.push(obj2);
	obj.splist = arr;
    $scope.splistArray.push(obj);

    var obj = {};
    obj.desc = "";
    obj.title = "曾光辉老师解盘";
    obj.id = "6";
    obj.iconurl = "images/video004.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "曾光辉解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1477";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1450";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151022";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1424";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1391";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1364";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1329";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1303";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1278";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1245";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151013";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1222";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1200";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "曾光辉解盘150923";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1002";
	arr.push(obj2);
	obj.splist = arr;
    $scope.splistArray.push(obj);



    var obj = {};
    obj.desc = "";
    obj.title = "薛武辉老师解盘";
    obj.id = "7";
    obj.iconurl = "images/video001.png";
	
	var arr = [];
    var obj2 = {};
    obj2.sptitle = "薛武辉解盘151026";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1478";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151023";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1454";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151022";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1427";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151021";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1395";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151020";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1368";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151019";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1334";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151016";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1306";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151015";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1281";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151014";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1253";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151013";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1229";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151012";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1203";
	arr.push(obj2);
	
	var obj2 = {};
    obj2.sptitle = "薛武辉解盘151008";
    obj2.spsrc = "http://m.iguxuan.com/index.php?&a=show&catid=10&typeid=2&id=1172";
	arr.push(obj2);	
	obj.splist = arr;
    $scope.splistArray.push(obj);

    //链接点击
    $scope.fxItemClick = function(_str)
    {
        if(_str == "1")
        {
            $scope.fxListshow = false;
            $scope.jpDivshow = true;
            //var localStorage = window.localStorage;
            //localStorage.setItem("fx_jpan", "true");
            //$scope.baseBottomVisible(false);
            gotoUp();
        }
        else if(_str == "2")
        {
            $scope.fxListshow = false;
            $scope.hdlistShow = true;
            //var localStorage = window.localStorage;
            //localStorage.setItem("fx_jpan", "false");
            $scope.baseBottomVisible(false);
            gotoUp();
        }
        else if(_str == "3")
        {
            $scope.fxListshow = false;
            $scope.splistShow = true;//视频列表界面
            //var localStorage = window.localStorage;
            //localStorage.setItem("fx_jpan", "false");
            $scope.baseBottomVisible(false);
            gotoUp();
        }
        else if(_str == "4")
        {
            //setbackList("../uufpBase.html?baseindex=5");
            //window.location.href = "kxds/KLineGame.html?userid="+$scope.userObj.f_id + "&&unionid="+ $scope.userObj.f_openid;
            xinyuNewBrowser("kxds/KLineGame.html?userid="+$scope.userObj.f_id + "&openid="+ $scope.userObj.f_openid);
        }
        else if(_str == "5")
        {
            //window.location.href = "jtBase.html";
            xinyuNewBrowser("jtBase.html?opentype=newwebview");
        }
        else if(_str == "6")
        {
            //window.location = "benefitsList.html" + "?backtitle=" + encodeURI("发现");
            xinyuNewBrowser("benefitsList.html" + "?backtitle=" + encodeURI("发现") + "&&opentype=newwebview");
        }
        else if(_str == "7")
        {
            xinyuNewBrowser("newfpBase.html?backtitle=" + encodeURI("发现"));
            //window.location.href ="newfpBase.html?backtitle=" + encodeURI("跟投");
        }
        else if(_str == "8")
        {
            //window.location.href = "tradinglive.html" + "?backtitle=" + encodeURI("发现");
            xinyuNewBrowser("tradinglive.html" + "?backtitle=" + encodeURI("发现") + "&&opentype=newwebview");
        }
        else if(_str == "9")
        {
            $scope.fxListshow = false;
            $scope.kbDivshow = true;
            $scope.baseBottomVisible(false);
            $scope.getlcskb();
            gotoUp();
        }

        //if(_obj.type == "jrzfb" || _obj.type == "jrdfb")
        //{
        //    window.location.href = "updownBase.html?type="+_obj.type+"&&parentIndex=5";
        //}
    }

    //链接点击
    $scope.lcsItemClick = function(_str)
    {
        if(_str == "1")
        {
            $scope.fxListshow = false;
            $scope.jrsypjlistShow = true;
            $scope.lcsjrsyb();
            $scope.baseBottomVisible(false);
        }
        else if(_str == "2")
        {
            $scope.fxListshow = false;
            $scope.ljsypjlistShow = true;
            $scope.ljsyb();
            $scope.baseBottomVisible(false);
        }
        else if(_str == "3")
        {
            $scope.fxListshow = false;
            $scope.jpDivshow = true;

            $scope.baseBottomVisible(false);
        }
        else if(_str == "4")
        {
            $scope.fxListshow = false;
            $scope.ccylDivshow = true;
            $scope.getlcscc();
            $scope.baseBottomVisible(false);
        }
    }


    $scope.discinit = function(newValue, oldValue, scope)
    {
        //console.log("发现",newValue, oldValue);
        if(newValue)
        {
            //var localStorage = window.localStorage;
            //var jpmark = localStorage.getItem("fx_jpan");
            //console.log("jpmark",jpmark);
            //if(jpmark == "true")
            //{
            //    $scope.fxItemClick('1');
            //}
            //else
            //{
                $scope.backtofxList();
            //}
        }
        else
        {
            //console.log("jpmark2",jpmark);
            //var localStorage = window.localStorage;
            //localStorage.setItem("fx_jpan", "false");
        }
    }

    $scope.$watch('basetabFiveShow', $scope.discinit);



    $scope.backtofxList = function()
    {
        $scope.fxListshow = true;
        $scope.splistShow = false;//视频列表界面
        $scope.hdlistShow = false;
        $scope.kbDivshow = false;

        $scope.jrsypjlistShow = false;
        $scope.ljsypjlistShow = false;
        $scope.jpDivshow = false;
        $scope.ccylDivshow = false;

        //$scope.jpDivshow = false;
        //var localStorage = window.localStorage;
        //localStorage.setItem("fx_jpan", "false");
        $scope.baseBottomVisible(true);

        $scope.ccylthisClearInterval();
        gotoUp();
    }


    //快报
    $scope.getlcskb = function()
    {
        var message = {};
        message['count'] = "20";
        ajaxService.sendMessage('user.getnewsflashaction', message, $scope.getkbCallBack2);
    }

    $scope.getkbCallBack2 = function(_data)
    {
        //console.log("快报", _data);
        $scope.lcskbList = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.resultlist;
            for(var i = 0;i<arr.length;i++)
            {
                if(arr[i].type == "2")//运营后台发布的及时消息
                {
                    var obj = {};
                    obj.type = arr[i].type;
                    obj.title = arr[i].f_title;
                    obj.iconimg = arr[i].f_img;
                    obj.timestr = arr[i].f_createtime;
                    obj.url = arr[i].f_url;
                    $scope.lcskbList.push(obj);
                }
                if(arr[i].type == "1")//运营后台发布的及时消息
                {
                    var obj = {};
                    obj.type = arr[i].type;
                    obj.headicon = arr[i].f_head;
                    obj.name = arr[i].f_nickname;
                    var str = arr[i].f_cnt.toString();
                    if(str.length>100)
                    {
                        obj.content = str.substr(0,100);
                    }
                    else
                    {
                        obj.content = str;
                    }
                    obj.timestr = arr[i].f_createtime;
                    obj.userid = arr[i].f_userid;
                    $scope.lcskbList.push(obj);
                }
            }
        }
    }

    //快讯点击
    $scope.lcskxItemClick = function(_obj)
    {
        if(_obj.type == '2')
        {
            var str = encodeURI(_obj.url);
            var ref = cordova.InAppBrowser.open(str, "_blank", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
        }
        if(_obj.type == '1')
        {
            //window.location.href = "viewpointInfo.html?peopleID=" + _obj.userid + "&opentype=''";
            xinyuNewBrowser("viewpointInfo.html?peopleID=" + _obj.userid + "&opentype=newwebview");
        }
    }


    $scope.spItemClick = function(_obj)
    {
        $scope.splistShow = false;
        $scope.onepersonsplistDivShow = true;
        $scope.selectspTitle = _obj.title;
        $scope.selectpersonObj = _obj.splist;
        //$scope.onespDivShow = true;//单个视频界面
        //for(var i = 0;i<$scope.splistArray.length;i++)
        //{
        //    if(_str == $scope.splistArray[i].id)
        //    {
        //        $scope.spObj = $scope.splistArray[i];
        //        console.log($scope.spObj.src);
        //        document.getElementById("spiframe").src = $scope.spObj.src;
        //        gotoUp();
        //        break;
        //    }
        //}
    }

    $scope.onepersonsplistbackto = function()
    {
        $scope.splistShow = true;
        $scope.onepersonsplistDivShow = false;
        $scope.selectspTitle = "";
    }

    $scope.selectspClick = function(_obj)
    {
        $scope.onepersonsplistDivShow = false;
        $scope.onespDivShow = true;
        $scope.spObj = _obj;
        document.getElementById("spiframe").src = $scope.spObj.spsrc;
    }

    //视频返回
    $scope.onespbackto = function()
    {
        $scope.onepersonsplistDivShow = true;//实盘列表界面
        $scope.onespDivShow = false;//单个视频界面
        $scope.spObj = {};
        document.getElementById("spiframe").src = "";
        gotoUp();
    }

    $scope.onehdItemClick = function(_str)
    {
        $scope.hdlistShow = false;
        $scope.hdDivshow = true;
        $scope.hdindex = _str;
        $scope.hdtitle = "";
        if(_str == "1")
        {
            $scope.onehdsrc = "images/jlgz1.png";
            $scope.hdtitle = "推荐跟投用户奖励";
        }
        else if(_str == "2")
        {
            $scope.onehdsrc = "images/jlgz2.png";
            $scope.hdtitle = "推荐理财师奖励";
        }
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = $scope.hdtitle;
        var desc = '专户理财师，人人都有自己的专户理财师～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?activityindex=" + $scope.hdindex;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {

        var title = $scope.hdtitle;
        var desc = '专户理财师，人人都有自己的专户理财师～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?activityindex=" + $scope.hdindex;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.hdfxintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?activityindex=" + $scope.hdindex);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.hdfxintervalId != undefined)
        {
            clearInterval($scope.hdfxintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.hdDivshow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?activityindex=" + $scope.hdindex;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.hdDivshow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    //今日收益榜
    $scope.lcsjrsyb = function()
    {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductjrsyrank', message, function (data) {
            //console.log("收益",data);
            if (data['op']['code'] == 'Y') {
                $scope.lcsjrsybList = data['gentouproductlist'];
                for(var i = 0;i<$scope.lcsjrsybList.length;i++)
                {
                    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                    //console.log("ff", ff);
                    $scope.lcsjrsybList[i].jrsy= parseFloat($scope.lcsjrsybList[i].jrsy);
                    $scope.lcsjrsybList[i].ljsy= parseFloat($scope.lcsjrsybList[i].ljsy);

                    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                }
            }
        });
    }

    $scope.ljsyb = function () {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductljsyrank', message, function (data) {
            //console.log("收益",data);
            if (data['op']['code'] == 'Y') {
                $scope.gtljsybList = data['gentouproductlist'];
                for(var i = 0;i<$scope.gtjrsybList.length;i++)
                {
                    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                    //console.log("ff", ff);
                    $scope.gtjrsybList[i].jrsy= parseFloat($scope.gtjrsybList[i].jrsy);
                    $scope.gtjrsybList[i].ljsy= parseFloat($scope.gtjrsybList[i].ljsy);

                    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                }
            }
        });
    };


    $scope.stocklist = [];
    $scope.order = "0";//0-不排序 1-升序 2-降序
    $scope.orderobj = "";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
    $scope.ccylintervalId;
    $scope.ccylintervalDuration = 5000;//间隔时间，3000毫秒

    //去除
    $scope.ccylthisClearInterval = function () {
        if ($scope.ccylintervalId != undefined) {
            clearInterval($scope.ccylintervalId);
        }
    }

    //理财师持仓一览
    $scope.getlcscc = function()
    {
        var message = {};
        ajaxService.sendMessage('sunflower.getLcsPositionAction', message, $scope.getlcsccCallBack);
    }

    $scope.getlcsccCallBack = function(_data)
    {
        $scope.ccylArray = [];
        var str = "";
        //console.log("持仓一览",_data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.stocklist;
            for(var i = 0;i<arr.length;i++)
            {
                if(i == 0)
                {
                    str = arr[i];
                }
                else
                {
                    str = str + "|" + arr[i];
                }
            }
        }

        if(str != "")
        {
            str = str.toLowerCase();
            //console.log("12", str);
            var message = {};
            message['symbols'] = str;
            ajaxService.sendMessage('hq.getselfrecard', message, $scope.lcscchqCallBack);
        }

    }

    $scope.lcscchqCallBack = function(_data)
    {
        //console.log("hq", _data);
        $scope.stocklist = [];

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.asset = arr[i].asset;//类型
                obj.gpdm = arr[i].symbol;
                obj.zqjc = arr[i].name;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                //obj.xzzt = "1";//选中状态，样式更改
                obj.zd = parseFloat(arr[i].zd.toString());
                obj.zdf = parseFloat(arr[i].zdf.toString());
                //if (obj.status == '3')
                //{
                //    obj.zdf = -10000;
                //    obj.zd = -10000;
                //}
                $scope.stocklist.push(obj);
            }
        }
        //$scope.ccylthisClearInterval();
        //$scope.ccylintervalId = setInterval($scope.getlcscc, $scope.ccylintervalDuration);
    }

    $scope.ggClick = function(_obj)
    {
        if(_obj.asset == "0"|| _obj.asset == "5")//股票和基金
        {
            var obj = {};
            obj.stockcode = _obj.gpdm;
            obj.stockname = encodeURIComponent(_obj.zqjc);
            obj.exchange = _obj.exchange.toLowerCase();
            obj.asset = _obj.asset;
            var localStorage = window.localStorage;
            localStorage.setItem("stockInfo", JSON.stringify(obj));
            //window.location.href = "onestockHQHtml.html";
            xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        }

    }





    //排行榜
    $scope.gtsyphbItemClick = function(_obj)
    {
        //console.log($scope.userObj.f_id, _obj.user.user.f_id);
        if(_obj.user.user.f_id == $scope.userObj.f_id)
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.id + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_fwz_fbz.html?productid=" + _obj.id + "&&account=" + _obj.account + "&&opentype=newwebview");
        }
        else
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.id + "&&bgtuserid=" + _obj.user.user.f_id;
            xinyuNewBrowser("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.id + "&&bgtuserid=" + _obj.user.user.f_id + "&&opentype=newwebview");
        }
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList("uufpBase.html?baseindex=3");
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview");
    }

    $scope.backtohdList = function ()
    {
        $scope.hdlistShow = true;
        $scope.hdDivshow = false;
        $scope.onehdsrc = "";
    }
}




