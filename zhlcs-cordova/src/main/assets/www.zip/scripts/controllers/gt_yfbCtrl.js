
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_yfbCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.xxxgCvsShow = false;//信息修改界面

    $scope.productname = "";//产品名
    $scope.productid = "";//产品id
    $scope.ybmArray = [];//跟投报名
    $scope.dqgtgtzzc = 0;//跟投总资产

    $scope.tabOneShow = true;//报名
    $scope.tabTwoShow = false;//理财师
    $scope.index = "1";//默认显示报名
    $scope.bgtuserid = "";//被跟投者
    $scope.bmCvsShow = false;//报名操作开始

    $scope.xyDivShow = false;//协议
    $scope.bmfirstShow = true;//报名第一步
    $scope.bmsecondShow = false;//第二步
    $scope.bmthirdShow = false;//第三步
    $scope.bmfourthShow = false;//第四步

    $scope.plCount = "--";

    //$scope.secondErrorInfo = "";//第二步错误提示
    $scope.thirdErrorInfo = "";//第三步错误提示

    $scope.gtcpszInfo = null;//跟投理财师设置的信息
    $scope.cpqbMark = false;//账户金额全部
    $scope.kgtzj = "--";//可跟投资金
    $scope.gtMark = true;//可操作
    $scope.zhListArray = [];//可发布用的账户
    $scope.ybdzhListArray = [];//已经被绑定账户，发布：被跟投账户不可用

    $scope.fcfsArray = [];//分成方式
    $scope.fcfs = null;//选择的分成方式
    $scope.dqxzaccount = null;//当前选择的账户

    $scope.bgtuserid = "";//理财师id
    $scope.setzyzsShow = false;//设置止盈止损

    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "--";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.bmjzsjstr = "--";
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.yjtrzj = "--";//预计投入资金
    $scope.dqgtInfo.property = "";
    $scope.lcsInfo = {};//理财师信息
    $scope.lcsInfo.headurl = "images/wutouxian.png";
    $scope.lcsInfo.name = "--";

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.gtdesc = "";//理财计划
    $scope.gtminmoney = "";//最小跟投金额
    $scope.gtmaxmoney = "";//最大跟投金额
    $scope.fwyjtrzj = "";//预计投入资金
    $scope.dzgkcheck = false;//是否公开给大众
    $scope.bmjzsj;//报名截止时间
    $scope.bmjzsjstr = "";
    $scope.lcsstatus = "0";//是否是理财师 2：理财师，非2：不是理财师
    $scope.errorInfo = "";//提示信息
    $scope.tjMark = true;//提交中
    $scope.opentype = "";//打开方式

    $scope.gtztString = "";//产品状态
    $scope.cpzt = "";

    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.opentype = getParameter("opentype");
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息
    $scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作



    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });

    $scope.getgtbmlist = function()
    {
        $scope.ybmArray = [];
        //var obj = {};
        //obj.headurl = "images/touxiang.png";//发布者信息
        //obj.username = "黄磊";
        //obj.productname = "招财一号";
        //obj.productid = "cpid";//产品id
        //obj.gtje = 10000;//跟投金额
        //obj.fcfs = "2/8";//分成方式
        //obj.zyx = "20%";//止盈线
        //obj.zsx = "10%";//止损线
        //$scope.dqgtgtzzc = $scope.dqgtgtzzc + obj.gtje;
        //
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.headurl = "images/touxiang.png";
        //obj.username = "黄磊";
        //obj.productname = "招财二号";
        //obj.productid = "cpid2";//产品id
        //obj.gtje = 10000;//跟投金额
        //obj.fcfs = "2/8";//分成方式
        //obj.zyx = "20%";//止盈线
        //obj.zsx = "10%";//止损线
        //$scope.dqgtgtzzc = $scope.dqgtgtzzc + obj.gtje;
        //$scope.dqgtArray.push(obj);
        var message = {};
        message['productid'] = $scope.productid;
        ajaxService.sendMessage('gentou.p_selectgentouapply',message, $scope.p_selectgentouapplyCallBack);

    }

    $scope.p_selectgentouapplyCallBack = function(_data)
    {
        console.log("被跟投情况：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinkapplylist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.headurl = arr[i].applyuser.user.f_head;//发布者信息
                obj.username = arr[i].applyuser.user.f_nickname;//发布者信息
                obj.productname = arr[i].productname;
                obj.productid = arr[i].productid;
                obj.gtje = arr[i].money;//跟投金额
                //var fc = (parseInt(arr[i].share)/10);
                console.log(arr[i].share);
                var fc = parseInt(arr[i].share)/10;
                obj.fcfs =  fc +":"+(10-fc);
                obj.zyx = arr[i].stopprofit//止盈线
                if(obj.zyx == undefined || obj.zyx == null || obj.zyx == "")
                {
                    obj.zyx = "--";
                }
                else
                {
                    obj.zyx = obj.zyx + "%";
                }
                obj.zsx = arr[i].stoploss;//止损线
                if(obj.zsx == undefined || obj.zsx == null || obj.zsx == "")
                {
                    obj.zsx = "--";
                }
                else
                {
                    obj.zsx = obj.zsx + "%";
                }

                $scope.dqgtgtzzc = $scope.dqgtgtzzc + parseFloat(obj.gtje);
                $scope.ybmArray.push(obj);
            }
        }

    }

    $scope.p_getgentouproductCallBack = function(_data)
    {
        console.log("产品："+ _data);
        $scope.fcfsArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            $scope.dqgtInfo.zq = product.gentouperiod;
            $scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.dqgtInfo.zxgtje = product.minmoney;
            $scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            $scope.dqgtInfo.yjtrzj = product.planmoney;//预计投入资金
            var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
            $scope.dqgtInfo.bmjzsj = str;//报名截止日期
            $scope.bmjzsjstr = $scope.dqgtInfo.bmjzsj.substr(0,4) + "-" + $scope.dqgtInfo.bmjzsj.substr(4,2) + "-" +  $scope.dqgtInfo.bmjzsj.substr(6,2);
            var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//服务结束时间
            $scope.dqgtInfo.fwjssj = str2;//服务结束时间
            var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3.substr(0,4) + "-" + str3.substr(4,2) + "-" + str3.substr(6,2);//服务开始时间
            $scope.dqgtInfo.fwkssj = str3;//服务开始时间
            var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4.substr(0,10);//服务发布时间
            $scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            $scope.dqgtInfo.productfbzname = product.user.user.f_nickname;//产品发布者name
            $scope.dqgtInfo.property = product.property.toString();//公开方式，private,好友；大众：public
            $scope.dqgtInfo.bmjzsjstr = product.endapplytimedesc;

            $scope.cpzt = product.status.toString();
            if($scope.cpzt == "A")
            {
                $scope.gtztString = "报名中";
            }
            else if($scope.cpzt == "G")
            {
                $scope.gtztString = "延期中";
            }

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }

            var sharearr = product.share;
            for(var i = 0;i<sharearr.length;i++)
            {
                var obj = {};
                obj.downprofit = sharearr[i].downprofit;//目标收益
                obj.share = sharearr[i].share;
                var fc = parseInt(obj.share)/10;
                obj.label = fc +":" +(10-fc) ;
                //obj.desc = "目标收益" +  sharearr[i].downprofit + "%后，跟投收益部分按照" + obj.label + "分成";
                if(fc == 2)
                {
                    obj.desc = "跟投用户实际收益超出平台基准收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；没有超出平台基准收益，理财师不分成";
                }
                else
                {
                    obj.desc = "跟投用户实际收益超出理财包目标收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；若未达到目标收益，按二八分成方式结算";
                }
                //obj.desc = sharearr[i].desc;
                //if(fc == 5)
                //{
                //    obj.desc = "实际收益大于理财包目标收益部分，理财师50%，跟投用户50%分成；没有超出目标收益，理财师不分成";
                //}
                //else
                //{
                //    obj.desc = "实际收益超出平台基准收益部分，理财师20%，跟投用户80%分成；没有超出平台基准收益，理财师不分成"
                //}
                obj.status = true;
                $scope.fcfsArray.push(obj);
            }

            if($scope.fcfsArray.length>0)
            {
                $scope.fcfs = $scope.fcfsArray[0];
            }

            var headastr = product.user.user.f_head;
            if(headastr != "" && headastr != undefined && headastr!= undefined)
            {
                $scope.lcsInfo.headurl = headastr;
            }

            $scope.lcsInfo.name = product.user.user.f_nickname;

        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);
    }

    $scope.p_getaccountlistCallBack = function(_data)
    {
        console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.check = false;
                obj.experience = element[item].experience.toString();
                if(obj.experience == "Y")
                {
                    obj.zqgsname = "跟投基金";
                }
                if(element[item].accountstatus.toString() != "c")//非绑定账户
                {
                    obj.gtlist = [];
                    if(element[item].accountstatus.toString() == "b")//普通用户
                    {
                        if(element[item].linkapplylist != undefined && element[item].linkapplylist != null)
                        {
                            //已报名
                            var arr1 = element[item].linkapplylist;
                            for(var i = 0;i<arr1.length;i++)
                            {
                                var obj2 = {};
                                obj2.bgtheadurl = arr1[i].linkuser.user.f_head;
                                obj2.bgtuserid = arr1[i].linkuser.user.f_id;
                                obj2.bgtusername = arr1[i].linkuser.user.f_nickname;
                                obj2.productid = arr1[i].productid;
                                obj2.productname = arr1[i].productname;
                                obj2.zq = arr1[i].gentouperiod;
                                obj2.mbsy = arr1[i].targetprofit + "%";//目标收益
                                var str = arr1[i].endapplytime.toString();
                                //obj2.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止时间
                                obj2.bmjzsj = str;//报名截止时间
                                obj2.status = "1";//已报名：1；跟投中(跟投)：3
                                obj.gtlist.push(obj2);
                            }
                        }
                        if(element[item].linklist != undefined && element[item].linklist != null)
                        {
                            //跟投他人
                            var arr2 = element[item].linklist;
                            for(var i = 0;i<arr2.length;i++)
                            {
                                var obj2 = {};
                                obj2.bgtheadurl = arr2[i].linkeduser.user.f_head;
                                obj2.bgtuserid = arr2[i].linkeduser.user.f_id;
                                obj2.bgtusername = arr2[i].linkeduser.user.f_nickname;
                                obj2.productid = arr2[i].productid;
                                obj2.productname = arr2[i].productname;
                                obj2.drsy = parseFloat(arr2[i].linkaccountmoney.jrsy);//当日收益
                                obj2.ljsy = parseFloat(arr2[i].linkaccountmoney.ljsy);//累计收益
                                var str = arr2[i].endgentoutime.toString();
                                //obj2.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);;//结束时间
                                obj2.jssj = str;//结束时间
                                obj2.status = "3";//已报名：1；跟投中(跟投)：3
                                obj.gtlist.push(obj2);
                            }
                        }
                    }
                    $scope.zhListArray.push(obj);
                }
                else
                {
                    obj.productid = element[item].product.id;
                    obj.productname = element[item].product.name;
                    $scope.ybdzhListArray.push(obj);
                }
            }
        }
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;

        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            $scope.$broadcast("setParameters", cstr);
            $scope.plmark = false;
        }
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }


    //初始相关操作界面
    $scope.yfbInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.productid = getParameter("productid");//产品id
            $scope.bgtuserid = $scope.userObj.f_id;
            $scope.lcsstatus = localStorage.getItem("lcsstatus");
            $scope.getgtbmlist();
            $scope.getdqgtInfo();
            $scope.getzhlb();
            $scope.changeTab($scope.index);
            $scope.getplcount();
            $scope.isguanzhuget();

        }catch (e){}
    }

    //$scope.yfbInit();

    $scope.appInit = function()
    {
        document.addEventListener('deviceready', function()
        {
            $scope.yfbInit();
        }, false);
    }
    $scope.appInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        xinyuNewBrowser("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }


    //跟投报名
    $scope.gtbmClick = function()
    {
        //setbackList(window.location.href);
        ////console.log("window.location", window.location.href);
        //window.location = "gtapply.html?productid=" + $scope.productid + "&&bgtuserid=" + $scope.userObj.f_id;
        $scope.mainShow = false;
        $scope.bmCvsShow = true;
        $scope.xyDivShow = true;
        //gotoUp();

    }

    //取消报名回到tab切换界面
    $scope.bmCancel = function()
    {
        $scope.mainShow = true;
        $scope.bmCvsShow = false;
        $scope.xyDivShow = false;
        $scope.bmsecondShow = false;
        $scope.bmthirdShow = false;
        $scope.bmfourthShow = false;

        $scope.dqxzaccount = null //选中的账户
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }

        $scope.thirdErrorInfo = "";
        $scope.kgtzj = "--";//可跟投资金
        $scope.gtcpszInfo = {};//跟投设置的信息
        $scope.gtcpszInfo.gtje = "";//跟投金额
        $scope.gtcpszInfo.zybfb = "";//止盈百分比
        $scope.gtcpszInfo.zsbfb = "";//止损百分比
        //$scope.fcfs = null;
        //for(var i = 0;i<$scope.fcfsArray.length;i++)
        //{
        //    if($scope.fcfsArray[i].status)
        //    {
        //        $scope.fcfsArray[i].status = false;
        //        break;
        //    }
        //}

        gotoUp();

    }

    $scope.gotosecondClick = function()
    {
        $scope.xyDivShow = false;
        $scope.bmsecondShow = true;
        gotoUp();
    }

    //返回协议界面
    $scope.backtoxyClick = function()
    {
        $scope.xyDivShow = true;
        $scope.bmsecondShow = false;
        gotoUp();
    }

    $scope.gotothirdClick = function()
    {
        //var mark = false;
        //for(var i = 0;i<$scope.zhListArray.length;i++)
        //{
        //    if($scope.zhListArray[i].check)
        //    {
        //        mark = true;
        //    }
        //}
        //
        if($scope.dqxzaccount == null)
        {
            //$scope.secondErrorInfo = "请选择账户";
            return;
        }

        //$scope.secondErrorInfo = "";
        $scope.thirdErrorInfo = "";
        $scope.kgtzj = "--";//可跟投资金
        $scope.gtcpszInfo = {};//跟投设置的信息
        $scope.gtcpszInfo.gtje = "";//跟投金额
        $scope.gtcpszInfo.zybfb = "";//止盈百分比
        $scope.gtcpszInfo.zsbfb = "";//止损百分比

        $scope.getkyzj();

        $scope.bmsecondShow = false;
        $scope.bmthirdShow = true;
        gotoUp();
    }

    //设置止盈止损
    $scope.setzyzsClick = function()
    {
        $scope.setzyzsShow = !$scope.setzyzsShow;
        if($scope.setzyzsShow == false)
        {
            $scope.gtcpszInfo.zybfb = "";//止盈百分比
            $scope.gtcpszInfo.zsbfb = "";//止损百分比
        }
    }

    $scope.p_kgtzjCallBack = function(_data)
    {
        //console.log("可用资金：", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.kgtzj = parseFloat(parseFloat(_data.kyzj).toFixed(2));
        }
    }

    //获取当前选择账户的可用资金
    $scope.getkyzj = function()
    {
        //$scope.kgtzj = 1000000;
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['account'] = $scope.dqxzaccount.account;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("gentou.p_kgtzj", message, $scope.p_kgtzjCallBack);
    }

    //选中全部金额
    $scope.gtcpzjqbClick = function()
    {
        //$scope.cpqbMark = !$scope.cpqbMark;
        //alert( $scope.lcsqbMark )
        //if($scope.cpqbMark)
        //{
        $scope.gtcpszInfo.gtje = (parseFloat($scope.kgtzj)).toFixed(2);
        //}
        //else
        //{
        //    $scope.gtcpszInfo.gtje = "";
        //}
    }
    $scope.zxgtjeClick = function()
    {
        $scope.gtcpszInfo.gtje = parseFloat($scope.dqgtInfo.zxgtje).toFixed(2);
    }

    $scope.zdgtjeClick = function()
    {
        $scope.gtcpszInfo.gtje = parseFloat($scope.dqgtInfo.zdgtje).toFixed(2);
    }


    $scope.gtjeChange = function()
    {
        $scope.cpqbMark = false;
    }

    $scope.backtosecondClick = function()
    {
        $scope.bmsecondShow = true;
        $scope.bmthirdShow = false;
        $scope.thirdErrorInfo = "";
        gotoUp();
    }

    $scope.gotofourthClick = function()
    {
        if($scope.gtMark) {
            if ($scope.gtcpszInfo.gtje == "") {
                //$scope.thirdErrorInfo = "请输入跟投金额";
                return;
            }
            if ($scope.kgtzj <= 0 || $scope.kgtzj == "--") {
                $scope.thirdErrorInfo = "可跟投资金不足";
                return;
            }
            //|| $scope.gtcpszInfo.zybfb == "" || $scope.gtcpszInfo.zsbfb == ""
            if (valueCheck($scope.gtcpszInfo.gtje) == false) {
                $scope.thirdErrorInfo = "跟投金额含有特殊字符，请输入有效值";
                return;
            }
            //if (parseFloat($scope.gtcpszInfo.gtje) > $scope.kgtzj) {
            //    $scope.thirdErrorInfo = "可跟投资金不足";
            //    return;
            //}
            //console.log($scope.gtszInfo.gtje, $scope.cpbgtAccountInfo.maxmoney, $scope.cpbgtAccountInfo.minmoney)

            if (parseFloat($scope.gtcpszInfo.gtje) > $scope.dqgtInfo.zdgtje) {
                $scope.thirdErrorInfo = "跟投金额大于可最大可跟投金额";
                return;
            }
            if (parseFloat($scope.gtcpszInfo.gtje) < $scope.dqgtInfo.zxgtje) {
                $scope.thirdErrorInfo = "跟投金额小于可最小可跟投金额";
                return;
            }

            if ($scope.gtcpszInfo.zybfb != "") {
                if (valueCheck($scope.gtcpszInfo.zybfb) == false) {
                    $scope.thirdErrorInfo = "止盈线含有特殊字符，请输入有效值";
                    return;
                }
            }
            if ($scope.gtcpszInfo.zsbfb != "") {
                if (valueCheck($scope.gtcpszInfo.zsbfb) == false) {
                    $scope.thirdErrorInfo = "止损线含有特殊字符，请输入有效值";
                    return;
                }
            }

            $scope.thirdErrorInfo = "";
            //$scope.bmthirdShow = false;
            //$scope.bmfourthShow = true;
            $scope.gtMark = false;
            $scope.gtbmcomfirm();
        }
    }

    $scope.backtothirdClick = function()
    {
        $scope.bmthirdShow = true;
        $scope.bmfourthShow = false;
    }

    $scope.fcfsClick = function(_obj)
    {
        for(var i = 0;i<$scope.fcfsArray.length;i++)
        {
            if($scope.fcfsArray[i].status)
            {
                $scope.fcfsArray[i].status = false;
                break;
            }
        }
        _obj.status = true;
        $scope.fcfs = _obj;
    }

    $scope.gtbmcomfirm = function()
    {
        var message = {};
        message['applyuserid'] = $scope.userObj.f_id;
        message['applyaccount'] = $scope.dqxzaccount.account;
        message['stopprofit'] = $scope.gtcpszInfo.zybfb;//止盈线
        message['stoploss'] = $scope.gtcpszInfo.zsbfb//止损线
        message['money'] = $scope.gtcpszInfo.gtje;
        message['productid'] = $scope.productid;
        message['sharedownprofit'] = $scope.fcfs.downprofit;
        message['share'] = $scope.fcfs.share;

        //console.log("跟投报名",message);
        ajaxService.sendMessage("sunflower.p_gentouapply", message, $scope.p_gentouapplyCallBack);
    }

    $scope.p_gentouapplyCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.gotofinished();
        }
        else
        {
            $scope.thirdErrorInfo = "跟投报名失败，原因：" + _data.op.info;
        }
        $scope.gtMark = true;
    }

    //账户选择，单一
    $scope.zhcheckClick = function (_obj)
    {
        //console.log("check");
        for(var i = 0;i<$scope.zhListArray.length;i++)
        {
            if($scope.zhListArray[i].check)
            {
                $scope.zhListArray[i].check = false;
                break;
            }
        }
        _obj.check = true;
        $scope.dqxzaccount = _obj;
    }

    //进入完成提示界面
    $scope.gotofinished = function()
    {
        $scope.bmthirdShow = false;
        $scope.bmfourthShow = true;
    }


    //信息修改
    $scope.gtxxxgClick = function()
    {
        $scope.mainShow = false;
        $scope.xxxgCvsShow = true;

        $scope.gtdesc = $scope.dqgtInfo.desc;//理财计划
        $scope.gtminmoney =  parseFloat($scope.dqgtInfo.zxgtje).toFixed(2);//最小跟投金额
        $scope.gtmaxmoney = parseFloat($scope.dqgtInfo.zdgtje).toFixed(2);//最大跟投金额
        if($scope.dqgtInfo.yjtrzj != null && $scope.dqgtInfo.yjtrzj != undefined && $scope.dqgtInfo.yjtrzj != "")
        {
            $scope.fwyjtrzj = parseFloat($scope.dqgtInfo.yjtrzj).toFixed(2);//预计投入资金
        }
        else
        {
            $scope.fwyjtrzj = "";
        }
        if($scope.dqgtInfo.property == "public")
        {
            $scope.dzgkcheck = true;
        }

        $scope.bmjzsj = new Date($scope.bmjzsjstr) ;//报名截止时间
    }

    $scope.dzgkcheckClick = function()
    {
        $scope.dzgkcheck = ! $scope.dzgkcheck;
    }

    //信息提交
    $scope.xgfwxxClick = function()
    {
        if($scope.tjMark)
        {
            $scope.errorInfo = "";
            if($scope.chanageCheck() == false)
            {
                $scope.errorInfo = "服务信息未修改，请修改后提交";
                return;
            }
            if($scope.gtminmoney == "")
            {
                $scope.errorInfo = "请输入最小跟投金额";
                return;
            }
            if($scope.gtmaxmoney == "")
            {
                $scope.errorInfo = "请输入最大跟投金额";
                return;
            }
            if(parseFloat($scope.gtminmoney)> parseFloat($scope.gtmaxmoney))
            {
                $scope.errorInfo = "最小跟投金额大于最大跟投金额，请重新输入";
                return;
            }
            if($scope.fwyjtrzj == "")
            {
                $scope.errorInfo = "请输入预计投入资金";
                return;
            }
            if($scope.bmjzsj == "")
            {
                $scope.errorInfo = "请选择报名截止时间";
                return;
            }
            var today = new Date();
            var yesterday_milliseconds=today.getTime()-1000*60*60*24;
            var yesterday = new Date();
            yesterday.setTime(yesterday_milliseconds);
            //console.log(today, yesterday);
            if ($scope.bmjzsj<yesterday)
            {
                $scope.errorInfo = "报名截止时间不应小于当前日期";
                return;
            }

            $scope.updatefwxx();

        }

    }

    //更新信息
    $scope.updatefwxx = function()
    {
        $scope.tjMark = false;
        $scope.errorInfo = "提交中，请稍候...";
        var message = {};
        message['productid'] = $scope.productid;
        message['minmoney'] = $scope.gtminmoney;
        message['maxmoney'] = $scope.gtmaxmoney;
        if($scope.dzgkcheck)
        {
            message['property'] = "public";
        }
        else
        {
            message['property'] = "private";
        }
        message['desc'] = $scope.gtdesc;//描述
        message['endapplyday'] = $scope.getDateFull($scope.bmjzsj);
        message['planmoney'] = $scope.fwyjtrzj;//预计投入资金
        //console.log(message);
        ajaxService.sendMessage("sunflower.p_updateproduct", message, $scope.p_updateproductCallBack);
    }

    $scope.p_updateproductCallBack = function(_data)
    {
        //console.log(_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.errorInfo = "";
            //重新获取信息
            $scope.getdqgtInfo();
            myAlert("服务信息修改成功");
        }
        else
        {
            $scope.errorInfo = "修改失败，请重试";
        }

        $scope.tjMark = true;

    }

    $scope.chanageCheck = function()
    {
        var mark = false;
        if($scope.gtdesc != $scope.dqgtInfo.desc)
        {
            console.log("1");
            mark = true;
            return mark;
        }
        if(parseFloat($scope.gtminmoney) != parseFloat($scope.dqgtInfo.zxgtje))
        {
            console.log("2");
            mark = true;
            return mark;
        }
        if(parseFloat($scope.gtmaxmoney) != parseFloat($scope.dqgtInfo.zdgtje))
        {
            console.log("3");
            mark = true;
            return mark;
        }
        if(parseFloat($scope.dqgtInfo.yjtrzj).toString() != parseFloat($scope.fwyjtrzj).toString())
        {
            console.log("4");
            mark = true;
            return mark;
        }
        if(($scope.dqgtInfo.property == "public" && $scope.dzgkcheck == false) || ($scope.dqgtInfo.property == "private" && $scope.dzgkcheck == true))
        {
            console.log("5");
            mark = true;
            return mark;
        }
        var str = $scope.getDateFull($scope.bmjzsj);
        str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2)
        if(str != $scope.bmjzsjstr)
        {
            console.log("6");
            mark = true;
            return mark;
        }

        return mark;
    }


    //信息修改返回
    $scope.xxxgbackto = function()
    {
        $scope.mainShow = true;
        $scope.xxxgCvsShow = false;
    }

    $scope.backtoP = function()
    {
        $scope.backto();
    }

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
            $scope.guanzhuing = false;
        }
        else
        {
            $scope.guanzhuing = true;
            myAlert("加关注失败，原因：" + _data.op.info);
        }
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname+'" 报名中');
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname +'，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        //console.log(543254354, desc);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname+'" 报名中');
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname + '，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })
    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    $scope.backto = function()
    {
        if($scope.opentype == "newwebview")
        {
            //window.location.href = "back";
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }

    $scope.getDateFull = function(_str)
    {
        //console.log("日期",_str);
        var yyyy = _str.getFullYear();
        //console.log("日期",yyyy);
        var mm = _str.getMonth() + 1;
        //console.log("日期",mm);
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        //console.log("日期",mm);
        var dd = _str.getDate();
        //console.log("日期",dd);
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }
        //console.log("日期",yyyy , mm , dd);
        return yyyy + "" + mm + "" + dd;
    }
//读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){

            //alert("数据库处理");
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    //alert("数据库处理2");
                    if(res.rows.length == 0){

                        $scope.hasReadNum = 0;

                    }else
                    {
                        $scope.hasReadNum = res.rows.item(0).readnum;

                    }

                    //alert("已读取评论数" + $scope.hasReadNum);

                    if($scope.hasReadNum < $scope.plCount)
                    {
                        $scope.plmark = true;
                    }
                    else
                    {
                        $scope.plmark = false;
                    }
                    //$scope.$apply();
                    //alert("数据库处理3");
                });
        })
    }

}



