
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
//var exec = cordova.require("cordova/exec");
//	exec(callbackok,callbackerr,"AndroidAPIforJS", "test1", ["test"]);
//
function gt_syCtrl($scope, ajaxService, $cookieStore, $sce) {
	
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = false;//主界面
    $scope.wqxDivshow = false;//无权限界面
    $scope.ewmDivShow = false;//二维码界面
    $scope.plInputShow = false;//评论
    $scope.productname = "";//产品名
    $scope.productid = "";//产品id
    $scope.account = "";//账户
    $scope.plCount = "--";
    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，服务结束时间
    $scope.jssjstrsy = "";//8位，日收益分析之类的用
    $scope.opentype = "";//打开方式
    $scope.canseeMark = false;//是否可以看
    $scope.cangtMark = false;//是否可以跟投（是否做了跟投设置）
    $scope.gtqyArray = [];//跟投签约

    $scope.isfwface = true;//是否是服务界面

    $scope.isyk = true;//是否是游客

    $scope.tabOneShow = false;//收益
    $scope.tabTwoShow = false;//持仓
    $scope.tabThreeShow = false;//交易记录
    $scope.tabFourShow = false;//评论

    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "--";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.beginzc = "--";//初始资金
    $scope.dqgtInfo.rundays = "--";//实盘天数
    $scope.isfirstin = true;//初次进界面
    $scope.isqymark = false;

    $scope.gtsytstartdate = ""//收益图开始日期
    $scope.gtsytenddate = "";//收益图结束日期

    $scope.ljsyshow = "";//累计收益
    $scope.dqgtInfo.productfbzname = "";

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通
    $scope.fcfsArray = [];//分成方式

    $scope.fzintervalId;//复制链接定时

    //服务设置
    $scope.assetopenflagall = "N"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "N";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "N"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "N";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "N";//对大众，交易指令公开
    $scope.assetopenflaggentou = "N";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "N";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "N";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "N";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "N";//对跟投者，交易指令公开

    $scope.sendflowerMark = true;
    $scope.pltitleshow = "评论";//评论的title

    $scope.productid = getParameter("productid");
    $scope.account = getParameter("account");
    $scope.bgtuserid = getParameter("bgtuserid");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index3 = index2;
    }

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息
    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    $scope.sce = $sce.trustAsResourceUrl;


    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        //$scope.ztcaption = _data.caption;
        //var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        //$scope.$broadcast("setParameters", cstr);
    });

    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;

            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            //$scope.dqgtInfo.zq = product.gentouperiod;
            //$scope.dqgtInfo.mbsy = product.targetprofit + "%";
            if(!!product.minmoney)//是否设置跟投
            {
                $scope.cangtMark = true;
            }
            else
            {
                $scope.cangtMark = false;
                $scope.dqgtInfo.zxgtje = product.minmoney;
            }
            //$scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            //$scope.dqgtInfo.beginzc = product.beginzc;//初始资金
            $scope.dqgtInfo.rundays = product.rundays;//实盘天数
            //var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str;//报名截止日期
            //var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2;//服务结束时间
            //var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3;//服务开始时间
            //var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            //$scope.kssjstr = $scope.dqgtInfo.fwkssj.toString().substr(0,8);
            $scope.kssjstr = "";
            $scope.ljsyshow = (parseFloat(product.ljsy)*100).toFixed(2) + "%";//累计收益率
            $scope.dqgtInfo.productfbzname = product.user.user.f_nickname;//产品发布者name

            var datestr = product.createtime;
            $scope.gtsytstartdate = datestr.substr(0,4) + datestr.substr(5,2) + datestr.substr(8,2);//收益图开始日期
            $scope.gtsytenddate = gettodayno();//收益图结束日期
            //console.log("kssj", $scope.gtsytstartdate, $scope.gtsytenddate);

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }
            $scope.showinfo();
        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.showinfo = function()
    {
        //收益等信息
        var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
        $scope.$broadcast("setParameters", cstr);

        //收益图
        var cstr  = {"account":$scope.account, "caption": "gtsysyt"};
        $scope.$broadcast("setParameters", cstr);

        ////今日交易记录
        //var cstr  = {"account":$scope.account, "caption": "gtsyjrjyjl"};
        //$scope.$broadcast("setParameters", cstr);
        //
        ////持仓、历史交易记录
        //var cstr  = {"account":$scope.account, "caption": "gtsycc"};
        //$scope.$broadcast("setParameters", cstr);
        //
        ////评论
        //var cstr  = {"account":$scope.account, "caption": "gtplshow"};
        //$scope.$broadcast("setParameters", cstr);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1") //今日交易记录
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;

            if($scope.isqymark)//签约用户，以签约用户来显示
            {
                if($scope.clearpositionopenflaggentou == 'Y' || $scope.tradecommandopenflaggentou == 'Y')
                {
                    var cstr  = {"account":$scope.account, "caption": "gtsyjrjyjl"};
                    $scope.$broadcast("setParameters", cstr);
                }
            }
            else
            {
                if($scope.clearpositionopenflagall == 'Y' || $scope.tradecommandopenflagall == 'Y')
                {
                    var cstr  = {"account":$scope.account, "caption": "gtsyjrjyjl"};
                    $scope.$broadcast("setParameters", cstr);
                }
            }

        }
        else if(_str == "2")//持仓
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;

            if($scope.isqymark)//签约用户，以签约用户来显示
            {
                if($scope.positionvarietyopenflaggentou == 'Y')
                {
                    var cstr  = {"account":$scope.account, "caption": "gtsycc"};
                    $scope.$broadcast("setParameters", cstr);
                }
            }
            else
            {
                if($scope.positionvarietyopenflagall == 'Y')
                {
                    var cstr  = {"account":$scope.account, "caption": "gtsycc"};
                    $scope.$broadcast("setParameters", cstr);
                }
            }
        }
        else if(_str == "4")//评论
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;

            var cstr  = {"account":$scope.account, "caption": "gtplshow"};
            $scope.$broadcast("setParameters", cstr);
        }

    }

    //$scope.p_getgentouproductCallBack = function(_data)
    //{
    //    console.log("产品关系", _data);
    //}

    //$scope.getInfo = function()
    //{
    //    var message = {};
    //
    //    message['productid'] = $scope.productid;
    //    message['userid'] = $scope.userObj.f_id;
    //    console.log("产品关系",$scope.productid);
    //    ajaxService.sendMessage("gentou.getUserProductRelationAction", message, $scope.p_getgentouproductCallBack);
    //}

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflagall = _data.assetopenflagall.toString();
            $scope.clearpositionopenflagall = _data.clearpositionopenflagall.toString();
            $scope.positionamountopenflagall = _data.positionamountopenflagall.toString();
            $scope.positionvarietyopenflagall = _data.positionvarietyopenflagall.toString();
            $scope.tradecommandopenflagall = _data.tradecommandopenflagall.toString();
            $scope.assetopenflaggentou = _data.assetopenflaggentou.toString();
            $scope.clearpositionopenflaggentou = _data.clearpositionopenflaggentou.toString();
            $scope.positionamountopenflaggentou = _data.positionamountopenflaggentou.toString();
            $scope.positionvarietyopenflaggentou = _data.positionvarietyopenflaggentou.toString();
            $scope.tradecommandopenflaggentou = _data.tradecommandopenflaggentou.toString();
        }
        $scope.getdqgtInfo();
        if(!!$scope.index3)
        {
            $scope.changeTab($scope.index3);
        }
        else
        {
            if($scope.isqymark)//签约用户，以签约用户来显示
            {
                if($scope.clearpositionopenflaggentou == 'Y' || $scope.tradecommandopenflaggentou == 'Y')
                {
                    $scope.changeTab("1");
                }
                else if($scope.positionvarietyopenflaggentou == 'Y')
                {
                    $scope.changeTab("2");
                }
                else
                {
                    $scope.changeTab("4");
                }
            }
            else//非签约用户
            {
                if($scope.clearpositionopenflagall == 'Y' || $scope.tradecommandopenflagall == 'Y')
                {
                    $scope.changeTab("1");
                }
                else if($scope.positionvarietyopenflagall == 'Y')
                {
                    $scope.changeTab("2");
                }
                else
                {
                    $scope.changeTab("4");
                }
            }
        }
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            //alert("当前评论数" + $scope.plCount);
            //selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    
    //获取评论数量
    $scope.getplcount = function()
    {
    	//selectHasRead($scope.productid,$scope.userObj.f_id);
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    $scope.getisgtinfoCallBack = function(_data)
    {
        //console.log("签约", _data);
        $scope.gtqyArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            if(arr.length >0 )
            {
                //$scope.isqymark = true;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    if(arr[i].status.toString() == "B")//实盘中
                    {
                        obj.gtindex = 1;
                        obj.gtstatus = "gt1";
                        obj.status = arr[i].status.toString();
                        obj.linkaccount = arr[i].linkaccount;//当前跟投的账户
                        obj.linkid = arr[i].id;
                        var bgtuser = arr[i].linkeduser.user;
                        obj.headurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.bgtuserid = bgtuser.f_id;
                        obj.productname = arr[i].productname;//产品id
                        obj.productid = arr[i].productid;//产品id
                        obj.zq = arr[i].gentouperiod;//周期
                        obj.money = arr[i].money;//跟投金额
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.drsy = arr[i].dqyk;
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.ljsy = arr[i].ljyk;
                        var ksstr = arr[i].createtime.toString();//跟投开始时间
                        obj.gtksrq = ksstr.substr(0,10);
                        //var str = arr[i].endgentoutime.toString();
                        //obj.jssj = str;
                        var cwstr = arr[i].cw;
                        if(parseFloat(cwstr) == 0)
                        {
                            obj.cw = "空仓";//当前仓位
                        }
                        else if(parseFloat(cwstr) == 1)
                        {
                            obj.cw = "满仓";//当前仓位
                        }
                        else
                        {
                            obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                        }
                        obj.buycount = arr[i].buycount;
                        obj.sellcount = arr[i].sellcount;
                        if(!!arr[i].linkaccountmoney)
                        {
                            obj.gtzh = arr[i].linkaccountmoney.belongaccount;
                            obj.gtzhgs = arr[i].linkaccountmoney.companyname;
                        }
                        else
                        {
                            obj.gtzh = "";
                            obj.gtzhgs = "";
                        }
                        $scope.gtqyArray.push(obj);
                    }
                    else if(arr[i].status.toString() == "C")//解除中
                    {
                        obj.gtindex = 2;
                        obj.gtstatus = "gt2";
                        obj.status = arr[i].status.toString();
                        //obj.mbsy = arr[i].targetprofit;
                        obj.linkaccount = arr[i].linkaccount;//当前跟投的账户
                        obj.linkid = arr[i].id;
                        var bgtuser = arr[i].linkeduser.user;
                        obj.headurl = bgtuser.f_head;
                        obj.username = bgtuser.f_nickname;
                        obj.bgtuserid = bgtuser.f_id;
                        obj.productname = arr[i].productname;//产品id
                        obj.productid = arr[i].productid;//产品id
                        //obj.zq = arr[i].gentouperiod;//周期
                        obj.money = arr[i].money;//跟投金额
                        obj.drsyl = parseFloat(arr[i].jrsy);
                        obj.drsy = arr[i].dqyk;
                        obj.ljsyl = parseFloat(arr[i].ljsy);
                        obj.ljsy = arr[i].ljyk;
                        //var str = arr[i].endgentoutime.toString();
                        //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                        //obj.jssj = str;
                        var ksstr = arr[i].createtime.toString();//跟投开始时间
                        obj.gtksrq = ksstr.substr(0,10);
                        var cwstr = arr[i].cw;
                        if(parseFloat(cwstr) == 0)
                        {
                            obj.cw = "空仓";//当前仓位
                        }
                        else if(parseFloat(cwstr) == 1)
                        {
                            obj.cw = "满仓";//当前仓位
                        }
                        else
                        {
                            obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                        }
                        obj.buycount = arr[i].buycount;
                        obj.sellcount = arr[i].sellcount;
                        if(!!arr[i].linkaccountmoney)
                        {
                            obj.gtzh = arr[i].linkaccountmoney.belongaccount;
                            obj.gtzhgs = arr[i].linkaccountmoney.companyname;
                        }
                        else
                        {
                            obj.gtzh = "";
                            obj.gtzhgs = "";
                        }
                        $scope.gtqyArray.push(obj);
                    }
                    else
                    {
                        obj.gtindex = 3;
                        obj.gtstatus = "gt3";
                        obj.username = arr[i].linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                        obj.headurl = arr[i].linkeduser.user.f_head;
                        obj.bgtuserid = arr[i].linkeduser.user.f_id;
                        obj.linkaccount = arr[i].linkaccount;//跟投的账户
                        obj.productid = arr[i].productid;
                        obj.productname = arr[i].productname;
                        obj.linkid = arr[i].id;
                        //obj.zq = arr[i].gentouperiod;//周期
                        obj.money = arr[i].money;
                        //obj.mbsy = arr[i].targetprofit;//目标收益
                        obj.ljsyl = parseFloat(arr[i].ljsy);//累计收益
                        obj.ljsy = arr[i].ljyk;
                        obj.status = arr[i].status.toString();
                        obj.gradeflat = arr[i].gradeflat.toString();
                        var ksstr = arr[i].createtime.toString();//跟投开始时间
                        obj.gtksrq = ksstr.substr(0,10);
                        var str = arr[i].endtime.toString();
                        obj.jssj = str;
                        obj.gtjsrq = obj.jssj;//跟投结束日期
                        obj.shouldpaymoney = arr[i].shouldpaymoney;
                        obj.rundays = arr[i].rundays;
                        obj.settleno = arr[i].settleno;
                        obj.settleid = arr[i].settleid;
                        if(!!arr[i].linkaccountmoney)
                        {
                            obj.gtzh = arr[i].linkaccountmoney.belongaccount;
                            obj.gtzhgs = arr[i].linkaccountmoney.companyname;
                        }
                        else
                        {
                            obj.gtzh = "";
                            obj.gtzhgs = "";
                        }
                        $scope.gtqyArray.push(obj);
                    }


                }
                //console.log("签约", $scope.gtqyArray.length);
                $scope.gtqyArray.sort(function(a, b)
                {
                    //console.log(b.gtindex, a.gtindex);
                    return a.gtindex - b.gtindex;
                });

                if($scope.gtqyArray.length>0)
                {
                    $scope.isqymark = true;
                }
                else
                {
                    $scope.isqymark = false;
                }
            }
            else
            {
                $scope.isqymark = false;
            }
        }

        if($scope.isfirstin)
        {
            $scope.getcpsz();
            $scope.isfirstin = false;
        }

    }

    //获取签约信息
    $scope.getisgtinfo =  function()
    {
        //var message = {};
        //message['userid'] = $scope.userObj.f_id;
        //message['productid'] = $scope.productid;
        //message['page.size'] = "max";
        //message['page.no'] = "1";
        //ajaxService.sendMessage("gentou.p_selectgentou", message, $scope.getisgtinfoCallBack);

        //var message = {};
        //message['account'] = "";
        //message['productid'] = $scope.productid;
        //message['userid'] = $scope.userObj.f_id;
        //message['linkoriginalaccount'] = "";
        //message['page.size'] = "max";
        //message['page.no'] = "1";
        ////console.log("产品信息收益",$scope.productid);
        //ajaxService.sendMessage("gentou.p_selectallgentou", message, $scope.getisgtinfoCallBack);

    }

    $scope.gotocanseeshow = function()
    {
        $scope.mainShow = true;//主界面
        $scope.wqxDivshow = false;//无权限界面
        $scope.getcpsz();
        //$scope.getisgtinfo();
        //$scope.getplcount();
        $scope.isguanzhuget();
    }

    $scope.checkcanseeCallBack = function(_data)
    {
        //console.log("check", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.canseeMark = true;
            $scope.gotocanseeshow();
        }
        else
        {
            $scope.mainShow = false;//主界面
            $scope.wqxDivshow = true;//无权限界面
        }
    }

    $scope.checkcansee = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.hasviewproductpermissionrule", message, $scope.checkcanseeCallBack);
    }

    //是否可以看
    $scope.getcansee = function()
    {
        if($scope.bgtuserid == $scope.userObj.f_id)
        {
            $scope.canseeMark = true;
            $scope.gotocanseeshow();
        }
        else
        {
            $scope.checkcansee()
        }
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
        //console.log("init");
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.userName = decodeURIComponent(localStorage.getItem("nickname"));
            $scope.jssjstr = getyesterdayno();
            $scope.getcansee();

        }catch (e){}
    }

    $scope.fbzInit();

    $scope.sendflowerCallBack = function(_data)
    {
        //console.log("送花", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getpl();
        }

        $scope.sendflowerMark = true;
    }

    //送花
    $scope.sendflowerClick = function()
    {
        if($scope.sendflowerMark)
        {
            $scope.sendflowerMark = false;
            var message = {};
            //message['contenttype'] = "text";
            message['cnt'] = "//flower//";
            message['cnttype'] = "2"; //1：文字评论；2：送花；3：语音
            message['subjectid'] = $scope.productid;
            message['subjecttype'] = "product";
            message['subjectuserid'] = $scope.bgtuserid;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendflowerCallBack);
        }
    }

    //查看分成方式
    $scope.gotofcfs = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //历史交易记录
    $scope.gotolsjy = function()
    {
        $scope.mainShow = false;
        $scope.lsjyjlDivShow = true;

        var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
        $scope.$broadcast("setParameters", cstr);
    }

    $scope.lsjyjlBackto = function()
    {
        $scope.mainShow = true;
        $scope.lsjyjlDivShow = false;
    }

    //分享
    //$scope.fxClick = function()
    //{
    //    //var title = $scope.userName + ' 邀请您关注向日葵理财服务';
    //    var title = $scope.productname;
    //    var desc = '向日葵理财，您的私人理财师～～';
    //    var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/gt_share.html?productid=" + $scope.productid;
    //    shareUrlToDialog(_content, title, desc, function(data){
    //        //alert(JSON.stringify(data));
    //    },function(){
    //        //alert("微信邀请好友失败，请重试");
    //        myAlert("微信分享失败");
    //    })
    //}

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }

    $scope.fwqxgzCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.fwqxgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.fwqxgzCallback);
        }
    }

    //评论
    $scope.plClick = function()
    {
        $scope.mainShow = false;
        $scope.plInputShow = true;
    }

    //评论返回
    $scope.plinputbackto = function()
    {
        $scope.mainShow = true;
        $scope.plInputShow = false;
        $scope.getpl();
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        //var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天， 累计收益：' + $scope.ljsyshow);
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        var title = encodeURI($scope.userName) + encodeURI('邀请您关注专户 "' + $scope.productname + '"');
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        if(!!$scope.dqgtInfo.desc && $scope.dqgtInfo.desc != '--')
        {
            var desc = encodeURI("理财说明：" + $scope.dqgtInfo.desc);
        }
        else
        {
            var desc = "";
        }
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        //var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天，累计收益：' + $scope.ljsyshow);
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        var title = encodeURI($scope.userName) + encodeURI('邀请您关注专户 "' + $scope.productname + '"');
        //var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        if(!!$scope.dqgtInfo.desc && $scope.dqgtInfo.desc != '--')
        {
            var desc = encodeURI("理财说明：" + $scope.dqgtInfo.desc);
        }
        else
        {
            var desc = "";
        }
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    $scope.fbgtBackto = function()
    {
        //console.log(getbackList());
        if($scope.opentype == "newwebview")
        {
            //window.location.href = "back";
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }

}



