
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function myFinancialBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.userName = "";

    $scope.zhListArray = [];//账号列表
    $scope.mainShow = true;//主界面
    $scope.addSecurityAccountShow = false;//添加账号界面显示
    $scope.khDivShow = false;//开户界面
    $scope.ewmDivShow = false;//二维码界面
    $scope.zqgsItemShow = false;//证券公司列表
    $scope.zszhShow = false;//真实账户
    $scope.monizhshow = false;//模拟账户
    $scope.newzqzh = "";//新的证券账号
    $scope.newzqzhpassword = "";//新的证券账号密码
    $scope.newzqyj = "0.0003";//新的证券账号佣金
    $scope.newxm = "";//新的张清账户姓名
    $scope.zqgsArray = [];//证券公司
    $scope.selectedzqgs = {};//证券公司id
    $scope.addnewzqzhMark = true;//新加管理账号中
    $scope.zsaddinfo = "";//真实账户添加操作中提示信息;
    $scope.fzintervalId;

    $scope.mnnewzhzdje = "";
    $scope.mnnewzqyj = "0.0008";
    $scope.moniaddinfo = "";//模拟账户添加操作中提示信息
    $scope.khurl = "";//开户地址
    $scope.selectkh = "";
    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.sftype = "";
    //$scope.ggjjje = 0;
    $scope.gtjjzh  = "";

    //置顶
    $scope.gotoTop = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }
    $scope.getgtjjjeCallBack = function(_data)
    {
        //console.log("333", _data);
        $scope.ggjjje = parseFloat(_data.money)-parseFloat(_data.applymoney);
    }


    $scope.getgtjjje = function()
    {
        //if($scope.gtjjzh != "")
        //{
            //var message = {};
            //message['userid'] = $scope.userObj.f_id;
            //message['account'] = $scope.gtjjzh;
            ////console.log(message);
            //ajaxService.sendMessage("gentou.p_kgtzj", message, $scope.getgtjjjeCallBack);
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            //console.log(message);
            ajaxService.sendMessage("sunflower.getexperienceaccountaction", message, $scope.getgtjjjeCallBack);
        //}
    }

    $scope.myfinInfo = function()
    {
        try
        {
            //$scope.userObj = $cookieStore.get('user');
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
            $scope.getzhlb();
            $scope.getzqgs();
            $scope.getgtjjje();
        }catch (e){}
    }

    //获取账户列表

    $scope.p_getaccountlistCallBack = function(_data)
    {
        console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.zqgsiocnurl = getzqgsLogo(obj.zqgs);//公司logo
                obj.zhxm = element[item].name;//账户姓名，添加账户时输入信息
                obj.accountstatus = element[item].accountstatus.toString();
                obj.experience = element[item].experience.toString();//是否是跟投基金，Y表示是跟投基金
                if(obj.experience == "Y")
                {
                    $scope.gtjjzh = obj.account;
                }
                obj.newflag = element[item].newflag;//是否已经转账操作
                if(obj.newflag == undefined || obj.newflag == null)
                {
                    obj.newflag = "";
                }
                //console.log("newflag", obj.newflag);
                if(obj.accountstatus == "a" )//a-普通账户（无跟投、无被跟投） b-跟投账户（跟投了其他账户） c-被跟投账户（被其他账户跟投）
                {
                    obj.tradeaccount = obj.account;
                }
                else
                {
                    if(obj.accountstatus == "b")
                    {
                        var zl = element[item].self;
                        if(zl == undefined || zl == null)
                        {
                            obj.tradeaccount = obj.account;
                        }
                        else
                        {
                            obj.tradeaccount = zl.account;//自留账户
                        }
                    }
                    else if(obj.accountstatus == "c")
                    {
                        var zl = element[item].self;
                        if(zl == undefined || zl == null)
                        {
                            obj.tradeaccount = obj.account;
                        }
                        else
                        {
                            obj.tradeaccount = zl.account;//自留账户
                        }
                    }
                }
                if(obj.experience != "Y")
                {
                    $scope.zhListArray.push(obj);
                }
            }
        }

        //$scope.getgtjjje();
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }

    //获取证券公司
    $scope.selectsecuritycompanyactionCallBack = function(_data)
    {
        //console.log("证券公司", _data);
        if(_data.op.code.toString() == "Y") {
            var element = _data.securitycompanylist;
            console.log(element.length);
            for (var item = 0;item < element.length; item++){
                var obj = {};
                obj.id = element[item]['company'];
                obj.name = element[item]['name'];
                //if(obj.id != "moni")
                //{
                    $scope.zqgsArray.push(obj);
                //}
            }
        }
    }

    //获取证券公司
    $scope.getzqgs = function()
    {
        //console.log("证券公司");
        $scope.zqgsArray = [];
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['company'] = "";
        message['name'] = "";
        message['desc'] = "";
        message['market'] = "";
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getsecuritycompany", message, $scope.selectsecuritycompanyactionCallBack);
        //ajaxService.sendMessage("counter.selectsecuritycompanyaction", message, $scope.selectsecuritycompanyactionCallBack);
    }

    //初始相关操作界面
    $scope.myfinInit = function()
    {
        $scope.myfinInfo();
        var localStorage = window.localStorage;
        $scope.sftype = localStorage.getItem("lcsstatus");
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }

    }

    $scope.myfinInit();

    //获取证券公司
    //var obj = {};
    //obj.id = "1";
    //obj.name = "信达证券";
    //$scope.zqgsArray.push(obj);
    //obj = {};
    //obj.id = "2";
    //obj.name = "国海证券";
    //$scope.zqgsArray.push(obj);
    //obj = {};
    //obj.id = "moni";
    //obj.name = "模拟证券";
    //$scope.zqgsArray.push(obj);

    //账户列表返回
    $scope.zhlistBackto = function()
    {
        //alert("账户返回");
        //window.location = getbackList();
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    $scope.newClick = function()
    {
        $scope.addSecurityAccountClick();
    }

    //添加证券账户
    $scope.addSecurityAccountClick = function()
    {
        $scope.mainShow = false;
        $scope.addSecurityAccountShow = true;
        $scope.zqgsItemShow = false;

        $scope.zszhShow = false;
        $scope.monizhshow = false;

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";
        $scope.gotoTop();

    }

    //返回home
    $scope.addzhBackto = function()
    {
        $scope.mainShow = true;
        $scope.addSecurityAccountShow = false;
        $scope.zszhShow = false;
        $scope.monizhshow = false;
        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";
        $scope.gotoTop();
    }
    //进入添加界面
    $scope.zqgsItemClick = function(_obj)
    {
        $scope.zqgsItemShow = true;
        $scope.selectedzqgs = _obj;

        if(_obj.id == "moni")
        {
            $scope.zszhShow = false;
            $scope.monizhshow = true;
        }
        else
        {
            $scope.zszhShow = true;
            $scope.monizhshow = false;
        }

    }
    //返回证券公司列表
    $scope.backtozqgslist = function()
    {
        $scope.zqgsItemShow = false;
        $scope.selectedzqgs = {};

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqyj = "0.0003";
        //$scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewzqyj = "0.0008";
        $scope.addnewzqzhMark = true;
        $scope.zsaddinfo = "";
        $scope.moniaddinfo = "";
    }

    //确定增加关联账号
    $scope.addnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.newzqzh == "")
            {
                $scope.zsaddinfo = "请输入证券账号";
                return;
            }
            if($scope.newzqzhpassword == "")
            {
                $scope.zsaddinfo = "请输入交易密码";
                return;
            }
            //if($scope.newxm == "")
            //{
            //    $scope.zsaddinfo = "请输入姓名";
            //    return;
            //}
            $scope.zsaddinfo = "";
            $scope.addnewzqzhMark = false;

            ////没有接口直接转回
            //$scope.mainShow = true;
            //$scope.addSecurityAccountShow = false;
            //$scope.zqgsItemShow = false;
            //$scope.newzqzh = "";
            //$scope.newzqzhpassword = "";
            //$scope.newzqyj = "0";
            //$scope.selectedzqgs = {};
            //$scope.addnewzqzhMark = true;
            //$scope.gotoTop();

            var message = {};
            message['account'] = $scope.newzqzh;//当前账号
            message['password'] = $scope.newzqzhpassword;
            message['company'] = $scope.selectedzqgs.id;
            //onsole.log($scope.selectedzqgs.id)
            message['source'] = "A";
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.newzqyj;
            //message['name'] = $scope.newxm;//姓名
            console.log("增加证券账户");
            $scope.zsaddinfo = "添加账户中，请稍候...";
            ajaxService.sendMessage("counter.p_bindsecurityaccount", message, $scope.p_bindsecurityaccountCallBack);
        }
    }

    $scope.p_bindsecurityaccountCallBack = function(_data)
    {
        console.log("增加证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            //查询证券账号列表
            $scope.getzhlb();

            //返回账号列表
            $scope.mainShow = true;
            $scope.addSecurityAccountShow = false;
            $scope.zqgsItemShow = false;
            $scope.zszhShow = false;
            $scope.newzqzh = "";
            $scope.newzqzhpassword = "";
            $scope.newzqyj = "0.0003";
            //$scope.newxm = "";
            $scope.selectedzqgs = {};
            $scope.zsaddinfo = "";
            $scope.gotoTop();
        }
        else
        {
            //alert("添加账号失败，原因：" + _data.op.info);
            $scope.zsaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }


    //确定增加关联模拟账号
    $scope.moniaddnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.checkValue($scope.mnnewzhzdje) == false)
            {
                $scope.moniaddinfo = "含有特殊字符，请输入有效值";
                return;
            }
            if($scope.mnnewzhzdje == "0" || $scope.mnnewzhzdje == "")
            {
                $scope.moniaddinfo = "请输入指定金额";
                return;
            }
            if(parseFloat($scope.mnnewzhzdje) < 10000)
            {
                $scope.moniaddinfo = "指定金额不能小于1万元";
                return;
            }
            if(parseFloat($scope.mnnewzhzdje) >10000000)
            {
                $scope.moniaddinfo = "指定金额不能大于1000万元";
                return;
            }
            $scope.moniaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.mnnewzqyj;
            message['money'] = $scope.mnnewzhzdje;
            console.log("增加模拟账户");
            ajaxService.sendMessage("counter.p_bindmoniaccount", message, $scope.bindmoniaccountCallBack);
        }
    }

    $scope.bindmoniaccountCallBack = function(_data)
    {
        console.log("增加模拟证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            //查询证券账号列表
            $scope.getzhlb();

            //返回账号列表
            $scope.mainShow = true;
            $scope.addSecurityAccountShow = false;
            $scope.zqgsItemShow = false;
            $scope.monizhshow = false;
            $scope.mnnewzhzdje = "";
            $scope.mnnewzqyj = "0.0008";
            $scope.selectedzqgs = {};
            $scope.moniaddinfo = "";
            $scope.gotoTop();
        }
        else
        {
            $scope.moniaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }

    //
    $scope.zhlistItemClick = function(_obj)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", _obj.tradeaccount);
        localStorage.setItem("accountcompany", _obj.zqgs);//证券公司id
        localStorage.setItem("accountName", encodeURIComponent(_obj.zqgsname));
        localStorage.setItem("accountShow", encodeURIComponent(_obj.account));
        localStorage.setItem("newflag", encodeURIComponent(_obj.newflag));

        //console.log(_obj.tradeaccount, _obj.account);

        setbackList(window.location.href);

        if(_obj.experience == "Y")
        {
            window.location.href = "tradeBase_gtjj.html";
        }
        else
        {
            if(_obj.accountstatus == "a")//不带跟投的交易
            {
                window.location.href = "tradeBase_wgt.html";
            }
            else if(_obj.accountstatus == "c" )//a-普通账户（无跟投、无被跟投） b-跟投账户（跟投了其他账户） c-被跟投账户（被其他账户跟投）
            {
                window.location.href = "tradeBase_bgtzzh.html";
            }
            //else if(_obj.accountstatus == "b" )//跟投了其他账户
            else
            {
                if(_obj.tradeaccount == _obj.account)//跟投成功，但是跟投未开始
                {
                    window.location.href = "tradeBase_wgt.html";
                }
                else
                {
                    window.location.href = "tradeBase_gtz.html";
                }
            }
        }
    }

    //开户
    $scope.khClick = function()
    {
        //$scope.mainShow = false;
        //$scope.khDivShow = true;
        //gotoUp();



        //setbackList("myFinancialBase.html");
        //window.location = "http://www.xinyusoft.com:8085/uuFinancialPlanner/zqkhLink.html?title=" + encodeURI("国海开户");
        //window.location = "http://www.welansh.com:9988/koqqq_gh/pages_qq_kd/a1.jsp?channel=4111&ing_org=100&from=singlemessage&isappinstalled=0";
        //try
        //{
        //    var str = "http://www.welansh.com:9988/koqqq_gh/pages_qq_kd/a1.jsp?channel=4111&ing_org=100&from=singlemessage&isappinstalled=0";
        //    var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
        //}
        //catch (e){
        //}
        //setbackList("myFinancialBase.html");
        //window.location = "openAccounts.html";
        xinyuNewBrowser("openAccounts.html?opentype=newwebview");

    }

    //开户
    $scope.khItemClick = function(_str)
    {
        if(_str == "gh")
        {
            try
            {
                var str = "http://cl.ghzq.cn/yykh/m?channel=XYKJ01";
                var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
            }
            catch (e){
            }
        }
        else if(_str == "gj")
        {
            try
            {
                var str = "https://webkh.yongjinbao.com.cn/index.php?channel_type=900067&page_nav=1";
                var ref = cordova.InAppBrowser.open(str, "_system", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
            }
            catch (e){
            }
        }
    }
    //分享
    $scope.fxItemClick = function(_str)
    {
        $scope.selectkh = _str;
    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);


        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr));
        //console.log("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr));
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        if($scope.selectkh == "gh")
        {
            var title = $scope.userName + ' 邀请您开通国海证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
        else if($scope.selectkh == "gj")
        {
            var title = $scope.userName + ' 邀请您开通国金证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
    }

    $scope.pyqfx = function()
    {
        if($scope.selectkh == "gh")
        {
            var title = $scope.userName + ' 邀请您开通国海证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToFriend(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("朋友圈分享失败");
            })
        }
        else if($scope.selectkh == "gj")
        {
            var title = $scope.userName + ' 邀请您开通国金证券账户';
            var desc = '万2.5佣金，实盘跟投服务～～';
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
            shareUrlToFriend(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("朋友圈分享失败");
            })
        }
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.khDivShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/kaihu_share.html?zqtype=" + $scope.selectkh + "&sftype=" + $scope.sftype + "&name=" + encodeURI($scope.userName) + "&headurl=" + encodeURI($scope.headstr);
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.khDivShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }


    //开户返回
    $scope.zhbackBackto = function()
    {
        $scope.mainShow = true;
        $scope.khDivShow = false;
        gotoUp();
    }

    //点击不显示手机弹出的键盘
    $scope.closePopClick = function()
    {}

    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                //alert("含有非数字字符");
                if(_str.charAt(i) != ".")
                {
                    return false;
                }
            }
        }
        return true;
    }

}



