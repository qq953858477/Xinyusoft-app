/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function tradeBase_gtzCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.account = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.tabOneShow = true;//综合
    $scope.tabTwoShow = false;//交易
    $scope.tabFourShow = false;//查询
    $scope.ztcaption = "";
    $scope.valueChange = false;
    $scope.deviceid = "";//设备号
    //$scope.account = getParameter("account");
    var ind = getParameter("index");

    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    //$scope.sessionID = localStorage.getItem('sessionid');
    $scope.account = localStorage.getItem('account');
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.accountzqgs = decodeURIComponent(localStorage.getItem('accountName'));
    $scope.accountShowValue = localStorage.getItem('accountShow');//界面显示用
    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid")!= undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }
    $scope.accountcompany = localStorage.getItem('accountcompany');//证券公司
    $scope.opentype = getParameter("opentype");//打开方式

    //$scope.sessionID = $cookieStore.get('sessionid');
    //$scope.account = $cookieStore.get('account');
    //$scope.userObj = $cookieStore.get('user');
    //$scope.accountzqgs = decodeURIComponent($cookieStore.get('accountName'));


    $scope.accountStr = "***" + $scope.account.substr($scope.account.length-4);

    $scope.urlShow = false;
    console.log($scope.sessionID,  $scope.account);

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });
    //console.log("tradeBase");

    //综合、交易/查询、关联切换
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = false;

            //console.log("$scope.ztcaption",$scope.ztcaption);
            if($scope.valueChange)
            {
                //console.log("重新获取数据");
                var cstr  = {"account":$scope.account, "caption": "zh_asset_gtz"};
                $scope.$broadcast("setParameters", cstr);
            }
        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabFourShow = false;

        }
        else//查询
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = true;
        }
        $scope.valueChange = true;
    }

    $scope.changeTab($scope.index);

    //返回上一级 ：交易、账号
    $scope.backtoPreviousLevel = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location.href = getbackList();
        }
    }

}




