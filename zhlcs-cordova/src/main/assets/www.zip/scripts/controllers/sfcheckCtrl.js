﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */


function sfcheckCtrl($scope, ajaxService, $cookieStore)
{
    $scope.p_getgentouproductCallBack = function(_data)
    {
        console.log("产品关系", _data);
    }

    $scope.getcheckInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        message['userid'] = $scope.userObj.f_id;
        console.log("产品关系",$scope.productid);
        ajaxService.sendMessage("gentou.getUserProductRelationAction", message, $scope.p_getgentouproductCallBack);
    }

    $scope.getcheckInfo();

}







