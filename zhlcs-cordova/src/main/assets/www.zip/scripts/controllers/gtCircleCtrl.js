/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function gtCircleCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.username = "";
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.backtitle = "";

    $scope.gtLcsCPlist = [];//好友发布中的
    $scope.gethyspz = [];//好友实盘中的

    $scope.dqlcbArray = [];//当前发布的、被跟投的理财包
    $scope.historylcfwAccount = "--";//历史理财包个数

    var ind = getParameter("index");
    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));

    $scope.getqzcpCallBack = function(data)
    {
        $scope.gtLcsCPlist = [];//好友发布中的
        $scope.gethyspz = [];//好友实盘中的
        //console.log("可跟投好友", data);
        if (data['op']['code'] == 'Y')
        {
            var arr = data.gentouproductlist;
            for(var i = 0;i< arr.length;i++)
            {
                if(arr[i].status.toString() == "A" || arr[i].status.toString() == "G")
                {
                    var obj = {};
                    obj.userhead = arr[i]['user']['user']['f_head'];
                    obj.username = arr[i]['user']['user']['f_nickname'];
                    obj.userid = arr[i]['user']['user']['f_id'];
                    obj.productname = arr[i].name;//产品名;
                    obj.productid = arr[i].id;//产品id;
                    obj.applycount = arr[i].applycount;//报名人数
                    obj.beginapplytime = arr[i].beginapplytime;//发布距离当前的时间
                    obj.gentouperiod = arr[i].gentouperiod;//周期
                    obj.targetprofit = arr[i].targetprofit;//目标收益
                    var str = arr[i].endapplyday.toString();
                    obj.endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//截止日期
                    obj.endapplytimedesc = arr[i].endapplytimedesc;
                    obj.status = arr[i].status.toString();//状态
                    if(obj.userid != $scope.userObj.f_id)
                    {
                        $scope.gtLcsCPlist.push(obj);
                    }
                }
                else if(arr[i].status.toString() == "B")//服务实盘中
                {
                    var obj = {};
                    obj.userhead = arr[i]['user']['user']['f_head'];
                    obj.username = arr[i]['user']['user']['f_nickname'];
                    obj.userid = arr[i]['user']['user']['f_id'];
                    obj.productname = arr[i].name;//产品名;
                    obj.productid = arr[i].id;//产品id;
                    obj.gentoucount = arr[i].gentoucount;//多少人跟投
                    obj.jrsy = parseFloat(arr[i].jrsy);//当日收益
                    obj.ljsy = parseFloat(arr[i].ljsy);//累计收益
                    obj.account = arr[i].account;//账号
                    obj.status = arr[i].status.toString();//状态
                    var str = arr[i].gentouday.toString();
                    obj.kssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    var str2 = arr[i].endgentouday.toString();
                    obj.jssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    if(obj.userid != $scope.userObj.f_id)
                    {
                        $scope.gethyspz.push(obj);
                    }
                }
            }
        }
    }

    $scope.getqzcp = function()
    {
        //可跟投好友，可报名、可查看的实盘中的
        var message2 = {};
        message2['userid'] = $scope.userObj.f_id;
        message2['page.size'] = 'max';
        message2['page.no'] = "";
        message2['status'] = "A,B,G";//A表示发布中 B表示实盘中
        //console.log(message2);
        ajaxService.sendMessage('sunflower.p_selectfriendgentouproduct', message2, $scope.getqzcpCallBack)
    }

    $scope.getlcfwCallBack = function(_data)
    {
        $scope.dqlcbArray = [];
        console.log("当前理财包",_data);
        if(_data.productlist.length>0)//自己的产品：发布中、被跟投中
        {
            var arr3 = _data.productlist;
            for(var i = 0;i<arr3.length;i++)
            {
                if(arr3[i].status.toString() == "A")//预售期（已发布，报名期）：cp1(A)； 交易期：cp2(B)；解除中：cp3(D)；报名延期中：cp4(G)
                {
                    var obj = {};
                    obj.status = "cp1";
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.mbsy = arr3[i].targetprofit;
                    obj.beginapplytime = arr3[i].beginapplytime;

                    var str = arr3[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr3[i].endapplytimedesc;//报名截止日期

                    $scope.dqlcbArray.push(obj);
                }
                if(arr3[i].status.toString() == "G")
                {
                    var obj = {};
                    obj.status = "cp4";
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.mbsy = arr3[i].targetprofit;
                    obj.beginapplytime = arr3[i].beginapplytime;

                    var str = arr3[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr3[i].endapplytimedesc;//报名截止日期

                    $scope.dqlcbArray.push(obj);
                }
                else if(arr3[i].status.toString() == "B")//被跟投中
                {
                    var obj = {};
                    obj.status = "cp2";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    var str = arr3[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr3[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;

                    $scope.dqlcbArray.push(obj);
                }
                else if(arr3[i].status.toString() == "D")//解除中
                {
                    var obj = {};
                    obj.status = "cp3";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //console.log("kec", obj.gentoucount);
                    obj.endgentoutime = arr3[i].endgentoutime + "解除";//多久前解除跟投
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    obj.mbsy = arr3[i].targetprofit;
                    $scope.dqlcbArray.push(obj);
                }
            }
        }
    }

    $scope.getlcfw = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_selectrelativeproducts", message, $scope.getlcfwCallBack);
    }


    $scope.linkedhisgentouCallBack = function(_data)
    {
        console.log("历史被跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            $scope.historylcfwAccount = arr.length;
        }
    }
    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);

    }

    $scope.qzgtinit = function()
    {
        $scope.getlcfw();
        $scope.getlsbgtList();
        $scope.getqzcp();
    }

    $scope.qzgtinit();

    //历史跟投，理财服务（用户自己发布的理财包）
    $scope.gtb_tab1lsgtClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "gt_history.html?type=1";
        xinyuNewBrowser("gt_history.html?type=1" + "&&opentype=newwebview");
    }

    //跟投list点击
    $scope.gtlistItemClick = function(_obj)
    {
        if(_obj.status == "cp1" || _obj.status == "cp4")
        {
            //setbackList(window.location.href);
            //window.location = "gt_yfb.html?productid=" + _obj.productid;
            xinyuNewBrowser("gt_yfb.html?productid=" + _obj.productid + "&&opentype=newwebview", "dqlcbupdate");
        }
        else if(_obj.status == "cp2")
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview", "dqlcbupdate");
        }
        else if(_obj.status == "cp3")
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview", "dqlcbupdate");
        }
    }

    dqlcbupdate = function()
    {
        $scope.getlcfw();
        $scope.getlsbgtList();
    }

    $scope.hygtbmItemClick = function(_obj)
    {

        //    setbackList("uufpBase.html");
        //    window.location = "gtapply.html?productid=" + _obj.productid + "&&bgtuserid=" + _obj.userid + "&&backtitle=" + encodeURI("实盘");
        //alert("gtapply.html?productid=" + _obj.productid + "&&bgtuserid=" + _obj.userid + "&&opentype=newwebview");
        xinyuNewBrowser("gtapply.html?productid=" + _obj.productid + "&&bgtuserid=" + _obj.userid + "&&opentype=newwebview", "dqlistUpdate");
    }

    $scope.hysytemClick = function(_obj)
    {

        //    setbackList("uufpBase.html");
        //    window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.userid ;
        xinyuNewBrowser("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.userid + "&&opentype=newwebview", "dqlistUpdate");
    }

    dqlistUpdate = function()
    {
        $scope.getqzcp();
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html" + "?backtitle=" + encodeURI("实盘");
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview");
    }

    //发布跟投
    $scope.fbgtClick = function()
    {
        //window.location = "gtrelease.html?backurl=gtbBase.html";
        //setbackList(window.location.href);
        //window.location = "gtrelease.html";
        xinyuNewBrowser("gtrelease.html" + "?opentype=newwebview", "dqlcbupdate");
    }

    //返回
    $scope.qzgtbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }
}




