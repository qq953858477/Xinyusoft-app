/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function fw_kjsetCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.homeDivShow = true;//主界面信息
    $scope.productid = "";//产品id
    $scope.opentype = "";//打开类型

    $scope.assetopenflagall = "Y"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "Y";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "Y"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "Y";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "Y";//对大众，交易指令公开

    $scope.szintervalDuration = 1500;//间隔时间，8000毫秒
    $scope.szintervalId;

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.productid = getParameter('productid');
    $scope.opentype = getParameter("opentype");

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflagall = _data.assetopenflagall.toString();
            $scope.clearpositionopenflagall = _data.clearpositionopenflagall.toString();
            $scope.positionamountopenflagall = _data.positionamountopenflagall.toString();
            $scope.positionvarietyopenflagall = _data.positionvarietyopenflagall.toString();
            $scope.tradecommandopenflagall = _data.tradecommandopenflagall.toString();
        }
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }


    $scope.zhsetinit = function()
    {
        $scope.getcpsz();
    }

    $scope.zhsetinit();

    //服务设置修改
    $scope.szchange = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        message['userid'] = $scope.userObj.f_id;
        message['assetopenflagall'] = $scope.assetopenflagall;
        message['clearpositionopenflagall'] = $scope.clearpositionopenflagall;
        message['positionamountopenflagall'] = $scope.positionamountopenflagall;
        message['positionvarietyopenflagall'] = $scope.positionvarietyopenflagall;
        message['tradecommandopenflagall'] = $scope.tradecommandopenflagall;
        ajaxService.sendMessage("sunflower.p_setproductsetting", message, $scope.cpItemszCallBack);
    }

    $scope.cpItemszCallBack = function(_data)
    {
        //console.log("设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getcpsz();
            myMsg("设置成功");
            $scope.szintervalId = setInterval($scope.szover, $scope.szintervalDuration);
        }
        else
        {
            myAlert("设置失败");
        }
    }

    $scope.szover = function()
    {
        if ($scope.szintervalId != undefined) {
            clearInterval($scope.szintervalId);
        }
        try{
            layer.closeAll();
        }
        catch (e){}
    }

    //针对大众的设置
    $scope.cpItemsz = function(_str)
    {
        if(_str == "1")
        {
            $scope.assetopenflagall = $scope.sztrueValue($scope.assetopenflagall);
        }
        else if(_str == "2")
        {
            $scope.positionvarietyopenflagall = $scope.sztrueValue($scope.positionvarietyopenflagall);
            if($scope.positionvarietyopenflagall == "N")
            {
                $scope.positionamountopenflagall = "N";
            }
        }
        else if(_str == "3")
        {
            if($scope.positionvarietyopenflagall == "Y")
            {
                $scope.positionamountopenflagall = $scope.sztrueValue($scope.positionamountopenflagall);
            }
            else
            {
                myAlert("请先设置持仓品种为可见");
            }
        }
        else if(_str == "4")
        {
            $scope.clearpositionopenflagall = $scope.sztrueValue($scope.clearpositionopenflagall);
        }
        else if(_str == "5")
        {
            $scope.tradecommandopenflagall = $scope.sztrueValue($scope.tradecommandopenflagall);
        }
    }

    $scope.fwszbackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    $scope.sztrueValue = function(_str)
    {
        var str ="";
        if(_str == "Y")
        {
            str = "N";
        }
        else
        {
            str = "Y";
        }
        return str;
    }
}




