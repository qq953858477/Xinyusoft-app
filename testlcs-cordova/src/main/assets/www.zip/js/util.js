﻿/* 取得url参数 */
//function GetParameter(param) {
//	var query = window.location.search;
//	var iLen = param.length;
//	var iStart = query.indexOf(param);
//	if (iStart == -1) {
//		return "";
//	}
//	iStart += iLen + 1;
//	var iEnd = query.indexOf("&", iStart);
//	if (iEnd == -1) {
//		return query.substring(iStart);
//	}
//	else {
//		return query.substring(iStart, iEnd);
//	}
//}

//获取cookie里的值
//function getCookie(cookie_name)
//{
//	var strCookie=document.cookie;
//	var arrCookie=strCookie.split(";");
//	for(var i=0;i<arrCookie.length;i++)
//	{
//		var index = arrCookie[i].indexOf( cookie_name );
//		if( index >= 0 ) {
//				var v = unescape(arrCookie[i].substring( index + cookie_name.length + 1 ));
//
//			return v;
//		}
//	}
//	return "";
//}

//设置cookie
//function setCookie(name,value)
//{
//   var days=365;
//   var exp=new Date();
//   exp.setTime(exp.getTime()+days*24*60*60*1000);
//   document.cookie=name+"="+escape(value)+";expires="+exp.toGMTString()+";path=/";
//}

var timeistradeing = true;//是否是交易时间

//验证参数是否为空，或者未定义，或者为空字符串
function isNull(param)
{
	if(param==null || param == undefined || param == ""){
		return true;
	}
	return false;
}


//强制取小数点后两位
//function changeTwoDecimal_f(x) {
//    var f_x = parseFloat(x);
//    if (isNaN(f_x)) {
//        alert('function:changeTwoDecimal->parameter error');
//        return false;
//    }
//    var f_x = Math.round(x * 100) / 100;
//    var s_x = f_x.toString();
//    var pos_decimal = s_x.indexOf('.');
//    if (pos_decimal < 0) {
//        pos_decimal = s_x.length;
//        s_x += '.';
//    }
//    while (s_x.length <= pos_decimal + 2) {
//        s_x += '0';
//    }
//    return s_x;
//}

//是否已登录，如果已登录则返回sid,否则转到登录界面
//function isLogin(backurl){
//	var sid = getCookie("sid");
//	if(isNull(sid)){
//		if(isNull(backurl)){
//			var pathname = location.pathname;
//			backurl = pathname.substring(pathname.lastIndexOf("/")+1,pathname.length);
//			location = "../jy-login.html?backurl="+backurl;
//		}else{
//			location = "../jy-login.html";
//		}
//		return;
//	}
//	return sid;
//}

//接口调用post请求，全部为同步请求
//function post(funcode,sid,dataParam,method){
//	var url = "../ESBServlet?command=jzkesb.processaction&funcode="+funcode+"&dataParam="+dataParam+"&sid="+sid;
//	$.ajax({
//		url:url,
//		type:"post",
//		dataType:"json",
//		cache:false,
//		async: false,
//		statusCode:{"200":method,"404":function(){
//			alert("您访问的地址不存在!");
//		},"500":function(){
//			alert("服务发生错误，请稍候再访问!");
//		}}
//	});
//}

//行情调用post请求
//function hqpost(command,dataParam,method,async){
//	if(isNull(async)){
//		async = false;
//	}
//	var url = "../ESBServlet?command="+command+"&"+dataParam;
//	$.ajax({
//		url:url,
//		type:"post",
//		dataType:"json",
//		cache:false,
//		async: async,
//		statusCode:{"200":method,"404":function(){
//			alert("您访问的地址不存在!");
//		},"500":function(){
//			alert("服务发生错误，请稍候再访问!");
//		}}
//	});
//}
//跟据命令和参数调用进行post请求 async如果为false，则为同步请求，否则为异常,默认为同步 
//function copost(command,dataParam,method,async){
//	var url = "ESBServlet?command="+command+"&"+dataParam;
//	if(isNull(async)){
//		async = false;
//	}
//	$.ajax({
//		url:url,
//		type:"post",
//		dataType:"json",
//		cache:false,
//		async: async,
//		statusCode:{"200":method,"404":function(){
//			alert("您访问的地址不存在!");
//		},"500":function(){
//			alert("服务发生错误，请稍候再访问!");
//		}}
//	});
//}

function log(str){
	console.log(str);
}

/**
 * 将数值四舍五入(保留2位小数)后格式化成金额形式
 *
 * @param num 数值(Number或者String)
 * @return 金额格式的字符串,如'1,234,567.45'
 * @type String
 */
//function formatCurrency(num) {
//    num = num.toString().replace(/\$|\,/g,'');
//    if(isNaN(num))
//    num = "0";
//    sign = (num == (num = Math.abs(num)));
//    num = Math.floor(num*100+0.50000000001);
//    cents = num%100;
//    num = Math.floor(num/100).toString();
//    if(cents<10)
//    cents = "0" + cents;
//    for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
//    num = num.substring(0,num.length-(4*i+3))+','+
//    num.substring(num.length-(4*i+3));
//    return (((sign)?'':'-') + num + '.' + cents);
//}

//格式化数字单位,返回数据含两位小数点
//function formatNumberUtil(num){
//	var number = Number(num);
//	if(number >= 1000000000000 || number <= -1000000000000){
//		return changeTwoDecimal_f(number/1000000000000)+" 万亿";
//	}else if(number >= 100000000 || number <= -100000000){
//		return changeTwoDecimal_f(number/100000000)+" 亿";
//	}else if(number >= 10000 || number <= -10000){
//		return changeTwoDecimal_f(number/10000)+" 万";
//	}else{
//		return number;
//	}
//}

//将时间以“-”格式化
//function formateDate(date){
//	var year = date.substring(0,4);
//	var month = date.substring(4,6);
//	var day = date.substring(6,8);
//	return year+"-"+month+"-"+day;
//}

function webSocketReq(method,start,destination,url,_channelID, _topic){
	var ws = new WebSocket(url);
	ws.status = 0;				//0：正在连接 1：连接成功 2：已关闭连接
	ws.url = url;				//连接地址
	ws.code = 1;
	ws.message = method;
	ws.start = start;
	ws.destination = destination;
	console.log("_topic", _topic);
	ws.register = function(){
		var msg ="cmd=uniapp.register&tunnelname="+_channelID ;//JSON.stringify({"cmd":"uniapp.register","tunnelname":_channelID});
		ws.send(msg);
	};
	ws.sub = function(){
		var msg ="cmd=uniapp.sub&topic="+_topic+"&destination="+ws.destination;// JSON.stringify({"cmd":"uniapp.sub","topic":_topic, "destination":ws.destination});
		ws.send(msg);
	};
	//ws.unsub = function(){
	//	var msg = JSON.stringify({"cmd":"uniapp.unsub","topic":"ywbd"});
	//	ws.send(msg);
	//};
	ws.onopen = function(){
		ws.status = 1;
		ws.register();
	}
	ws.onmessage = function(evt){
		var resultmsg = JSON.parse(evt.data);
		log(evt.data);
		if(ws.code == 0){
			ws.message(evt);
			return;
		}
		
		var cmd = resultmsg.cmd;
		if(cmd == "uniapp.register"){
			ws.sub();
		}else if(cmd == "uniapp.sub"){
			ws.code = 0;
			if(!isNull(ws.start)){
				ws.start(evt);
			}
		}
	}
	ws.onclose = function(){
		log("已关闭: " + ws.url);
		ws.status = 2;
		ws =  new WebSocket(ws.url);
	}
	ws.onerror = function(){
		//alert("请求发生异常，请稍候再试!");
	}
	return ws;
}

//时间处理
function showTimeFun(premsgtime,curmsgtime)
{
	if(premsgtime == "")
	{
		return "";
	}
	var nowtime = new Date();
	var curm = nowtime.getMonth()+1;
	var curd = nowtime.getDate();
	var cury = nowtime.getFullYear();

	var curmsgY = curmsgtime.substring(0,4);
	var curmsgM = curmsgtime.substring(4,6);
	var curmsgD = curmsgtime.substring(6,8);
	var curmsgH = curmsgtime.substring(8,10);
	var curmsgMinute = curmsgtime.substring(10,12);
	var curmsgSec = curmsgtime.substring(12,14);

	var curmsgDate = new Date(curmsgY,curmsgM-1,curmsgD,curmsgH,curmsgMinute,curmsgSec);


	//var curmsgD = curmsgtime.substring(6,8);

	var prmsgY = premsgtime.substring(0,4);
	var prmsgM = premsgtime.substring(4,6);
	var prmsgD = premsgtime.substring(6,8);
	var prmsgH = premsgtime.substring(8,10);
	var prmsgMinute = premsgtime.substring(10,12);
	var prmsgSec = premsgtime.substring(12,14);

	var prmsgDate = new Date(prmsgY,prmsgM-1,prmsgD,prmsgH,prmsgMinute,prmsgSec);

	if((curmsgDate.getTime()-prmsgDate.getTime()) - 5 * 60 * 1000 > 0)
	{
		if(curm == curmsgM && curd == curmsgD && cury == curmsgY)
		{

			return curmsgH+":"+curmsgMinute;
		}
		else
		{
			if((curmsgDate.getTime() - prmsgDate.getTime()) - (7 * 24 * 3600 * 1000) >= 0)
			{
				//超过7天
				return curmsgY+"年"+curmsgM+"月"+curmsgD+"日 "+curmsgH + ":" + curmsgMinute+":"+curmsgSec;
			}
			else
			{
				var day = curmsgDate.getDay();

				if(day == 0)
				{
					return "星期天 "+curmsgH+":"+curmsgSec;
				}
				else if(day == 1)
				{
					return "星期一 "+curmsgH+":"+curmsgSec;
				}
				else if(day == 2)
				{
					return "星期二 "+curmsgH+":"+curmsgSec;
				}
				else if(day == 3)
				{
					return "星期三 "+curmsgH+":"+curmsgSec;
				}
				else if(day == 4)
				{
					return "星期四 "+curmsgH+":"+curmsgSec;
				}
				else if(day == 5)
				{
					return "星期五 "+curmsgH+":"+curmsgSec;
				}
				else(day == 6)
				{
					return "星期六 "+curmsgH+":"+curmsgSec;
				}
			}
		}
	}

	return "";
}

//当前时间
function getPresentTime()
{
	var pt = "";
	var nowtime = new Date();
	var curm = nowtime.getMonth()+1;
	var curmstr = "";
	if(curm<10)
	{
		curmstr = "0" + curm;
	}
	else
	{
		curmstr = curm.toString();
	}

	var curd = nowtime.getDate();

	var curdstr = "";
	if(curd<10)
	{
		curdstr = "0" + curd;
	}
	else
	{
		curdstr = curd.toString();
	}

	var cury = nowtime.getFullYear();
	var curystr  = cury.toString();

	var curHours = nowtime.getHours();
	var curHoursstr = "";
	if(curHours<10)
	{
		curHoursstr = "0" + curHours;
	}
	else
	{
		curHoursstr = curHours.toString();
	}
	var curMinute = nowtime.getMinutes();

	var curMinutestr = "";
	if(curMinute<10)
	{
		curMinutestr = "0" + curMinute;
	}
	else
	{
		curMinutestr = curMinute.toString();
	}

	var curSec = nowtime.getSeconds();

	var curSecstr = "";
	if(curSec<10)
	{
		curSecstr = "0" + curSec;
	}
	else
	{
		curSecstr = curSec.toString();
	}

	pt = curystr + curmstr + curdstr + curHoursstr + curMinutestr + curSecstr;
	return pt;
}

//将{applyid=227, type=apply, topic=glsqts, destination=17, applyaccount=122000000368}这样的数据转成json
function convertGltsToJson(str)
{
	str = str.replace(eval("/{/gi"), "");
	str = str.replace(eval("/}/gi"), "");
	str = str.replace(eval("/ /gi"), "");
	var strarray = str.split(",");

	var jsonObj = {};
	for ( var i in strarray){
		var a = strarray[i];
		var array = a.split("=");
		jsonObj[array[0]] = array[1];
	}

	return jsonObj;
}

//获取入参
function getParameter(param)
{
	var query = window.location.search;
	//console.log("getParameter", query);
	var iLen = param.length;
	var iStart = query.indexOf(param);
	if (iStart == -1) {
		return "";
	}
	iStart += iLen + 1;
	var iEnd = query.indexOf("&", iStart);
	if (iEnd == -1) {
		return query.substring(iStart);
	}
	else {
		return query.substring(iStart, iEnd);
	}
}


//返回用户信息
function isLogin()
{
	var localStorage = window.localStorage;
	return JSON.parse(localStorage.getItem('user'));

}

function getzqgsLogo(_str)
{
	var str = "";
	switch (_str)
	{
		case "moni"://模拟证券
			str = "images/logo_moni.png";
			break;
		case "91000"://恒生网络
			str = "images/logo_hensheng.png";
			break;
		case "xdzq"://信达证券
			str = "images/logo_xingda.png";
			break;
		case "ghzq"://国海证券
			str = "images/logo_guohai.png";
			break;
		case "dhzq"://东海证券
			str = "images/logo_donghai.png";
			break;
		default:
			break;
	}
	return str;
}

//置顶
function gotoUp()
{
	document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
}


function gettoday()
{
	var today = new Date();
	var yearstr = today.getFullYear();
	var monthN = today.getMonth()+1;
	var monthStr = "";

	if(monthN<10)
	{
		var monthStr = "0" + monthN;
	}
	else
	{
		var monthStr = monthN+"";
	}
	var dayN = today.getDate();
	if(dayN<10)
	{
		var dayStr = "0" + dayN;
	}
	else
	{
		var dayStr = dayN+"";
	}
	 var todayStr = yearstr + "-" + monthStr + "-" + dayStr;
	return todayStr;
}

function gettodayno()
{
	var today = new Date();
	var yearstr = today.getFullYear();
	var monthN = today.getMonth()+1;
	var monthStr = "";

	if(monthN<10)
	{
		var monthStr = "0" + monthN;
	}
	else
	{
		var monthStr = monthN+"";
	}
	var dayN = today.getDate();
	if(dayN<10)
	{
		var dayStr = "0" + dayN;
	}
	else
	{
		var dayStr = dayN+"";
	}
	var todayStr = yearstr + monthStr + dayStr;
	return todayStr;
}

function getyesterdayno()
{
	var today = new Date();
	var yesterday_milliseconds=today.getTime()-1000*60*60*24;
	var yesterday = new Date();
	yesterday.setTime(yesterday_milliseconds);
	//console.log("yes", yesterday);
	//console.log(today, yesterday);
	var yearstr = yesterday.getFullYear();
	var monthN = yesterday.getMonth()+1;
	var monthStr = "";

	if(monthN<10)
	{
		var monthStr = "0" + monthN;
	}
	else
	{
		var monthStr = monthN+"";
	}
	var dayN = yesterday.getDate();
	if(dayN<10)
	{
		var dayStr = "0" + dayN;
	}
	else
	{
		var dayStr = dayN+"";
	}
	var yesterdayStr = yearstr + monthStr + dayStr;
	return yesterdayStr;
}




//清空返回列表
function deleteback()
{
	var localStorage = window.localStorage;
	try
	{
		//console.log("backlistsucess");
		localStorage.removeItem("backList");
	}
	catch(e){
		//console.log("backlisterror");
	}
}

//当前页面信息放入返回列表
function setbackList(_str)
{
	var localStorage = window.localStorage;
	var arr = JSON.parse(localStorage.getItem('backList'));
	//console.log("backlist", arr)
	if(arr == null || arr == undefined)
	{
		arr = [];
	}
	arr.push(_str);
	//console.log("push",_str);
	localStorage.setItem('backList', JSON.stringify(arr));
}

//获取返回页面信息
function getbackList()
{
	var localStorage = window.localStorage;
	var arr = JSON.parse(localStorage.getItem('backList'));
	if(arr != null && arr!= undefined)
	{
		if(arr.length>0)
		{
			var str = arr[arr.length-1];
			arr.splice(arr.length-1,1);
			localStorage.setItem('backList', JSON.stringify(arr));
			return str;
		}
	}
}


//判断是否全为数值
function numericCheck(_str)
{
	var len = _str.length;
	for(var i=0;i<len;i++)
	{
		//console.log(_str.charAt(i));
		if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
		{
			//alert("含有非数字字符");
			return false;
		}
	}
	return true;
}

//判断是否全为数值和小数点
function valueCheck(_str)
{
	var len = _str.length;
	for(var i=0;i<len;i++)
	{
		//console.log(_str.charAt(i));
		if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
		{
			//alert("含有非数字字符");
			if(_str.charAt(i) != ".")
			{
				return false;
			}
		}
	}
	return true;
}

//小数位数判断
function decimaldigitsCheck(_str)
{
	var pointindex = _str.indexOf(".",1);
	var len = _str.length;
	if(len-1-pointindex>2)
	{
		return false;
	}
	else
	{
		return true;
	}
}

//判断substr字符串在str中出现的次数  isIgnore是否忽略大小写!
function countSubstr(str,substr,isIgnore){
	//console.log(str, substr);
	var count = 0;
	var reg="";
	if(isIgnore==true)
	{
		reg="/"+substr+"/gi";
	}
	else
	{
		reg="/"+substr+"/g";
	}
	reg=eval(reg);
	if(str.match(reg)==null)
	{
		count=0;
	}
	else
	{
		count=str.match(reg).length;
	}
	return count;
}

function getfwscStr(input)
{
	var result = "";
	if(input == "1w")
	{
		result = "1周";
	}
	else if(input == "1m")
	{
		result = "1个月";
	}
	else if(input == "3m")
	{
		result = "3个月";
	}
	else if(input == "6m")
	{
		result = "半年";
	}
	else if(input == "12m")
	{
		result = "1年";
	}
	//console.log(input, result);
	return result;
}

//判断是否是花等表情
function checkisFlower(_str)
{
	var ma = false;
	if(_str == "//flower//")
	{
		ma = false;
	}
	else
	{
		ma = true;
	}
	return ma;
}

//评分显示
function setsunflowerpf(pointindex)
{
	var arr = [];
	if(pointindex != 0)
	{
		var num = pointindex;
		for(var i = 1;i< num+1; i++)
		{
			var obj = {};
			obj.value = i;
			obj.djsrc = "images/star1.png";
			arr.push(obj);
		}
		for(var i = num+1;i<6;i++)
		{
			var obj = {};
			obj.value = i;
			obj.djsrc = "images/star2.png";
			arr.push(obj);
		}
	}
	else
	{
		for(var i = 1;i<6;i++)
		{
			var obj = {};
			obj.value = i;
			obj.djsrc = "images/star2.png";
			arr.push(obj);
		}
	}
	return arr;
}


function xgmsgPop(_str)
{
	//alert("推送信息返回" + _str);
	//var da = JSON.parse(_str);
	//alert("推送登陆返回type，" + da.tp  + " " + da.id);
	//var errcode = da.errcode;
	//if(errcode == null || errcode == undefined || errcode == "")
	//{

}

//截取小数点后两位
jqnumxsdlw = function(_value)
{
	var backvalue;
	var str = _value.toString();
	var str2 = "";
	var _index = str.indexOf(".", 0);//小数点的位置
	if(_index == -1)//无小数点
	{
		backvalue = _value;
	}
	else//有小数点
	{
		//console.log(str.length, _index, str.length);
		str2 = str.substring(_index, str.length);
		//console.log("backvalue",str2);
		if(str2.length <= 3)//小数点后两位
		{
			backvalue = _value;
		}
		else
		{
			backvalue = parseFloat(str.substring(0, _index+3));
			//console.log("backvalue",backvalue);
		}
	}
	return backvalue;
}

function getccStatus(_str)
{
	var str = "";
	switch (_str)
	{
		case "0":
			str = "正常";
			break;
		case "1":
			str = "涨停";
			break;
		case "2":
			str = "跌停";
			break;
		case "3":
			str = "停牌";
			break;
		case "4":
			str = "退市";
			break;
		default:
			break;
	}
	return str;
}

//证券类型
function getzqStatus(_str)
{
	var str = "";
	switch (_str)
	{
		case "zs":
			str = "4";
			break;
		case "a":
			str = "0";
			break;
		case "b":
			str = "0";
			break;
		case "jj":
			str = "5";
			break;
		default:
			str = "11";
			break;
	}
	return str;
}

xhintIntervalDuration = 30000;//间隔时间，8000毫秒
xhintintervalId = "";

//去除
function xhintClearInterval() {
	if (!!xhintintervalId) {
		clearInterval(xhintintervalId);
	}
}

function getAllHintCallback(_data)
{
	//console.log("hint",_data);
	if(_data.op.code.toString() == "Y")
	{
		//alert("xhint");
		var jsonstr = JSON.stringify(_data.xhintlist);
		//console.log(2, str);
		//str.replace(/'taskgoal'/,"taskGoal");
		//str.replace(/;/,"?");
		var re1 = new RegExp("taskgoal",["g"]);
		var re2 = new RegExp("totalnum",["g"]);
		var re3 = new RegExp("lastmessage",["g"]);
		var re4 = new RegExp("lastsender",["g"]);
		jsonstr = jsonstr.replace(re1, "taskGoal");
		jsonstr = jsonstr.replace(re2, "totalNum");
		jsonstr = jsonstr.replace(re3, "lastMessage");
		jsonstr = jsonstr.replace(re4, "lastSender");
		//jsonstr = '{"lastSender":"77","totalNum":"1","time":"2016-02-21 18:07:27.0","lastMessage":"//flower//","type":"comment","taskGoal":"product_106"}';
		//console.log(jsonstr);
		//alert(jsonstr);


		try
		{
			navigator.SqliteUserPlugin.update(function (data){
				//alert("appback:" + data);
				xhintClearInterval();
				xhintintervalId = setInterval(getAllHint, xhintIntervalDuration);
			}, jsonstr);
		}catch (e){
			//alert("xhinterror:" + e.toString());
		}


		//console.log(3, JSON.parse(jsonstr));
		//xhintClearInterval();
		//xhintintervalId = setInterval(getAllHint, xhintIntervalDuration);
	}
	else
	{

	}

}

function getAllHint() {
	var message = {};
	//console.log("gethint", jsonpUrl);
	message['command'] = "user.getallxhintaction";
	message['rmd'] = new Date().getTime();
	$.ajax({
		type: "POST",
		data: message,
		url: jsonpUrl,
		dataType: "jsonp",
		async: false,
		//jsonp和jsonpCallback两参数可以不要，在请求WebService时，会自动加callback参数在url后面
		timeout: 60000,
		success: getAllHintCallback,
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			if (XMLHttpRequest.readyState == 4) {
				//alert(action + ":" + XMLHttpRequest.status);
				//alert(textStatus + "  " + errorThrown);
				//console.log(action + ":" + XMLHttpRequest.status);
				//console.log(textStatus + "  " + errorThrown);
			}
		}
	});
}


