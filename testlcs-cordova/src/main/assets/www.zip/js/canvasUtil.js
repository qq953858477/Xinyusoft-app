// JavaScript Document

$(function($){
	$.fn.extend({
		/**
		 * 获取canvas的上下文绘图环境
		 * @returns 
		 */
		getContent:function(){
			return $(this)[0].getContext('2d');
		},
		
		/**
		 *  获取canvas的宽度
		 * @returns canvas的宽度 width
		 */
		getWidth:function(){
			return $(this)[0].width;
		},
		/**
		 * 获取canvas的高度
		 * @returns  canvas的高度 height
		 */
		getHeight:function(){
			return $(this)[0].height;
		},
		/**
		 * 设置canvas宽度
		 * @param width 宽
		 */
		setWidth:function(width){
			return $(this)[0].width = width;
		},
		/**
		 * 设置canvas高度
		 * @param height 高
		 */
		setHeight:function(height){
			return $(this)[0].height = height;
		},
	
		/**************/
		/**颜色样式和阴影**/
		/**************/
		
		/*属性*/
		/*
		 * 设置或返回用于笔触的颜色、渐变或模式
		 */
		strokeStyle:function(style){
			if(isNull(style)){
				return $(this).getContent().strokeStyle;
			}
			$(this).getContent().strokeStyle = style;
			return $(this);
		},
		/*
		 *设置或返回用于填充绘画的颜色、渐变或模式
		 */
		fillStyle:function(style){
			if(isNull(style)){
				return $(this).getContent().fillStyle;
			}
			$(this).getContent().fillStyle = style;
			return $(this);
		},
		/*
		 *设置或返回用于阴影的颜色
		 */
		shadowColor:function(color){
			if(isNull(color)){
				return $(this).getContent().shadowColor;
			}
			$(this).getContent().shadowColor = color;
			return $(this);
		},
		/*
		 *设置或返回用于阴影的模糊级别
		 */
		shadowBlur:function(blur){
			if(isNull(blur)){
				return $(this).getContent().shadowBlur;
			}
			$(this).getContent().shadowBlur = blur;
			return $(this);
		},
		/*
		 *设置或返回阴影距形状的水平距离
		 */
		shadowOffsetX:function(offsetX){
			if(isNull(offsetX)){
				return $(this).getContent().shadowOffsetX;
			}
			$(this).getContent().shadowOffsetX = offsetX;
			return $(this);
		},
		/*
		 *设置或返回阴影距形状的垂直距离
		 */
		shadowOffsetY:function(offsetY){
			if(isNull(offsetY)){
				return $(this).getContent().shadowOffsetY;
			}
			$(this).getContent().shadowOffsetX = offsetY;
			return $(this);
		},
		/* 方法 */
		
		/*
		 *创建线性渐变（用在画布内容上）
		 */
		createLinearGradient:function(x0,y0,x1,y1){
			$(this).getContent().createLinearGradient(x0,y0,x1,y1);
			return $(this);
		},
		/*
		 *在指定的方向上重复指定的元素
		 */
		createPattern:function(image,repeatType){
			$(this).getContent().createPattern(image,repeatType);
			return $(this);
		},
		/*
		 *在指定的方向上重复指定的元素
		 */
		createRadialGradient:function(x0,y0,r0,x1,y1,r1){
			$(this).getContent().createRadialGradient(x0,y0,r0,x1,y1,r1);
			return $(this);
		},
		/*
		 *在指定的方向上重复指定的元素
		 */
		addColorStop:function(stop,color){
			$(this).getContent().addColorStop(stop,color);
			return $(this);
		},
		
		
		
		
		
		
		
		
		
		/** 线条样式 **/
		/************/
		/************/
		/* 属性 */
		/*
		 *设置或返回线条的结束端点样式
		 */
		lineCap:function(cap){
			if(isNull(cap)){
				return $(this).getContent().lineCap;
			}
			$(this).getContent().lineCap = cap;
			return $(this);
		},
		/*
		 *设置或返回两条线相交时，所创建的拐角类型
		 */
		lineJoin:function(join){
			if(isNull(join)){
				return $(this).getContent().lineJoin;
			}
			$(this).getContent().lineJoin = join;
			return $(this);
		},
		/*
		 *设置或返回当前的线条宽度
		 */
		lineWidth:function(width){
			if(isNull(width)){
				return $(this).getContent().lineWidth;
			}
			$(this).getContent().lineWidth = width;
			return $(this);
		},
		/*
		 *设置或返回当前的线条宽度
		 */
		miterLimit:function(limit){
			if(isNull(limit)){
				return $(this).getContent().miterLimit;
			}
			$(this).getContent().miterLimit = limit;
			return $(this);
		},
		/** 矩形 **/
		/*********/
		/*********/
		/*方法*/
		/*
		 *创建矩形
		 */
		rect:function(x,y,width,height){
			$(this).getContent().rect(x,y,width,height);
			return $(this);
		},
		/*
		 *绘制“被填充”的矩形
		 */
		fill:function(){
			$(this).getContent().fill();
			return $(this);
		},
		/*
		 *绘制“被填充”的矩形
		 */
		fillRect:function(x,y,width,height){
			$(this).getContent().fillRect(x,y,width,height);
			return $(this);
		},
		/*
		 *绘制矩形（无填充）
		 */
		strokeRect:function(x,y,width,height){
			$(this).getContent().strokeRect(x,y,width,height);
			return $(this);
		},
		/*
		 *绘制矩形（无填充）
		 */
		clearRect:function(x,y,width,height){
			$(this).getContent().clearRect(x,y,width,height);
			return $(this);
		},
		
		/** 路径 **/
		/*********/
		/*********/
		/* 方法 */
		/*
		 *填充当前绘图（路径）
		 */
		fill:function(){
			$(this).getContent().fill();
			return $(this);
		},
		/*
		 *绘制已定义的路径
		 */
		stroke:function(){
			$(this).getContent().stroke();
			return $(this);
		},
		/*
		 *起始一条路径，或重置当前路径
		 */
		beginPath:function(){
			$(this).getContent().beginPath();
			return $(this);
		},
		/*
		 *把路径移动到画布中的指定点，不创建线条
		 */
		moveTo:function(x,y){
			$(this).getContent().moveTo(x,y);
			return $(this);
		},
		/*
		 *创建从当前点回到起始点的路径
		 */
		closePath:function(){
			$(this).getContent().closePath();
			return $(this);
		},
		/*
		 *添加一个新点，然后在画布中创建从该点到最后指定点的线条
		 */
		lineTo:function(x,y){
			$(this).getContent().lineTo(x,y);
			return $(this);
		},
		/*
		 *从原始画布剪切任意形状和尺寸的区域
		 */
		clip:function(){
			$(this).getContent().clip();
			return $(this);
		},
		/*
		 *创建二次贝塞尔曲线
		 */
		quadraticCurveTo:function(cpx,cpy,x,y){
			$(this).getContent().quadraticCurveTo(cpx,cpy,x,y);
			return $(this);
		},
		/*
		 *创建三次方贝塞尔曲线
		 */
		bezierCurveTo:function(cp1x,cp1y,cp2x,cp2y,x,y){
			$(this).getContent().bezierCurveTo(cp1x,cp1y,cp2x,cp2y,x,y);
			return $(this);
		},
		/*
		 *创建弧/曲线（用于创建圆形或部分圆）
		 */
		arc:function(x,y,r,sAngle,eAngle,counterclockwise){
			$(this).getContent().arc(x,y,r,sAngle,eAngle,counterclockwise);
			return $(this);
		},
		/*
		 *创建两切线之间的弧/曲线
		 */
		arcTo:function(x1,y1,x2,y2,r){
			$(this).getContent().arcTo(x1,y1,x2,y2,r);
			return $(this);
		},
		/*
		 *如果指定的点位于当前路径中，则返回 true，否则返回 false
		 */
		isPointInPath:function(x,y){
			$(this).getContent().isPointInPath(x,y);
			return $(this);
		},
		/** 转换 **/
		/*********/
		/*********/
		/* 方法 */
		/*
		 *缩放当前绘图至更大或更小
		 */
		scale:function(scalewidth,scaleheight){
			$(this).getContent().scale(scalewidth,scaleheight);
			return $(this);
		},
		/*
		 *旋转当前绘图
		 */
		rotate:function(angle){
			$(this).getContent().rotate(angle);
			return $(this);
		},
		/*
		 *重新映射画布上的 (0,0) 位置
		 */
		translate:function(x,y){
			$(this).getContent().translate(x,y);
			return $(this);
		},
		/*
		 *替换绘图的当前转换矩阵
		 */
		transform:function(a,b,c,d,e,f){
			$(this).getContent().transform(a,b,c,d,e,f);
			return $(this);
		},
		/*
		 *将当前转换重置为单位矩阵。然后运行 transform()
		 */
		setTransform:function(a,b,c,d,e,f){
			$(this).getContent().setTransform(a,b,c,d,e,f);
			return $(this);
		},
		/** 文本 **/
		/*********/
		/*********/
		/* 属性 */
		/*
		 *设置或返回文本内容的当前字体属性
		 */
		font:function(font){
			if(isNull(font)){
				return $(this).getContent().font;
			}
			$(this).getContent().font = font;
			return $(this);
		},
		/*
		 *设置或返回文本内容的当前对齐方式
		 */
		textAlign:function(align){
			if(isNull(align)){
				return $(this).getContent().textAlign;
			}
			$(this).getContent().textAlign = align;
			return $(this);
		},
		/*
		 *设置或返回在绘制文本时使用的当前文本基线
		 */
		textBaseline:function(baseLine){
			if(isNull(baseLine)){
				return $(this).getContent().textBaseline;
			}
			$(this).getContent().textBaseline = baseLine;
			return $(this);
		},
		/* 方法 */
		/*
		 *在画布上绘制“被填充的”文本
		 */
		fillText:function(text,x,y,maxWidth){
			$(this).getContent().fillText(text,x,y,maxWidth);
			return $(this);
		},
		/*
		 *在画布上绘制文本（无填充）
		 */
		strokeText:function(text,x,y,maxWidth){
			$(this).getContent().strokeText(text,x,y,maxWidth);
			return $(this);
		},
		/*
		 *返回包含指定文本宽度的对象
		 */
		measureText:function(text){
			$(this).getContent().measureText(text).width;
			return $(this);
		},
		/** 图像绘制 **/
		/*********/
		/*********/
		/* 方法*/
		/*
		 *向画布上绘制图像、画布或视频
		 *在画布上定位
		 */
		drawImage:function(img,x,y){
			$(this).getContent().drawImage(img,x,y);
			return $(this);
		},
		/*
		 *向画布上绘制图像、画布或视频
		 *在画布上定位图像，并规定图像的宽度和高度
		 */
		drawImage:function(img,x,y,width,height){
			$(this).getContent().drawImage(img,x,y,width,height);
			return $(this);
		},
		/*
		 *向画布上绘制图像、画布或视频
		 *剪切图像，并在画布上定位被剪切的部分
		 */
		drawImage:function(img,sx,sy,swidth,sheight,x,y,width,height){
			$(this).getContent().drawImage(img,sx,sy,swidth,sheight,x,y,width,height);
			return $(this);
		},
		
		/** 像素操作 **/
		/*********/
		/*********/
		/* 属性 */
		/*
		 *返回 ImageData 对象的宽度
		 */
		imageWidth:function(width){
			if(isNull(width)){
				return $(this).getContent().width;
			}
			$(this).getContent().width = width;
			return $(this);
		},
		/*
		 *返回 ImageData 对象的宽度
		 */
		imageHeight:function(height){
			if(isNull(height)){
				return $(this).getContent().height;
			}
			$(this).getContent().height = height;
			return $(this);
		},
		
		/* 方法 */
		/*
		/*
		 *创建新的、空白的 ImageData 对象
		 *创建与指定的另一个 ImageData 对象尺寸相同的新 ImageData 对象（不会复制图像数据）象
		 */
		createImageData:function(width,height){
			return $(this).getContent().createImageData(width,height);
		},
		/*
		 *返回 ImageData 对象，该对象为画布上指定的矩形复制像素数据
		 *
		 */
		getImageData:function(x,y,width,height){
			return $(this).getContent().getImageData(x,y,width,height);
		},
		/*
		 *把图像数据（从指定的 ImageData 对象）放回画布上
		 */
		putImageData:function(imgData,x,y,dirtyX,dirtyY,dirtyWidth,dirtyHeight){
			$(this).getContent().putImageData(imgData,x,y,dirtyX,dirtyY,dirtyWidth,dirtyHeight);
			return $(this);
		},
		/** 合成 **/
		/*********/
		/*********/
		/* 属性 */
		/*
		 *设置或返回绘图的当前 alpha 或透明值
		 */
		globalAlpha:function(alpha){
			if(isNull(alpha)){
				return $(this).getContent().globalAlpha;
			}
			$(this).getContent().globalAlpha = alpha;
			return $(this);
		},
		/*
		 *设置或返回绘图的当前 alpha 或透明值
		 */
		globalCompositeOperation:function(compositeOperation){
			if(isNull(compositeOperation)){
				return $(this).getContent().globalCompositeOperation;
			}
			$(this).getContent().globalCompositeOperation = compositeOperation;
			return $(this);
		},
		
		/** 其他 **/
		/*********/
		/*********/
		/* 方法 */
		/*
		 *保存当前环境的状态
		 */
		save:function(){
			$(this).getContent().save();
			return $(this);
		},
		/*
		 *返回之前保存过的路径状态和属性
		 */
		restore:function(){
			$(this).getContent().restore();
			return $(this);
		},
		createEvent:function(){
			$(this).getContent().createEvent();
			return $(this);
		},
		toDataURL:function(){
			$(this).getContent().toDataURL();
			return $(this);
		},
		
		
		
		
		
		
		
		
		/*
		 *绘制一条直线
		 */
		drawLine:function(startX,startY,endX,endY){
			$(this).beginPath();
			$(this).moveTo(startX,startY);
			$(this).lineTo(endX,endY);
			$(this).stroke();
			return $(this);
		},
		/*
		 *连续绘制多条直线
		 *lines = [[x,y],[x,y]]
		 */
		drawLines:function(startX,startY,lines){
			$(this).beginPath();
			$(this).moveTo(startX,startY);
			for(var i = 0; i<lines.length; i++){
				$(this).lineTo(lines[i][0], lines[i][1]);
			}
			$(this).stroke();
			return $(this);
		},
		/*
		 *绘制一条填充直线
		 */
		drawFillLine:function(startX,startY,endX,endY){
			$(this).moveTo(startX,startY);
			$(this).lineTo(endX,endY);
			$(this).fill();
			return $(this);
		},
		/*
		 *绘制一条带圆头直线
		 */
		drawRoundLine:function(startX,startY,endX,endY,lineColor,startColor,endColor){
			if(!isNull(lineColor)){
				$(this).strokeStyle(lineColor);
			}
			var lineWidth = $(this).lineWidth();
			$(this).beginPath();
			$(this).drawLine(startX,startY,endX,endY,lineColor);
			$(this).beginPath();
			if(!isNull(endColor)){
				$(this).fillStyle(endColor);
			}else{
				$(this).fillStyle(lineColor);
			}
			$(this).drawFillArc(endX,endY,lineWidth*3,0,Math.PI*2,false);
			$(this).beginPath();
			if(!isNull(startColor)){
				$(this).fillStyle(startColor);
			}else{
				$(this).fillStyle(lineColor);
			}
			$(this).drawFillArc(startX,startY,lineWidth*3,0,Math.PI*2,false);
			return $(this);
		},
		//绘制金条lines [[20,30],[155,166],[255,255]]
		drawRoundLines:function(lines,colors){
			for(var i = 0; i<lines.length-1; i++){
				var startX = lines[i][0];
				var startY = lines[i][1];
				var endX = lines[i+1][0];
				var endY = lines[i+1][1];
				$(this).drawRoundLine(startX,startY,endX,endY,colors[0],colors[1],colors[2])
			}
		},
		/*
		 *绘制一个不被填充的圆 
		 */
		drawArc:function(x,y,r,sAngle,eAngle,counterclockwise){
			$(this).arc(x,y,r,sAngle,eAngle,counterclockwise);
			$(this).stroke();
			return $(this);
		},
		/*
		 *绘制一个填充的圆
		 */
		drawFillArc:function(x,y,r,sAngle,eAngle,counterclockwise){
			$(this).arc(x,y,r,sAngle,eAngle,counterclockwise);
			$(this).fill();
			return $(this);
		},
		/*
		 * 绘制不被填充的矩形
		 */
		drawRect:function(x,y,width,height,color){
			if(!isNull(color)){
				$(this).strokeStyle(color);
			}
			$(this).strokeRect(x,y,width,height);
			return $(this);
		},
		/*
		 *绘制填充的矩形
		 */
		drawFillRect:function(x,y,width,height,color){
			if(!isNull(color)){
				$(this).fillStyle(color);
			}
			$(this).fillRect(x,y,width,height);
			return $(this);
		},
		
		/** 清除 **/
		/*********/
		/*********/
		//清除整个canvas
		clearCanvasAll:function(color)
		{
			var width = $(this).getWidth();
			var height = $(this).getHeight();
			if(!isNull(color)){
				$(this).fillStyle(color);
				$(this).fillRect(0,0,width,height);
			}else{
				$(this).clearRect(0,0,width,height);
			}
			return $(this);
		},
		/*
		 *清除指定的矩形区域，如果有颜色的话，则指定的颜色清除
		 */
		clear:function(x,y,width,height,color){
			if(!isNull(color)){
				$(this).fillStyle(color);
				$(this).fillRect(x,y,width,height);
			}else{
				$(this).clearRect(x,y,width,height);
			}
			return $(this);
		},

		
		/*****事件*******/
		//添加事件
		
		addEvent:function(eventType,method){
			if(eventType.indexOf("mouse") != -1){
				$(this).bind(eventType,function(event){
					var offsetX = event.offsetX;
					var offsetY = event.offsetY;
					e = {"offsetX":offsetX,"offsetY":offsetY};
					method(e,event);
					event.preventDefault();
				});
			}else if(eventType.indexOf("touch") != -1){
				$(this).bind(eventType,function(event){
					var left = $(this).offset().left;
					var top = $(this).offset().top;
					var clientX = event.originalEvent.changedTouches[0].clientX;
					var clientY = event.originalEvent.changedTouches[0].clientY;
					
					var offsetX = clientX - left;
					var offsetY = clientY - top;
					e = {"offsetX":offsetX,"offsetY":offsetY};
					method(e,event);
					event.preventDefault();
				});
			}
			return $(this);
		}
	});
	
	/*
	 *非空验证，如果是空则返回true,否则返回false
	 */
	function isNull(param){
		if(param==null||param==undefined){
			return true;
		}
		return false;
	}
	/*
	 *验证是否为canvas对象
	 */
	function isCanvas(){
		if($(this).prop("tagName")!="CANVAS"){
			return false;
		}else{
			return true;
		}		
	}
});

/**
 * 绘制饼形图
 * @param canvas 需要绘制饼形图的canvas对象id;
 * @param param 通过此参数进行对饼形图的修改化定制
 */
$.pieChart = function(canvas,param){
	canvas = "#"+canvas;
	
	var backColor = "#191A1F";
	var outArcColor = "#1D222F";
	var inArcColor = "#252C3C";
	
	var w = $(canvas).getWidth()-20;
	var h =  $(canvas).getHeight()-20;
	
	var x = w*0.5;
	var y = h*0.5;
	var pi = 2*Math.PI;
	var data = param;
	var blur = 3;
	var colors = ["#48BE08","#EC3608","#F87F00","#8EE80C"];
	var text = ["主力流入","散户流入","主力流出","散户流出"];
	var outR = Math.min(w,h)*0.25;
	var outLine = outR*0.09;
	var inR = outR*0.7;
	var inLine = outR*0.10;
	var centerR = outR*0.86;	
	var centerLine = outR*0.2;
	
	$(canvas).beginPath().strokeStyle(outArcColor).lineWidth(outLine).drawArc(x,y,outR,0,pi,false);
	$(canvas).beginPath().strokeStyle(inArcColor).lineWidth(inLine).drawArc(x,y,inR,0,pi,false);
	var startPI = 0;
	var endPI = 0;
	var dPI = 0;
	var nowPI = 0;
	//var sudu = 0.01;
	$(canvas).lineCap("butt").shadowBlur(blur).shadowColor("black");
	var i= 0;
	var action = function(){
		startPI = endPI-0.01;
		if(endPI >= pi*data[i]+dPI){
			dPI = pi*data[i]+dPI;
			var startX = 0;
			var startY = 0;
			var endX = 0;
			var endY = 0;
			var fontX = 0;
			var fontY = 0;
			var font2X = 0;
			var font2Y = 0;
			var juli = 2;
			var lineLong = outR*0.2;
			var position = endPI-pi*data[i]*0.5;
			var sz = function(){
				if(position < Math.PI*0.5){
					startX = x + Math.cos(position)*outR + juli;
					startY = y + Math.sin(position)*outR + juli;
					endX = startX + lineLong;
					endY = startY + lineLong;
					fontX = endX + lineLong/2;
					fontY = endY + lineLong;
					font2X = fontX;
					font2Y = fontY + lineLong+6;
				}else if(position <= Math.PI){
					startX = x - Math.sin(position-0.5*Math.PI)*outR -juli;
					startY = y + Math.cos(position-0.5*Math.PI)*outR +juli;
					endX = startX - lineLong;
					endY = startY + lineLong;
					fontX = endX - lineLong-5;
					fontY = endY + lineLong+5;
					font2X = fontX - lineLong+5;
					font2Y = fontY + lineLong+6;
				}else if(position <= Math.PI*1.5){
					startX = x - Math.cos(position-Math.PI)*outR - juli;
					startY = y - Math.sin(position-Math.PI)*outR - juli;
					endX = startX - lineLong;
					endY = startY - lineLong;
					fontX = endX - lineLong;
					fontY = endY - lineLong;
					font2X = fontX - lineLong;
					font2Y = fontY - lineLong-5;
				}else if(position <= Math.PI*2){
					startX = x + Math.sin(position-Math.PI*1.5)*outR + juli;
					startY = y - Math.cos(position-Math.PI*1.5)*outR - juli;
					endX = startX + lineLong;
					endY = startY - lineLong;
					fontX = endX + lineLong;
					fontY = endY - lineLong;
					font2X = fontX;
					font2Y = fontY + lineLong+2;
				}
			}
			
			if((data[0]<=0.1 && data[1]<=0.1 && data[2] <= 0.1)){
				startX = x + Math.cos(position)*outR + juli;
				startY = y + Math.sin(position)*outR + juli;
				if(i == 0){
					endX = startX + lineLong;
					endY = startY - lineLong;
					fontX = endX;
					fontY = endY -lineLong;
					font2X = fontX;
					font2Y = fontY - lineLong;
				}else if(i == 1){
					endX = startX + lineLong;
					endY = startY + lineLong/2;
					fontX = endX+lineLong;
					fontY = endY + lineLong;
					font2X = fontX;
					font2Y = fontY + lineLong;
				}else if(i == 2){
					endX = startX + lineLong/2;
					endY = startY + lineLong*1.5;
					fontX = endX;
					fontY = endY + lineLong*1.5;
					font2X = fontX;
					font2Y = fontY + lineLong;
					
				}else{
					sz();
				}
			}else if(data[0] <= 0.1 && data[1] <= 0.1 && data[3] <= 0.1){
				if(i == 0){
					startX = x + Math.cos(position)*outR + juli;
					startY = y + Math.sin(position)*outR + juli;
					endX = startX + lineLong*1.5;
					endY = startY + lineLong/2;
					fontX = endX+lineLong;
					fontY = endY + lineLong/2;
					font2X = fontX;
					font2Y = fontY + lineLong;
				}else if(i == 1){
					startX = x + Math.cos(position)*outR + juli;
					startY = y + Math.sin(position)*outR + juli;
					endX = startX + lineLong/2;
					endY = startY + lineLong*1.5;
					fontX = endX;
					fontY = endY + lineLong*1.5;
					font2X = fontX;
					font2Y = fontY + lineLong;
				}else if(i == 3){
					startX = x + Math.sin(position-Math.PI*1.5)*outR + juli;
					startY = y - Math.cos(position-Math.PI*1.5)*outR - juli;
					endX = startX + lineLong;
					endY = startY - lineLong*1.5;
					fontX = endX+lineLong/2;
					fontY = endY - lineLong/2;
					font2X = fontX;
					font2Y = fontY - lineLong;
				}else{
					sz();
				}
			}else if(data[1] <= 0.1 && data[2] <= 0.1 && data[3] <= 0.1){
				startX = x + Math.sin(position-Math.PI*1.5)*outR + juli;
				startY = y - Math.cos(position-Math.PI*1.5)*outR - juli;
				if(i == 1){
					endX = startX + lineLong/2;
					endY = startY - lineLong*1.5;
					fontX = endX;
					fontY = endY - lineLong/2;
					font2X = fontX;
					font2Y = fontY - lineLong-5;
				}else if(i == 2){
					endX = startX + lineLong*1.5;
					endY = startY - lineLong/5;
					fontX = endX + lineLong;
					fontY = endY - lineLong/5;
					font2X = fontX;
					font2Y = fontY - lineLong-5;
				}else if(i == 3){
					endX = startX + lineLong;
					endY = startY + lineLong*1.5;
					fontX = endX + lineLong/5;
					fontY = endY + lineLong*1.5;
					font2X = fontX;
					font2Y = fontY + lineLong+5;
				}else{
					sz();
				}
			}else if(data[1] <= 0.1 && data[2] <= 0.1){
				if(position < Math.PI*0.5){
					startX = x + Math.cos(position)*outR + juli;
					startY = y + Math.sin(position)*outR + juli;
					if(i == 0){
						endX = startX + lineLong * 1.5;
						endY = startY - lineLong/4;
						fontX = endX + lineLong/2;
						fontY = endY;
						font2X = fontX;
						font2Y = fontY - lineLong*1.2;
					}else if(i == 1){
						endX = startX + lineLong;
						endY = startY + lineLong*1.5;
						fontX = endX + lineLong/5;
						fontY = endY + lineLong*1.5;
						font2X = fontX;
						font2Y = fontY + lineLong+5;
					}else if(i == 2){
						endX = startX - lineLong;
						endY = startY + lineLong*1.5;
						fontX = endX - lineLong;
						fontY = endY + lineLong*1.5;
						font2X = fontX - lineLong * 3;
						font2Y = fontY + lineLong+5;
					}else{
						sz();
					}
				}else if(position <= Math.PI){
					startX = x - Math.sin(position-0.5*Math.PI)*outR -juli;
					startY = y + Math.cos(position-0.5*Math.PI)*outR +juli;
					if(i == 1){
						endX = startX + lineLong/2;
						endY = startY + lineLong*1.5;
						fontX = endX + lineLong/5;
						fontY = endY + lineLong*1.5;
						font2X = fontX;
						font2Y = fontY + lineLong+5;
					}else if(i == 2){
						endX = startX - lineLong;
						endY = startY + lineLong*1.5;
						fontX = endX - lineLong*2;
						fontY = endY + lineLong*1.5;
						font2X = fontX - lineLong*3;
						font2Y = fontY - lineLong*1.5;
					}else{
						sz();
					}
				}else if(position <= Math.PI*1.5){
					startX = x - Math.cos(position-Math.PI)*outR - juli;
					startY = y - Math.sin(position-Math.PI)*outR - juli;
					if(i == 1){
						endX = startX - lineLong*1.3;
						endY = startY + lineLong/3;
						fontX = endX - lineLong*2;
						fontY = endY + lineLong;
						font2X = fontX - lineLong * 2.2;
						font2Y = fontY + lineLong;
					}else if(i == 2){
						endX = startX - lineLong;
						endY = startY - lineLong;
						fontX = endX - lineLong;
						fontY = endY - lineLong;
						font2X = fontX - lineLong;
						font2Y = fontY - lineLong-5;
					}else{
						sz();
					}
				}else{
					sz();
				}
			}else if(data[2] <= 0.1 && data[3] <= 0.1){
				startX = x + Math.sin(position-Math.PI*1.5)*outR + juli;
				startY = y - Math.cos(position-Math.PI*1.5)*outR - juli;
				if(i == 2){
					endX = startX + lineLong;
					endY = startY - lineLong;
					fontX = endX;
					fontY = endY - lineLong/2;
					font2X = fontX;
					font2Y = fontY - lineLong*1.2;
				}else if(i == 3){
					endX = startX + lineLong;
					endY = startY + lineLong;
					fontX = endX + lineLong;
					fontY = endY + lineLong;
					font2X = fontX;
					font2Y = fontY - lineLong*1.2;
				}else{
					sz();
				}
			}else{
				sz();
			}
			
			
			
			$(canvas).beginPath()
				  .lineCap("round")
				  .shadowBlur(0)
				  .strokeStyle("white")
				  .lineWidth(1)
				  .drawRoundLine(startX,startY,endX,endY,"white")					//绘制带圆点的实线
				  .fillStyle(colors[i])
				  .font("bold "+outR*0.2+"px Arial")
				  .textAlign("left")
				  .fillText((data[i]*100).toFixed(0) + "%",fontX,fontY,outR)		//绘制百分比
				  .fillText((data[i]*100).toFixed(0) + "%",fontX,fontY,outR)		//绘制百分比
				  .fillStyle("white")
				  .fillText(text[i],font2X,font2Y,outR);							//绘制文字
			$(canvas).beginPath()
			  .lineCap("butt")
			  .shadowBlur(3)
			  .shadowColor("black")
			  .strokeStyle(colors[i])
			  .lineWidth(centerLine)
			  .drawArc(x,y,centerR,startPI,endPI,false);
			i++;
		}
		if(endPI>=pi){
			return;}
		endPI += 0.06;
		//sudu -=0.00002;
		$(canvas).beginPath()
			  .lineCap("butt")
			  .shadowBlur(0)
			  .shadowColor("black")
			  .strokeStyle(colors[i])
			  .lineWidth(centerLine)
			  .drawArc(x,y,centerR,startPI,endPI,false);
		setTimeout(function(){
			action();
		},0);
	}
	action();
	$(canvas).shadowBlur(0)
		  .font("bold "+outR*0.18+"px Arial")
		  .fillStyle("white")
		  .textAlign("center")
		  .fillText("今日资金",x,y-outR*0.08,2*w*0.20);
	$(canvas).font("bold "+outR*0.15+"px Arial")
		  .textAlign("center");
	$(canvas).fillStyle("#4070B4")
		  .fillText("Capital Flows",x,y-outR*0.06+outR*0.25,2*w*0.20);
}


$.histogramChart = function(canvas,param){	
	var data = param;
	canvas = $("#"+canvas);
	var width = canvas.getWidth();
	var height = canvas.getHeight();
	
	
	var lineX = 0.05*width;
	var lineY = 0.5*height;
	var lineW = 0.9*width;
	var maxH = 0.35*height;
	var color1 = "#ED3707";
	var color2 = "#42AD07";
	var color3 = "white";
	var centerLineWidth = 2;
	var shadowColor = "#FF3B02"
	
	var maxValue = 0;
	$.each(data,function(i,v){
		var value = Math.abs(v.value); 
		if(maxValue < value){
			maxValue = value;
		}
	});
	
	for(var i = 0; i<data.length; i++){
		var dateX = lineW/data.length*i+lineX+8;
		var dateY = 2*maxH+0.22*height;
		var preset = maxH/maxValue;
		
		var valueX = dateX+lineW*0.1/2;
		var valueY = lineY-centerLineWidth/2;
		var valueH = valueY-data[i].value*preset;
		var vY = lineY+0.2*lineY;
		var color = color1;
		shadowColor = "#FF3B02";
		if(data[i].value<0){
			color = color2;
			valueY += centerLineWidth;
			vY = lineY-0.2*lineY + centerLineWidth;
			shadowColor = "#56F400";
		}
		canvas.beginPath().lineWidth(lineW*0.94/data.length*0.5).shadowBlur(2).shadowColor(shadowColor).strokeStyle(color).drawLine(valueX,valueY,valueX,valueH);
		canvas.beginPath().font("bold 12px Arial").shadowBlur(0).fillStyle("white").textAlign("center").fillText(data[i].date,valueX,dateY,lineW);
		canvas.beginPath().font("bold 12px Arial").shadowBlur(0).fillStyle(color).textAlign("center").fillText((data[i].value / 10000).toFixed(1),valueX,vY,lineW);
	}
	canvas.beginPath().lineWidth(centerLineWidth).shadowBlur(0).strokeStyle("#2A2D32").drawLine(lineX,lineY,lineW,lineY);
}

$.drawKDay = function(){
	
}