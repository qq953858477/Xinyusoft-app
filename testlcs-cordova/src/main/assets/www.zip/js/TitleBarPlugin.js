var TitleBarPlugin = function() {
};

// 改变标题栏的按钮状态
/*
 * posion 位置，可传1-4的的值，1代表最左边的那个按钮，以此类推 icon 图标，需要一个本地的相对路径（html5包下） color 设置颜色
 * title 设置文本 successCallback 成功的回调 errorCallback 失败回调
 */
TitleBarPlugin.prototype.changebButtonAttr = function(position, icon, color,
		title, callback, successCallback, errorCallback) {
	cordova.exec(successCallback, errorCallback, 'TitleBarPlugin',
			'changebButtonAttr', [ {
				'position' : position,
				'icon' : icon,
				'color' : color,
				'title' : title,
				'callback' : callback
			} ]);
}


TitleBarPlugin.prototype.changebButtonIcon = function(position, icon, callback,
		successCallback, errorCallback) {
	cordova.exec(successCallback, errorCallback, 'TitleBarPlugin',
			'changebButtonIcon', [ {
				'position' : position,
				'icon' : icon,
				'callback' : callback
			} ]);
}

// 设置中心标题
TitleBarPlugin.prototype.setTitle = function(title, successCallback,
		errorCallback) {
	cordova.exec(successCallback, errorCallback, 'TitleBarPlugin', 'setTitle',
			[ {
				'title' : title
			} ]);
}

//是否需要显示标题栏
//isShow 1代表显示，0代表不显示，必须在最前面设置，如果不显示也需要调用这个方法
TitleBarPlugin.prototype.isShow = function(isShow, successCallback,
		errorCallback) {
	cordova.exec(successCallback, errorCallback, 'TitleBarPlugin', 'isShow',
			[ {
				'isShow' : isShow
			} ]);
}

if (!window.plugins) {
	window.plugins = {};
}
if (!window.plugins.TitleBarPlugin) {
	window.plugins.TitleBarPlugin = new TitleBarPlugin();
	for ( var key in window.plugins.TitleBarPlugin) {
		window[key] = window.plugins.TitleBarPlugin[key];
	}
}