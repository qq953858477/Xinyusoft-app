﻿/**
 * 获取屏幕宽度
 * @returns
 */
function getWidth()
{
var xWidth = null;
if(window.screen != null)
  xWidth = window.screen.availWidth;

if(window.innerWidth != null)
  xWidth = window.innerWidth;

if(document.body != null)
  xWidth = document.body.clientWidth;

return xWidth;
}

var getPixelRatio = function(context) {
  var backingStore = context.backingStorePixelRatio ||
    context.webkitBackingStorePixelRatio ||
    context.mozBackingStorePixelRatio ||
    context.msBackingStorePixelRatio ||
    context.oBackingStorePixelRatio ||
    context.backingStorePixelRatio || 1;
   return (window.devicePixelRatio || 1) / backingStore;
};

/**
 * 获取屏幕高度
 * @returns
 */
function getHeight() {
 var  xHeight = null;
  if(window.screen != null)
    xHeight = window.screen.availHeight;

  if(window.innerHeight != null)
    xHeight =   window.innerHeight;
  
  if(document.body != null)
    //xHeight = document.body.clientHeight;

  return xHeight;
}

var sshqChart;
	//绘制分时图
	function drawF(){
        //console.log("htmlType", htmlType);
       
        minsChart.prototype = {
            /*
            data format like :{
            quote: {
            time: 20111214150106,
            open: 2241.390,
            preClose: 2248.590,
            highest: 2256.740,
            lowest: 2224.730,
            price: 2228.530,
            volume: 4407982200,
            amount: 38621178573
            },
            mins: [
            {price:2239.45,volume:49499299,amount:459279327}
            ]
            }
            */
            paint: function (data) {
                //this.fillTopText(data);
				this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
                this.paintChart(data);
                this.paintxAxis();
                this.fillBottomText(data);
                this.paintVolume(data);
            },
            paintVolume: function (data) {
                var ctx = this.ctx;
                var options = this.volume;
                ctx.beginPath();
                ctx.rect(options.region.x, options.region.y, options.region.width, options.region.height);
                ctx.strokeStyle = options.borderColor;
                ctx.stroke();
                
                line(ctx, options.region.x, options.region.y + options.region.height / 2, options.region.x + options.region.width, options.region.y + options.region.height / 2, options.splitLineColor);
               
			    options.getDataLength = function () { return this.data.items.length; };
                options.maxDotsCount = this.maxDotsCount;
                var volumePainterImp = new volumePainter(options);
                var painter = new Painter(this.canvas.id, volumePainterImp, { items: data.mins,quote:data.quote });
                painter.paint();
                var max = painter.maxVolume;
                
                var unit;
                if (max / 1000000 > 1000) {
                    max = max / 1000000;
                    unit = '百万';
                } else {
                    max = max / 10000;
                    unit = '万';
                }
                //var scalers = [max.toFixed(2), (max / 2).toFixed(2), '(' + unit + ')'];
                var scalers = [max.toFixed(2), '(' + unit + ')'];
                var yscaler = new yAxis(this.volume.yScaler);
                var painter = new Painter(this.canvas.id, yscaler, scalers);
                //painter.paint();
            },

            fillBottomText: function (data) {
                if (!this.bottomText) return;
                //高9999 低9999 成交888999
                var ctx = this.ctx;
                var txt = '高';
                var options = this.bottomText;
                ctx.font = options.font;
                ctx.fillStyle = options.color;
                var w = ctx.measureText(txt).width;
                ctx.fillText(txt, options.region.x, options.region.y);
                var x = options.region.x + w;
                var quote = data.quote;
                var me = this;
                function getTxtColor(val) { return val > quote.preClose ? me.riseColor : (val == quote.preClose ? me.normalColor : me.fallColor); }
                var highColor = getTxtColor(quote.highest);
                var high = toMoney(quote.highest);
                ctx.fillStyle = highColor;
                w = ctx.measureText(high).width;
                ctx.fillText(high, x, options.region.y);
                x += w;
                txt = ' 低';
                ctx.fillStyle = options.color;
                w = ctx.measureText(txt).width;
                ctx.fillText(txt, x, options.region.y);
                x += w;
                var lowColor = getTxtColor(quote.lowest);
                var low = toMoney(quote.lowest);
                w = ctx.measureText(low).width;
                ctx.fillStyle = lowColor;
                ctx.fillText(low, x, options.region.y);
                x += w;
                ctx.fillStyle = options.color;
                var amount = ' 成交' + bigNumberToText(quote.amount);
                ctx.fillText(amount, x, options.region.y);
            },

            paintxAxis: function () {
                var xAxisImpl = new xAxis(this.xScaler);
                var xAxisPainter = new Painter(this.canvas.id, xAxisImpl, this.xScaler.data);
                xAxisPainter.paint();
            },

            paintChart: function (data) {
                var minsChartOptions = this.minsChart;
                var region = this.minsChart.region;
                var ctx = this.ctx;
                ctx.beginPath();
                ctx.strokeStyle = minsChartOptions.borderColor;
                ctx.rect(region.x, region.y, region.width, region.height);
                ctx.stroke();
                //水平线
				//alert("horizontalLineCount="+this.minsChart.horizontalLineCount)
                var middleIndex = (this.minsChart.horizontalLineCount + this.minsChart.horizontalLineCount % 2) / 2;
                //console.log("middleIndex", this.minsChart.horizontalLineCount);
                var splitCount = this.minsChart.horizontalLineCount + 1;
                for (var i = 1; i <= this.minsChart.horizontalLineCount; i++) {
                    var color = (i == middleIndex ? minsChartOptions.middleLineColor : minsChartOptions.otherSplitLineColor);
                    var y = region.y + region.height * i / splitCount;
                    //console.log(ctx, region.x,  y, region.x + region.width, y, color);
                    line(ctx, region.x, y, region.x + region.width, y, color);
                }

		
                //垂直线 
                splitCount = this.minsChart.verticalLineCount + 1;
                for (var i = 1; i <= this.minsChart.verticalLineCount; i++) {
                    var x = region.x + region.width * i / splitCount;
                    line(ctx, x, region.y, x, region.y + region.height, minsChartOptions.otherSplitLineColor);
                }

				var priceitems = data.mins;
				//console.log("价格线");
                //console.log(priceitems);
                //价格线
                var lineOptions = {
                    region: region,
                    maxDotsCount: this.maxDotsCount,
                    getDataLength: function () { return this.data.items.length; },
                    getItemValue: function (item) { return item.price; },
                    middleValue: data.quote.preClose, 														//通常是昨收
                    lineColor: minsChartOptions.priceLineColor,
					highest:data.quote.highest,
					lowest:data.quote.lowest
                };
                var linePainterImp = new linePainter(lineOptions);
                var priceLinePainter = new Painter(this.canvas.id, linePainterImp, { items: data.mins });
                priceLinePainter.paint();

				
                //y轴
                var yOptions = this.minsChart.yScalerLeft;
                var preClose = data.quote.preClose;
                var me = this;
                yOptions.color = function (val) {
                    return val > preClose ? me.riseColor : (val == preClose ? me.normalColor : me.fallColor);
                };
				
				
                var scalersLeft = [];
                var scalersRight = [];
				//alert(priceLinePainter.maxDiff)
				if(priceLinePainter.maxDiff)
				{
					var min = preClose - priceLinePainter.maxDiff;
					var space = priceLinePainter.maxDiff * 2 / (this.minsChart.horizontalLineCount + 1);
				   
					for (var i = this.minsChart.horizontalLineCount + 1; i >= 0; i--) 
					{
						var val = min + i * space;
						//scalersLeft.push(val.toFixed(2));
						
						var percent = (val - preClose) * 100 / preClose;
						//alert(percent);
						//scalersRight.push(percent.toFixed(2) + '%');
						
						if(i == this.minsChart.horizontalLineCount + 1)
						{
							//scalersRight[this.minsChart.horizontalLineCount + 1] = percent;
							scalersRight.push(percent.toFixed(2) + '%');
							scalersLeft.push(val.toFixed(2));
						}
						else if(i ==0)
						{
							//scalersRight[0] = percent
							scalersRight.push(percent.toFixed(2) + '%');
							scalersLeft.push(val.toFixed(2));
						}
					}
				}
		
                
                var yx = new yAxis(yOptions);
                var yAxisPainter = new Painter(this.canvas.id, yx, scalersLeft);
                yAxisPainter.paint();

                var yPercentOptions = this.minsChart.yScalerRight;
                yPercentOptions.color = function (val) {
                    return (val == '0.00%' ? '#489AB2' : (val.charAt(0) == '-' ? '#899198' : '#899198'));
                };
                var yxPercent = new yAxis(yPercentOptions);
                var yxPercentPainter = new Painter(this.canvas.id, yxPercent, scalersRight);
                yxPercentPainter.paint();


                //均线
                if (this.needPaintAvgPriceLine) {
                    //生成移动均线数据
                   //alert("3333");
                    lineOptions.lineColor = minsChartOptions.avgPriceLineColor;
                    lineOptions.getItemValue = function (item) { return item.avgprice; };
                    linePainterImp = new linePainter(lineOptions);
                    var painterAvg = new Painter(this.canvas.id, linePainterImp, { items: priceitems });
                    painterAvg.paint();
                }

                var me = this;
                var chartRegion = me.minsChart.region;

                function getY(x) {
                    var index = Math.ceil((x - me.minsChart.region.x) * me.maxDotsCount / me.minsChart.region.width);
                    var val;
                    var isNewQuote;
                    if (index >= 0 && index < data.mins.length) {
                        val = data.mins[index].price;
                        isNewQuote = false;
                    } else {
                        val = data.quote.price;
                        isNewQuote = true;
                    }
                    if (me.canvas.tip) me.canvas.tip.dataContext = { data: data, isNewQuote: isNewQuote, index: index };
                    var diff = val - preClose;
                    var middleY = (me.minsChart.region.y + me.minsChart.region.height / 2);
                    return middleY - diff * me.minsChart.region.height / 2 / priceLinePainter.maxDiff;
                }

               //添加鼠标事件
               /* addCrossLinesAndTipEvents(this.canvas, {
                    getCrossPoint: function (ev) { return { x: ev.offsetX, y: getY(ev.offsetX) }; },
                    triggerEventRanges: { x: chartRegion.x, y: chartRegion.y, width: chartRegion.width, height: me.volume.region.y + me.volume.region.height - chartRegion.y },
                    tipOptions: {
                        getTipHtml: function (ev) { return null; },
                        position: { x: false, y: false }
                    },
                    crossLineOptions: {
                        color: '#E3E8F4'
                    }
                });*/
            },

            fillTopText: function (data, minIndex) {
                var quote = data.quote;
                var ctx = this.ctx;
                var topText = this.topText;
                var region = topText.region;
                ctx.clearRect(region.x, region.y, region.width, region.height);
                var price;
                var time;
                if (typeof minIndex == 'undefined') {
                    price = quote.price;
                    time = quote.time;
                } else {
                    price = data.mins[minIndex].price;
                    time = quote.time.toString().substr(0, 8) + getMinTime(minIndex);
                }

                ctx.fillStyle = topText.color;
                ctx.font = topText.font;
                if (topText.textBaseline) ctx.textBaseline = topText.textBaseline;
                var txt = '最新' + toMoney(price);
                var width = ctx.measureText(txt).width;
                ctx.fillText(txt, topText.region.x, topText.region.y);

                var isRise = price > quote.preClose;
                var isEqual = price == quote.preClose;
                var isFall = price < quote.preClose;
                var diff = toMoney(price - quote.preClose);
                var txtRiseFall = (isRise ? '↑' : (isFall ? '↓' : '')) + diff
            + ('(')
            + toMoney(diff * 100 / quote.preClose)
            + '%)';

                var x = topText.region.x + width;
                ctx.fillStyle = isRise ? this.riseColor : (isFall ? this.fallColor : this.normalColor);
                ctx.fillText(txtRiseFall, x, topText.region.y);

                var temp = new String(time);
                var txtTime = temp.charAt(8) + temp.charAt(9) + ':' + temp.charAt(10) + temp.charAt(11);
                ctx.fillStyle = topText.color;
                var timeWidth = ctx.measureText(txtTime).width;
                ctx.fillText(txtTime, topText.region.x + topText.region.width - timeWidth, topText.region.y);
            }
        };
        
		//document.getElementById("sshqLine").getContext("2d");
		//var ratio = getPixelRatio(document.getElementById("sshqLine").getContext("2d"));
        if(htmlType == "indexbaseType")
        {
            var ratio = getPixelRatio(document.getElementById("sshqLine").getContext("2d"));
        }
        else
        {
            var ratio = getPixelRatio(document.getElementById("onestockhqbasesshqLine").getContext("2d"));
        }
		//alert(ratio);
		
        if(!sshqChart)
		{
			var wWidth = sshqCanvasWidth-5;//window.innerWidth;				//获取窗体宽度
			//alert(wWidth);
			var wHeight = sshqCanvasHeight-5;//window.innerHeight;			//获取窗体高度
			
            if(htmlType == "indexbaseType")
            {
                var c = document.getElementById("sshqLine");
            }
            else
            {
                var c = document.getElementById("onestockhqbasesshqLine");
            }
			c.width = wWidth*ratio;
			c.height = wHeight*ratio;


            if(htmlType == "indexbaseType")
            {
                document.getElementById("sshqLine").style.width=wWidth+"px";

                document.getElementById("sshqLine").getContext("2d").scale(ratio, ratio);
            }
            else
            {
                document.getElementById("onestockhqbasesshqLine").style.width=wWidth+"px";

                document.getElementById("onestockhqbasesshqLine").getContext("2d").scale(ratio, ratio);
            }

			var startX = 0;
			var chartWidth = wWidth-5;
			var startY = 5.5;
			//wHeight-80-30 改成200
            if(htmlType == "indexbaseType")
            {
                var idstr = "sshqLine";
            }
            else
            {
                var idstr = "onestockhqbasesshqLine";

            }
				//backgroundColor:'#2C3844'
				//priceLineColor: '#489AB2'
				//avgPriceLineColor: '#af9106'
				//color: '#80888F'
				//bigcolor:'#ff334a',smallcolor:'#2dda1b'
				// middleLineColor: '#5D7262
				//borderColor: '#2C3844', splitLineColor: '#2C3844',
				//middleLineColor: '#5D7262', otherSplitLineColor: '#2C3844', borderColor: '#2C3844'
				
				sshqChart =  new minsChart(idstr, {
				fallColor: '#72CC5A', riseColor: '#899198', normalColor: '#489AB2', maxDotsCount: 240, needPaintAvgPriceLine: true,
				backgroundColor:'#cfdae6',
				topText:{ //设置顶部文本
						font: '10px 宋体', color: '#EFEFEF', region: { x: 58.5, y: -20.5, width: wWidth-120, height: 14 }, textBaseline: 'top' 
				},
				minsChart: {//#05B9E0
					region: { x: startX, y: startY, width: chartWidth, height: 135 },
					priceLineColor: '#589bfd', avgPriceLineColor: '#eddc20', middleLineColor: '#00ff00', otherSplitLineColor: '#cfdae6', borderColor: '#cfdae6',
					horizontalLineCount: 3, verticalLineCount: 3,
					yScalerLeft: { font: '13px', region: { x: 0.5, y: startY, width: 50.5, height: 130 }, align: 'left', fontHeight: 9, textBaseline: 'top' },
					yScalerRight: { font: '13px', region: { x: wWidth-48, y: startY, width: 40.5, height: 130 }, align: 'right', fontHeight: 9, textBaseline: 'top' }
				},
				xScaler: {//设置底部时间属性
					font: '13px', color: '#a5a5a5',
					region: { x: startX, y: 145+startY, width:  chartWidth, height: 15 },
					data: ['09:30','10:30', '11:30/13:00', '14:00','15:00']
				},
				//bottomText: #80888F{ font: '11px 宋体', color: 'black', region: { x: 5.5, y: 260, width: 400, height: 20} },
				volume: {
					region: { x: startX, y: 155.5, width:  chartWidth, height: 70 },
					bar: { color: '#D5392C', width: 2 ,bigcolor:'#f76e73',smallcolor:'#59f26b'},
					borderColor: '#cfdae6', splitLineColor: '#cfdae6',
					yScaler: { font: '13px', region: { x: 1.5, y: 140.5, width: 50.5, height: 60 }, color: '#489AB2', align: 'left', fontHeight: 12, textBaseline: 'top' }
				}
			});
			
		}
			
		
		
		//data: ['09:30', '10:30', '11:30/13:00','14:00',  '15:00']
		var miniData = getQuote(sshqChart,code);
        //alert(miniData);
		//alert(stock);
		/*while(!stock)
		{
			//等待stock数据
		}*/
		
		
	}
	
	var fivechart;
	//绘制5分图
	function draw5F(){
       
	   
        minsChart.prototype = {
                /*
                data format like :{
                quote: {
                time: 20111214150106,
                open: 2241.390,
                preClose: 2248.590,
                highest: 2256.740,
                lowest: 2224.730,
                price: 2228.530,
                volume: 4407982200,
                amount: 38621178573
                },
                mins: [
                {price:2239.45,volume:49499299,amount:459279327}
                ]
                }
                */
                paint: function (data) {
                    //this.fillTopText(data);
					this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
                    this.paintChart(data);
                    this.paintxAxis();
                    this.fillBottomText(data);
                    this.paintVolume(data);
                },

                paintVolume: function (data) {
                    var ctx = this.ctx;
                    var options = this.volume;
    				var rw = options.region.width;
                    ctx.beginPath();
                    ctx.rect(options.region.x, options.region.y, options.region.width, options.region.height);
                    ctx.strokeStyle = options.borderColor;
                    ctx.stroke();

                    line(ctx, options.region.x, options.region.y + options.region.height / 2, options.region.x + options.region.width, options.region.y + options.region.height / 2, options.splitLineColor);
    				//alert(this.maxDotsCount)
    				//options.region.width = rw/5;
                    options.getDataLength = function () { return this.data.items.length; };
                    options.maxDotsCount = this.maxDotsCount;
                    var volumePainterImp = new volumePainter(options);
                    var painter = new Painter(this.canvas.id, volumePainterImp, { items: data.mins });
                    painter.paint();
                    var max = painter.maxVolume;
                    var unit;
                    if (max / 1000000 > 1000) {
                        max = max / 1000000;
                        unit = '百万';
                    } else {
                        max = max / 10000;
                        unit = '万';
                    }
                   /*  var scalers = [max.toFixed(2), (max / 2).toFixed(2), '(' + unit + ')']; */
                    var scalers = [max.toFixed(2), '(' + unit + ')'];
                    var yscaler = new yAxis(this.volume.yScaler);
                    var painter = new Painter(this.canvas.id, yscaler, scalers);
                   // painter.paint();
                },

                fillBottomText: function (data) {
                    if (!this.bottomText) return;
                    //高9999 低9999 成交888999
                    var ctx = this.ctx;
                    var txt = '高';
                    var options = this.bottomText;
                    ctx.font = options.font;
                    ctx.fillStyle = options.color;
                    var w = ctx.measureText(txt).width;
                    ctx.fillText(txt, options.region.x, options.region.y);
                    var x = options.region.x + w;
                    var quote = data.quote;
                    var me = this;
                    function getTxtColor(val) { return val > quote.preClose ? me.riseColor : (val == quote.preClose ? me.normalColor : me.fallColor); }
                    var highColor = getTxtColor(quote.highest);
                    var high = toMoney(quote.highest);
                    ctx.fillStyle = highColor;
                    w = ctx.measureText(high).width;
                    ctx.fillText(high, x, options.region.y);
                    x += w;
                    txt = ' 低';
                    ctx.fillStyle = options.color;
                    w = ctx.measureText(txt).width;
                    ctx.fillText(txt, x, options.region.y);
                    x += w;
                    var lowColor = getTxtColor(quote.lowest);
                    var low = toMoney(quote.lowest);
                    w = ctx.measureText(low).width;
                    ctx.fillStyle = lowColor;
                    ctx.fillText(low, x, options.region.y);
                    x += w;
                    ctx.fillStyle = options.color;
                    var amount = ' 成交' + bigNumberToText(quote.amount);
                    ctx.fillText(amount, x, options.region.y);
                },

                paintxAxis: function () {
                    var xAxisImpl = new xAxis(this.xScaler);
                    var xAxisPainter = new Painter(this.canvas.id, xAxisImpl, this.xScaler.data);
                    xAxisPainter.paint();
                },

                paintChart: function (data) {
                    var minsChartOptions = this.minsChart;
                    var region = this.minsChart.region;
                    var ctx = this.ctx;
                    ctx.beginPath();
                    ctx.strokeStyle = minsChartOptions.borderColor;
                    ctx.rect(region.x, region.y, region.width, region.height);
                    ctx.stroke();
                    //水平线
                    var middleIndex = (this.minsChart.horizontalLineCount + this.minsChart.horizontalLineCount % 2) / 2;
                    var splitCount = this.minsChart.horizontalLineCount + 1;
                    for (var i = 1; i <= this.minsChart.horizontalLineCount; i++) {
                        var color = (i == middleIndex ? minsChartOptions.middleLineColor : minsChartOptions.otherSplitLineColor);
                        var y = region.y + region.height * i / splitCount;
                        line(ctx, region.x, y, region.x + region.width, y, color);
                    }
                    //垂直线
                    splitCount = this.minsChart.verticalLineCount + 1;
                    for (var i = 1; i <= this.minsChart.verticalLineCount; i++) {
                        var x = region.x + region.width * i / splitCount;
                        line(ctx, x, region.y, x, region.y + region.height, minsChartOptions.otherSplitLineColor);
                    }
    				
    				var rw = region.width;
    				//region.width = region.width/5;	//设置每日分时的时间为1/5

                    //价格线
                    var lineOptions = {
                        region: region,
                        maxDotsCount: this.maxDotsCount,
                        getDataLength: function () { return this.data.items.length; },
                        getItemValue: function (item) { return item.price; },
                        middleValue: data.quote.preClose, //通常是昨收
                        lineColor: minsChartOptions.priceLineColor
                    };
                    var linePainterImp = new linePainter(lineOptions);
                    var priceLinePainter = new Painter(this.canvas.id, linePainterImp, { items: data.mins });
                    priceLinePainter.paint();

    				/*
    				*/
    				//region.width = rw;		//将值设为原来的值
                    //y轴
                    var yOptions = this.minsChart.yScalerLeft;
                    var preClose = data.quote.preClose;
                    var me = this;
                    yOptions.color = function (val) {
                        return val > preClose ? me.riseColor : (val == preClose ? me.normalColor : me.fallColor);
                    };
                    var scalersLeft = [];
                    var scalersRight = [];
                    var min = preClose - priceLinePainter.maxDiff;
                    var space = priceLinePainter.maxDiff * 2 / (this.minsChart.horizontalLineCount + 1);
                    for (var i = this.minsChart.horizontalLineCount + 1; i >= 0; i--) {
                        var val = min + i * space;
                        //scalersLeft.push(val.toFixed(2));
                        var percent = (val - preClose) * 100 / preClose;
                        //scalersRight.push(percent.toFixed(2) + '%');
						
						if(i == this.minsChart.horizontalLineCount + 1)
						{
							//scalersRight[this.minsChart.horizontalLineCount + 1] = percent;
							scalersRight.push(percent.toFixed(2) + '%');
							scalersLeft.push(val.toFixed(2));
						}
						else if(i ==0)
						{
							//scalersRight[0] = percent
							scalersRight.push(percent.toFixed(2) + '%');
							scalersLeft.push(val.toFixed(2));
						}
                    }
    				
                    var yx = new yAxis(yOptions);
                    var yAxisPainter = new Painter(this.canvas.id, yx, scalersLeft);
                    yAxisPainter.paint();

                    var yPercentOptions = this.minsChart.yScalerRight;
                    yPercentOptions.color = function (val) {
                        return (val == '0.00%' ? '#489AB2' : (val.charAt(0) == '-' ? '#899198' : '#899198'));
                    };
                    var yxPercent = new yAxis(yPercentOptions);
                    var yxPercentPainter = new Painter(this.canvas.id, yxPercent, scalersRight);
                    yxPercentPainter.paint();


                    //均线 this.needPaintAvgPriceLine
                   /* if (true) {
                        //生成移动均线数据
                        var items = [];
                        var totalVolume = 0;
                        var totalAmount = 0;
                        data.mins.each(function (item) {
                           	//totalVolume += item.volume/240;
                            //totalAmount += item.amount;
                            items.push(item.avgprice);
                        });
                        lineOptions.lineColor = minsChartOptions.avgPriceLineColor;
                        lineOptions.getItemValue = function (item) { return item; };
                        linePainterImp = new linePainter(lineOptions);
                        var painterAvg = new Painter(this.canvas.id, linePainterImp, { items: items });
                        painterAvg.paint();
                    }*/
                    //均线
                if (this.needPaintAvgPriceLine) {
                    //生成移动均线数据
                    
                    lineOptions.lineColor = minsChartOptions.avgPriceLineColor;
                    lineOptions.getItemValue = function (item) { return item.avgprice; };
                    linePainterImp = new linePainter(lineOptions);
                    var painterAvg = new Painter(this.canvas.id, linePainterImp, { items: data.mins });
                    painterAvg.paint();
                }

                    var me = this;
                    var chartRegion = me.minsChart.region;

                    function getY(x) {
                        var index = Math.ceil((x - me.minsChart.region.x) * me.maxDotsCount / me.minsChart.region.width);
                        var val;
                        var isNewQuote;
                        if (index >= 0 && index < data.mins.length) {
                            val = data.mins[index].price;
                            isNewQuote = false;
                        } else {
                            val = data.quote.price;
                            isNewQuote = true;
                        }

                        if (me.canvas.tip) me.canvas.tip.dataContext = { data: data, isNewQuote: isNewQuote, index: index };
                        var diff = val - preClose;
                        var middleY = (me.minsChart.region.y + me.minsChart.region.height / 2);
                        return middleY - diff * me.minsChart.region.height / 2 / priceLinePainter.maxDiff;
                    }
    				
                    //添加鼠标事件
                    /*addCrossLinesAndTipEvents(this.canvas, {
                        getCrossPoint: function (ev) { return { x: ev.offsetX, y: getY(ev.offsetX) }; },
                        triggerEventRanges: { x: chartRegion.x, y: chartRegion.y, width: chartRegion.width*5, height: me.volume.region.y + me.volume.region.height - chartRegion.y },
                        tipOptions: {
                            getTipHtml: function (ev) { return null; },
                            position: { x: false, y: false }
                        },
                        crossLineOptions: {
                            color: '#E3E8F4'
                        }
                    });*/
                },

                fillTopText: function (data, minIndex) {
                    var quote = data.quote;
                    var ctx = this.ctx;
                    var topText = this.topText;
                    var region = topText.region;
                    ctx.clearRect(region.x, region.y, region.width, region.height);
                    var price;
                    var time;
                    if (typeof minIndex == 'undefined') {
                        price = quote.price;
                        time = quote.time;
                    } else {
                        price = data.mins[minIndex].price;
                        time = quote.time.toString().substr(0, 8) + getMinTime(minIndex);
                    }

                    ctx.fillStyle = topText.color;
                    ctx.font = topText.font;
                    if (topText.textBaseline) ctx.textBaseline = topText.textBaseline;
                    var txt = '最新' + toMoney(price);
                    var width = ctx.measureText(txt).width;
                    ctx.fillText(txt, topText.region.x, topText.region.y);

                    var isRise = price > quote.preClose;
                    var isEqual = price == quote.preClose;
                    var isFall = price < quote.preClose;
                    var diff = toMoney(price - quote.preClose);
                    var txtRiseFall = (isRise ? '↑' : (isFall ? '↓' : '')) + diff
                + ('(')
                + toMoney(diff * 100 / quote.preClose)
                + '%)';

                    var x = topText.region.x + width;
                    ctx.fillStyle = isRise ? this.riseColor : (isFall ? this.fallColor : this.normalColor);
                    ctx.fillText(txtRiseFall, x, topText.region.y);

                    var temp = new String(time);
                    var txtTime = temp.charAt(8) + temp.charAt(9) + ':' + temp.charAt(10) + temp.charAt(11);
                    ctx.fillStyle = topText.color;
                    var timeWidth = ctx.measureText(txtTime).width;
                    ctx.fillText(txtTime, topText.region.x + topText.region.width - timeWidth, topText.region.y);
                }
            };

		
        if(!fivechart)
		{
			
			
			var wWidth = getWidth();//window.innerWidth;
			var wHeight = 310;//getHeight();//window.innerHeight;
			//alert(wHeight)
            if(htmlType == "indexbaseType")
            {
                var c = document.getElementById("fiveLine");
            }
            else
            {
                var c = document.getElementById("onestockhqbasefiveLine");
            }
			//if(mybrowser.chrome)
			//{
			//
			//	c.width = wWidth //- 15;
			//}
			//else
			//{
				c.width = wWidth;
			//}
			

            if(htmlType == "indexbaseType")
            {
                var ratio = getPixelRatio(document.getElementById("fiveLine").getContext("2d"));
            }
            else
            {
                var ratio = getPixelRatio(document.getElementById("onestockhqbasefiveLine").getContext("2d"));
            }
			c.width = wWidth*ratio;
			c.height = wHeight*ratio;

            if(htmlType == "indexbaseType")
            {
                document.getElementById("fiveLine").style.width=wWidth+"px";

                document.getElementById("fiveLine").getContext("2d").scale(ratio, ratio);
            }
            else
            {
                document.getElementById("onestockhqbasefiveLine").style.width=wWidth+"px";

                document.getElementById("onestockhqbasefiveLine").getContext("2d").scale(ratio, ratio);
            }
			

			
			var chartWidth = wWidth-9;//wWidth-30;
			var startX = 0.5;
			var chartY = 5.5;

            if(htmlType == "indexbaseType")
            {
                var idstr = "fiveLine";
            }
            else
            {
                var idstr = "onestockhqbasefiveLine";
            }
			//backgroundColor:'#17191e',
			//priceLineColor: '#489AB2', avgPriceLineColor: '#af9106'
			
			fivechart = new minsChart(idstr, {
				fallColor: '#72CC5A', riseColor: '#899198', normalColor: '#899198', maxDotsCount: 1200, needPaintAvgPriceLine: true,
				backgroundColor:'#cfdae6',
				topText:{ //设置顶部文本
						font: '0px 宋体', color: '#489AB2', region: { x: startX, y: -20, width: chartWidth, height: 0 }, textBaseline: 'top'
				},
				minsChart: {//设置主体区域
					region: { x: startX, y: chartY, width: chartWidth, height: 135 },
					priceLineColor: '#589bfd', avgPriceLineColor: '#eddc20', middleLineColor: '#00ff00', otherSplitLineColor: '#cfdae6', borderColor: '#cfdae6',
					horizontalLineCount: 3, verticalLineCount: 4,
					yScalerLeft: { font: 'Bold 13px', region: { x: 7, y: chartY, width: 50.5, height: 130 }, align: 'left', fontHeight: 9, textBaseline: 'top' },
					yScalerRight: { font: 'Bold 13px', region: { x: wWidth-48, y: chartY, width: 40.5, height: 130 }, align: 'right', fontHeight: 9, textBaseline: 'top' }
				},
				xScaler: {//设置底部时间属性
					font: '13px', color: '#a5a5a5',
					region: { x: 1, y: 145+chartY, width:  chartWidth, height: 20 },
					/* data: ['05-11', '05-12', '05-13', '05-14', '05-15'] */
					data:getDate()
				},
				//bottomText: { font: '11px 宋体', color: 'black', region: { x: 5.5, y: 260, width: 400, height: 20} },
				volume: {
					region: { x: startX, y: 155.5, width:  chartWidth, height: 60 },
					bar: { color: '#D5392C', width: 1 ,bigcolor:'#f76e73',smallcolor:'#59f26b'},
					borderColor: '#cfdae6', splitLineColor: '#cfdae6',
					yScaler: { font: '13px', region: { x: 5.5, y: 145.5, width: 50.5, height: 60 }, color: '#899198', align: 'left', fontHeight: 12, textBaseline: 'top' }
				}
			});
			
		}
		
		
		//alert(chart.xScaler.data)
		var data = getFiveQuote(fivechart,code);
		
	}
