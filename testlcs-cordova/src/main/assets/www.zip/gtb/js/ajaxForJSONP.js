﻿var isjsonp = true;
var jsonpUrl = "http://192.168.0.200:8086/uuFinancialPlanner/JSONP";
//var jsonpUrl = "http://120.26.117.113:8080/uuFinancialPlanner/JSONP";//测试环境
//var jsonpUrl = "http://test.xinyusoft.com:8080/uuFinancialPlanner/JSONP";//测试环境

function jqueryJsonP(url,param,method)
{
	var curdataType = "json";
	
	if(isjsonp)
	{
		url = jsonpUrl;
		curdataType = "text";
	}
	
	param["callback"] = "flightHandler";
	
	
	$.ajax({
		url:url,
		type:"post",
		data:param,
		dataType:curdataType,
		cache:false,
		async: true,
		timeout : 600000,
		statusCode:{"200":function(data){
			
			if(isjsonp)
			{
				var flightHandler = function(json)
				{
					method(json);
				}
				eval(data);
			}
			else
			{
				method(data);
			}
			
		},"404":function(){
			myAlert("您访问的地址不存在!");
			//alert("404:"+url);
		},"500":function(){
			myAlert("服务发生错误，请稍候再访问!");
			//alert("500:"+url);
		}},
		error:function(data,statusText){
			//log("data:" + JSON.stringify(data))
			if(statusText == "timeout"){
				myAlert("请求超时，您的网络连接不佳!");
				//alert("timeout:"+url);
			}else{
				myAlert("请求失败，您的网络不佳或服务器繁忙<br/>,statusText: " + statusText);
				//alert("other:"+url);
			}
		}
	});
}


//获取cookie里的值
function getCookie(cookie_name)
{
	/*var strCookie=document.cookie;
	var arrCookie=strCookie.split(";");
	for(var i=0;i<arrCookie.length;i++)
	{
		
		var arrCookiePro = arrCookie[i].split("=");
		
		if(arrCookiePro[0].trim() == cookie_name)
		{
			return unescape(arrCookiePro[1]);
		}
	}
	return "";*/
	
	var localStorage = window.localStorage;
	return localStorage.getItem(cookie_name);
}

/* 取得url参数 */
function GetParameter(param) {
	var query = window.location.search;
	var iLen = param.length;
	var iStart = query.indexOf(param);
	if (iStart == -1) {
		return "";
	}
	iStart += iLen + 1;
	var iEnd = query.indexOf("&", iStart);
	if (iEnd == -1) {
		return query.substring(iStart);
	}
	else {
		return query.substring(iStart, iEnd);
	}
}