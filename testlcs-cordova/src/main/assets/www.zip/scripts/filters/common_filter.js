/**
 * Created by/ 曾建峰 on 2014/511.
 */

/**
 * 资金显示过滤器
 * @returns {Function}
 */
function moneyFilter() {
    /**
     * flag: true-显示到“万”，false-显示到”元“
     */
    return function (input, flag) {
        var out = "";
        if (input == null || typeof(input) == 'undefined') {
            return "-";
        }
//        if (!angular.isNumber(input)) {
//            return input;
//        }
        if (isNaN(input)) {
            return input;
        }
        input = Number(input);
        input = input.toFixed(2);
        var pointPose = input.toString().indexOf(".");
        var nagitiveNum = false;

        if (input.toString().indexOf("-") > -1) {
            nagitiveNum = true;
        }

        var intPartlength;
        var doublePart;
        var intPart;
        if (pointPose > -1)
        {
            if (nagitiveNum) {
                intPart = input.toString().substring(1, pointPose);
            } else {
                intPart = input.toString().substring(0, pointPose);
            }
            intPartlength = intPart.substring(0, pointPose).length;
            doublePart = input.toString().substring(pointPose, pointPose + 3);
        } else
        {
            if (nagitiveNum)
            {
                intPart = input.toString().substring(1);
            } else
            {
                intPart = input.toString().substring(0);
            }
            intPartlength = intPart.length;
            doublePart = ".00";
        }

        var count = 0 ;
        for (var i = intPartlength - 1; i >= 0; i--) {
            count ++ ;
            out = intPart.charAt(i) + out;
            if ( count%3 == 0 && i != 0 && i != intPartlength - 1)
            {
                out = "," + out;
            }
        }

        out = out + doublePart;
        if (nagitiveNum) {
            return "-" + out;
        } else {
            return "" + out;
        }
    }
}

function money1Filter() {
     /**
     * flag: true-显示到“万”，false-显示到”元“
     */
    return function (input, flag) {
        var out = "";
        if (input == null || typeof(input) == 'undefined') {
            return "-";
        }
        if (!angular.isNumber(input)) {
            return input;
        }
        input = Number(input);
        var pointPose = input.toString().indexOf(".");
        var nagitiveNum = false;

        if (input.toString().indexOf("-") > -1) {
            nagitiveNum = true;
        }

        var intPartlength;
        var doublePart;
        var intPart;
        if (pointPose > -1)
        {
            if (nagitiveNum) {
                intPart = input.toString().substring(1, pointPose);
            } else {
                intPart = input.toString().substring(0, pointPose);
            }
            intPartlength = intPart.substring(0, pointPose).length;
            doublePart = input.toString().substring(pointPose, pointPose + 3);
        } else
        {
            if (nagitiveNum)
            {
                intPart = input.toString().substring(1);
            } else
            {
                intPart = input.toString().substring(0);
            }
            intPartlength = intPart.length;
            doublePart = ".00";
        }

        var count = 0 ;
        for (var i = intPartlength - 1; i >= 0; i--) {
            count ++ ;
            out = intPart.charAt(i) + out;
            if ( count%3 == 0 && i != 0 && i != intPartlength - 1)
            {
                out = "," + out;
            }
        }

        out = out + doublePart;
        if (nagitiveNum) {
            return "-" + out;
        } else {
            return "" + out;
        }
    }
}

function percentFilter() {
    /**
     *
     * 百分比转换
     * @param source 要转换的数
     */
    return function (source) {
        var percent;
        if (typeof(source) == 'undefined' || Number(source) == 0) {
            return "0.00%";
        }
        if(isNaN(source)) return '-';
//        console.log("percentFilter :" + source);
        //保证两位小数 不足补齐
        var pointPose = source.toString().lastIndexOf(".");
        percent = source.toString().substring(0, pointPose + 6);
        //console.log("source", source, percent,pointPose)
        percent = Number(percent) * 100;
        percent = percent.toFixed(2);
        //console.log("source", source, percent);

        //保证两位小数 不足补齐
        pointPose = percent.toString().lastIndexOf(".");
        if (pointPose == -1) {
            percent = percent + ".";
            for (i = 1; i <= 2; i++) {
                percent = percent + "0";
            }
        } else {
            percent = percent.substring(0, pointPose + 3);
            for (i = percent.length; i <= pointPose + 2; i++) {
                percent = percent + "0";
            }
        }
        return percent + "%";
    };
}

function percentnomulFilter() {
    /**
     *
     * 百分比转换
     * @param source 要转换的数
     */
    return function (source) {
        var percent;
        if (typeof(source) == 'undefined' || Number(source) == 0) {
            return "0.00%";
        }
        if(isNaN(source)) return '-';
//        console.log("percentFilter :" + source);
        //保证两位小数 不足补齐
        var pointPose = source.toString().lastIndexOf(".");
        percent = source.toString().substring(0, pointPose + 6);
        //console.log("source", source, percent,pointPose)
        percent = Number(percent);
        percent = percent.toFixed(2);
        //console.log("source", source, percent);

        //保证两位小数 不足补齐
        pointPose = percent.toString().lastIndexOf(".");
        if (pointPose == -1) {
            percent = percent + ".";
            for (i = 1; i <= 2; i++) {
                percent = percent + "0";
            }
        } else {
            percent = percent.substring(0, pointPose + 3);
            for (i = percent.length; i <= pointPose + 2; i++) {
                percent = percent + "0";
            }
        }
        return percent + "%";
    };
}

function percentNOPoit(){
    return function (source) {
        var percent;
        if (typeof(source) == 'undefined' || Number(source) == 0) {
            return "0%";
        }
//        console.log("percentFilter :" + source);
        //保证两位小数 不足补齐
        var pointPose = source.toString().lastIndexOf(".");
        if(pointPose > -1){
            percent = source.toString().substring(0, pointPose + 3);
        }

        percent = Math.round(Number(percent) * 100);//Number强转会出现显示“*0.00000000001”的问题
//        percent = Number(percent) * 100;
        percent = percent.toString();
//        console.log(percent);
        return percent + "%";
    }

}

function transforNotEmpty() {
    return function (input, instead) {
        if (typeof(input) == 'undefined' || input.length == 0 || input == 'null') {
            return instead;
        } else {
            return input;
        }
    }
}
/**
 * 买卖标志过滤
 * @returns {Function}
 */
function exchangeFilter(){
    return function (flag) {
        if(flag == "B")
        {
            return "买入";
        }else{
            return "卖出";
        }
    }
}
/**
 * 买卖策略
 * @returns {Function}
 */
function buyPolicy(){
    return function(input) {
        var price = Number(input);
        if (price == 0) {
            return "市价买卖";
        }else{
            var tempFun = moneyFilter();
            return tempFun(input,false);
        }
    }
}

/**
 * 委托状态
 * @returns {Function}
 */
function wtstatus(){
    return function(input) {
        var status = Number(input);
        switch (status)
        {
            case 0 : return "未申报";break;
            case 1 : return "待申报";break;
            case 2 : return "已申报";break;
            case 4 : return "无效委托";break;
            case 5 : return "部分撤单";break;
            case 6 : return "已撤单";break;
            case 7 : return "部分成交";break;
            case 8 : return "已成交";break;
        }
    }
}

/**
 * 只显示时间
 * @returns {Function}
 */
function shorttime(){
    return function(input)
    {
        return input.split(" ")[1];
    }
}

/**
 * 只显示日期
 * @returns {Function}
 */
function shortdate(){
    return function(input)
    {
        return input.split(" ")[0];
    }
}

function dateFilter() {
    return function (input) {
        return input;
    }
}

function periodFilter()
{
    return function (input)
    {
        //var result = input.toString().replace('w', '周').replace('m', '个月');
        var result = "";
        if(input == "1w")
        {
            result = "1周";
        }
        else if(input == "1m")
        {
            result = "1个月";
        }
        else if(input == "3m")
        {
            result = "3个月";
        }
        else if(input == "6m")
        {
            result = "半年";
        }
        else if(input == "12m")
        {
            result = "1年";
        }
        //console.log(input, result);
        return result;
    }
}

//月\日
function mdFilter()
{
    return function (input)
    {
        if(input != "" && input != null && input != undefined && input != "--")
        {
            if(input.indexOf("-",0) == -1)
            {
                var month = input.toString().substr(4, 2);
                var day = input.toString().substr(6, 2);
                return month + "月" + day + "日";
            }
            else
            {
                var month = input.toString().substr(5, 2);
                var day = input.toString().substr(8, 2);
                return month + "月" + day + "日";
            }
        }
        else
        {
            return "--";
        }
    }
}

//月\日\时\分
function mdmsFilter()
{
    return function (input)
    {
        if(input != "" && input != null && input != undefined && input != "--")
        {
            if(input.indexOf("-",0) == -1)
            {
                var month = input.toString().substr(4, 2);
                var day = input.toString().substr(6, 2);
                var shi = input.toString().substr(8, 2);
                var fen = input.toString().substr(10, 2)
                if(!shi && !fen)
                {
                    return month + "月" + day + "日";
                }
                else
                {

                    return month + "月" + day + "日" + shi + "点" + fen +"分";
                }
            }
            else
            {
                var month = input.toString().substr(5, 2);
                var day = input.toString().substr(8, 2);
                var shi = input.toString().substr(11, 2);
                var fen = input.toString().substr(14, 2);
                if(!shi && !fen)
                {
                    return month + "月" + day + "日";
                }
                else
                {

                    return month + "月" + day + "日" + shi + "点" + fen +"分";
                }

            }
        }
        else
        {
            return "--";
        }
    }
}

/**
 * 数字统一过滤器
 * @returns {Function}
 */
function numberFormatFilter() {

    return function (input, type) {
//        console.log(input + " = " + type);
        if (type == "number")
        {
            var tempFun = new transforNotEmpty();
            return tempFun(input, '0');
        }
        else if (type == "money")
        {
            var tempFun = new moneyFilter();
            return tempFun(input, false);
        }
        else if (type == "exchangeflag")
        {
            var tempFun = new exchangeFilter();
            return tempFun(input, false);
        }
        else if( type == 'wtstatus')
        {
            var tempFun = new wtstatus();
            return tempFun(input);
        }
        else if (type == "money1")
        {
            var tempFun = new money1Filter();
            return tempFun(input, false);
        }
        else if( type == "buypolicy")
        {
            var tempFun = new buyPolicy();
            return tempFun(input);
        }
        else if (type == "date")
        {
            var tempFun = new dateFilter();
            return tempFun(input);
        } else if(type == "shorttime"){
            var tempFun = new shorttime();
            return tempFun(input);
        }else if(type == 'shortdate'){
            var tempFun = new shortdate();
            return tempFun(input);
        }else if(type == 'stockcode'){
           var tempFun = new stcokcodeFilter();
            return tempFun(input);
        } else if (type == "percent")
        {
            var tempFun = new percentFilter();
            return tempFun(input);
        }
        else if (type == "percentnomul")
        {
            var tempFun = new percentnomulFilter();
            return tempFun(input);
        }
        else if( type == "percentNopoint")
        {
            var tempFun = new percentNOPoit();
            return tempFun(input);
        }else if( type == 'capitalFrom')
        {
            var tempFun = new capitalFromTypeFilter();
            return tempFun(input);
        }else if( type == 'moneyType')
        {
            var tempFun = new moneyTypeFilter();
            return tempFun(input);
        }else if( type == 'handToHundred')
        {
            var tempFun = new handToHundredFilter();
            return tempFun(input);
        }else if( type == 'formatNumUtil')
        {
            var tempFun = new formatNumberUtil();
            return tempFun(input, '-');
        }
        else if( type == 'periodFilter')
        {
            var tempFun = new periodFilter();
            return tempFun(input);
        }
        //else if( type == 'enddayfilter')
        //{
        //    var tempFun = new enddayfilter();
        //    return tempFun(input);
        //}
        else if( type == 'mdfilter')
        {
            //console.log("mdfilter");
            var tempFun = new mdFilter();
            return tempFun(input);
        }
        else if( type == 'mdmsfilter')
        {
            var tempFun = new mdmsFilter();
            return tempFun(input);
        }
        else {
            var tempFun = new transforNotEmpty();
            return tempFun(input, '-');
        }

    }
}


/**
 *
 * 组合状态过滤器
 */
function statusFilter() {

    var statusObject = {"C": "创建中", "Y": "正常", "I": "未初始化", "O": "已过期", "N": "已注销"};
    return function (input) {
        if (typeof(input) == 'undefined' || input == null) {
            return '-';
        } else {
            return statusObject[input];
        }
    };
}

/**
 * 证券代码过滤器
 */
function stcokcodeFilter(){
    return function(input)
    {
        if (typeof(input) == 'undefined' || input == null) {
            return '-';
        } else if(input.length == 8){
            return input.substring(2);
        }else{
            return input;
        }
    }
}


function moneyTypeFilter() {

    var moneyTypes = {"R": "人民币", "A": "美元","H":"港币"};
    return function (input) {
        if (typeof(input) == 'undefined' || input == null) {
            return '-';
        } else {
            return moneyTypes[input];
        }
    };
}

function handToHundredFilter() {

    return function (input) {
        if (typeof(input) == 'undefined' || input == null || isNaN(input) ) {
            return '-';
        } else {
            return Math.floor(input / 100) * 100;
        }
    };
}

function capitalFromTypeFilter() {

    var capitaTypes = {"A": "资金方", "C": "组合交易员"};
    return function (input) {
        if (typeof(input) == 'undefined' || input == null) {
            return '-';
        } else {
            return capitaTypes[input];
        }
    };
}

function riskInfoFilter() {
    return function (ratio) {
        if (ratio==0)
        {
            return "禁止买入";
        }
        else
        {
            return "持仓比例不能超过该组合总资产的"+(Number(ratio)*100).toFixed(2)+"%";
        }
    };
}

function changeTwoDecimal_f(x) {
    var f_x = parseFloat(x);
    if (isNaN(f_x)) {
        //alert('function:changeTwoDecimal->parameter error');
        return false;
    }
    var f_x = Math.round(x * 100) / 100;
    var s_x = f_x.toString();
    var pos_decimal = s_x.indexOf('.');
    if (pos_decimal < 0) {
        pos_decimal = s_x.length;
        s_x += '.';
    }
    while (s_x.length <= pos_decimal + 2) {
        s_x += '0';
    }
    return s_x;
}

//格式化数字单位
function formatNumberUtil()
{
    return function (num)
    {
        if(num != "" && num !="--" && num != "-" && num !=null)
        {
            var number = Number(num);
            if(number >= 1000000000000 || number <= -1000000000000)
            {
                return changeTwoDecimal_f(number/1000000000000)+" 万亿";
            }
            else if(number >= 100000000 || number <= -100000000)
            {
                return changeTwoDecimal_f(number/100000000)+" 亿";
            }
            else if(number >= 10000 || number <= -10000)
            {
                return changeTwoDecimal_f(number/10000)+" 万";
            }
            else {
                return number;
            }
        }
        else
        {
            return "--";
        }
    }
}


