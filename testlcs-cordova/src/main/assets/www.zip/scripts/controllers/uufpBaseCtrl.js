﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function uufpBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userName = "";//用户名
    $scope.head = "images/wutouxian.png";
    //$scope.iconurl = "images/ico02_1.png";
    $scope.longitude = "";//经度
    $scope.latitude = "";//纬度
    $scope.deviceid = "";//设备号
    $scope.iphone_model="";//手机型号
    $scope.iphone_pixels="";//手机尺寸
    $scope.iphone_release = "";//手机操作系统版本
    $scope.app_version = "";//app版本
    $scope.basetabOneShow = false;
    $scope.basetabTwoShow = false;
    $scope.basetabThreeShow = false;
    $scope.basetabFourShow = false;
    $scope.basetabFiveShow = false;

    $scope.baseindex = "1";
    $scope.loginDivShow = false;//登录界面
    $scope.fpBaseDivShow = false;//主界面
    $scope.firstInDivShow = false;//第一次登陆使用
    $scope.wxdlDivShow = true;//微信登陆
    $scope.dlmdlDivShow = false;//登陆码

    $scope.token = "";//登录码
    $scope.userObj;//个人信息
    $scope.loginInfo = "";
    $scope.loginMark = true;//是否能点击登陆按钮
    $scope.baseBottomShow = false;//主界面下方操作按钮是否显示
    $scope.basecookiezxgList = [];//自选股列表
    $scope.lcsstatus = "0";//0：未申请，且不是理财师或者申请不通过；1：申请中；2：申请通过，已是理财师

    $scope.clickcount = 0;
    $scope.bcidstr = "-1";// 专户理财师："-1"; 雷帝:333
    //console.log(window.location.hash);

    $scope.dlm = [];

    $scope.xsbdImg = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/lcs_xsbd_zhlcs.png?20160308";

    $scope.typeDLM = function (pos) {
        if ($scope.dlm[pos-1] != null && $scope.dlm[pos-1].length>0) {
            if (pos < 4) {
                document.getElementById("pwd_" + (pos+1)).focus();
            }
            else {
                document.getElementById("pwd_" + 4).focus();
            }
        }else{
            if (pos > 1) {
                document.getElementById("pwd_" + (pos - 1)).focus();
            }
            else {
                document.getElementById("pwd_" + 1).focus();
            }
        }

    };

    //底部是否显示
    $scope.baseBottomVisible = function (_value) {
        $scope.baseBottomShow = _value;
    }


    $scope.bottomtabClick = function (_str) {
        switch (_str)
        {
            case "1"://实盘
                document.getElementById("homeswiperDiv").style.display = "";
                $scope.basetabOneShow = true;
                $scope.basetabTwoShow = false;
                $scope.basetabThreeShow = false;
                $scope.basetabFourShow = false;
                $scope.basetabFiveShow = false;
                window.location.href = "#baseindex=1";
                $scope.baseBottomVisible(true);
                break;
            //case "2"://解盘
            //    $scope.basetabOneShow = false;
            //    $scope.basetabTwoShow = true;
            //    $scope.basetabThreeShow = false;
            //    $scope.basetabFourShow = false;
            //    $scope.basetabFiveShow = false;
            //    if ($scope.clickcount > 0) {
            //        window.location.href = "#baseindex=2";
            //    }
            //
            //    break;
            case "3"://交易理财师
                document.getElementById("homeswiperDiv").style.display = "none";
                $scope.basetabOneShow = false;
                $scope.basetabTwoShow = false;
                $scope.basetabThreeShow = true;
                $scope.basetabFourShow = false;
                $scope.basetabFiveShow = false;
                if ($scope.clickcount > 0) {
                    window.location.href = "#baseindex=3";
                }
                $scope.baseBottomVisible(true);
                break;
            case "4"://我
                document.getElementById("homeswiperDiv").style.display = "none";
                $scope.basetabOneShow = false;
                $scope.basetabTwoShow = false;
                $scope.basetabThreeShow = false;
                $scope.basetabFourShow = true;
                $scope.basetabFiveShow = false;
                $scope.baseBottomVisible(true);
                if ($scope.clickcount > 0) {
                    window.location.href = "#baseindex=4";
                }
                break;
            case "42"://我
                document.getElementById("homeswiperDiv").style.display = "none";
                $scope.basetabOneShow = false;
                $scope.basetabTwoShow = false;
                $scope.basetabThreeShow = false;
                $scope.basetabFourShow = true;
                $scope.basetabFiveShow = false;
                $scope.baseBottomVisible(false);
                if ($scope.clickcount > 0) {
                    window.location.href = "#baseindex=42";
                }
                break;
            case "5"://发现
                document.getElementById("homeswiperDiv").style.display = "none";
                $scope.basetabOneShow = false;
                $scope.basetabTwoShow = false;
                $scope.basetabThreeShow = false;
                $scope.basetabFourShow = false;
                $scope.basetabFiveShow = true;
                $scope.baseBottomVisible(true);
                if ($scope.clickcount > 0) {
                    window.location.href = "#baseindex=5";
                }

            default :
                break;
        }
        $scope.clickcount++;
        gotoUp();
    }

    $scope.getzxglist = function () {
        //console.log("自选股列表：", $scope.userObj.f_id);
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        message["ordeCol"] = "";
        message["ordeBy"] = "";

        ajaxService.sendMessage("hq.getzxghqaction", message, function (_data) {
            //console.log("自选股列表：" + _data);
            $scope.basecookiezxgList = [];
            if (_data.op.code.toString() == "Y") {
                var arr = _data.data;
                for (var i = 0; i < arr.length; i++) {
                    var obj2 = {};
                    obj2.tc = arr[i].exchange.toString().toUpperCase() + arr[i].symbol;
                    $scope.basecookiezxgList.push(obj2);
                }
            }
            //$cookieStore.put('cookiezxgList', $scope.basecookiezxgList);

            var localStorage = window.localStorage;
            localStorage.setItem("cookiezxgList", JSON.stringify($scope.basecookiezxgList));

            //console.log("zxg", JSON.parse(localStorage.getItem("cookiezxgList")));
            //
            //var arr = JSON.parse(localStorage.getItem("cookiezxgList"));
            //console.log(arr);
            //console.log(arr.length);
            //for(var i = 0;i<arr.length;i++)
            //{
            //    console.log(arr[i].tc);
            //}
        })
    }

    $scope.getlcsStatus = function () {
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        //console.log("userid状态", $scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, function (_data) {
            //console.log("理财师：" + _data);
            //for(var k in _data)
            //{
            //    console.log("key: " + k + "；value: " + _data[k]);
            //}
            //var lcspj = "0";
            if (_data.op.code.toString() == "Y") {
                if (_data.lcsapplyinfo.isexist.toString() == "false") {
                    $scope.lcsstatus = "0";//0：未申请
                }
                else {
                    if (_data.lcsapplyinfo.status.toString() == "A") {
                        $scope.lcsstatus = "1";//1：申请中
                    }
                    else if (_data.lcsapplyinfo.status.toString() == "Y") {
                        $scope.lcsstatus = "2";//1：申请通过，已是理财师
                        //lcspj = _data.lcsapplyinfo.level;
                    }
                    else//N，申请未通过
                    {
                        $scope.lcsstatus = "0";//0：未申请
                    }
                }
                if ($scope.lcsstatus == "2") {
                    $scope.abletofb = 'true';//是理财师，可以发布解盘
                }
                else {
                    $scope.abletofb = 'false';
                }
                //console.log("lcsstatus", $scope.lcsstatus);
            }
            var localStorage = window.localStorage;
            localStorage.setItem("lcsstatus", $scope.lcsstatus);
            //localStorage.setItem("lcspj", lcspj);

            //if (window.location.hash == "#/baseindex=2") {
            //    $scope.baseindex = '2';
            //}
            //if (window.location.hash == "#/baseindex=1") {
            //    $scope.baseindex = '1';
            //}
            //else if (window.location.hash == "#/baseindex=3") {
            //    $scope.baseindex = '3';
            //}
            //else if (window.location.hash == "#/baseindex=4") {
            //    $scope.baseindex = '4';
            //}
            //else if (window.location.hash == "#/baseindex=42") {
            //    $scope.baseindex = '42';
            //}
            //else if (window.location.hash == "#/baseindex=5") {
            //    $scope.baseindex = '5';
            //}
            //$scope.bottomtabClick($scope.baseindex);

        })
    }

    $scope.addlogininfoCallBack = function(_data)
    {
        //console.log("logininfo", _data);
    }

    //录入使用状态
    $scope.setsyzt = function()
    {
        var localStorage = window.localStorage;
        $scope.deviceid = localStorage.getItem("deviceid");
        if($scope.deviceid == null || $scope.deviceid == undefined)
        {
            $scope.deviceid = "";
        }
        var message = {};
        message["logininfo.userid"] = $scope.userObj.f_id;
        message["logininfo.deviceid"] = $scope.deviceid;
        //console.log("userid状态", message);
        ajaxService.sendMessage("user.addlogininfo", message, $scope.addlogininfoCallBack);
    }

    //$scope.isjytimeCallBack = function(_data)
    //{
    //    //console.log(timeistradeing);
    //    //console.log("交易时间", _data);
    //    if(_data.op.code.toString() == "Y")
    //    {
    //        if(_data.ftradeday == "Y" && _data.ftradetime == "Y")
    //        {
    //            timeistradeing = true;
    //        }
    //        else
    //        {
    //            timeistradeing = false;
    //        }
    //        //console.log(timeistradeing);
    //    }
    //}
    ////是否是交易时间
    //$scope.isjytime = function()
    //{
    //    var message = {};
    //    ajaxService.sendMessage("counter.GetSystemStatusAction", message, $scope.isjytimeCallBack);
    //
    //}

    $scope.getInfo = function () {
        //console.log("getInfo");
        //缓存数据
        var ind = getParameter("baseindex");
        if (ind != "") {
            $scope.baseindex = ind;
            //console.log("位置",$scope.baseindex);
        }
        var localStorage = window.localStorage;
        $scope.userName = decodeURIComponent(localStorage.getItem("nickname"));
        $scope.head = decodeURIComponent(localStorage.getItem('iconurl'));

        localStorage.setItem("lcs_childIndex", "0");
        //var iulr = decodeURIComponent(localStorage.getItem("iconurl"));
        //
        //if (iulr != "" && iulr != undefined) {
        //    $scope.iconurl = iulr;
        //}
        //alert("$scope.userObj " + $scope.userObj);
        //console.log("info");
        $scope.getzxglist();//存cookie
        $scope.getlcsStatus();

        $scope.setsyzt();


        if (window.location.hash == "#/baseindex=1") {
            $scope.baseindex = '1';
        }
        else if (window.location.hash == "#/baseindex=3") {
            $scope.baseindex = '3';
        }
        else if (window.location.hash == "#/baseindex=4") {
            $scope.baseindex = '4';
        }
        else if (window.location.hash == "#/baseindex=42") {
            $scope.baseindex = '42';
        }
        else if (window.location.hash == "#/baseindex=5") {
            $scope.baseindex = '5';
        }
        $scope.bottomtabClick($scope.baseindex);

        getAllHint();
        //$scope.isjytime();
    }

    //登录返回
    $scope.loginCallBack = function (_data)
    {
        //alert("登陆返回");
        //myAlert(_data.user.f_qq + "  " + _data.user.f_weixinhao + _data.user.f_province);
        //alert("登陆名称：" + _data.user.f_nickname);
        //alert("返回登陆经纬度："  + _data.user.f_longitude + " " +  _data.user.f_latitude + " " + _data.user.f_deviceid);
        //console.log("登陆", _data);
        if (_data.op.code.toString() == "Y")
        {
            //alert("成功！")
            //$scope.sessionID = _data.session.id;
            $scope.loginInfo = "";
            $scope.userObj = _data.user;
            //console.log($scope.userObj);
            var localStorage = window.localStorage;
            localStorage.setItem("sessionid", _data.sessionid);
            localStorage.setItem("user", JSON.stringify(_data.user));
            localStorage.setItem("nickname", encodeURIComponent(_data.user.f_nickname));
            localStorage.setItem("bcid", $scope.bcidstr);
            //console.log("iconurl", _data.user.f_head);

            var txstr = _data.user.f_head;
            if (txstr == null || txstr == undefined || txstr == "") {
                txstr = "images/wutouxian.png";
            }
            localStorage.setItem("iconurl", encodeURIComponent(txstr));
            localStorage.setItem("token", _data.user.f_token);
            $scope.jp_userid = $scope.userObj.f_id;

            //console.log("1", $scope.jp_userid);

            //console.log("jpid", $scope.jp_userid);

            //console.log(localStorage.getItem("sessionid"));
            //console.log(localStorage.getItem("user"));


            //
            //$cookieStore.put('sessionid',_data.sessionid);
            //$cookieStore.put('user',_data.user);
            //$cookieStore.put('nickname', encodeURIComponent(_data.user.f_nickname));
            //$cookieStore.put('iconurl', encodeURIComponent(_data.user.f_head));

            //app写入token
            //try
            //{
            //    writeFile("uulcs/token.html", _data.user.f_token, function(_data)
            //    {
            //        //alert("写入onSuccess:" + _data);
            //    }, function(e){
            //        // alert("写入onError:" + e.toString());
            //    });
            //}catch(e){
            //    // alert("写入catchonError:" + e.toString());
            //};
            //跳转至home

            $scope.loginDivShow = false;//登录界面
            //var isfirst = $scope.userObj.f_isfirsttime.toString();
            //isfirst = "Y";
            //console.log("is", isfirst);
            //if(isfirst == "Y")
            //{
            //    $scope.firstInDivShow = true;
            //    $scope.fpBaseDivShow = false;//主界面
            //}
            //else
            //{
                $scope.fpBaseDivShow = true;//主界面
                //$scope.firstInDivShow = false;
                $scope.getInfo();
            //}
            $scope.loginInfo = "";

        }
        else
        {
            $scope.loginInfo = "登录失败，请重试" + _data.op.info;
            $scope.loginDivShow = true;//登录界面
            $scope.fpBaseDivShow = false;//主界面
            //$scope.firstInDivShow = false;
        }
        $scope.loginMark = true;
    }

    //登录
    $scope.loginClick = function () {
        if($scope.loginMark)
        {
            //if($scope.dlm != null)
            //{
            //    if($scope.dlm.length == 4)
            //    {
            //        if($scope.dlm[0] == "" ||$scope.dlm[1] == "" || $scope.dlm[2] =="" || $scope.dlm[3] == "")
            //        {
            //            $scope.loginInfo = "请输入登录码";
            //            return;
            //        }
            //    }
            //    else
            //    {
            //        $scope.loginInfo = "请输入登录码";
            //        return;
            //    }
            //}
            //else
            //{
            //    $scope.loginInfo = "请输入登录码";
            //    return;
            //}
            //$scope.token = "";
            //for(var i = 0;i<$scope.dlm.length;i++)
            //{
            //    $scope.token = $scope.token + $scope.dlm[i];
            //}
            if ($scope.token == "")
            {
                $scope.loginInfo = "请输入登录码";
                return;
            }

            $scope.loginInfo = "登录中，请稍候...";
            $scope.loginMark = false;

            var message = {};
            message['user.longitude'] = $scope.longitude;//经度
            message['user.latitude'] = $scope.latitude;//纬度
            message['user.deviceid'] = $scope.deviceid;//设备号
            message['user.pwd'] = $scope.token;
            message['user.bcid'] = $scope.bcidstr;
            message['user.mobilemodel'] = $scope.iphone_model;
            message['user.mobilesize'] = $scope.iphone_pixels;
            message['user.systemversion'] = $scope.iphone_release;
            //message['user.openid'] = $scope.token;
            //message['user.nickname'] = "提婆丶达多";
            //var headstr = "http:\/\/wx.qlogo.cn\/mmopen\/n24XYyibqQPYScb1jkpNvKfTOE5O9CCWtKm1tmYjJbxp59ichYfx3ZeBMaAeicT8ORPAibjXiawiccxymWFqwsiaND7O0upeMdNZfcV\/0";
            ////var headstr = "http://wx.qlogo.cn/mmopen/QrbVfpGceJxHYaibnQbtvPQB7y9B8KSJ7A1QkJMG0rgMicpeNCBB9kHvHP3x3mD85BPGGVgdBI6iaY1crNVRrJxpV9bmZDfO09O/0";
            ////var str = "/";
            ////var str1 = "";
            ////var headstr2 = headstr.replace(eval("/"+str+"/gi"), str1);
            //message['user.head'] = headstr;
            //message['user.province'] = "hunan";
            //console.log(121212, $scope.token);
            //alert("登录码登录：" + $scope.longitude + " " +  $scope.latitude + " " + $scope.deviceid);
            ajaxService.sendMessage('user.p_login', message, $scope.loginCallBack);
        }
        //$scope.userObj = {};
        //$scope.userObj.f_id = "71";
        //$cookieStore.put('user', $scope.userObj);
        //$scope.loginDivShow = false;//登录界面
        //$scope.fpBaseDivShow = true;//主界面
        //$scope.loginInfo = "";
        //$scope.bottomtabClick($scope.baseindex);
    }


    $scope.show = function ()
    {
        //alert("有无token");
        if ($scope.token == "" || $scope.token == undefined)//没有token，显示登录界面
        {
            //alert("无token");
            $scope.token = "";
            //alert("loginDivShow111 false");
            $scope.loginDivShow = true;//登录界面
            //alert("loginDivShow true");
            $scope.wxdlDivShow = true;//微信登陆
            $scope.fpBaseDivShow = false;//主界面
            //$scope.firstInDivShow = false;
            $scope.dlmdlDivShow = false;//登陆码
            $scope.$apply();
            //alert("无token界面显示" + $scope.loginDivShow);
        }
        else//有token直接登录
        {
            //alert("有token");
            $scope.loginMark = false;
            var message = {};
            message['user.pwd'] = $scope.token;
            message['user.longitude'] = $scope.longitude;//经度
            message['user.latitude'] = $scope.latitude;//纬度
            message['user.deviceid'] = $scope.deviceid;//设备号
            message['user.bcid'] = $scope.bcidstr;
            message['user.mobilemodel'] = $scope.iphone_model;
            message['user.mobilesize'] = $scope.iphone_pixels;
            message['user.systemversion'] = $scope.iphone_release;
            //alert("token直接登录：" + $scope.longitude + " " +  $scope.latitude + " " + $scope.deviceid);
            ajaxService.sendMessage('user.p_login', message, $scope.loginCallBack);
        }
    }


    function onBackKeyDown() {
        //Toast.showShort('再点击一次退出!');
        showToast('再点击一次退出',1000);
        document.removeEventListener("backbutton", onBackKeyDown, false); // 注销返回键
        document.addEventListener("backbutton", exitApp, false);//绑定退出事件
        // 3秒后重新注册
        var intervalID = window.setInterval(function() {
            window.clearInterval(intervalID);
            document.removeEventListener("backbutton", exitApp, false); // 注销返回键
            document.addEventListener("backbutton", onBackKeyDown, false); // 返回键
        }, 3000);
    }
    function exitApp(){
        navigator.app.exitApp();
    }

    /**
     * 自定义toast，js实现android中toast效果
     * @param msg 显示文字
     * @param duration 显示的时间长度
     */
    function showToast(msg, duration) {
        duration = isNaN(duration) ? 3000 : duration;
        var m = document.createElement('div');
        m.innerHTML = msg;
        m.style.cssText = "width:60%; min-width:150px; background:#000; opacity:0.5; height:40px; color:#fff; line-height:40px; text-align:center; border-radius:5px; position:fixed; top:70%; left:20%; z-index:999999; font-weight:bold;";
        document.body.appendChild(m);
        setTimeout(function() {
            var d = 0.5;
            m.style.webkitTransition = '-webkit-transform ' + d
            + 's ease-in, opacity ' + d + 's ease-in';
            m.style.opacity = '0';
            setTimeout(function() {
                document.body.removeChild(m)
            }, d * 1000);
        }, duration);
    }



    $scope.init = function ()
    {
        //检测是否有用户信息
        //alert("检测是否有用户信息");
        $scope.userObj = isLogin();

        //console.log("user",$scope.userObj);
        if ($scope.userObj == undefined || $scope.userObj == null)//无用户信息
        {
            //alert("无用户信息");
            //app
            //try
            //{
            //    readFile("uulcs/token.html", function(_data)
            //    {
            //        //alert("读取onSuccess:" + _data);
            //        //获取token
            //        if(_data.result == 1)//成功
            //        {
            //            $scope.token = _data.content.toString();
            //            $scope.show();
            //        }
            //        else//失败
            //        {
            //            $scope.show();
            //        }
            //    }, function(e){
            //        $scope.show();
            //    });
            //}
            //catch(e){
            //    //alert("读取catchonError:" + e.toString());
            //    $scope.show();
            //}
            //设备号
            try
            {
                getDeviceId(function(_data)
                {
                    var da = JSON.parse(_data);
                    //alert("读取设备号onSuccess:" + da);
                    //alert("读取设备号onSuccess:" + da.result);
                    //alert("读取设备号onSuccess:" + da.deviceid);
                    //获取token
                    if(da.result == 1)//成功
                    {
                        $scope.deviceid = da.deviceid.toString();
                        $scope.iphone_model = da.model.toString();//手机型号
                        $scope.iphone_pixels = da.pixels.toString();//手机尺寸
                        $scope.iphone_release = da.release.toString();;//手机操作系统版本
                        $scope.app_version = "V"+ da.version.toString();//app版本
                        var localStorage = window.localStorage;
                        localStorage.setItem("deviceid", $scope.deviceid);
                    }
                    else//失败
                    {
                        //alert("设备号读取Error");
                    }
                }, function(e){
                    //alert("设备号读取Error:" + e.toString());
                });
            }
            catch(e){
                //alert("设备号读取catchonError:" + e.toString());
            }
            //经纬度
            try
            {
                navigator.locationplugin.location("locationCallBack");
            }
            catch(e){
                //alert("读取catchonError:" + e.toString());
            }
            try {
                var localStorage = window.localStorage;
                localStorage.getItem("token");
                //alert("token:" + $scope.token);
                $scope.show();
            } catch (e) {
                $scope.show();
            }
        }
        else {
            //alert("有用户信息");
            //alert("loginDivShow22 false");
            $scope.loginDivShow = false;//登录界面
            $scope.fpBaseDivShow = true;//主界面
            //$scope.firstInDivShow = false;//有登录信息，表示不是第一次登录

            $scope.jp_userid = $scope.userObj.f_id;
            //console.log("2", $scope.jp_userid);
            try
            {
                getDeviceId(function(_data)
                {
                    var da = JSON.parse(_data);
                    //获取token
                    if(da.result == 1)//成功
                    {
                        $scope.app_version = "V"+ da.version.toString();//app版本
                    }
                    else//失败
                    {
                    }
                }, function(e){
                });
            }
            catch(e){
                //alert("设备号读取catchonError:" + e.toString());
            }
            $scope.getInfo();
        }
    }
    //$scope.init();

    $scope.appinit = function()
    {
        //alert("appinit");
        document.addEventListener('deviceready', function()
        {
            //alert("deviceready");
            $scope.init();
            document.addEventListener("backbutton", onBackKeyDown, false);
        }, false);
    }
    $scope.appinit();

    //经纬度
    locationCallBack = function(_data)
    {
        try
        {
            var da = JSON.parse(_data);
            $scope.longitude = da.lontitude;
            $scope.latitude = da.latitude;

            //alert("经纬度：" + $scope.longitude + $scope.latitude);
        }catch (e){
            //alert("经纬度Error：" + e.toString());
        }
    }

    //微信登陆
    $scope.wxOnload = function()
    {
        //alert("微信登录");
        navigator.wxplugin.login("wxloginCallback");
    }

    wxloginCallback = function(_data)
    {
        try
        {
            var da = JSON.parse(_data);
            //myAlert("微信登陆返回，" + _data );
            //var errcode = da.errcode;
            //if(errcode == null || errcode == undefined || errcode == "")
            //{
                var obj = {};
                obj.openid = da.openid;
                obj.province = da.province;
                obj.nickname = da.nickname;
                obj.headimgurl = da.headimgurl;
                obj.unionid = da.unionid;
                obj.city = da.city;
                //alert("微信登陆返回unionid，" + obj.unionid );
                var message = {};
                message['user.openid'] = obj.openid;
                //alert("微信登陆nickname，" + obj.nickname);
                message['user.nickname'] = obj.nickname;
                message['user.unionid'] = obj.unionid;
                //message['user.pwd'] = "";//登陆码
                //message['user.mobile'] = "";//手机号
                //message['user.sfz'] = "";//身份证
                //message['user.weixinhao'] = "";//微信号
                //message['user.ip'] = "";
                //message['user.systemid'] = "";
                message['user.longitude'] = $scope.longitude;//经度
                message['user.latitude'] = $scope.latitude;//纬度
                message['user.deviceid'] = $scope.deviceid;//设备号
                message['user.head'] = obj.headimgurl;
                message['user.province'] = obj.province;
                message['user.city'] = obj.city;
                message['user.mobilemodel'] = $scope.iphone_model;
                message['user.mobilesize'] = $scope.iphone_pixels;
                message['user.systemversion'] = $scope.iphone_release;
                message['user.bcid'] = $scope.bcidstr;// 专户理财师：""; 雷帝:333
                //message['user.inviterid'] = "77";
                //alert("inviterid= 77");
                //myAlert("微信登录："  + $scope.longitude + " " +  $scope.latitude + " " + $scope.deviceid);
                ajaxService.sendMessage('user.p_login', message, $scope.loginCallBack);
            //}
            //else
            //{
            //    $scope.loginInfo = da.errmsg;
            //}


        }catch(e)
        {
            $scope.loginInfo = "登录失败";
        }
    }

    $scope.gotoxsbdDiv = function()
    {
        $scope.fpBaseDivShow = false;//主界面
        $scope.firstInDivShow = true;
        gotoUp();
    }

    $scope.gotomainDiv = function()
    {
        $scope.fpBaseDivShow = true;//主界面
        $scope.firstInDivShow = false;
        gotoUp();
    }

    //以登陆码登陆
    $scope.qhdlmdlClick = function()
    {
        $scope.wxdlDivShow = false;//微信登陆
        $scope.dlmdlDivShow = true;//登陆码
    }
    //微信登陆
    $scope.wxdlClick = function()
    {
        $scope.wxOnload();
    }

    //更新普通用户信息
    $scope.getptyhNewInfo = function()
    {
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        ajaxService.sendMessage("user.getuser", message, $scope.getptCallBack) ;
    }

    $scope.getptCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.userObj = _data.user;
            //console.log("更新",$scope.userObj);
            var localStorage = window.localStorage;
            localStorage.setItem("sessionid", _data.sessionid);
            localStorage.setItem("user", JSON.stringify(_data.user));
            localStorage.setItem("nickname", encodeURIComponent(_data.user.f_nickname));
            //console.log("iconurl", _data.user.f_head);

            var txstr = _data.user.f_head;
            if (txstr == null || txstr == undefined || txstr == "") {
                txstr = "images/wutouxian.png";
            }
            localStorage.setItem("iconurl", encodeURIComponent(txstr));
            $scope.userName = decodeURIComponent(localStorage.getItem("nickname"));
            $scope.head = decodeURIComponent(localStorage.getItem('iconurl'));
        }
        else
        {

        }
    }

    //退出
    $scope.baseLoginOut = function () {
        //console.log("退出");
        //$scope.loginInfo = "";
        //$scope.loginDivShow = true;//登录界面
        //$scope.fpBaseDivShow = false;//

        var localStorage = window.localStorage;
        localStorage.clear();
        //clearthisCookie();
        window.location.href = "uufpBase.html";
        //alert("退出");
        //$cookieStore.remove('sessionid');
        //$cookieStore.remove('user');
        //$cookieStore.remove('nickname');
        //$cookieStore.remove('iconurl');
        //$cookieStore.remove('cookiezxgList');
    }

    clearthisCookie = function()
    {
        //alert("2323");
        try{
            //alert("success");
            var keys=document.cookie.match(/[^ =;]+(?=\=)/g);
            if (keys) {
                for (var i = keys.length; i--;)
                    document.cookie= keys[i]+'=0;expires=' + new Date( 0).toUTCString()
            }
        }catch (e){
            //alert("e" + e.toString());
        }
        //alert("56546");
        window.location.href = "uufpBase.html";
    }

    $scope.basezxgUpdate = function()
    {
        $scope.getzxglist();
    }

}



