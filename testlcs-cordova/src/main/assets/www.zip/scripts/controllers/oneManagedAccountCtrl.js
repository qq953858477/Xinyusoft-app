/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function oneManagedAccountCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.previous = "";//上一级

    $scope.onemanagedaccount = "";//关联账号
    $scope.highaccount = "";//主账号
    $scope.accountName = ""//证券公司，显示用，主账号证券公司
    $scope.highaccountStr = ""; //显示主
    $scope.oneglzhShow = false;//一个关联账号的显示
    $scope.glzhtabOneShow = true;
    $scope.glzhtabTwoShow = false;
    $scope.glzhtabThreeShow = false;


    $scope.onemanagedaccount = getParameter("managedaccount");
    $scope.highaccount = getParameter("highaccount");
    $scope.accountName = decodeURIComponent(getParameter("accountName"));
    $scope.previous = getParameter("previous");

    //console.log($scope.onemanagedaccount, $scope.highaccount, $scope.accountName, $scope.previous);

    $scope.onemanagedaccountStr = "***" + $scope.onemanagedaccount.substr($scope.onemanagedaccount.length-4);

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        var cstr  = {"account":$scope.onemanagedaccount, "caption": _data.caption};
        $scope.$broadcast("setParameters", cstr);
    });

    //综合、交易/查询切换
    $scope.glzhchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.glzhtabOneShow = true;
            $scope.glzhtabTwoShow = false;
            $scope.glzhtabThreeShow = false;
            //parent->child的的入参
            var cstr  = {"account":$scope.onemanagedaccount};
            $scope.$broadcast("setParameters", cstr);
        }
        else if(_str == "2")
        {
            $scope.glzhtabOneShow = false;
            $scope.glzhtabTwoShow = true;
            $scope.glzhtabThreeShow = false;
        }
        else if(_str == "3")
        {
            $scope.glzhtabOneShow = false;
            $scope.glzhtabTwoShow = false;
            $scope.glzhtabThreeShow = true;
        }
    }

    //返回关联账号列表
    $scope.oneglzhback = function()
    {
        //跳转至单个账号
        //alert($scope.previous);
        if($scope.previous == "tradeBase")
        {
            window.location.href="tradeBase.html?index=3";
        }
        else
        {
            window.location.href="uufpBase.html?index=3";
        }
    }

    //置顶
    $scope.gotoUp = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }
}




