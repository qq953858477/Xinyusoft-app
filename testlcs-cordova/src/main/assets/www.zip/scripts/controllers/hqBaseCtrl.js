/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function hqBaseCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("首页", $scope.cesxinxi);
    $scope.ggfhParent = "";//个股返回父对象 首页：home；涨幅榜列表：morezfb；跌幅榜列表:moredfb；行业：hy；搜索:searchlist
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.indexbaseShow = false;//大盘指数
    $scope.homebaseShow = true;//主界面
    $scope.hqbaseoneStockHQBaseShow = false;//个股行情
    $scope.zfbstocklist = [];//涨幅榜
    $scope.dfbstocklist = [];//跌幅榜
    $scope.rmhyList = [];//热门行业
    $scope.rmhyDivShow = true;//热门行业显示
    $scope.zfbDivShow = true;//涨幅榜显示
    $scope.dfbDivShow = true;//跌幅榜显示
    $scope.hynstockListDivShow = false;//行业内股票列表展示
    $scope.hylistArray = [];//行业内股票数组
    $scope.hynstockList = "one";//哪里进入  首页进入：one； 展开界面进入：two
    $scope.order = "2";//0-不排序 1-升序 2-降序
    $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
    $scope.dqhyObj = {};//当前行业

    $scope.zfbmorestockListDivShow = false;//涨幅榜
    $scope.zfbmorelistArray = [];//涨幅榜更多
    $scope.dfbmorestockListDivShow = false;//跌幅榜
    $scope.dfbmorelistArray = [];//涨幅榜更多
    $scope.hymoreDivShow = false; //更多行业界面
    $scope.hymorelistArr = [];//行业更多
    $scope.gnmorelistArr = [];//概念更多
    $scope.hytabOneShow = false;//行业下行业
    $scope.hytabTwoShow = false;//行业下概念
    $scope.ggssDivShow = false;//个股搜索

    $scope.sshqintervalDuration = 5000;//间隔时间，8000毫秒
    $scope.sshqintervalId;

    $scope.szzsObj = {}
    $scope.szczObj = {}
    $scope.cybzObj = {}

    $scope.szzsObj.zs = "-";
    $scope.szzsObj.zd = "-";
    $scope.szzsObj.zdf = "-";
    $scope.szzsObj.status = "3";
    $scope.szzsObj.bz = "";

    $scope.szczObj.zs = "-";
    $scope.szczObj.zd = "-";
    $scope.szczObj.zdf = "-";
    $scope.szczObj.status = "3";
    $scope.szczObj.bz = "";

    $scope.cybzObj.zs = "-";
    $scope.cybzObj.zd = "-";
    $scope.cybzObj.zdf = "-";
    $scope.cybzObj.status = "3";
    $scope.cybzObj.bz = "";

    $scope.cookiezxgList = [];//存放入cookie的自选股列表

    $scope.allSearchStockListArray = [];//搜索出的股票列表数组
    $scope.searchStockValue = "";//搜索输入框内容
    $scope.dqxzstock = {};//当前选中

    //去除
    $scope.myhomeClearInterval = function () {
        if ($scope.sshqintervalId != undefined) {
            clearInterval($scope.sshqintervalId);
        }
    }


    $scope.szCallBack = function(_data)
    {
        console.log("指数", _data);
        if(_data.op.code.toString() =="Y")
        {
            if(_data.datalist.length>0)
            {
                $scope.szzsObj.zs = parseFloat(_data.datalist[0].close.toString()).toFixed(2);
                var zd = parseFloat(_data.datalist[0].netchange.toString());
                if(zd > 0)
                {
                    $scope.szzsObj.zd = "+" + zd.toFixed(2);
                    $scope.szzsObj.status = "1";//1:红，2：绿，3：白
                    $scope.szzsObj.bz = "↑";
                }
                else
                {
                    $scope.szzsObj.zd = zd.toFixed(2);
                    if(zd<0)
                    {
                        $scope.szzsObj.status = "2";
                        $scope.szzsObj.bz = "↓";
                    }
                    else
                    {
                        $scope.szzsObj.status = "3";
                        $scope.szzsObj.bz = "";
                    }
                }
                var zdf = parseFloat(_data.datalist[0].netchangeratio.toString());
                if(zdf > 0)
                {
                    $scope.szzsObj.zdf = "+" + zdf.toFixed(2)+ "%";
                }
                else
                {
                    $scope.szzsObj.zdf = zdf.toFixed(2)+ "%";
                }

                $scope.szczObj.zs = parseFloat(_data.datalist[1].close.toString()).toFixed(2);
                var zd = parseFloat(_data.datalist[1].netchange.toString());
                if(zd > 0)
                {
                    $scope.szczObj.zd = "+" + zd.toFixed(2);
                    $scope.szczObj.status = "1";//1:红，2：绿，3：白
                    $scope.szczObj.bz = "↑";
                }
                else
                {
                    $scope.szczObj.zd = zd.toFixed(2);
                    if(zd<0)
                    {
                        $scope.szczObj.status = "2";
                        $scope.szczObj.bz = "↓";
                    }
                    else
                    {
                        $scope.szczObj.status = "3";
                        $scope.szczObj.bz = "";
                    }
                }
                var zdf = parseFloat(_data.datalist[1].netchangeratio.toString());
                if(zdf > 0)
                {
                    $scope.szczObj.zdf = "+" + zdf.toFixed(2)+ "%";
                }
                else
                {
                    $scope.szczObj.zdf = zdf.toFixed(2)+ "%";
                }

                $scope.cybzObj.zs = parseFloat(_data.datalist[2].close.toString()).toFixed(2);
                var zd = parseFloat(_data.datalist[2].netchange.toString());
                if (zd > 0) {
                    $scope.cybzObj.zd = "+" + zd.toFixed(2);
                    $scope.cybzObj.status = "1";//1:红，2：绿，3：白
                    $scope.cybzObj.bz = "↑";
                }
                else {
                    $scope.cybzObj.zd = zd.toFixed(2);
                    if (zd < 0) {
                        $scope.cybzObj.status = "2";
                        $scope.cybzObj.bz = "↓";
                    }
                    else {
                        $scope.cybzObj.status = "3";
                        $scope.cybzObj.bz = "";
                    }
                }

                var zdf = parseFloat(_data.datalist[2].netchangeratio.toString());
                if (zdf > 0) {
                    $scope.cybzObj.zdf = "+" + zdf.toFixed(2) + "%";
                }
                else {
                    $scope.cybzObj.zdf = zdf.toFixed(2) + "%";
                }
            }
        }
    }

    //热门行业
    $scope.tradeRankingCallBack = function(_data)
    {
        console.log("热门行业", _data);
        $scope.rmhyList = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.hycode = arr[i].hycode;
                obj.hyname = arr[i].hyname;
                obj.hyzdvalue = parseFloat(arr[i].hyzd.toString());
                if (obj.hyzdvalue > 0) {
                    obj.hyzd = "+" + obj.hyzdvalue.toFixed(2);
                    obj.status = "1";//1:红，2：绿，3：白
                    obj.bz = "↑";
                }
                else {
                    obj.hyzd = obj.hyzdvalue.toFixed(2);
                    if (obj.hyzdvalue < 0) {
                        obj.status = "2";
                        obj.bz = "↓";
                    }
                    else {
                        obj.status = "3";
                        obj.bz = "";
                    }
                }
                obj.exchange = arr[i].exchange.toString();
                obj.symbol = arr[i].symbol.toString();
                obj.zxj = parseFloat(arr[i].price.toString()).toFixed(2);
                obj.zdfvalue = parseFloat(arr[i].zdf.toString());
                if (obj.zdfvalue > 0) {
                    obj.zdf = "+" + obj.zdfvalue.toFixed(2);
                }
                else
                {
                    obj.zdf = obj.zdfvalue.toFixed(2);
                }
                $scope.rmhyList.push(obj);
            }
        }
    }

    $scope.zfbdfbstocklistCallBack = function(_data)
    {
        //console.log("涨幅榜", _data);
        $scope.zfbstocklist = [];
        $scope.dfbstocklist = []
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.risedata;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.gpdm = arr[i].stockcode;
                obj.zqjc = arr[i].stockname;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zd = parseFloat(parseFloat(arr[i].netchange.toString()).toFixed(2));
                obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                $scope.zfbstocklist.push(obj);
            }

            var arr2 = _data.downdata;
            for(var i = 0;i<arr2.length;i++)
            {
                var obj = {};
                obj.gpdm = arr2[i].stockcode;
                obj.zqjc = arr2[i].stockname;
                obj.exchange = arr2[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr2[i].price.toString());
                obj.status = arr2[i].stockstatus.toString();
                //console.log("状态：" + arr2[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zd = parseFloat(parseFloat(arr2[i].netchange.toString()).toFixed(2));
                obj.zdf = parseFloat(parseFloat(arr2[i].netchangeratio.toString()).toFixed(2));
                $scope.dfbstocklist.push(obj);
            }
        }


    }


    $scope.getSSHQ = function()
    {
        //上证
        console.log("getss");
        var message = {};
        message['code'] = "sh000001,sz399001,sz399006";
        ajaxService.sendMessage('hq.getindexhqaction', message, $scope.szCallBack);


        //热门行业
        var message = {};
        message["stockCode"] = "A";
        message["marketCode"] = "Industry_";
        ajaxService.sendMessage("hq.getIndexRankList",message, $scope.tradeRankingCallBack);

        //涨幅榜//跌幅榜
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 10;
        message["type"] = "risedown";
        ajaxService.sendMessage("hq.getranklist",message, $scope.zfbdfbstocklistCallBack);

    }

    //自选股
    $scope.getzxglist =function()
    {
        //console.log("自选股列表：", $scope.userObj.f_id);
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        message["ordeCol"] = "";
        message["ordeBy"] = "";

        ajaxService.sendMessage("hq.getzxghqaction",message,function(_data)
        {
            //console.log("自选股列表：" + _data);
            $scope.cookiezxgList = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.data;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj2 = {};
                    obj2.tc =  arr[i].exchange.toString().toUpperCase() + arr[i].symbol;
                    $scope.cookiezxgList.push(obj2);
                }
            }
            //$cookieStore.put('cookiezxgList', $scope.cookiezxgList);
            var localStorage = window.localStorage;
            localStorage.setItem("cookiezxgList", JSON.stringify($scope.cookiezxgList));
        })
    }


    $scope.init = function()
    {
        $scope.userObj = {};
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        //$scope.userObj.f_id = getParameter("userid");//获取用户id
        //$scope.userObj.f_id = "3";

        //获取行情
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);

        $scope.getzxglist();//存cookie
    }

     $scope.init();

    //$scope.glzhClick = function ()
    //{
    //    //console.log("543254", $scope.tabOneShow, $scope.tabTwoShow, $scope.tabThreeShow, $scope.tabFourShow);
    //    //$scope.tabOneShow = false;
    //    //$scope.tabTwoShow = false;
    //    //$scope.tabThreeShow = true;
    //    //$scope.tabFourShow = false;
    //
    //    $scope.$parent.tabOneShow = false;
    //    $scope.$parent.tabTwoShow = false;
    //    $scope.$parent.tabThreeShow = true;
    //    $scope.$parent.tabFourShow = false;
    //}

    //上证指数
    $scope.szzsClick = function()
    {
        $scope.ggfhParent = "";
        $scope.myhomeClearInterval();
        var obj = {};
        obj.stockcode = "000001";
        obj.stockname = encodeURIComponent("上证指数");
        obj.exchange = "sh";
        obj.back = "hqbase";
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        $scope.indexbaseShow = true;
        $scope.homebaseShow = false;
    }

    //深证成指
    $scope.szczClick = function()
    {
        $scope.ggfhParent = "";
        $scope.myhomeClearInterval();
        var obj = {};
        obj.stockcode = "399001";
        obj.stockname = encodeURIComponent("深证成指");
        obj.exchange = "sz";

        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.indexbaseShow = true;
        $scope.homebaseShow = false;
    }

    //创业板指
    $scope.cybzClick = function()
    {
        $scope.ggfhParent = "";
        $scope.myhomeClearInterval();
        var obj = {};
        obj.stockcode = "399006";
        obj.stockname = encodeURIComponent("创业板指");
        obj.exchange = "sz";
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.indexbaseShow = true;
        $scope.homebaseShow = false;
    }

    //个股
    $scope.ggClick = function(_obj, _str)
    {
        //$scope.ggfhParent = _str;
        //$scope.myhomeClearInterval();
        ////_obj.xzzt = "0";
        //var obj = {};
        //obj.stockcode = _obj.gpdm;
        //obj.stockname = encodeURIComponent(_obj.zqjc);
        //obj.exchange = _obj.exchange.toString();
        //$cookieStore.put('stockInfo', obj);

        $scope.ggfhParent = _str;
        $scope.myhomeClearInterval();
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = "0";
        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));


        $scope.hqbaseoneStockHQBaseShow = true;
        $scope.homebaseShow = false;
        $scope.zfbmorestockListDivShow = false;
        $scope.dfbmorestockListDivShow = false;
        $scope.hynstockListDivShow = false;
        gotoUp();

    }

    //热门行业显示隐藏
    $scope.rmhyShowClcik = function()
    {
        $scope.rmhyDivShow = !$scope.rmhyDivShow;
    }
    //涨幅榜显示隐藏
    $scope.zfbShowClcik = function()
    {
        $scope.zfbDivShow = !$scope.zfbDivShow;
    }
    //跌幅榜显示隐藏
    $scope.dfbShowClcik = function()
    {
        $scope.dfbDivShow = !$scope.dfbDivShow;
    }

    //大盘指数返回
    $scope.indexbaseBackto = function()
    {
        if($scope.ggfhParent == "searchlist")
        {
            $scope.indexbaseShow = false;
            $scope.ggssDivShow = true;
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if($scope.allSearchStockListArray[i].xzzt == "0")
                {
                    $scope.allSearchStockListArray[i].xzzt = "1";
                    break;
                }
            }
            $scope.dqxzstock = null;
        }
        else
        {
            $scope.indexbaseShow = false;
            $scope.homebaseShow = true;

            $scope.getSSHQ();
            $scope.myhomeClearInterval();
            $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
        }
        $scope.ggfhParent = "";

    }

    //个股返回
    $scope.oneStockHQBaseBackto = function()
    {
        if($scope.ggfhParent == "home")
        {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.homebaseShow = true;
        }
        else if($scope.ggfhParent == "morezfb")
        {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.zfbmorestockListDivShow = true;
        }
        else if($scope.ggfhParent == "moredfb")
        {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.dfbmorestockListDivShow = true;
        }
        else if($scope.ggfhParent == "hy")
        {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.hynstockListDivShow = true;
        }
        else if($scope.ggfhParent == "searchlist")
        {
            $scope.hqbaseoneStockHQBaseShow = false;
            $scope.ggssDivShow = true;
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if($scope.allSearchStockListArray[i].xzzt == "0")
                {
                    $scope.allSearchStockListArray[i].xzzt = "1";
                    break;
                }
            }
            $scope.dqxzstock = null;
        }
        if($scope.ggfhParent != "searchlist")
        {
            $scope.getSSHQ();
            $scope.myhomeClearInterval();
            $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
        }
        $scope.ggfhParent = "";
    }

    $scope.sortStock = function (obj)
    {
        //if($scope.orderobj == "")//初始化，未排序
        //{
        //    $scope.orderobj = obj;
        //    $scope.order = "2";//降序
        //}
        //else if($scope.orderobj == "+index")//回复原数据排序
        //{
        //    $scope.orderobj = obj;
        //    $scope.order = "2";//降序
        //}
        //else
        //{
            var str = obj.substr(0,1);//取出符号 ：+ ，-
            obj = obj.substr(1, obj.length-1);
            if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
            {
                if($scope.order == "2")
                {
                    $scope.orderobj = "+" + obj;
                    $scope.order = "1";//升序
                }
                else
                {
                    $scope.orderobj = "-" + obj;
                    $scope.order = "2";//降序
                }
            }
            else//不同排序字段
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        //}

    }

    //涨幅榜更多
    $scope.zfbMore = function()
    {
        $scope.myhomeClearInterval();
        $scope.zfbmorestockListDivShow = true;
        $scope.homebaseShow = false;
        gotoUp();

        $scope.zfbMoreRefresh();
    }

    $scope.zfbMoreRefresh = function()
    {
        $scope.zfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

        //涨幅榜//跌幅榜
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 100;
        message["type"] = "rise";
        ajaxService.sendMessage("hq.getranklist",message, $scope.zfbmorelistCallBack);
    }

    $scope.zfbmorelistCallBack = function(_data)
    {
        //console.log("涨幅榜", _data);
        $scope.zfbmorelistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.risedata;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.gpdm = arr[i].stockcode;
                obj.zqjc = arr[i].stockname;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                $scope.zfbmorelistArray.push(obj);
            }
        }
    }

    //涨幅榜返回
    $scope.zfbmoreBackto = function()
    {
        $scope.zfbmorestockListDivShow = false;
        $scope.homebaseShow = true;
        $scope.zfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
    }

    //跌幅榜更多
    $scope.dfbMore = function()
    {
        $scope.myhomeClearInterval();
        $scope.dfbmorestockListDivShow = true;
        $scope.homebaseShow = false;
        gotoUp();
        $scope.dfbMoreRefresh();

    }

    $scope.dfbMoreRefresh = function()
    {
        $scope.dfbmorelistArray = [];

        $scope.order = "1";//0-不排序 1-升序 2-降序
        $scope.orderobj = "+zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

        //涨幅榜//跌幅榜
        var message = {};
        message["rankType"] = "riseRatioList";
        message["rankScope"] = "all";
        message["num"] = 100;
        message["type"] = "down";
        ajaxService.sendMessage("hq.getranklist",message, $scope.dfbmorelistCallBack);
    }

    $scope.dfbmorelistCallBack = function(_data)
    {
        //console.log("跌幅榜", _data);
        $scope.dfbmorelistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.downdata;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.gpdm = arr[i].stockcode;
                obj.zqjc = arr[i].stockname;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].netchangeratio.toString()).toFixed(2));
                $scope.dfbmorelistArray.push(obj);
            }
        }
    }

    //跌幅榜返回
    $scope.dfbmoreBackto = function()
    {
        $scope.dfbmorestockListDivShow = false;
        $scope.homebaseShow = true;
        $scope.dfbmorelistArray = [];

        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
    }

    //行业更多
    $scope.hymoreDivShowClick = function()
    {
        $scope.myhomeClearInterval();
        $scope.hymoreDivShow = true;
        $scope.homebaseShow = false;
        $scope.hymorelistArr = [];
        $scope.gnmorelistArr = []
        $scope.hychangeTab("1");
    }

    $scope.hychangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.hytabOneShow = true;
            $scope.hytabTwoShow = false;

            //行业
            var message = {};
            message["stockCode"] = "A";
            message["marketCode"] = "Industry_";
            message["num"] = 10000;
            message["type"] = "hy";
            ajaxService.sendMessage("hq.getIndexRankList",message, $scope.hymoreCallBack);
        }
        else
        {
            $scope.hytabOneShow = false;
            $scope.hytabTwoShow = true;

            //概念
            var message = {};
            message["stockCode"] = "A";
            message["marketCode"] = "Concept_";
            message["num"] = 10000;
            message["type"] = "gn";
            ajaxService.sendMessage("hq.getIndexRankList",message, $scope.gnmoreCallBack);
        }
    }

    $scope.hymoreCallBack = function(_data)
    {
        //console.log("热门行业", _data);
        $scope.hymorelistArr = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.hycode = arr[i].hycode;
                obj.hyname = arr[i].hyname;
                obj.exchange = arr[i].exchange.toString();
                obj.symbol = arr[i].symbol.toString();
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].zdf.toString()).toFixed(2));

                $scope.hymorelistArr.push(obj);
            }
        }
    }

    $scope.gnmoreCallBack = function(_data)
    {
        $scope.gnmorelistArr = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.index = i;
                obj.hycode = arr[i].hycode;
                obj.hyname = arr[i].hyname;
                obj.exchange = arr[i].exchange.toString();
                obj.symbol = arr[i].symbol.toString();
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(parseFloat(arr[i].zdf.toString()).toFixed(2));

                $scope.gnmorelistArr.push(obj);
            }
        }
    }

    //进入某个行业，显示行业下股票列表
    $scope.hymoreonehyClick = function(_obj)
    {
        $scope.hymoreDivShow = false;
        $scope.hynstockListDivShow = true;
        $scope.hynstockList = "two";//行业更多进入
        $scope.hylistArray = [];
        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.dqhyObj = {};
        $scope.dqhyObj.hycode = _obj.hycode
        $scope.dqhyObj.hyname = _obj.hyname;

        //行业股票列表
        var message = {};
        message["code"] = $scope.dqhyObj.hycode;
        message["type"] = "industry";
        ajaxService.sendMessage("hq.getIndustryAStocksAction",message, $scope.getIndustryAStocksActionCallBack);
    }

    //进入某个概念，显示概念下股票列表
    $scope.hymoreonegnClick = function(_obj)
    {
        $scope.hymoreDivShow = false;
        $scope.hynstockListDivShow = true;
        $scope.hynstockList = "two";//行业更多进入
        $scope.hylistArray = [];
        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.dqhyObj = {};
        $scope.dqhyObj.hycode = _obj.hycode
        $scope.dqhyObj.hyname = _obj.hyname;

        //行业股票列表
        var message = {};
        message["code"] = $scope.dqhyObj.hycode;
        message["type"] = "concept";
        ajaxService.sendMessage("hq.getIndustryAStocksAction",message, $scope.getIndustryAStocksActionCallBack);
    }

    //行业返回
    $scope.hymoreDivbackto = function()
    {
        $scope.hymoreDivShow = false;
        $scope.homebaseShow = true;
        $scope.hymorelistArr = [];
        $scope.gnmorelistArr = []
        $scope.hytabOneShow = false;
        $scope.hytabTwoShow = false;
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);

    }

    //进入某个行业，显示行业下股票列表
    $scope.onehyClick = function(_obj)
    {
        $scope.myhomeClearInterval();
        $scope.homebaseShow = false;
        $scope.hynstockListDivShow = true;
        $scope.hynstockList = "one";
        $scope.hylistArray = [];
        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.dqhyObj = {};
        $scope.dqhyObj.hycode = _obj.hycode;
        $scope.dqhyObj.hyname = _obj.hyname;
        //行业股票列表
        var message = {};
        message["code"] = $scope.dqhyObj.hycode;
        message["type"] = "industry";
        ajaxService.sendMessage("hq.getIndustryAStocksAction",message, $scope.getIndustryAStocksActionCallBack);
    }

    $scope.getIndustryAStocksActionCallBack = function(_data)
    {
        //console.log("行业下股票：" + _data.toString());
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        //for(var k in _data.data)
        //{
        //    console.log("key: " + k + "；value: " + _data.data[k]);
        //}
        $scope.hylistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.data;
            for(var i = 0;i<arr.length;i++)
            {
                //if(i == 0 || i==1)
                //for(var k in arr[i])
                //{
                //    console.log("key: " + k + "；value: " + arr[i][k]);
                //}
                var obj = {};
                obj.index = i;
                obj.gpdm = arr[i].symbol;
                obj.zqjc = arr[i].name;
                obj.exchange = arr[i].exchange.toString();
                obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                obj.zxj = parseFloat(arr[i].price.toString());
                obj.status = arr[i].stockstatus.toString();
                //console.log("状态：" + obj.zqjc + "  " + arr[i].stockstatus.toString())
                obj.xzzt = "1";//选中状态，样式更改
                obj.zdf = parseFloat(arr[i].zdf.toString());
                $scope.hylistArray.push(obj);
            }
        }
    }

    $scope.hynstockListrefresh = function()
    {
        $scope.hylistArray = [];
        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        //行业股票列表
        var message = {};
        message["code"] = $scope.dqhyObj.hycode;
        message["type"] = "industry";
        ajaxService.sendMessage("hq.getIndustryAStocksAction",message, $scope.getIndustryAStocksActionCallBack);
    }


    //行业股票列表返回
    $scope.hynstockListBackto = function()
    {
        $scope.hylistArray = [];
        $scope.order = "2";//0-不排序 1-升序 2-降序
        $scope.orderobj = "-zdf";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序
        $scope.dqhyObj = {};
        if($scope.hynstockList == "one")
        {
            $scope.homebaseShow = true;
            $scope.hynstockListDivShow = false;
            $scope.getSSHQ();
            $scope.myhomeClearInterval();
            $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
        }
        else
        {
            $scope.hymoreDivShow = true;
            $scope.hynstockListDivShow = false;
        }
    }

    //进入行情返回主页面
    $scope.jrhqBackto = function()
    {
        //window.location.href = getParameter("backurl");
        //window.location.href = "back";
        closeNewBrowser();
    }

    //股票搜索界面
    $scope.gpssClick = function()
    {
        $scope.myhomeClearInterval();
        $scope.homebaseShow = false;
        $scope.ggssDivShow = true;
    }

    $scope.ggssBackto = function()
    {
        $scope.homebaseShow = true;
        $scope.ggssDivShow = false;
        $scope.getSSHQ();
        $scope.myhomeClearInterval();
        $scope.sshqintervalId = setInterval($scope.getSSHQ, $scope.sshqintervalDuration);
    }

    //股票搜索框改变
    $scope.searchinputChange = function()
    {
        if($scope.searchStockValue != "")
        {
            $scope.checkContent();
        }
        else
        {
            $scope.allSearchStockListArray = [];
        }
    }

    //判断并显示搜索股票
    $scope.checkContent = function()
    {
        //匹配
        //ajaxService.searchStock($scope.searchStockValue, $scope.searchStockCallBack);
        var message = {};
        message['key'] = $scope.searchStockValue.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        //message['stockcode'] = $scope.searchStockValue;
        //console.log($scope.searchStockValue)
        //ajaxService.sendMessage('model.getStockcodeListAction', message, $scope.searchStockCallBack);
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.searchStockCallBack);

    }

    //搜索股票返回
    $scope.searchStockCallBack = function(_data)
    {
        //console.log("搜索");
        console.log(_data);
        $scope.allSearchStockListArray = [];
        if($scope.searchStockValue == "")
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.searchStockValue.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数，5：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        //var p = /\s+/g;
                        //var namestr = element[i]['name'].toString();
                        //namestr = namestr.replace(p, "");

                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        //obj.dqj = (parseFloat(element[i]['now'].toString())).toFixed(2);//当前价
                        //obj.zdf = (parseFloat(element[i]['zdf'].toString())).toFixed(2);//涨跌幅
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == 0 || obj.asset == 4 || obj.asset == 5) {
                            arr.push(obj);
                        }
                    }
                    $scope.allSearchStockListArray = arr;
                }
                else {
                    $scope.allSearchStockListArray = [];
                    return;
                }
            }
        }
        else
        {
            $scope.allSearchStockListArray = [];
            return;
        }

    }

    //点击查看行情
    $scope.gplistItmeClick = function(_obj)
    {
        $scope.ggfhParent = "searchlist";//返回用
        _obj.xzzt = "0";
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = _obj.asset;

        //console.log("obj.asset",obj.asset);
        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.dqxzstock = obj;
        $scope.myhomeClearInterval();
        $scope.ggssDivShow = false;

        if(_obj.asset == "0" || _obj.asset == "5")//股票
        {
            $scope.hqbaseoneStockHQBaseShow = true;
        }
        else
        {
            $scope.indexbaseShow = true;
        }
        gotoUp();
    }
}



