
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function newfpBaseCtrl($scope, ajaxService, $cookieStore) {

    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.userName = "";
    $scope.lcsCount = 0;
    //$scope.repeatvalue = false;
    $scope.backtitle = "";

    $scope.lcslistArray = [];//理财师
    $scope.mainShow = true;//主界面

    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.lcslistIndex = 0;
    $scope.gtbmArray = [];//报名列表
    //$scope.jiepanShow = false;

    //setIn = function()
    //{
    //    $scope.myActiveSlide = 0;
    //    $scope.repeatvalue = true;
    //}

    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        console.log("理财师",_data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.lcsapplyinfo.isexist.toString() == "true")
            {
                var lcsInformation = {};
                lcsInformation.lcshearurl = _data.lcsapplyinfo.user.user.f_head;
                //if(_data.lcsapplyinfo.user.user.f_nickname.length >3)
                //{
                //    lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname.toString().substr(0,3);
                //}
                //else
                //{
                lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname;
                if(lcsInformation.lcsname.length>3)
                {
                    lcsInformation.lcsname = lcsInformation.lcsname.substr(0,3);
                }

                if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city == undefined)
                {
                    lcsInformation.dq = "";
                }
                else if(_data.lcsapplyinfo.user.user.f_province != undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_province + _data.lcsapplyinfo.user.user.f_city;
                }
                else if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_city;
                }
                else
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_province;
                }
                //}
                lcsInformation.lcsid = _data.lcsapplyinfo.userid;
                lcsInformation.lcslszj = _data.lcsapplyinfo.lszj;
                lcsInformation.lcstzsc = _data.lcsapplyinfo.tzsc;
                lcsInformation.lcstzln = _data.lcsapplyinfo.tzln;
                if(lcsInformation.lcstzln.length>30)
                {
                    lcsInformation.lcstzln = lcsInformation.lcstzln.substr(0,30);
                }
                var sclystr = _data.lcsapplyinfo.scly;
                //console.log("sclystr",sclystr);
                var ind = sclystr.indexOf("|",0);
                if(ind == -1)//无|
                {
                    lcsInformation.lcsscly = sclystr;
                }
                else//有|
                {
                    var sclyarr = sclystr.split("|");
                    var str2 = "";
                    for(var i = 0;i<sclyarr.length;i++)
                    {
                        if(str2 == "")
                        {
                            if(sclyarr[i]!="")
                            {
                                str2 = sclyarr[i];
                            }

                        }
                        else
                        {
                            if(sclyarr[i]!="")
                            {
                                str2 = str2 + "," + sclyarr[i];
                            }
                        }
                    }
                    lcsInformation.lcsscly = str2;
                }

                var us = _data.lcsapplyinfo.user.user;
                if(us.f_weixinhao != undefined && us.f_weixinhao != null)
                {
                    lcsInformation.wxh = us.f_weixinhao;
                }
                else
                {
                    lcsInformation.wxh = "";
                }
                if(us.f_qq != undefined && us.f_qq != null)
                {
                    lcsInformation.qq = us.f_qq;
                }
                else
                {
                    lcsInformation.qq = "";
                }
                $scope.lcslistArray[$scope.lcslistIndex].lcsInformation = lcsInformation;


                $scope.lcslistIndex +=1;
                //console.log("有", $scope.lcslistIndex, $scope.lcslistArray.length);
                if($scope.lcslistIndex<$scope.lcslistArray.length)
                {
                    $scope.getoneInfo();
                }
                //if($scope.lcslistIndex >0)
                //{
                //    console.log("长度",$scope.lcslistArray.length);
                //    setIn();
                //}
            }
        }
    }

    $scope.getoneInfo = function()
    {
        //console.log(11111);
        var message = {};
        message['userid'] = $scope.lcslistArray[$scope.lcslistIndex].id;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, $scope.p_getlcsapplyinfoCallBack);
    }


    //获取账户列表
    $scope.getNewLcsActionCallBack = function(_data)
    {
        console.log("获取理财师列表", _data);
        $scope.lcslistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            $scope.lcsCount = _data.count;
            var arr = _data.newlcs;
            for (var i = 0;i < arr.length; i++)
            {
                var obj = {};
                obj.id = arr[i];
                $scope.lcslistArray.push(obj);
            }

            //var obj = {};
            //obj.id = "79";
            //$scope.lcslistArray.push(obj);
            //
            //var obj = {};
            //obj.id = "7";
            //$scope.lcslistArray.push(obj);
            //
            //var obj = {};
            //obj.id = "81";
            //$scope.lcslistArray.push(obj);
        }

        if($scope.lcslistArray.length >0)
        {
            $scope.lcslistIndex = 0;
            $scope.getoneInfo();
        }
        else
        {
            //$scope.mainShow = false;
        }
    }

    $scope.getlcslist = function()
    {
        var message = {};
        ajaxService.sendMessage("sunflower.getNewLcsAction", message, $scope.getNewLcsActionCallBack);

    }

    //跟投报名
    $scope.gtbm = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;//getParameter('userid');
        message['page.size'] = 'max';
        message['page.no'] = 1;
        message['range'] = "lcs";
        ajaxService.sendMessage('sunflower.p_selectcanapplyproducts', message, function (data)
        {
            console.log("报名",data);
            if (data['op']['code'] == 'Y')
            {
                $scope.gtbmArray  = data['gentouproductlist'];
            }

            $scope.getlcslist();
        });
    }

    $scope.getInfo = function()
    {
        try
        {
            //$scope.userObj = $cookieStore.get('user');
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
            $scope.lcsstatus =  localStorage.getItem("lcsstatus");
            //$scope.gtbm();
            $scope.getlcslist();
        }catch (e){}
    }



    //初始相关操作界面
    $scope.newfpInit = function()
    {
        $scope.getInfo();
    }

    $scope.newfpInit();


    //理财师跟投报名
    $scope.gtbmItemClick = function(_obj)
    {
        if(_obj.user.user.f_id == $scope.userObj.f_id)
        {

            //try
            //{
            //    var str = "gt_yfb.html?productid=" + _obj.id;
            //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
            //}
            //catch (e){
                setbackList(window.location.href);
                window.location = "gt_yfb.html?productid=" + _obj.id;
            //}
        }
        else
        {
            //try
            //{
            //    var str = "gtapply.html?productid=" + _obj.id + "&&bgtuserid=" + _obj.user.user.f_id;
            //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
            //}
            //catch (e){
                setbackList(window.location.href);
                window.location = "gtapply.html?productid=" + _obj.id + "&&bgtuserid=" + _obj.user.user.f_id;
            //}
        }
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview");
    }

    //解盘
    $scope.jpClick = function()
    {
        //$scope.mainShow = false;
        //$scope.jiepanShow = true;
        setbackList(window.location.href);
        $scope.fbstatus = false;
        if($scope.lcsstatus == "2")
        {
            $scope.fbstatus = true;
        }
        else
        {
            $scope.fbstatus = false;
        }
        window.location.href="jiepan_relative.html?title=" + encodeURI("解盘") +"&abletofb=" + $scope.fbstatus + "&userid=" + $scope.userObj.f_id;
    }


    $scope.newfpBackto = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("lcs_childIndex", "0");
        //window.location = getbackList();
        closeNewBrowser();
    }

}



