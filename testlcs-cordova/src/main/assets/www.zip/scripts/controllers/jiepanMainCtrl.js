/**
 * Created by wangtao on 2015/8/18 0018.
 */
Date.prototype.format = function (format) {
    var o = {
        "M+": this.getMonth() + 1, //month
        "d+": this.getDate(),    //day
        "h+": this.getHours(),   //hour
        "m+": this.getMinutes(), //minute
        "s+": this.getSeconds(), //second
        "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
        "S": this.getMilliseconds() //millisecond
    }
    if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
        (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)if (new RegExp("(" + k + ")").test(format))
        format = format.replace(RegExp.$1,
            RegExp.$1.length == 1 ? o[k] :
                ("00" + o[k]).substr(("" + o[k]).length));
    return format;
}

function jiepanMainCtrl($scope, jpajaxService, tabService) {
    //console.log("122132fafafd",$scope.userObj);
    $scope.jpbacktitle = "";
    $scope.titlestr = "";
    $scope.opentype = "";
    try{
        if($scope.basetabFiveShow == true)
        {
            $scope.jpbacktitle = "发现";
            $scope.titlestr = "解盘";
        }
        else if($scope.basetabOneShow == true)
        {
            $scope.jpbacktitle = "关注";
            $scope.titlestr = "今日观点";
        }
    }
    catch (e){}



    //if(!$scope.userObj)
    //{
    //    var localStorage = window.localStorage;
    //    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    //    if($scope.userObj)
    //    {
    //        $scope.jp_userid = $scope.userObj.f_id;
    //    }
    //}
    //else
    //{
    //    $scope.jp_userid = $scope.userObj.f_id;
    //}
    //console.log("3",$scope.jp_userid);
    //console.log("5",$scope.jp_fbuser);
    //$scope.abletofb = false;//是否能发布，默认不能发布
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    $scope.jptitle = "";//解盘
    //console.log(1,$scope.abletofb)
    $scope.jpneedback = false;//解盘是否需要返回
    //console.log($scope.abletofb == null,$scope.abletofb == undefined, $scope.ablet);
    if($scope.abletofb == null || $scope.abletofb == undefined ||  $scope.abletofb == "")
    {
        $scope.abletofb = tabService.getParam("abletofb");
        $scope.jpneedback = true;
        //console.log(22222221,$scope.abletofb);
    }
    $scope.isApp = true; // 是否在APP 中使用，控制头显示标记
    $scope.tabs = tabService.tabs;
    //tabService.init();
    $scope.changeTabFunction = function (id) {

        $scope.currentTab = tabService.changeTabFunction(id);
        $scope.showTab = $scope.currentTab['id'];
        var localStorage = window.localStorage;
        localStorage.setItem("jpbaseChildIndex", id);
        //$scope.currentTab = tabService.changeTabFunction(id);
    }
    var tabId = !!$scope.jp_type ? $scope.jp_type : tabService.getParam("$");
    $scope.jptitle = decodeURI(tabService.getParam('title'));

    //console.log("tabId", tabId);
    if (!tabId) {
        var localStorage = window.localStorage;
        tabId = localStorage.getItem("jpbaseChildIndex");
        if(tabId == null || tabId == undefined)
        {
            tabId = 4;
            //console.log("5454", tabindex);
        }
        //tabId = 0;
    }
    //console.log("tabId", tabId);
    $scope.changeTabFunction(tabId);
    $scope.userInfo = {};
    //console.log("jpid2", $scope.jp_userid);
    $scope.userInfo['f_id'] = !!$scope.jp_userid ? $scope.jp_userid :tabService.getParam('userid');
    $scope.userInfo['f_openid'] = !!$scope.jp_openid ? $scope.jp_openid :tabService.getParam('openid');
    jpajaxService.sendESBReq('user.UserCheck', {'User.id': $scope.userInfo['f_id']}, function (data) {
        if (data['op']['code'] == 'Y') {
            $scope.userInfo = data['user'];
        }
    });

    $scope.showselfHistory = function () {
        window.location.href = 'jiepan_relative.html?userid=' + $scope.userInfo['f_id'] + '&fbuser=' + $scope.userInfo['f_id'] + "&title=" + encodeURI("历史解盘") + "&backtitle=" + encodeURI("解盘") + "&abletofb=false"+  '&rmd=' + new Date().getTime();
    }

    $scope.fb = function () {
        //window.location.href = 'jiepan-fabu.html?userid=' + $scope.userInfo['f_id'] + '&fbuser=' + $scope.userInfo['f_id'] + '&rmd=' + new Date().getTime();
        window.location = 'jiepan-fabu-gd.html?userid='+$scope.userInfo['f_id']+'&rmd='+new Date().getTime();
    }

    //解盘返回
    $scope.jpbackto = function()
    {
        //console.log($scope.abletofb);
        if($scope.backtitle == '我' || $scope.opentype == 'newwebview')//理财师自己的解盘进入
        {
            //window.location.href = "uufpBase.html?baseindex=4";//返回“我”
            closejp();
        }
        else//进入理财师界面看解盘
        {
            //window.location.href = "peopleSpaceBase.html";//返回他人空间
            javascript:history.go(-1);
        }
    }
    closejp = function()
    {
        //alert("关闭解盘");
        closeNewBrowser();
    }

    //$scope.setTitle = function(_str)
    //{
    //    $scope.jptitle = _str;
    //}

    $scope.setjpbacktitle = function(_str)
    {
        //console.log("解盘文字", _str);
        $scope.jpbacktitle = _str;
    }

    $scope.jpbacktoP = function()
    {
        $scope.backtolcsList();

    }
}

function jiepanListCtrl($scope, jpajaxService, tabService) {

    //tabService.init();
    $scope.jpList = [];
    $scope.jrgdList = [];
    $scope.jrgdPageNo = 1;
    var numb = document.body.offsetWidth * 0.83 * 8 * 6 / 100;
    $scope.textMaxLength = parseInt(numb);
    var numb2 = (document.body.offsetWidth * 0.83 - 100) * 8 / 100;
    $scope.titletextMaxLength = parseInt(numb2);
    // 100PX宽度一行可以显示8个汉字，一共6行
    var pageSize = 20;
    $scope.hqJPId = -1;
    $scope.lastTab = 0;
    $scope.showNoMore = false;
    $scope.isBusy = true;

    $scope.openUrl = function (directurl) {
        if (directurl.indexOf("http:") < 0) {
            directurl = "http://" + directurl;
        }
        //window.location.href = directurl;
        var str = encodeURI(directurl);
        var ref = cordova.InAppBrowser.open(str, "_blank", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");

        //if($scope.jpneedback == false)
        //{
        //    //window.location.href = "urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl) + "&backtitle=" + encodeURI("解盘");
        //    //var str = "urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl) + "&backtitle=" + encodeURI("解盘");
        //    //var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    //xinyuNewBrowser("urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl) + "&backtitle=" + encodeURI("解盘"));
        //}
        //else
        //{
        //    //window.location.href = "urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl);
        //    var str = "urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl);
        //    var ref = cordova.InAppBrowser.open(str, "_blank", "location=yes,toolbar=yes,toolbarposition=top,closebuttoncaption=返回,ediaPlaybackRequiresUserAction=yes,allowInlineMediaPlayback=yes");
        //    //var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    //xinyuNewBrowser("urlLink.html?title="+encodeURI('原文链接')+"&url="+encodeURI(directurl));
        //}
    };

    $scope.commontShowID = '';

    $scope.showPl = function (jp) {
        jp['showPl'] = !jp['showPl'];
        if (!jp['showPl']) {
            jp['showCommentInput'] = false;
            jp['jpplshow'] = jp['showCommentInput'];
        }
        else {
            jp['showHQ'] = false;
        }
    }

    //$scope.commontContent = '';
    $scope.showCommontInput = function (jp) {
        //alert(jp);
        jp['showCommentInput'] = !jp['showCommentInput'];
        jp['jpplshow'] = jp['showCommentInput'];
        //var key = jp['f_id'] + '_input';
        //setTimeout(function () {
        //    document.getElementById(key).focus();
        //}, 1000);
        if (jp['jpplshow']) {
            $scope.getCommont(jp);
        }
    }

    $scope.commont = function (jp) {
        var message = {};
        var commontCount = !jp['f_commontcount'] ? 0 : Number(jp['f_commontcount'].toString());
        message['subjectid'] = jp['f_id'];
        message['subjecttype'] = "jiepan";
        message['fromUser'] = $scope.userInfo['f_id'];
        message['contenttype'] = 'text';
        var content = {};
        content['commont'] = jp['commontContent'];
        content['userid'] = $scope.userInfo['f_id'];
        content['head'] = $scope.userInfo['f_head'];
        content['name'] = $scope.userInfo['f_nickname'];
        message['content'] = JSON.stringify(content);
        if (!$scope.userInfo['f_nickname']) {
            //alert('请先登录再评论');
            myAlert("请先登录再评论");
            return;
        }

        if (!jp['commontContent'] || jp['commontContent'].length <= 0) {
            myAlert('请输入评论内容');
            return;
        }
        jpajaxService.sendESBReq('user.recordMessage', message, function (data) {
            if (data['op']['code'] == 'Y') {
                jp['f_commontcount'] = commontCount + 1;
                jp['commontContent'] = '';
                jp['showCommentInput'] = false;
                if (jp['commontlist']) {
                    var time = new Date();
                    content['t'] = time.format('yyyy-MM-dd hh:mm');
                    //jp['commontlist'].unshift(content);
                    jp['commontlist'].push(content);
                }
            }
        });

    };
    $scope.getCommont = function (jp) {
        var message = {};
        jp['showHQ'] = false;
        message['subjectid'] = jp['f_id'];
        message['subjecttype'] = "jiepan";
        message['userid'] = $scope.userInfo['f_id'];
        message['contenttype'] = 'text';
        message['msgamount'] = 20;
        message['lastmsgid'] = 0;

        jp['jpplshow'] = jp['showCommentInput'];
        $scope.commontShowID = jp['f_id'];
        jpajaxService.sendESBReq('user.GetMessageRecord', message, function (data) {
            if (data['op']['code'] == 'Y') {
                jp['commontlist'] = [];
                for (var i = 0; data['msglist'] && i < data['msglist'].length; i++) {
                    var temp = data['msglist'][i];
                    var content = eval(temp['content']);
                    //console.log(content);
                    content['t'] = temp['t'].toString().substr(0, 12);
                    content['t'] = content['t'].substr(0, 4) + "-" + content['t'].substr(4, 2) + "-" + content['t'].substr(6, 2) + " " + content['t'].substr(8, 2) + ":" + content['t'].substr(10, 2);
                    jp['commontlist'].push(content);
                }
            }
        });

    }

    $scope.praise = function (jp) {
        var message = {};
        var praisecount = !jp['praisecount'] ? 0 : Number(jp['praisecount'].toString());
        var praiseSubmit = (jp['f_praise'] == 1) ? 0 : 1;
        message['JiepanPraise.jpid'] = jp['f_id'];
        message['JiepanPraise.praise'] = praiseSubmit;
        message['JiepanPraise.userid'] = $scope.userInfo['f_id'];
        message['JiepanPraise.openid'] = $scope.userInfo['f_openid'];
        jpajaxService.sendESBReq('user.AddJiepanPraise', message, function (data) {
            if (data['op']['code'] == 'Y') {
                jp['f_praise'] = message['JiepanPraise.praise'];
                if (praiseSubmit > 0) {
                    jp['praisecount'] = praisecount + 1;
                } else {
                    if (praisecount > 0) {
                        jp['praisecount'] = praisecount - 1;
                    }
                }
            }
        });
    };

    $scope.showHq = function (jp) {
        //,jp['f_code'],jp['f_exchange']
        if(jp['f_zdf'])
        {
            $scope.stockcode = jp['f_code'];
            $scope.exchange = jp['f_exchange'];
            if ($scope.currentTab['id'] >= 1) {
                return;
            }
            if ($scope.hqJPId == jp['f_id'])
            {
                jp['showHQ'] = !jp['showHQ'];
            }
            else
            {
                jp['showHQ'] = true;
                jp['showCommentInput'] = false;
                jp['jpplshow'] = jp['showCommentInput'];
            }
            if (!!jp['showHQ']) {
                jp['showCommentInput'] = false;
                jp['jpplshow'] = jp['showCommentInput'];
            }

            $scope.hqJPId = jp['f_id'];
            //console.log($scope.stockcode,jp['f_id']==$scope.hqJPId && jp['showHQ']);
        }

    }


    $scope.showrelated = function (jptype, stockcode, stockname)
    {
        window.location.href = 'jiepan_relative.html?type=' + jptype + '&stockcode=' + stockcode + '&stockname=' + encodeURI(stockname) + '&userid=' + $scope.userInfo['f_id'] + "&title=" + encodeURI(stockname) + "&backtitle=" + encodeURI("解盘") +"&abletofb=false"+ '&rmd=' + new Date().getTime();
    }

    var loadingdata = function (data)
    {
        //console.log("解盘个股",data);
        if (data['op']['code'] == 'Y')
        {
            if (data['jiepanlist'].length > 0)
            {
                for (var i = 0; i < data['jiepanlist'].length; i++)
                {
                    var tempdata = data['jiepanlist'][i];
                    tempdata['showall'] = false;
                    //tempdata['f_createtime'];
                    tempdata['showHQ'] = true;
                    if (tempdata['f_zdf']) {
                        tempdata['f_zdf'] = (Number(tempdata['f_zdf'].toString()) * 100).toFixed(2);
                    }
                    tempdata['needAllButton'] = tempdata['f_content'].length > $scope.textMaxLength;
                    $scope.jpList.push(tempdata);
                    if (i == data['jiepanlist'].length - 1) {
                        $scope.currentTab['typeLastId'] = tempdata['f_id'];
                    }
                }
                $scope.showNoMore = false;
            }
            else
            {
                $scope.showNoMore = true;
            }
        }
        else
        {
            $scope.showNoMore = true;
        }
        $scope.isBusy = false;
    };

    $scope.jrgdCallBack = function(_data)
    {
        //console.log("今日观点",_data);
        if (_data['op']['code'] == 'Y')
        {
            var arr = _data.list;
            if(arr.length >0)
            {
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.type = arr[i].type;
                    obj.headicon = arr[i].f_head;
                    obj.name = arr[i].f_nickname;
                    obj.userid = arr[i].f_userid;
                    var str = arr[i].f_cnt;
                    if(str.length>100)
                    {
                        obj.content = str.substr(0,100);
                    }
                    else
                    {
                        obj.content = str;
                    }
                    obj.timestr = arr[i].f_createtime;
                    $scope.jrgdList.push(obj);
                }
                $scope.showNoMore = false;
                $scope.jrgdPageNo = $scope.jrgdPageNo +1;
            }
            else
            {
                $scope.showNoMore = true;
            }
        }
        else
        {
            $scope.showNoMore = true;
        }
        $scope.isBusy = false;
    }

    $scope.jrgdAllCallBack = function(_data)
    {
        //console.log("今日观点",_data);
        if (_data['op']['code'] == 'Y')
        {
            var arr = _data.list;
            if(arr.length >0)
            {
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.type = arr[i].type;
                    obj.headicon = arr[i].f_head;
                    obj.name = arr[i].f_nickname;
                    obj.userid = arr[i].f_userid;
                    var str = arr[i].f_cnt;
                    if(str.length>100)
                    {
                        obj.content = str.substr(0,100);
                    }
                    else
                    {
                        obj.content = str;
                    }
                    obj.timestr = arr[i].spacetime;
                    $scope.jrgdList.push(obj);
                }
                $scope.showNoMore = false;
                $scope.jrgdPageNo = $scope.jrgdPageNo +1;
            }
            else
            {
                $scope.showNoMore = true;
            }
        }
        else
        {
            $scope.showNoMore = true;
        }
        $scope.isBusy = false;
    }

    var stockname = !!$scope.jp_stockname ? $scope.jp_stockname : tabService.getParam('stockname');
    //if (stockname) {
    //    //document.title = decodeURI(stockname);
    //    $scope.setTitle(decodeURI(stockname));
    //    //console.log("$scope.jptitle", $scope.jptitle)
    //}

    $scope.queryJp = function (clearAll)
    {
        //console.log("43243");
        $scope.isBusy = true;
        $scope.showNoMore = false;
        if (clearAll) {
            $scope.jpList = [];
        }
        var stockcode =!!$scope.jp_stockcode ? $scope.jp_stockcode : tabService.getParam('stockcode');
        var fbUser = !!$scope.jp_fbuser ? $scope.jp_fbuser : tabService.getParam('fbuser');
        //console.log("fbUser", fbUser);

        //if (!!fbUser) {
        //    //document.title = "历史解盘";
        //    $scope.setTitle("历史解盘");
        //    //console.log("$scope.jptitle", "历史解盘");
        //}
        //if(fbUser == "" || fbUser == undefined || fbUser == null)
        //{
        //    console.log("查看所有")
        //}
        //else
        //{
        //    console.log("查看某个人的")
        //}

        //console.log("---333-------" + $scope.userInfo['f_id'] + "----333---------");
        if($scope.currentTab['id'] == "4")
        {
            //jpajaxService.sendESBReq("user.getviewpointaction",
            //    {
            //        'page.pageno': $scope.jrgdPageNo+'',
            //        'page.pagesize': pageSize,
            //        //'userid':""
            //        'userid': $scope.userInfo['f_id']
            //    }, $scope.jrgdCallBack);
            if(fbUser == "" || fbUser == undefined || fbUser == null)
            {
                //查看所有
                jpajaxService.sendESBReq("user.selectviewpointaction",
                    {
                        'page.pageno': $scope.jrgdPageNo+'',
                        'page.pagesize': pageSize,
                        //'userid':""
                        'userid': $scope.userInfo['f_id']
                    }, $scope.jrgdAllCallBack);
            }
            else
            {
                //查看个人
                jpajaxService.sendESBReq("user.getviewpointaction",
                {
                    'page.pageno': $scope.jrgdPageNo+'',
                    'page.pagesize': pageSize,
                    //'userid':""
                    'userid': fbUser
                }, $scope.jrgdCallBack);
            }

        }
        else
        {
            jpajaxService.sendESBReq("user.selectJiepanByPage",
                {
                    'jiepan.type': !!!fbUser ? $scope.currentTab['id'] : '',
                    'jiepan.id': $scope.currentTab['typeLastId'],
                    'Jiepan.code': stockcode ? stockcode : '',
                    'Jiepan.userid': fbUser ? fbUser : '',
                    'page.pagesize': pageSize,
                    'Jiepan.readerid': $scope.userInfo['f_id']
                }, loadingdata);

        }

    };

    $scope.$watch('showTab', function (newValue, oldValue) {
        //console.log("12341234",newValue);
        //console.log("12341234",oldValue);
        $scope.queryJp(true);
    });


    $scope.showAllArtical = function (obj) {
        obj['showAll'] = true;
    };

    $scope.hideSomeArtical = function (obj) {
        obj['showAll'] = false;
    };

    $scope.showNextList = function () {
        //console.log($scope.isBusy, $scope.showNoMore);
        if ($scope.isBusy || $scope.showNoMore) return;
        $scope.isBusy = true;
        $scope.queryJp(false);
    }

    //进入解盘评论
    $scope.jrgdItemClick = function(_obj)
    {
        //window.location.href = "viewpointInfo.html?peopleID=" + _obj.userid + "&opentype=newwebview";
        xinyuNewBrowser("viewpointInfo.html?peopleID=" + _obj.userid + "&opentype=newwebview");
    }


    //$scope.qscroll = new qScroll(function(){
    //    $scope.query(true);
    //});
}


//function timeFilter(){
//    return
//}
