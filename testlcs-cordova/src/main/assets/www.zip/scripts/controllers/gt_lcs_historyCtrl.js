
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_lcs_historyCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.lsfwlistArray = [];
    $scope.lcsuserid = getParameter("lcsuserid");//当前理财师的id
    $scope.opentype = getParameter("opentype");

    $scope.linkedhisgentouCallBack = function(_data)
    {
        //console.log("历史被跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.lsfwlistArray = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.gentouproductlist;
                for(var i= 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.name = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                    obj.headurl = arr[i].user.user.f_head;
                    obj.bgtuserid = arr[i].user.user.f_id;
                    obj.productid = arr[i].id;
                    obj.productname = arr[i].name;
                    obj.account = arr[i].account;
                    obj.zq = arr[i].gentouperiod;//周期
                    obj.bmrs = arr[i].gentoucount;//跟投人数
                    obj.mbsy = arr[i].targetprofit;//目标收益
                    var str = arr[i].actualendgentouday.toString();
                    obj.endgentoudaystr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    if(arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null)
                    {
                        obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                    }
                    else
                    {
                        obj.endgentoutime = "";
                    }

                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.gtstatus = "1";//跟投其他人：0；被其他人跟投：1
                    obj.xzzt = "1"; //界面显示效果
                    //console.log("累计收益率：" + obj.ljsyl);
                    $scope.lsfwlistArray.push(obj);
                }
            }
        }
    }

    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        //var message = {};
        //message['linkeduserid'] =  $scope.lcsuserid;
        //message['page.size'] =  "max";
        //message['page.no'] =  "";
        //ajaxService.sendMessage("gentou.p_selecthisgentou", message, $scope.linkedhisgentouCallBack);
        var message = {};
        message['userid'] =  $scope.lcsuserid;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);
    }


    //初始相关操作界面
    $scope.fbzInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.lsgtlistArray = [];
            $scope.getlsbgtList();

        }catch (e){}
    }

    $scope.fbzInit();

    //进入某个历史信息
    $scope.hisItemClick = function(_obj)
    {
        _obj.xzzt = "0";
        setbackList(window.location.href);
        window.location = "gt_sy_history.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + $scope.lcsuserid;
    }

    $scope.gthistoryBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }

        //console.log(getbackList());
        //window.location = getParameter("backurl");
    }





}



