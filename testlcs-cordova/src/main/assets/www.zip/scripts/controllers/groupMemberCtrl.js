﻿/**
 * 控制器
 */
function groupMemberCtrl($scope, ajaxService, $cookieStore){
	$scope.group_id = getParameter("groupid");
	$scope.sessionID = "";//session
    $scope.mainShow = true;
    $scope.bottomtab1Show = true;//下方tab
    $scope.gandfArray = [];//好友\群组列表
    $scope.nofriend = false;//无好友：true， 有好友：false
    $scope.intervalDuration = 3000;//间隔时间，3000毫秒
    $scope.intervalId;
	$scope.index = "1";

    //置顶
    $scope.gotoTop = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

	$scope.getfriendAllInfoCallBack = function(_data)
    {	
		//alert(angular.toJson(_data));
        //console.log("好友列表",_data);
        $scope.gandfArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.groupmemberlist;
            for (var item in element)
            {
                var obj = {};
				//obj.infoNum = 0;
                obj.iconUrl = element[item]['f_head'];
                obj.name = element[item]['f_nickname'];
                obj.id = element[item]['f_friend_id'];//element[item]['f_friend_id'];
                //obj.mobile = element[item]['f_head'];
                obj.role = element[item]['f_role'];
                if(obj.role == "V")
                {
                    obj.vshow = true;
                }
                else
                {
                    obj.vshow = false;
                }
                obj.source = element[item]['f_source'];
                obj.system_id = element[item]['f_system_id'];
                //obj.weixinhao = element[item]['f_head'];
                obj.token = element[item]['f_token'];
                obj.openid = element[item]['f_openid'];
                obj.xzzt = "1";
                $scope.gandfArray.push(obj);
            }
            if($scope.gandfArray.length>0)
            {
                $scope.nofriend = false;
                //间隔执行
                //console.log("间隔执行", $scope.intervalId);
                $scope.thisClearInterval();
                $scope.intervalId = setInterval($scope.repeatingFunction, $scope.intervalDuration);
            }
            else
            {
                $scope.nofriend = true;
            }
        }

    }

    //获取好友列表
    $scope.getFriends = function()
    {	
		
        $scope.gandfArray = [];
        console.log("好友列表");
        var message = {};
        message['Groupmember.groupid'] = $scope.group_id;
        ajaxService.sendMessage("user.selectgroupmember", message, $scope.getfriendAllInfoCallBack) ;

        
    }

	//点击切换 ：群组、搜索
    $scope.bottomtabClick = function(_str)
    {
        switch (_str)
        {
            case "1":
                $scope.bottomtab1Show = true;
                $scope.bottomtab2Show = false;
                $scope.bottomtab3Show = false;
                $scope.bottomtab4Show = false;
                $scope.bottomtab5Show = false;
                //window.location.href = "#/";

                //获取好友列表
                $scope.getFriends();
                break;
            case "2":
                $scope.bottomtab1Show = false;
                $scope.bottomtab2Show = true;
                $scope.bottomtab3Show = false;
                $scope.bottomtab4Show = false;
                $scope.bottomtab5Show = false;
                //window.location.href = "#/gentou";
                break;
            default:
                break;
        }
        $scope.gotoTop();
    }

    $scope.bottomtabClick($scope.index);

    $scope.backto = function()
    {
        window.location = getbackList();
    }
}