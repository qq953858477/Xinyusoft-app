﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */


function myModelBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.userObj = null;
    $scope.sessionID = "";//session
    $scope.voteforCombinationArray = [];//跟投组合
    $scope.createdStockPool = [];//当前自己创建的股票组合//$scope.listArr
    $scope.twoStockPool = [];//两种股票组合：自己创建的、跟投的
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    //console.log("gthomeCtrl", gthomeCtrl);

    //跟投的组合
    $scope.p_selectgentoustockpoolsCallBack = function(_data)
    {
        console.log("跟投的组合",_data);
        if(_data.op.code.toString() == "Y")
        {
            var arr1 = _data.gentousignlist;
            var arr = [];
            for(var i = 0;i<arr1.length;i++)
            {
                var obj = new Object();
                obj.id = arr1[i].modelid;
                obj.gtje = arr1[i].directmoney;//跟投金额
                //console.log("gentousignlist", obj.id );
                //obj.name = arr[i].name;
                //obj.desc = arr[i].desc;
                //obj.yxsj = arr[i].runinfo;//运行时间
                //obj.rsy = $scope.changeValue((arr[i].rsyl*100).toFixed(2)) + "%";//日收益
                //obj.ysy = $scope.changeValue((arr[i].ysyl*100).toFixed(2)) + "%";//月收益
                //obj.zsy = $scope.changeValue((arr[i].zsyl*100).toFixed(2)) + "%";//总收益
                obj.xzzt = "1";//选中状态，样式更改
                arr.push(obj);
                //$scope.twoStockPool.push(obj);
            }

            var arr2 = _data.modellist;
            for(var i = 0;i<arr2.length;i++)
            {
                var obj = new Object();
                obj.id = arr2[i].id;
                obj.name = arr2[i].name;
                obj.desc = arr2[i].desc;
                obj.yxsj = arr2[i].runinfo;//运行时间
                obj.rsy = $scope.changeValue((arr2[i].zjyrsyl*100).toFixed(2)) + "%";//日收益
                obj.ysy = $scope.changeValue((arr2[i].zjyysyl*100).toFixed(2)) + "%";//月收益
                obj.zsy = $scope.changeValue((arr2[i].zsy*100).toFixed(2)) + "%";//总收益
                obj.sptype = "gt";//股票组合是自己创建的还是跟投的。自己创建：my；跟投：gt
                obj.xzzt = "1";//选中状态，样式更改
                console.log("modellist", obj.id );
                for(var j=0;j<arr.length;j++)
                {
                    if(arr[j].id == obj.id)
                    {
                        obj.gtje = arr[j].gtje;
                        $scope.twoStockPool.push(obj);
                        break;
                    }
                }

            }

        }
    }
    $scope.getvoteforCombination = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage('gentou.p_selectgentoustockpools', message, $scope.p_selectgentoustockpoolsCallBack);
    }

    //查询我的股票池
    $scope.selectmystockpoolsCallBack = function(_data)
    {
        console.log("我的股票池", _data);
        $scope.createdStockPool = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.modellist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = new Object()
                obj.id = arr[i].id;
                obj.name = arr[i].name;
                obj.desc = arr[i].desc;
                obj.yxsj = arr[i].runinfo;//运行时间
                obj.rsy = $scope.changeValue((arr[i].zjyrsyl*100).toFixed(2));//日收益
                obj.ysy = $scope.changeValue((arr[i].zjyysyl*100).toFixed(2));//月收益
                obj.zsy = $scope.changeValue((arr[i].zsy*100).toFixed(2));//总收益

                if(parseFloat(obj.rsy)>0)
                {
                    obj.status = "red";
                }
                else if(parseFloat(obj.rsy)<0)
                {
                    obj.status = "green";
                }
                else
                {
                    obj.status = "darkgray";
                }

                obj.xzzt = "1";//选中状态，样式更改
                obj.sptype = "my";//股票组合是自己创建的还是跟投的。自己创建：my；跟投：gt
                obj.gtje = "-";//跟投金额
                var ct = arr[i].createtime.toString();
                obj.createtime = "创建于 " + ct.substr(0,4) +"." + ct.substr(5,2) +"." + ct.substr(8,2);
                $scope.createdStockPool.push(obj);
                //$scope.twoStockPool.push(obj);
            }
        }
        //获取跟投的组合
        //$scope.getvoteforCombination();

    }
    //进入我的股票池
    $scope.myCombination = function()
    {
        $scope.twoStockPool = [];
        //查询我的股票池
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        //message['source'] = "";
        message['userid'] = $scope.userObj.f_id;
        //message['app'] = "";
        ajaxService.sendMessage('model.selectmodelaction', message, $scope.selectmystockpoolsCallBack);
    }

    $scope.mymInit = function()
    {
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.myCombination();//我的组合
    }

    $scope.mymInit();




    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    //我的组合，股票池列表点击，进入单个股票池
    $scope.stockPoolListItemClick = function(_obj)
    {
        //console.log("stockPoolListItemClick", _obj);
        _obj.xzzt = "0";
        setbackList(window.location.href);
        if(_obj.sptype == "my")
        {
            window.location.href = "myStockPool.html?oneStockPoolID=" + _obj.id + "&oneStockPoolName=" + encodeURI(_obj.name)  ;//+ "&runningTime="+ encodeURI(_obj.yxsj);
        }
        else if(_obj.sptype == "gt")
        {
            window.location.href = "gtStockPool.html?oneStockPoolID=" + _obj.id + "&oneStockPoolName=" + encodeURI(_obj.name) ;//+ "&runningTime="+ encodeURI(_obj.yxsj);
        }
    }

    //添加股票组合
    $scope.addStockPoolClick = function()
    {
        setbackList(window.location.href);
        window.location.href = "addNewStockPool.html?backurl=myModelBase.html";
    }

    $scope.backtoP = function()
    {
        //window.location.href = getParameter("backurl");
        //window.location.href = "uufpBase.html?baseindex=4";
        //window.location = getbackList();
        window.location.href = "back";
    }

}







