//var sqScope = null;
/**
 * 控制器
 */

function onePersonWinCtrl($scope, ajaxService, $cookieStore, $sce) {
    //console.log("聊天34324654356");
    //sqScope = $scope;
    //$scope.userObj = {};//当前用户信息
    $scope.userName = "";//当前用户的名称
    $scope.onePersonName = "";//朋友名称
    $scope.onePersonID = "";//朋友id
    $scope.onePersoniulr = "images/ico02_1.png";//朋友头像
    $scope.currentUserid = "";//当前用户id
    $scope.currentiulr = "images/ico02_1.png";//当前用户头像
    $scope.gchatList = [];//聊天记录
	$scope.gandfArray = [];//群成员列表
	//alert(angular.toJson($scope.gchatList));
    $scope.chartmainShow = true;//主显示对象
    $scope.moreBtnAreaShow = false;//多功能按钮显示区
    $scope.btnChooseShow = false;//按钮功能选择区

    $scope.glsqShow = false;//关联申请
    $scope.glsqfirstShow = false;//关联申请第一步
    $scope.glsqsecondShow = false;//关联申请第二步
    $scope.selectedzqzh = {};//选择作为申请的账号信息

    $scope.zhlistArray = [];//用户账号
    $scope.checkedvalue = "";//关联账号
    $scope.sqzdje = "";//申请时指定金额
    $scope.sqfc = "";//申请时指定分岑
    $scope.ws;
    $scope.applyObj = {};//当前申请处理的对象

    $scope.keyboardaudioShow = true;//true：显示键盘输入，false：显示语音输入
    $scope.beginaudio = false;//开始录音

    $scope.operationMark = true;//当前可操作标志

    $scope.audioMessageURL = "";//语音信息地址
    $scope.chartMessage = "";//需发送的信息
    $scope.chartListArray =[];//聊天信息

    $scope.chartListSize = 20;//一次性取的聊天量
    $scope.chartListRemainingQty = 0;//剩余数量
    $scope.lastmsgreadID = "0";//最后读取消息的编号，0则表示未读取过
    $scope.newmsgcount = "5";//未读消息获取的条数
        //$scope.hisinfoClickShow = false;//是否显示可点击获取历史消息，$scope.lastmsgreadID大于0或者totalBefore大于0

    $scope.pageupEnabel = false;//是否可以向前取数据（最远的）
    $scope.pagedownEnabel = false;//是否可以向后取数据（最近的）

    $scope.gchathisList = [];//历史消息
    $scope.hisListGetDataNum = "20";//一次取的历史数据的长度
    $scope.hislastmsgreadID = "0";//历史记录查询的当前编号
    $scope.histotalBefore = "0";////向后是否还有数据，若当前位置为10,则10-30的值
    $scope.histotalcount = "0";//历史记录总数
    $scope.hisIndex = 1;//当前页数index
    $scope.hisMaxIndex = 1;//最大页数

	 $scope.sce = $sce.trustAsResourceUrl;

    var wsjson = mywsConfig;
	var recordnum = 10;//查询的记录条数每次自增20
	var selectid = "";
	var lastrecord = "";
	var msgnum = 0;//页面上应显示的消息数量
	var pull = false;//判断是否触发下拉事件
	var oncenum = 0;//单次查询的数量(若用户数据少于10条即查询对应条数)
	
	
    $scope.websocketurl = wsjson.url;
    $scope.channelID = wsjson.channelID;
    $scope.topic= wsjson.topic;
	$scope.pic = "images/user01.png";


    $scope.onePersonID = $scope.peopleID;//getParameter("id");
    //console.log("id", $scope.onePersonID);
	$scope.lastmsgreadID = "";
	$scope.newmsgcount = "";
	//alert($scope.onePersonID);

    var localStorage = window.localStorage;
    //$scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
    $scope.currentiulr = decodeURIComponent(localStorage.getItem('iconurl'));
    $scope.currentUserid = $scope.userObj.f_id;

    //console.log("聊天", $scope.peopleID, $scope.onePersonID ,$scope.onePersonName, $scope.peopleName);
    
	
	//alert($scope.lastmsgreadID+"and"+$scope.newmsgcount)
    //$scope.lastmsgreadID = getParameter("lastmsgid");
    //$scope.newmsgcount = getParameter("newmsgcount");
	$scope.newmsg = [];
	$scope.type = getParameter("type");
	
	var selectid = $scope.onePersonID;//聊天对象的id,用于sql查询
	//获取好友列表//上次最后一次读取的位置id
    $scope.getFriends = function()
    {
        //console.log("获取好友信息");
			var message = {};
			message['user.id'] = $scope.currentUserid;
			message['friendinfo'] = "Y";
			ajaxService.sendMessage("user.selectfriendinfo", message, $scope.getfriendAllInfoCallBack) ;
        
	}
	
	//获取好友信息回调函数
	$scope.getfriendAllInfoCallBack = function(_data)
    {
		//alert(angular.toJson(_data));
        if(_data.op.code.toString() == "Y")
        {	
			//alert(_data.op);
            var element = _data.friendlist;
				for (var item in element)
				{ 
					//alert(element[item]['f_friend_id']);
					//alert($scope.onePersonID);
					if(element[item]['f_friend_id']==$scope.onePersonID){
						$scope.newmsgcount = element[item]['newmsgcount'];//有多少未读消息
						$scope.lastmsgreadID =  element[item]['lastmsgid'];//已经读过的消息位置  
						//alert($scope.lastmsgreadID+"and"+$scope.newmsgcount);
						$scope.init();
					}	
				}
        }

    }
	
    var ind = getParameter("prev");
    if(ind != "")
    {
        $scope.prev = ind;
    }

    $scope.getTimesql = function(time)
    {
        return isshowTime(time);
    }
	$scope.getTime = function(_str)
    {
        var str2 = "";
        if($scope.gchatList.length>0)
        {
            //console.log($scope.gchatList[$scope.gchatList.length-1].t);
            str2 = $scope.gchatList[$scope.gchatList.length-1].t;
        }
        else
        {
            str2 = "20150601010101";
        }
        return showTimeFun(str2, _str);
    }
    //Div显示底部
    $scope.setScrollHeight = function()
    {
        var chartD = document.getElementById('chartDiv');
        chartD.scrollTop = chartD.scrollHeight;
        //console.log(chartD.scrollTop, chartD.scrollHeight);
    }

    //创建连接，准备接收推送消息
    $scope.receiveMessage = function()
    {
        //聊天
        //$scope.ws = webSocketReq(function(event){console.log("linkapply", event.toString())},null,"1","ws://121.40.177.191:8871", channelID);		//ws://10.29.226.22:8888 ws://121.40.177.191:8881
        //微信
        console.log($scope.websocketurl, $scope.channelID, $scope.topic);
        if($scope.websocketurl != "" && $scope.channelID != "" && $scope.topic != "")
        {	
				$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.currentUserid, $scope.websocketurl, $scope.channelID, $scope.topic);
        }

        //app
        //$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.currentUserid,"ws://127.0.0.1:6688", channelID, topic);
    }
	
    //聊天
    $scope.chatonMessage = function(event)
    {
        $scope.$apply($scope.chatonMessagedeal(event));
    }

    $scope.chatonMessagedeal = function(event)
    {
        //console.log(event.data);
        var _data = JSON.parse(event.data);
        console.log("聊天信息推送", _data);
        if(_data != null)
        {
            //console.log("_data.type", _data.type);
            if(_data.f.toString() == $scope.onePersonID && _data.r.toString() == $scope.currentUserid)
            {
                if(_data.type == "text")
                {
                    var obj = {};
                    obj.u  = _data.f.toString();//发送方
                    obj.c = _data.content.toString();//内容
                    obj.t = _data.t.toString();
                    obj.showTime = $scope.getTime(obj.t);
                    obj.isshow = true;
                    if(obj.showTime == null || obj.showTime == "")
                    {
                        obj.isshow = false;
                    }
                    obj.i = _data.r.toString();//接收方
                    obj.lastmsgid = _data.i.toString();//当前位置
                    obj.f_head = $scope.onePersoniulr;
                    obj.type = "1";
                    $scope.gchatList.push(obj);
					//myScroll.scrollTo(0, -81, 100);
					//alert("insert1");
					//alert(obj.lastmsgid);
					insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,obj.lastmsgid);
					//select();
					//chatrecord = [];
                }else{
					var obj = {};
                    obj.u  = _data.f.toString();//发送方
                    obj.c = _data.content.toString();//内容
                    obj.t = _data.t.toString();
                    obj.showTime = $scope.getTime(obj.t);
                    obj.isshow = true;
                    if(obj.showTime == null || obj.showTime == "")
                    {
                        obj.isshow = false;
                    }
                    obj.i = _data.r.toString();//接收方
                    obj.lastmsgid = _data.i.toString();//当前位置
                    obj.f_head = $scope.onePersoniulr;
                    obj.type = "6";
                    $scope.gchatList.push(obj);
					//myScroll.scrollTo(0, -81, 100);
					//alert("insert1");
					//alert(obj.lastmsgid);
					insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,obj.lastmsgid);
					//select();
					//chatrecord = [];
                }
               
                $scope.sendReceipt($scope.gchatList[$scope.gchatList.length-1].lastmsgid);//发送回执，表示收到信息
            }
            //Div显示底部
            //$scope.setScrollHeight();
        }
    }

    //发送回执
    $scope.sendReceipt = function(_lastmsgid)
    {
        $scope.lastmsgreadID = _lastmsgid;
        console.log("回执", $scope.lastmsgreadID);
        var message = {};
        message['lastmsgid'] = _lastmsgid;//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = "";//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
		message['friendid'] = $scope.onePersonID;
        message['subjecttype'] = "friendTalk";
        message['subjectid'] ="";
        message['msgamount'] = "1";//查询条数
        console.log($scope.lastmsgreadID, $scope.currentUserid);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.sendReceiptCallBack);
    }

    //回执返回
    $scope.sendReceiptCallBack = function(_data)
    {

    }

    //获取聊天记录
    /*$scope.getChartList = function()
    {
        //type: 1，对话；2：我方关联申请成功后，我方信息显示；3，对方关联申请我方显示信息； 4，我方关联申请，对方处理结果在我方状态说明（同意，不同意操作处理结果）；5：对方关联申请，我方处理结果在我方显示；6：语音
        var obj = {};
        obj.u  = $scope.currentUserid;
        obj.c = "说";
        obj.t = "2015-06-05";
        obj.i = "12";
        obj.isshow = true;
        obj.f_head = $scope.currentiulr;
        obj.type = "1";
        $scope.gchatList.push(obj);
		

        var obj = {};
        obj.u  = $scope.onePersonID;
        obj.c = "什么"
        obj.t = "2015-06-05";
        obj.i = $scope.currentUserid;
        obj.isshow = true;
        obj.f_head = $scope.onePersoniulr;
        obj.type = "1";
        $scope.gchatList.push(obj);
		

        obj = {};
        obj.u  = $scope.onePersonID;
        obj.glzh ="243943494";//申请关联的账户
        obj.glzhstr =  "***" + obj.glzh.substr(obj.glzh.length-4);
        obj.c = obj.glzhstr + "账号申请关联";
        obj.fc = "收益分成：20%";
        obj.t = "2015-06-05";
        obj.showTime = $scope.getTime(obj.t);

        obj.isshow = true;
        obj.i =  $scope.currentUserid;
        obj.f_head = $scope.onePersoniulr;
        obj.type = "3";
        obj.operationChooseShow = true;//对方申请处理界面,操作选择界面
        obj.agreezhlistShow = false;//对方申请同意处理，显示账号列表供选择，同意操作界面
        obj.agreeEnabel = true; //同意按钮是否可操作
        obj.disagreeEnabel = true;//不同意按钮是否可操作
        $scope.gchatList.push(obj);


        var obj = {};
        obj.u  = $scope.currentUserid;
        obj.c = $sce.trustAsResourceUrl("http://www.xinyusoft.com:8085/uuFinancialPlanner/upload/10908247017152260.3gp");
        obj.t = "2015-06-05";
        obj.i = "12";
        obj.isshow = true;
        obj.f_head = $scope.currentiulr;
        obj.type = "6";
        obj.audioID = "audio" + Math.random(1000000);
        $scope.gchatList.push(obj);

        var obj = {};
        obj.u  = $scope.onePersonID;
        obj.c = $sce.trustAsResourceUrl("test.mp3");
        obj.t = "2015-06-05";
        obj.i = $scope.currentUserid;
        obj.isshow = true;
        obj.f_head = $scope.onePersoniulr;
        obj.type = "6";
        obj.audioID = "audio" + Math.random(1000000);
        $scope.gchatList.push(obj);

    }*/

    $scope.getUnreadInfoCallBack = function(_data)
    {
        //console.log("未读取的信息", _data);
        if(_data.op.code.toString() == "Y")
        {	
            var arr = _data.msglist;
            for (var i = 0; i < arr.length; i++) {
                var obj = {};
                if(arr[i].type == "text")
                {
                    obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    obj.t = arr[i].t.toString();
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                    }
                    obj.type = "1";
                    //$scope.gchatList.push(obj);
					//insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type);
					//alert("kaishi");
					count();
					select(selectid);
					lasttime(obj);
                }else{
					obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    obj.t = arr[i].t.toString();
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                    }
                    obj.type = "6";
                    //$scope.gchatList.push(obj);
					//insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type);
					//alert("kaishi");
					count();
					select(selectid);
					lasttime(obj);
                }
            }

            for (var i = 0; i < $scope.gchatList.length; i++) {
                var _str = "";
                var _str2 = "";
                if (i == 0) {
                    _str2 = "201506010101";
                }
                else {
                    _str2 = $scope.gchatList[i - 1].t;
                }
                _str = $scope.gchatList[i].t;
                $scope.gchatList[i].showTime = showTimeFun(_str2, _str);
                $scope.gchatList[i].isshow = true;
                if ($scope.gchatList[i].showTime == null || $scope.gchatList[i].showTime == "") {
                    $scope.gchatList[i].isshow = false;
                }
            }

            $scope.lastmsgreadID = (parseInt($scope.lastmsgreadID) + arr.length-1).toString();//位置变动到读取完成的地方

            //Div显示底部
            //$scope.setScrollHeight();

        }
        //侦听推送
        $scope.receiveMessage();
    }

    //获取未读取的信息
    $scope.getUnreadInfo = function()
    {
        //$scope.receiveMessage();
        var message = {};
        message['lastmsgid'] = $scope.lastmsgreadID;//(parseInt($scope.lastmsgreadID)+1).toString();//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = "";//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
		message['friendid'] = $scope.onePersonID;
		message['subjecttype'] = "friendTalk";
		message['subjectid'] ="";
        message['msgamount'] = "";//$scope.newmsgcount;//查询条数
        console.log($scope.lastmsgreadID, $scope.currentUserid);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.getUnreadInfoCallBack);
    }


    $scope.init = function()
    {
        //获取未读取的信息
        $scope.getUnreadInfo();
    }
	//获取当前好友的最后消息id

    $scope.chartinit = function(newValue, oldValue, scope)
    {
        console.log("chart", newValue, oldValue);
        if(newValue)
        {
            $scope.onePersonName = $scope.peopleName;//decodeURI(getParameter("name"));
            $scope.onePersoniulr = $scope.peoplehead;//decodeURIComponent(getParameter("headurl"));
            $scope.getFriends();
        }
        else
        {

        }
    }
    $scope.$watch('chartShow', $scope.chartinit);

    
    //语言和键盘输入切换
    $scope.keyboardaudioChange = function()
    {
        $scope.keyboardaudioShow = !$scope.keyboardaudioShow;
    }

 //   按下
    $scope.audioOnMouseDown = function()
    {
        //console.log("按下");
        //开始录音
        $scope.beginaudio = true;
        try
        {
			
			navigator.recordplugin.startRecord("startAudioCallBack");
            //alert("fasong");
        }
        catch(e){
            //alert(e.toString());
        }
    }

    startAudioCallBack = function(_data)
    {
        //myAlert("开始录音：" + _data);
    }

//    弹起
    $scope.audioOnMouseUp = function()
    {
        //console.log("弹起");
		$scope.beginaudio = false;
        try
        {
            navigator.recordplugin.endRecord("stopAudioCallBack","http://58.56.93.137:8081/qft/uploadVoice");
        }
        catch(e){
            //alert(e.toString());
            //alert("录音结束onError:" + e.toString());
           // console.log("弹起onError:" +  e.toString());
        }
        //录音结束并上传，获取url地址，并发送
        //$scope.sendAudioMessageClick();
    }

    stopAudioCallBack = function(_data)
    {
        //alert("录音结束，返回：" + _data);
        var da = JSON.parse(_data);
        if(da["op.code"].toString() == "Y")
        {
            var str = da.src.toString();
            $scope.audioMessageURL = str;
            $scope.sendAudioMessageClick();
            //if(str.substr(0,7) != "http://")
            //{
            //    str = "http://" + str;
            //}
        }
        else
        {
            myAlert("语音发送失败！");
        }

    }

    $scope.sendAudioMessageClick = function()
    {
        if($scope.audioMessageURL != "")
        {
            var message = {};
            message['subjecttype'] = "friendTalk";
            message['subjectid'] = "";
            message['receiver'] = $scope.onePersonID;
            message['fromUser'] = $scope.currentUserid;
            message['msgid'] = "";
            message['contenttype'] = "audio";
            message['content'] = $scope.audioMessageURL;
            message['commenttype'] = "";
            //console.log(message['id'] , message['account']);
            ajaxService.sendMessage("user.recordmessage", message, $scope.recordAudioMessageCallBack);

            var obj = {};
            obj.u  = $scope.currentUserid;
            obj.c = $scope.audioMessageURL;
            obj.t = getPresentTime();
            obj.showTime = $scope.getTime(obj.t);
            obj.isshow = true;
            if(obj.showTime == null || obj.showTime == "")
            {
                obj.isshow = false;
            }
            obj.i = $scope.onePersonID;
            obj.f_head = $scope.currentiulr;
            obj.type = "6";//语音
            //obj.audioID = "audio" + Math.random(1000000);
			//alert("obj="+angular.toJson(obj));
			$scope.temp = obj;
            //$scope.gchatList.push(obj);
			//insert(obj.u, obj.i, $scope.audioMessageURL, obj.t, obj.f_head, obj.type,obj.lastmsgid);
            $scope.audioMessageURL = "";
            //Div显示底部
            //$scope.setScrollHeight();
        }
        else
        {
            myAlert("录音地址为空");
        }
    }

    //语音信息发送是否成功
    $scope.recordAudioMessageCallBack = function(_data)
    {
		var obj = $scope.temp;
		//$scope.voice = false;
		//alert("audio="+angular.toJson(_data));
        if(_data.op.code.toString() == "Y")
        {
            //console.log("成功");
			obj.lastmsgid = _data.msgid;
			$scope.gchatList.push(obj);
            $scope.lastmsgreadID = _data.msgid;
			insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,_data.msgid);
        }
        else
        {
            console.log("失败，原因：" + _data.op.info.toString())
        }
    }

    //当前聊天音频点击
    $scope.chartlistaudioClick = function(obj)
    {
    
        //有正在播放的录音暂停播放并回到开始
        var chartaudio = document.getElementById(obj.lastmsgid);
		//alert(chartaudio);
        var mark = false;
        for(var i=0;i<$scope.gchatList.length;i++)
        {
            try
            {
                var chartaudio2 = document.getElementById($scope.gchatList[i].lastmsgid);
                if(chartaudio2!=null)
                {
                    if (!chartaudio2.paused)//播放中
                    {
                        chartaudio2.pause();// 暂停
                        if(obj.lastmsgid != $scope.gchatList[i].lastmsgid)//不是同一个
                        {
                            chartaudio.play();
                        }
                        mark = true;
                        //console.log(545454, mark);
                        //chartaudio2.currentTime = chartaudio2.startTime;
                        break;
                    }
                }
            }
            catch(e){
                //console.log(32132, e.toString());
            }
        }
        if(mark == false)
        {
            //console.log(32432, mark);
            chartaudio.play();
            //console.log(chartaudio.duration);
        }
    }


    //当前聊天音频可以播放的时候，显示时间
    audioCanplay = function(_obj)
    {
        //console.log("232", _obj.id);
        if(_obj.duration != NaN)
        {
            var t = Math.ceil(_obj.duration);
            for(var i=0;i<$scope.gchatList.length;i++)
            {
                //console.log($scope.gchatList[i].audioID);
                if(_obj.id == $scope.gchatList[i].lastmsgid)
                {
                    $scope.gchatList[i].duration = t + "＂";
                    $scope.$apply();
                    break;
                }
            }
        }
    }

    //进入好友界面
    $scope.headClick = function()
    {
        //var localStorage = window.localStorage;
        //localStorage.setItem("peopleID", $scope.onePersonID);
        //setbackList(window.location.href);
		//window.location.href="peopleSpaceBase.html";
        $scope.chartspaseChange()

    }

    //多功能按钮区显示
    $scope.moreBtnAreaClick = function()
    {
        $scope.moreBtnAreaShow = !$scope.moreBtnAreaShow;
        if($scope.moreBtnAreaShow)
        {
           $scope.btnChooseShow = true;
			var height = $('#chartDiv').height(); 
			$('#chartDiv').css('height',height-192);
			myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
        }
        else
        {
            $scope.btnChooseShow = false;
			var height = $('#chartDiv').height(); 
			$('#chartDiv').css('height',height+192);
        }
    }

	$scope.delRecord = function(){
		del();
		$scope.gchatList = [];
	}
   

    //聊天信息发送和推送
    $scope.sendMessageClick = function()
    {
        if($scope.chartMessage == "")
        {
            myAlert("请输入信息");
            return;
        }

        //console.log("$scope.chartMessage", $scope.chartMessage, $scope.onePersonID);

        var message = {};
        message['subjecttype'] = "friendTalk";
        message['subjectid'] = "";
        message['receiver'] = $scope.onePersonID;
        message['fromUser'] = $scope.currentUserid;
        message['msgid'] = "";
        message['contenttype'] = "text";
        message['content'] = $scope.chartMessage;
        message['commenttype'] = "";
        //console.log(message['id'] , message['account']);
			//alert("persontalk");
			ajaxService.sendMessage("user.recordmessage", message, $scope.recordmessageCallBack);
			var obj = {};
			obj.u  = $scope.currentUserid;
			obj.c = $scope.chartMessage;
			obj.t = getPresentTime();
			//alert(obj.t);
			obj.showTime = $scope.getTime(obj.t);
			obj.isshow = true;
			if(obj.showTime == null || obj.showTime == "")
			{
				obj.isshow = false;
			}
			obj.i = $scope.onePersonID;
			obj.f_head = $scope.currentiulr;
			obj.type = "1";
			obj.lastmsgid = Number($scope.lastmsgreadID)+1;
			$scope.temp = obj;
			$scope.gchatList.push(obj);
			//myScroll.scrollTo(0, -81, 100);
			//alert("insert2");
			//alert(obj.lastmsgid);
			//xunhuan 
			//insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,obj.lastmsgid);
			//select();
			//chatrecord = [];
			$scope.chartMessage = "";
			//Div显示底部
			//$scope.setScrollHeight();

    }

    //信息发送是否成功
    $scope.recordmessageCallBack = function(_data)
    {
    	var obj = $scope.temp;
        if(_data.op.code.toString() == "Y")
        {
            console.log("成功");
            //$scope.lastmsgreadID = (parseInt($scope.lastmsgreadID) + 1).toString();
            insert(obj.u, obj.i, obj.c, obj.t, obj.f_head, obj.type,_data.msgid);
        }
        else
        {
            console.log("失败，原因：" + _data.op.info.toString())
        }
    }

    //进入历史记录查询界面
    $scope.lsjlClick = function()
    {
        $scope.chartmainShow = false;
        $scope.moreBtnAreaShow = false;
        $scope.lsjllistShow = true;

        $scope.getlsjl();

    }

    $scope.getlsjl = function()
    {
       
        //获取聊天记录
        $scope.hislastmsgreadID = $scope.lastmsgreadID;
        var message = {};
        message['lastmsgid'] = "";//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = $scope.hislastmsgreadID;//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
        message['friendid'] = $scope.onePersonID;
        message['subjecttype'] = "friendTalk";
        message['subjectid'] ="";
        message['msgamount'] = $scope.hisListGetDataNum;//查询条数
        //console.log("获取历史", $scope.currentUserid, $scope.hislastmsgreadID);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.firstgetmessagerecordCallBack);

    }

    $scope.firstgetmessagerecordCallBack = function(_data)
    {
        $scope.gchathisList = [];
        //console.log("历史消息", _data);
        $scope.histotalBefore = _data.totalBefore;
        $scope.histotalcount = _data.totalcount;
        $scope.hisMaxIndex = Math.ceil(parseInt($scope.histotalcount)/parseInt($scope.hisListGetDataNum));
        //console.log($scope.hisMaxIndex, $scope.hisIndex);
        if(parseInt($scope.histotalBefore)>0)
        {
            $scope.pageupEnabel = true;
        }
        else
        {
            $scope.pageupEnabel = false;
        }
        if($scope.hisMaxIndex>$scope.hisIndex)
        {
            $scope.pagedownEnabel = true;
        }
        else
        {
            $scope.pagedownEnabel = false;
        }
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.msglist;
            for (var i = 0; i < arr.length; i++) {
                var obj = {};
                if(arr[i].type == "text")
                {
                    obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    var tt = arr[i].t.toString();
                    obj.t = tt.substr(0,4)+"-"+tt.substr(4,2)+"-"+tt.substr(6,2)+" "+tt.substr(8,2)+":"+tt.substr(10,2)+":"+tt.substr(12,2);
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                        obj.name = $scope.userName;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                        obj.name = $scope.onePersonName;
                    }
                    obj.type = "1";
                    $scope.gchathisList.push(obj);
                }          
            }
        }
    }

    //取之前的历史数据
    $scope.gotoBefore = function()
    {
        $scope.hisIndex = $scope.hisIndex+1;
        $scope.hislastmsgreadID = (parseFloat($scope.hislastmsgreadID) - parseInt($scope.hisListGetDataNum)).toString();
        var message = {};
        message['lastmsgid'] = "";//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] = $scope.hislastmsgreadID;//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
        message['friendid'] = $scope.onePersonID;
        message['subjecttype'] = "friendTalk";
        message['subjectid'] ="";
        message['msgamount'] = $scope.hisListGetDataNum;//查询条数
        console.log("获取历史Before", $scope.currentUserid, $scope.hislastmsgreadID);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.beforegetmessagerecordCallBack);
    }

    $scope.beforegetmessagerecordCallBack = function(_data)
    {
        $scope.gchathisList = [];
        //console.log("历史消息", _data);
        if($scope.hisIndex>1)
        {
            $scope.pageupEnabel = true;
        }
        else
        {
            $scope.pageupEnabel = false;
        }
        if($scope.hisMaxIndex>$scope.hisIndex)
        {
            $scope.pagedownEnabel = true;
        }
        else
        {
            $scope.pagedownEnabel = false;
        }
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.msglist;
            for (var i = 0; i < arr.length; i++) {
                var obj = {};
                if(arr[i].type == "text")
                {
                    obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    var tt = arr[i].t.toString();
                    obj.t = tt.substr(0,4)+"-"+tt.substr(4,2)+"-"+tt.substr(6,2)+" "+tt.substr(8,2)+":"+tt.substr(10,2)+":"+tt.substr(12,2);
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                        obj.name = $scope.userName;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                        obj.name = $scope.onePersonName;
                    }
                    obj.type = "1";
                    $scope.gchathisList.push(obj);
                }
              
            }
        }
    }

    //取之后的数据
    $scope.gotoAfter = function()
    {
        $scope.hisIndex = $scope.hisIndex-1;
        $scope.hislastmsgreadID = (parseFloat($scope.hislastmsgreadID) + parseInt($scope.hisListGetDataNum)).toString();
        var message = {};
        message['lastmsgid'] = "";//当前id为最小id,若为50，则取回为51-100的数据
        message['currentmsgid'] =$scope.hislastmsgreadID;//当前id为最大id,若为50，则取回为1-50的数据，传这个值时，回参totalBefore表示剩余还有多少条消息记录
        message['userid'] = $scope.currentUserid;
        message['friendid'] = $scope.onePersonID;
        message['subjecttype'] = "friendTalk";
        message['subjectid'] ="";
        message['msgamount'] = $scope.hisListGetDataNum;//查询条数
        console.log("获取历史After", $scope.currentUserid, $scope.hislastmsgreadID);
        ajaxService.sendMessage("user.getmessagerecord", message, $scope.aftergetmessagerecordCallBack);
    }

    $scope.aftergetmessagerecordCallBack = function(_data)
    {
        $scope.gchathisList = [];
        console.log("历史消息", _data);
        if($scope.hisIndex>1)
        {
            $scope.pageupEnabel = true;
        }
        else
        {
            $scope.pageupEnabel = false;
        }
        if($scope.hisMaxIndex>$scope.hisIndex)
        {
            $scope.pagedownEnabel = true;
        }
        else
        {
            $scope.pagedownEnabel = false;
        }
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.msglist;
            for (var i = 0; i < arr.length; i++) {
                var obj = {};
                if(arr[i].type == "text")
                {
                    obj.u = arr[i].f.toString();//发送方
                    obj.i = arr[i].r.toString();//接收方
                    obj.c = arr[i].content.toString();//内容
                    var tt = arr[i].t.toString();
                    obj.t = tt.substr(0,4)+"-"+tt.substr(4,2)+"-"+tt.substr(6,2)+" "+tt.substr(8,2)+":"+tt.substr(10,2)+":"+tt.substr(12,2);
                    obj.lastmsgid = arr[i].i.toString();//当前位置
                    if (obj.u == $scope.currentUserid) {
                        obj.f_head = $scope.currentiulr;
                        obj.name = $scope.userName;
                    }
                    else {
                        obj.f_head = $scope.onePersoniulr;
                        obj.name = $scope.onePersonName;
                    }
                    obj.type = "1";
                    $scope.gchathisList.push(obj);
                }
            }
        }
    }

    //历史音频加载可以播放时显示时间
    hisaudioCanplay = function(_obj)
    {
        //console.log("232", _obj.id);
        if(_obj.duration != NaN) {
            var t = Math.ceil(_obj.duration);
            for (var i = 0; i < $scope.gchathisList.length; i++) {
                //console.log($scope.gchatList[i].audioID);
                if (_obj.id == $scope.gchathisList[i].audioID) {
                    $scope.gchathisList[i].duration = t + "＂";
                    $scope.$apply();
                    break;
                }
            }
        }
    }

    //历史聊天音频点击
    $scope.gchathisaudioClick = function(obj)
    {
        //有正在播放的录音暂停播放并回到开始
        var chartaudio = document.getElementById(obj.audioID);
        var mark = false;
        for(var i=0;i<$scope.gchathisList.length;i++)
        {
            try
            {
                var chartaudio2 = document.getElementById($scope.gchathisList[i].audioID);

                if(chartaudio2!=null)
                {
                    if (!chartaudio2.paused)//播放中
                    {
                        chartaudio2.pause();// 暂停
                        if(obj.audioID != $scope.gchathisList[i].audioID)//不是同一个
                        {
                            chartaudio.play();
                        }
                        mark = true;
                        //console.log(545454, mark);
                        //chartaudio2.currentTime = chartaudio2.startTime;
                        break;
                    }
                }
            }
            catch(e){
                //console.log(32132, e.toString());
            }
        }
        if(mark == false)
        {
            //console.log(32432, mark);
            chartaudio.play();
        }
    }

    //历史聊天返回聊天界面
    $scope.lsjlbackto = function()
    {
        $scope.moreBtnAreaShow = false;
        $scope.chartmainShow = true;
        $scope.lsjllistShow = false;
        $scope.gchathisList = [];
    }

    //返回列表界面
    $scope.onePersonbackto = function()
    {	
		//if($scope.type=="group"){
		//	window.location = "gtbBase.html";
		//}else{
		//	window.location = "myGroupBase.html";
		//}
        //window.location = getbackList();
        $scope.peoplespaceBackto();
        
    }
    //点击不显示手机弹出的键盘
    $scope.closePopClick = function(){
        //console.log("545");
		//alert(1);
		if($scope.moreBtnAreaShow){
			$scope.moreBtnAreaShow = !$scope.moreBtnAreaShow
			$scope.btnChooseShow = false;
			var height = $('#chartDiv').height(); 
			$('#chartDiv').css('height',height+192);
		}
		document.getElementById("bkclose").blur();
        //if($scope.moreBtnAreaShow)
        //{	
         //   $scope.moreBtnAreaClick();
        //}

    };

    //打开键盘关闭多功能界面
    $scope.closemedia = function(){
		if($scope.moreBtnAreaShow){
			$scope.moreBtnAreaShow = !$scope.moreBtnAreaShow
			$scope.btnChooseShow = false;
			var height = $('#chartDiv').height(); 
			$('#chartDiv').css('height',height+192);
		}
	}
    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                return false;
            }
        }
        return true;
    }
	//sqlite
	var chatrecord = [];
	function insert(send, receive, context, time, f_head, type, lastmsgid) {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS record (send integer , receive integer, context text, time text, f_head text, type text, lastmsgid text)");
					log("插入数据")
					tx.executeSql(
							"INSERT INTO record (send, receive, context, time, f_head, type, lastmsgid) VALUES (?,?,?,?,?,?,?)",
							[send, receive, context, time, f_head, type,lastmsgid],function(tx,res){
								//myScroll.scrollTo(0, -50, 100);
								//alert(send+"and"+receive);
								msgnum = msgnum+1;
								if(msgnum>7){
									myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
								}
							});
				})	
	}
	//数据总数
	function count() {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
			db.transaction(function(tx) {
				tx.executeSql("CREATE TABLE IF NOT EXISTS record (send integer , receive integer, context text, time text, f_head text, type text, lastmsgid text)");
				tx.executeSql("SELECT rowid,time FROM record where send = "+selectid+" or receive = "+selectid,[],
					function(tx,res){
						//alert(10000);
						//alert("res.rows.length=="+res.rows.length);
						if(res.rows.length<10){
							recordnum = 0;
							msgnum = res.rows.length;
							oncenum = res.rows.length;
						}else{
							recordnum = res.rows.length-10;	
							msgnum = 10;
							oncenum = 10;
						}
						chatrecord = [];
						//alert("num="+recordnum);
					});
			})
	}
	//删除聊天记录
	function del() {
		//alert("selectid="+selectid)
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
			db.transaction(function(tx) {
				//tx.executeSql("CREATE TABLE IF NOT EXISTS record (send integer , receive integer, context text, time text, f_head text, type text, lastmsgid text)");
				tx.executeSql("DELETE FROM record where send = "+selectid+" or receive = "+selectid,[],
					function(tx,res){
						//alert("删除成功");
					});
			})
	}
	//计算最后一条记录的id
	function lasttime(param) {
		//alert(angular.toJson(param));
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
			db.transaction(function(tx) {
				tx.executeSql("SELECT rowid,lastmsgid FROM record where send = "+selectid+" or receive = "+selectid+" order by rowid desc LIMIT 1",[],
					function(tx,res){
						//alert(10000);
						//alert(2);
						if(res.rows.length!=0){
							lastrecord = res.rows.item(0).lastmsgid;
							//alert("lastrecord="+lastrecord);
							//alert(param.lastmsgid);
							if(Number(param.lastmsgid) != Number(lastrecord)){
								//alert("id不同");
								insert(param.u, param.i, param.c, param.t, param.f_head, param.type, param.lastmsgid);
								$scope.newmsg.push(param);
								//alert(angular.toJson($scope.newmsg));
								//alert($scope.gchatList);
								if($scope.newmsgcount == 0){
									for(var i=0;i<$scope.newmsg.length;i++){
										$scope.gchatList.push($scope.newmsg[i]);
										$scope.$apply();
									}
								}
							}
						}else{
							insert(param.u, param.i, param.c, param.t, param.f_head, param.type, param.lastmsgid);
							param.isshow = true;
							//alert(res.rows.item(i).time);
							param.showTime = $scope.getTimesql(param.t);
							$scope.gchatList.push(param);
							$scope.$apply();
						}
						//alert("num="+recordnum);
						if(msgnum>7){
							myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
						}
					});
			})
		return lastrecord;
	}
	//查询数据
	function select(selectid){
		//alert("selectid"+selectid);
		log("打开数据库");
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
			});
			//alert(2);
			db.transaction(function(tx) {
						
				tx.executeSql("SELECT * FROM (SELECT rowid,send,receive,context,time,f_head,type,lastmsgid FROM record where send = "+selectid+" or receive = "+selectid+") LIMIT "+recordnum+","+oncenum, [],
							function(tx, res) {
								for(var i = res.rows.length-1;i>=0;i--){
									var obj1 = {};
									obj1.u  = res.rows.item(i).send;//发送方
									obj1.c = res.rows.item(i).context;//内容
									obj1.t = res.rows.item(i).time;	
									obj1.i = res.rows.item(i).receive;//接收方
									obj1.f_head = res.rows.item(i).f_head;
									obj1.type = res.rows.item(i).type;
									obj1.lastmsgid = res.rows.item(i).lastmsgid;
									if(i==0){
										obj1.isshow = true;
										obj1.showTime = $scope.getTimesql(res.rows.item(i).time);
									}else
										if(i>0&&res.rows.item(i).time-res.rows.item(i-1).time>500){
											obj1.isshow = true;
											//alert(res.rows.item(i).time);
											obj1.showTime = $scope.getTimesql(res.rows.item(i).time);
										}
									chatrecord.unshift(obj1);	
								}	
								//alert(angular.toJson(chatrecord));
								//alert("count="+$scope.newmsgcount)
								if($scope.newmsgcount == 0){
									//alert("success");
									$scope.gchatList = chatrecord;
									$scope.$apply();
								}
								if($scope.newmsgcount>0){
									$scope.newmsgcount = $scope.newmsgcount-1;
								}
								if(pull){
									if(msgnum<10){
										myScroll.scrollToElement('div:nth-child('+msgnum+')', 100);
									}else{
										myScroll.scrollToElement('div:nth-child(10)', 100);
									}
								}
							});
			})
			
	}
	
	 //iscroll
	var myScroll,
	pullDownEl, pullDownOffset,
	generatedCount = 0;
		
	function pullDownAction(){
		//alert(1);
		//chatrecord = [];
		//alert($scope.gchatList);
		pull = true;
		if(recordnum == 0){
			recordnum = 0;
		}
		else if(recordnum<10){
			oncenum = recordnum;
			msgnum = recordnum;
			recordnum = 0;
			select(selectid);
		}else{
			recordnum = recordnum-10;
			oncenum = 10;
			select(selectid);
		}
		$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
	}

	
		pullDownEl = document.getElementById('pullDown');
		pullDownOffset = pullDownEl.offsetHeight;
		
		myScroll = new iScroll('wrapper', {
			useTransition: true,
			checkDOMChanges:true,//检查dom是否更新
			topOffset: pullDownOffset,
			onRefresh: function () {
				if (pullDownEl.className.match('loading')) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
					$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
				} 
			},
			onScrollMove: function () {
				if (this.y > 5 && !pullDownEl.className.match('flip')) {
					pullDownEl.className = 'flip';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '释放更新';
					$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
					this.minScrollY = 0;
				} else if (this.y < 5 && pullDownEl.className.match('flip')) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
					$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
					this.minScrollY = -pullDownOffset;
				}
			},
			onScrollEnd: function () {
				if (pullDownEl.className.match('flip')) {
					pullDownEl.className = 'loading';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '加载中';				
					pullDownAction();	
					$("#scroller").css("transform", "translate(0px, -51px) scale(1) translateZ(0px)");
					$("#scroller").css("transition-duration", "400ms");
				} 
			}
		});
		
		setTimeout(function () { document.getElementById('wrapper').style.left = '0'; }, 800);
		
		//时间处理
	function isshowTime(pretime)
	{
		//数据库中须处理的时间
		preyear = pretime.substring(0,4);
		premouth = pretime.substring(4,6)-1;
		preday = pretime.substring(6,8);
		prehour = pretime.substring(8,10);
		premin = pretime.substring(10,12);
		presec = pretime.substring(12,14);
		var predate = new Date(preyear,premouth,preday,prehour,premin,presec);
		//当前时间
		var nowtime = new Date();
		var curmouth = nowtime.getMonth();
		var curday = nowtime.getDate();
		var curyear = nowtime.getFullYear();
		var curhour = nowtime.getHours();
		var curmin = nowtime.getMinutes();
		var cursec = nowtime.getSeconds();
		
		if(preyear==curyear&&premouth==curmouth&&preday==curday){
			return prehour+":"+premin;
		}else
			if(preyear==curyear&&premouth==curmouth&&(curday-preday)==1){
				return "昨天"+" "+prehour+":"+premin;
			}else
				if((nowtime.getTime()-predate.getTime())-(7 * 24 * 3600 * 1000)<0){
					var day = predate.getDay();
					if(day == 0){
						return "星期天"+" "+prehour+":"+premin;
					}
					if(day == 1){
						return "星期一"+" "+prehour+":"+premin;
					}
					if(day == 2){
						return "星期二"+" "+prehour+":"+premin;
					}
					if(day == 3){
						return "星期三"+" "+prehour+":"+premin;
					}
					if(day == 4){
						return "星期四"+" "+prehour+":"+premin;
					}
					if(day == 5){
						return "星期五"+" "+prehour+":"+premin;
					}
					if(day == 6){
						return "星期六"+" "+prehour+":"+premin;
					}
				}else{
					return preyear+"年"+(premouth+1)+"月"+preday+"日"+" "+prehour+":"+premin;
				}
				
	}
	
	
}

