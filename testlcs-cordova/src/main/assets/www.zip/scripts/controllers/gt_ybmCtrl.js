
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_ybmCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.applyid = "";//跟投申请id
    $scope.productname = "";//产品名
    $scope.productid = "--";//产品id
    $scope.productfbzname = "";//服务发布者名称
    $scope.headurl = "--";//用户头像
    $scope.name = "--";//用户名字
    $scope.mbsy = "--";//目标收益
    $scope.zq = "--";//周期
    $scope.zyx = "--";//止盈线
    $scope.zsx = "--";//止损线
    $scope.gtje = "--";//跟投金额
    $scope.fcfs = "--";//分成方式
    $scope.lcjhdesc = "--";//理财计划
    $scope.fwfbsj = "--";//服务发布时间
    $scope.bmjzsj = "--";//报名截止时间
    $scope.fwkssj = "--";//服务开始时间
    $scope.fwjssj = "--";//服务结束时间
    $scope.gtzhzqgs = "";//跟投账户证券公司
    $scope.gtzhzqgsstr = "";//跟投账户证券公司
    $scope.gtzhzqzh = "--";//跟投账户证券账户
    $scope.bmjzsjstr = "--";

    $scope.plCount = "--";

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    $scope.gtztString = "";//产品状态
    $scope.cpzt = "";

    $scope.errorInfo = "";//报错提示

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面

    $scope.opentype = "";//打开方式

    //$scope.xxqrShow = false; //已经报名
    $scope.czMark = true;

    $scope.tabOneShow = true;//已经报名的跟投
    $scope.tabTwoShow = false;//理财师
    $scope.index = "1";//默认
    $scope.bgtuserid = "";//被跟投id
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }


    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息
    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });


    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.headurl = product.user.user.f_head;
            $scope.name = product.user.user.f_nickname;//用户名字
            $scope.userid = product.user.user.f_id;
            $scope.mbsy = product.targetprofit;//目标收益
            $scope.zq = product.gentouperiod;//周期
            $scope.lcjhdesc = product.desc;//说明，理财计划

            var str = product.endapplyday;
            //$scope.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
            $scope.bmjzsj = str;//报名截止日期
            var str2 = product.endgentouday;
            //$scope.fwjssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//服务结束时间
            $scope.fwjssj = str2;//服务结束时间
            var str3 = product.gentouday;
            //$scope.fwkssj = str3.substr(0,4) + "-" + str3.substr(4,2) + "-" + str3.substr(6,2);//服务开始时间
            $scope.fwkssj = str3;//服务开始时间
            var str4 = product.createtime;
            //$scope.fwfbsj = str4.substr(0,10);//服务发布时间
            $scope.fwfbsj = str4;//服务发布时间
            $scope.productfbzname = product.user.user.f_nickname;//产品发布者name
            $scope.bmjzsjstr = product.endapplytimedesc;

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }

            $scope.cpzt = product.status.toString();
            if($scope.cpzt == "A")
            {
                $scope.gtztString = "报名中";
            }
            else if($scope.cpzt == "G")
            {
                $scope.gtztString = "延期中";
            }
        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.checkisgtjjCallBack = function(_data)
    {
        //console.log("判断是否是跟投基金", _data);
        if(_data.op.code.toString() == "Y")//是跟投基金
        {
            $scope.gtzhzqgs = "跟投基金";
        }
        else//不是跟投基金
        {
            $scope.gtzhzqgs = $scope.gtzhzqgsstr;
        }
    }

    //判断是否是跟投基金
    $scope.checkisgtjj = function()
    {
        var message = {};
        message['account'] = $scope.gtzhzqzh;
        ajaxService.sendMessage("sunflower.isexperienceaccountrule", message, $scope.checkisgtjjCallBack);
    }

    $scope.p_getgentouapplyCallBack = function(_data)
    {
        console.log("跟投："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.gentouapply;
            if(obj.stopprofit != null && obj.stopprofit != "" && obj.stopprofit != undefined)
            {
                $scope.zyx = obj.stopprofit;
            }
            if(obj.stoploss != null && obj.stoploss != "" && obj.stoploss != undefined)
            {
                $scope.zsx = obj.stoploss;
            }

            $scope.gtje = parseFloat(obj.money);
            var fc = parseInt(obj.share)/10;
            $scope.fcfs = fc + ":"  + (10-fc);
            var applyObj = obj.applyaccountinfo;
            $scope.gtzhzqzh = applyObj.account;
            $scope.checkisgtjj();
            $scope.gtzhzqgsstr = applyObj.companyname;
        }
    }

    $scope.getgtsqinfo = function()
    {
        var message = {};
        message['applyid'] = $scope.applyid;
        ajaxService.sendMessage("gentou.p_getgentouapply", message, $scope.p_getgentouapplyCallBack);
    }


    $scope.changeTab = function(_str)
    {
        if(_str == "1")//已报名的信息
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;

        }
        else if(_str == "2")//理财师
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            $scope.$broadcast("setParameters", cstr);

            $scope.plmark = false;
        }
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    //初始相关操作界面
    $scope.gtybmInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.productid = getParameter("productid");//产品id
            $scope.applyid = getParameter("applyid");
            $scope.bgtuserid = getParameter("bgtuserid");//被跟投用户id

            $scope.getdqgtInfo();
            $scope.getgtsqinfo()
            $scope.changeTab($scope.index);
            $scope.getplcount();
            $scope.isguanzhuget();

        }catch (e){}
    }

    //$scope.gtybmInit();

    $scope.appInit = function()
    {
        document.addEventListener('deviceready', function()
        {
            $scope.gtybmInit();
        }, false);
    }
    $scope.appInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        xinyuNewBrowser("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //取消报名
    $scope.cancelClick = function()
    {
        //if($scope.czMark)
        //{
        //    //$scope.xxqrShow = true;
        //
        //}
        //var str = "";
        $scope.mainShow = false;
        $scope.xxqrShow = true;
    }

    $scope.thisConfirm = function()
    {
        //$scope.backto();
        if($scope.czMark)
        {
            $scope.errorInfo = "取消报名中，请稍候...";
            $scope.czMark = false;
            $scope.qxgtsqClick();
        }
    }

    $scope.thisCancel = function()
    {
        $scope.mainShow = true;
        $scope.xxqrShow = false;
    }

    //取消跟投申请
    $scope.qxgtsqClick = function()
    {
        var message = {};
        message['linkapplyid'] = $scope.applyid;//跟投申请id
        ajaxService.sendMessage("gentou.p_cancellinkapply", message, $scope.p_cancellinkapplyCallBack);
    }

    $scope.p_cancellinkapplyCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.backto();
        }
        else
        {
            $scope.errorInfo = "取消报名失败，原因：" + _data.op.info;
        }
        $scope.czMark = true;
    }

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }

    $scope.fwqxgzCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.fwqxgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.fwqxgzCallback);
        }
    }


    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname+'" 报名中');
        var desc = encodeURI('理财师：' +$scope.productfbzname +'，服务时长：'+ getfwscStr($scope.zq) + '，目标收益：' + $scope.mbsy + "%");
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        //console.log(543254354, desc);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname+'" 报名中');
        var desc = encodeURI('理财师：' +$scope.productfbzname + '，服务时长：'+ getfwscStr($scope.zq) + '，目标收益：' + $scope.mbsy + "%");
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })
    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtSign_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    $scope.backto = function()
    {
        if($scope.backtitle == "实盘" || $scope.opentype == "newwebview")
        {
            //window.location.href = "back";
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }
    //读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    if(res.rows.length == 0){

                        $scope.hasReadNum = 0;

                    }else
                    {
                        $scope.hasReadNum = res.rows.item(0).readnum;

                    }

                    //alert("已读取评论数" + $scope.hasReadNum);

                    if($scope.hasReadNum < $scope.plCount)
                    {
                        $scope.plmark = true;
                    }
                    else
                    {
                        $scope.plmark = false;
                    }
                });
        })
    }


}



