/**
 * 控制器
 */
function invitedConCtrl($scope, ajaxService, $cookieStore) {
    $scope.userObj = null;//个人信息
    $scope.inviterName = "";//邀请者名称
    $scope.inviterID = "";//被邀请id
    $scope.inviteeID = "";//被邀请者
    $scope.systemID = "1";
    $scope.firstShow = true;
    $scope.secondShow = false;
    $scope.verificationCode = "";//验证码

    try
    {
        $scope.inviterName = decodeURIComponent(getParameter("inviterName"));
        $scope.inviterID = getParameter("inviterID");
        $scope.inviteeID = getParameter("friendid");
        //alert("被邀请者id：" + $scope.inviteeID);
        //$scope.systemID = getParameters("systemID");
        $scope.verificationCode = getParameter("loginCode");
    }
    catch(e){
    }

    //确定加入优优理财师
    $scope.joinClick = function()
    {
        //添加好友
        var message = {};
        message['userid'] = $scope.inviterID;
        message['friendid'] = $scope.inviteeID;
        //message['friend.createtime'] = "";
        message['systemid'] = $scope.systemID;
        //alert(message['userid'] + "  " + message['friendid']  +  "  " +  message['systemid'] );
        ajaxService.sendMessage("user.p_addfriend", message, $scope.addfriendCallBack) ;

    }

    $scope.addfriendCallBack = function(_data)
    {
        if (_data.op.code.toString() == 'Y')
        {
            //alert("加为好友成功！");
            $scope.firstShow = false;
            $scope.secondShow = true;
        }
        else
        {
            alert("好友添加失败！"+ _data.op.info);
        }
    }

    //关注好融e
    $scope.attentionHRE = function()
    {
        window.open ('http://mp.weixin.qq.com/s?__biz=MzAwMTIzNzYxOA==&mid=207436472&idx=1&sn=123b385633b3a25759d780bc10255b29#rd;');
    }

}

