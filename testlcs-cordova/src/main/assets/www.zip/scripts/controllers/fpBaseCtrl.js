/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function fpBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.mainShow = true;
    $scope.tabOneShow = true;
    $scope.tabTwoShow = false;
    $scope.index = "1";

    $scope.fpArray = [];//理财师列表
    $scope.fpCombDivShow = false;//某一理财师的组合列表显示
    $scope.onefpName = "";//理财师的名字
    $scope.fpCombinationArray = [];//理财师的投资组合

    $scope.allCombinationArray = [];//所有组合
    $scope.hotCombinationArray = [];//热门组合
    $scope.hotCombNum = 10;//热门组合查询个数

    $scope.hotCombDivShow = false;//显示热门组合
    $scope.allCombDivShow = false;//所有组合显示

    //置顶
    $scope.gotoTop = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }
    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    //获取理财师
    $scope.getlcsCallBack = function(_data)
    {
        console.log("理财师",_data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.userlist;
            for (var item in element) {
                var obj = {};
                obj.iconUrl = element[item]['f_head'];
                obj.name = element[item]['f_nickname'];
                obj.id = element[item]['f_id'];
                obj.mobile = element[item]['f_mobile'];
                obj.role = element[item]['f_role'];
                obj.source = element[item]['f_source'];
                obj.system_id = element[item]['f_system_id'];
                obj.weixinhao = element[item]['f_weixinhao'];
                obj.xzzt = "1";//选中状态，样式更改
                $scope.fpArray.push(obj);
            }
        }
    }

    //获取理财师列表
    $scope.getfp = function()
    {
        $scope.fpArray = [];
        var message = {};
        message['pageSize'] = "";
        message['pageNo'] = "";
        ajaxService.sendMessage("user.p_getlcs", message, $scope.getlcsCallBack);

        //var obj = {};
        //obj.iconUrl = "";//头像地址
        //obj.name = "刘建良";
        //obj.xzzt = "1";
        //$scope.fpArray.push(obj);
        //
        //obj = {};
        //obj.iconUrl = "";//头像地址
        //obj.name = "王维";
        //obj.xzzt = "1";
        //$scope.fpArray.push(obj);
        //
        //obj = {};
        //obj.iconUrl = "";//头像地址
        //obj.name = "程静怡";
        //obj.xzzt = "1";
        //$scope.fpArray.push(obj);
    }


    //跟什么
    $scope.p_gethotstockpoolCallBack = function(_data)
    {
        var arr = [];
        console.log("跟什么", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.modellist;
            for (var item in element)
            {
                var obj = {};
                obj.id = element[item]['id'];//股票池id
                obj.name = element[item]['name'];
                obj.desc = element[item]['desc'];//说明
                obj.yxsj = element[item]['runinfo'];//运行时间
                obj.rsy = $scope.changeValue((element[item]['zjyrsyl']*100).toFixed(2));//日收益
                obj.ysy = $scope.changeValue((element[item]['zjyysyl']*100).toFixed(2));//月收益
                obj.zsy = $scope.changeValue((element[item]['zsy']*100).toFixed(2));//总收益
               // obj.zsy = - + obj.zsy;
                if(parseFloat(obj.zsy)>0)
                {
                    obj.status = "red";
                }
                else if(parseFloat(obj.zsy)<0)
                {
                    obj.status = "green";
                }
                else
                {
                    obj.status = "darkgray";
                }
                //console.log( obj.status);
                obj.xzzt = "1";//选中状态，样式更改
                $scope.hotCombinationArray.push(obj);
            }
            var element2 = _data.gentouinfolist;
            for (var item2 in element2)
            {
                var obj = {};
                obj.id = element2[item2]['id'];//股票池id
                obj.allcount = element2[item2]['allcount'];//所有跟投数量
                obj.todaycount = element2[item2]['todaycount'];//今日跟投数量
                arr.push(obj);
            }
            for(var i = 0;i<$scope.hotCombinationArray.length;i++)
            {
                for(var j = 0; j<arr.length; j++)
                {
                    if($scope.hotCombinationArray[i].id == arr[j].id)
                    {
                        $scope.hotCombinationArray[i].allcount = arr[j].allcount;
                        $scope.hotCombinationArray[i].todaycount = arr[j].todaycount;
                        break;
                    }
                }
            }
        }
    }


    //查询热门跟投组合
    $scope.hotCombination = function()
    {
        console.log("查热门");
        $scope.hotCombinationArray = [];
        var message = {};
        message['number'] = $scope.hotCombNum;
        ajaxService.sendMessage('gentou.p_gethotstockpool', message, $scope.p_gethotstockpoolCallBack);
    }

    //跟什么
    $scope.allCombination = function()
    {
        $scope.hotCombDivShow = true;
        $scope.allCombDivShow = false;
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶

        //查询热门跟投组合
        $scope.hotCombination();
    }


    //点击切换 ：理财师、跟投组合
    $scope.bottomtabClick = function(_str)
    {
        switch (_str)
        {
            case "1":
                $scope.tabOneShow = true;
                $scope.tabTwoShow = false;
                $scope.getfp();
                break;
            case "2":
                $scope.tabOneShow = false;
                $scope.tabTwoShow = true;
                $scope.allCombination();
                break;
            default:
                break;
        }
        $scope.gotoTop();
    }

    $scope.fpInfo = function()
    {
        var ind = getParameter("index");
        if(ind != "")
        {
            $scope.index = ind;
        }
        try {
            //$scope.userObj = $cookieStore.get('user');
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
        }catch (e){}
    }


    //初始相关操作界面
    $scope.fpInit = function()
    {
        $scope.fpInfo();
        $scope.bottomtabClick($scope.index);
    }

    $scope.fpInit();

    $scope.getallCombination = function()
    {
        // 显示所有组合
        $scope.mainShow = false;//显示热门组合
        $scope.allCombDivShow = true;//所有组合显示

        $scope.allCombinationArray = [];
        $scope.allCombinationPageSize = 20;
        $scope.allCombinationPageNumber = 1;
        $scope.allCombinationPageMaxNum = 1;

        $scope.allCombMoreClick();

    }

    $scope.selectallstockpoolsCallBack = function(_data)
    {
        console.log("所有组合", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.modellist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = new Object()
                obj.id = arr[i].id;
                obj.name = arr[i].name;
                obj.desc = arr[i].desc;
                obj.yxsj = arr[i].runinfo;//运行时间
                obj.rsy = $scope.changeValue((arr[i].zjyrsyl*100).toFixed(2)) + "%";//日收益
                obj.ysy = $scope.changeValue((arr[i].zjyysyl*100).toFixed(2)) + "%";//月收益
                obj.zsy = $scope.changeValue((arr[i].zsy*100).toFixed(2)) + "%";//总收益
                obj.xzzt = "1";//选中状态，样式更改
                $scope.allCombinationArray.push(obj);
            }
            if($scope.allCombinationPageNumber == 1)
            {
                $scope.allCombinationPageMaxNum = parseInt(_data.page.totalpage);
            }
            //console.log($scope.allCombinationPageMaxNum, $scope.allCombinationPageNumber)
            $scope.allCombinationPageNumber = $scope.allCombinationPageNumber +1;
            if($scope.allCombinationPageNumber <= $scope.allCombinationPageMaxNum)
            {
                $scope.allCombMoreDivShow = true;
            }
            else
            {
                $scope.allCombMoreDivShow = false;
            }
            console.log($scope.allCombMoreDivShow)
        }
    }

    //显示更多股票组合
    $scope.allCombMoreClick = function()
    {
        var message = {};
        message['page.size'] = $scope.allCombinationPageSize;
        message['page.no'] = $scope.allCombinationPageNumber;
        console.log(message['page.pagesize'] , message['page.pageno'] )
        ajaxService.sendMessage('gentou.p_selectallmodels', message, $scope.selectallstockpoolsCallBack);
    }

    //跟什么， 进入单个股票池界面，可操作跟投
    $scope.allCombinationItemClick = function(_obj)
    {
        _obj.xzzt = "0";
        window.location.href = "oneStockPool.html?oneStockPoolID=" + _obj.id + "&oneStockPoolName=" + encodeURI(_obj.name) + "&prev=2"  ;//+ "&runningTime="+ encodeURI(_obj.yxsj);
    }

    //返回hot
    $scope.backtohot = function()
    {
        $scope.mainShow = true;//显示热门组合
        $scope.allCombDivShow = false;//所有组合显示
        $scope.allCombinationArray = [];
    }

    //理财师点击获取投资组合列表
    $scope.fpItemClick = function(_obj)
    {
        _obj.xzzt = "0";
        $scope.mainShow = false;
        $scope.fpCombDivShow = true;
        $scope.onefpName = _obj.name;
        $scope.fpCombinationArray = [];
        var message = {};
        message['userid'] = _obj.id;
        console.log(message['userid']);
        ajaxService.sendMessage('gentou.p_selectlcsmodels', message, $scope.selectlcsmodelsCallBack);

    }

    $scope.selectlcsmodelsCallBack = function(_data)
    {
        console.log("理财师名下可跟投组合", _data);
        $scope.fpCombinationArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.modellist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = new Object()
                obj.id = arr[i].id;
                obj.name = arr[i].name;
                obj.desc = arr[i].desc;
                obj.yxsj = arr[i].runinfo;//运行时间
                obj.rsy = $scope.changeValue((arr[i].zjyrsyl*100).toFixed(2)) + "%";//日收益
                obj.ysy = $scope.changeValue((arr[i].zjyysyl*100).toFixed(2)) + "%";//月收益
                obj.zsy = $scope.changeValue((arr[i].zsy*100).toFixed(2)) + "%";//总收益
                obj.xzzt = "1";//选中状态，样式更改
                $scope.fpCombinationArray.push(obj);
            }
        }
    }

    //返回理财师列表
    $scope.backtofplist = function()
    {
        $scope.lcslistchangeStatus();
        $scope.mainShow = true;
        $scope.fpCombDivShow = false;
        $scope.onefpName = "";
    }

    //理财师列表样式更改
    $scope.lcslistchangeStatus = function()
    {
        for(var i = 0;i<$scope.fpArray.length;i++)
        {
            if($scope.fpArray[i].xzzt == "0")
            {
                $scope.fpArray[i].xzzt = "1";
                break;
            }
        }
    }

    //某一理财师名下投资组合点击
    $scope.fpCombinationArrayItemClick = function(_obj)
    {
        _obj.xzzt = "0";
        window.location.href = "oneStockPool.html?oneStockPoolID=" + _obj.id + "&oneStockPoolName=" + encodeURI(_obj.name) + "&prev=1"  ;//+ "&runningTime="+ encodeURI(_obj.yxsj);
    }


    //返回主界面
    $scope.backto = function()
    {
        window.location = "uufpBase.html";
    }

    //点击不显示手机弹出的键盘
    $scope.closePopClick = function()
    {}

}




