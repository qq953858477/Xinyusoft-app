/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function tradeBase_bgtCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.account = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.tabOneShow = true;//综合
    $scope.tabTwoShow = false;//交易
    $scope.tabFourShow = false;//查询
    $scope.productid = "";//产品id
    $scope.deviceid = "";//设备号

    $scope.ztcaption = "";
    $scope.valueChange = false;

    //$scope.account = getParameter("account");
    var ind = getParameter("index");

    if(ind != "")
    {
       // $scope.index = ind;
    }
    var localStorage = window.localStorage;
    $scope.sessionID = localStorage.getItem('sessionid');
    $scope.account = localStorage.getItem('account');
    $scope.accountzlValue = localStorage.getItem('accountzlValue');//自留账户值
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.accountzqgs = decodeURIComponent(localStorage.getItem('accountName'));
    $scope.accountShowValue = localStorage.getItem('accountShow');//界面显示用
    $scope.productid = localStorage.getItem('productid');//界面显示用
    $scope.opentype = getParameter("opentype");//打开方式

    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid")!= undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }
    $scope.accountcompany = localStorage.getItem('accountcompany');//证券公司

    //$scope.sessionID = $cookieStore.get('sessionid');
    //$scope.account = $cookieStore.get('account');
    //$scope.userObj = $cookieStore.get('user');
    //$scope.accountzqgs = decodeURIComponent($cookieStore.get('accountName'));
    $scope.urlShow = false;
    //console.log($scope.sessionID,  $scope.account, $scope.accountShowValue);


    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });
    //console.log("tradeBase");

    //综合、交易/查询、关联切换
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = false;

            if($scope.valueChange)
            {
                //console.log("重新获取数据");
                var cstr  = {"account":$scope.account, "caption": "zh_asset_bgt"};
                $scope.$broadcast("setParameters", cstr);
            }
        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabFourShow = false;
        }
        else//查询
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = true;
        }
        $scope.valueChange = true;
    }

    $scope.changeTab($scope.index);

    //返回上一级 ：交易、账号
    $scope.backtoPreviousLevel = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", $scope.accountzlValue);//更改实际交易账户(返回主账户界面时用)
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location.href = getbackList();
        }

        //closeNewBrowser();
    }

    //公开设置
    $scope.gkszClick = function()
    {
        window.location.href = "trade_setzh.html?type=2&&productid=" + $scope.product.id;
    }

}




