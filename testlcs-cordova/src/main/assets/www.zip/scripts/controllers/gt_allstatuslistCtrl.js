
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_allstatuslistCtrl($scope, ajaxService, $cookieStore) {
    //console.log("3333");
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.lsgtlistArray = [];//历史跟投
    $scope.ybmArray = [];//已报名
    $scope.spzArray = [];//实盘中
    $scope.jczArray = [];//解除中
    $scope.wzfArray = [];//未支付
    $scope.wpfArray = [];//未评分
    $scope.backtitle = "";
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.histype = "1";//1：已报名，2：实盘中；3：解除中；4：未支付；5：未评分；6：已结束
    $scope.titlestr = "";

    $scope.hisinfo = {};
    $scope.hisinfo.zds = "--";//历史总单数
    $scope.hisinfo.zgtje = "--";//历史总跟投金额
    $scope.hisinfo.zljsyl = "--";//历史总收益率
    $scope.hisinfo.zljsy = "--";//历史总收益

    $scope.pmzzhow = false;//遮罩
    $scope.wpjpjDivShow = false;//
    $scope.chooseplObj = null;//被选中的
    $scope.pfcontetArray = [];//评分图片
    $scope.ispftjing = false;//是否评分提交中
    $scope.pjscore = 0;//评价分数
    $scope.pjdesc = "";//评论内容
    $scope.pjscorestr = "";
    //console.log("33344435555");
    var str = getParameter("type");
    //console.log(str);
    if(str != "" && str != undefined)
    {
        $scope.histype = str;
    }
    $scope.getlsallinfoCallBack = function(_data)
    {
        //console.log("历史数据", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.hisinfo = {};
            $scope.hisinfo.zds = _data.count;//历史总单数
            $scope.hisinfo.zgtje = _data.money;//历史总跟投金额
            $scope.hisinfo.zljsyl = parseFloat(_data.ljsyl);//历史总收益率
            $scope.hisinfo.zljsy = parseFloat(_data.ljsy);//历史总收益
        }
    }

    $scope.getlsallinfo = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.getcustomerendgentoustatsaction", message, $scope.getlsallinfoCallBack);
    }

    $scope.getlsgtCallBack = function(_data)
    {
        $scope.lsgtlistArray = [];//历史跟投
        //console.log("历史跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].linkeduser.user.f_head;
                obj.bgtuserid = arr[i].linkeduser.user.f_id;
                obj.gtstatus = "0";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                obj.linkaccount = arr[i].linkaccount;//跟投的账户
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.linkid = arr[i].id;
                obj.money = arr[i].money;
                obj.ljsyl = parseFloat(arr[i].ljsy);//累计收益
                obj.ljsy = arr[i].ljyk;
                obj.status = arr[i].status.toString();
                //var sharestr = arr[i].share;
                //var fc = parseInt(sharestr)/10;
                //obj.share = fc +":" +(10-fc) ;
                obj.gradeflat = arr[i].gradeflat.toString();
                if(obj.status == "D")
                {
                    obj.statusstr = "未支付";
                }
                else if(obj.status == "E")
                {
                    if(obj.gradeflat == "N")
                    {
                        obj.statusstr = "未评分";
                    }
                    else
                    {
                        obj.statusstr = "已结束";
                        obj.score = arr[i].score;
                        if(obj.score == undefined || obj.score == null || obj.score == "")
                        {
                            obj.score = 0;
                        }
                        obj.scoreArray = setsunflowerpf(parseInt(obj.score));
                    }
                }
                var str = arr[i].endtime.toString();
                //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.jssj = str;
                obj.shouldpaymoney = arr[i].shouldpaymoney;
                obj.rundays = arr[i].rundays;
                obj.settleno = arr[i].settleno;
                obj.settleid = arr[i].settleid;
                //console.log(obj.zj, arr[i].expirezc);
                $scope.lsgtlistArray.push(obj);
            }
        }
    }


    //历史跟投
    $scope.getlsgt = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectendaccountlink", message, $scope.getlsgtCallBack);
    }

    $scope.updatlsgt = function()
    {
        var obj = {};
        obj = $scope.chooseplObj;
        obj.statusstr = "已结束";
        obj.score = $scope.pjscore;
        if(obj.score == undefined || obj.score == null || obj.score == "")
        {
            obj.score = 0;
        }
        obj.scoreArray = setsunflowerpf(parseInt(obj.score));

        for(var i = 0;i<$scope.lsgtlistArray.length;i++)
        {
            if($scope.lsgtlistArray[i].linkid == obj.linkid)
            {
                $scope.lsgtlistArray[i] = obj;
                break;
            }
        }
        $scope.chooseplObj = null;
        $scope.pjscore = 0;
        $scope.pjscorestr = "";
    }

    $scope.getwzfCallBack = function(_data)
    {
        $scope.wzfArray = [];//历史跟投
        //console.log("历史跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].linkeduser.user.f_head;
                obj.bgtuserid = arr[i].linkeduser.user.f_id;
                obj.gtstatus = "0";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                obj.linkaccount = arr[i].linkaccount;//跟投的账户
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.linkid = arr[i].id;
                obj.money = arr[i].money;
                obj.status = arr[i].status.toString();
                obj.statusstr = "未支付";
                obj.ljsyl = parseFloat(arr[i].ljsy);//累计收益
                obj.ljsy = arr[i].ljyk;
                //var sharestr = arr[i].share;
                //var fc = parseInt(sharestr)/10;
                //obj.share = fc +":" +(10-fc) ;
                var str = arr[i].endtime.toString();
                //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.jssj = str;
                obj.shouldpaymoney = arr[i].shouldpaymoney;
                obj.rundays = arr[i].rundays;
                obj.settleno = arr[i].settleno;
                obj.settleid = arr[i].settleid;
                $scope.wzfArray.push(obj);
            }
        }
    }

    //未支付
    $scope.getwzf = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectunpayaccountlink", message, $scope.getwzfCallBack);
    }

    $scope.getwpfCallBack = function(_data)
    {
        $scope.wpfArray = [];//历史跟投
        //console.log("历史跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].linkeduser.user.f_head;
                obj.bgtuserid = arr[i].linkeduser.user.f_id;
                obj.gtstatus = "0";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                obj.linkaccount = arr[i].linkaccount;//跟投的账户
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.linkid = arr[i].id;
                obj.money = arr[i].money;
                obj.ljsyl = parseFloat(arr[i].ljsy);//累计收益
                obj.ljsy = arr[i].ljyk;
                obj.status = arr[i].status.toString();
                obj.statusstr = "未评分";
                //var sharestr = arr[i].share;
                //var fc = parseInt(sharestr)/10;
                //obj.share = fc +":" +(10-fc) ;
                var str = arr[i].endtime.toString();
                //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.jssj = str;
                obj.shouldpaymoney = arr[i].shouldpaymoney;
                obj.rundays = arr[i].rundays;
                $scope.wpfArray.push(obj);
            }
        }
    }

    $scope.getwpf = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectungradeaccountlink", message, $scope.getwpfCallBack);
    }

    $scope.updatewpf = function()
    {
        var obj = {};
        obj = $scope.chooseplObj;
        obj.statusstr = "已结束";
        obj.score = $scope.pjscore;
        if(obj.score == undefined || obj.score == null || obj.score == "")
        {
            obj.score = 0;
        }
        obj.scoreArray = setsunflowerpf(parseInt(obj.score));

        for(var i = 0;i<$scope.wpfArray.length;i++)
        {
            if($scope.wpfArray[i].linkid == obj.linkid)
            {
                $scope.wpfArray[i] = obj;
                break;
            }
        }
        $scope.chooseplObj = null;
        $scope.pjscore = 0;
        $scope.pjscorestr = "";
    }

    $scope.getybmCallBack = function(_data)
    {
        //console.log("报名的", _data);
        $scope.ybmArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr2 = _data.accountlinkapplylist;
            for(var i = 0;i<arr2.length;i++)
            {
                var obj = {};
                obj.status = "ybm";
                var bgtuser = arr2[i].linkuser.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.bgtuserid = bgtuser.f_id;
                obj.applyid = arr2[i].id;
                obj.productname = arr2[i].productname;
                obj.productid = arr2[i].productid;//产品id
                obj.productname = arr2[i].productname;//产品id
                obj.gtje = arr2[i].money;//跟投金额
                obj.status2 = arr2[i].productstatus;
                //var str = arr2[i].gentouday;
                //obj.gtrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//跟投日期
                //var str2 = arr2[i].endapplytime.toString();//跟投报名截止时间
                //obj.bmjzsj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                //console.log(arr2[i].endapplytime.toString());
                //obj.bmjzsj = arr2[i].endapplytime.toString();//跟投报名截止时间
                //obj.bmjzsjstr = arr2[i].endapplytimedesc.toString();

                $scope.ybmArray.push(obj);
            }

        }

    }

    $scope.getybm = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectgentouapply", message, $scope.getybmCallBack);
    }

    $scope.getspzCallBack = function(_data)
    {
        $scope.spzArray = [];
        //console.log("实盘中",_data);

        var arr1 = _data.accountlinklist;
        for(var i = 0; i<arr1.length;i++)
        {
            var obj = {};
            obj.status = "gt1";
            obj.linkaccount = arr1[i].linkaccount;//当前跟投的账户
            obj.linkid = arr1[i].id;
            var bgtuser = arr1[i].linkeduser.user;
            obj.hearurl = bgtuser.f_head;
            obj.username = bgtuser.f_nickname;
            obj.bgtuserid = bgtuser.f_id;
            obj.productname = arr1[i].productname;//产品name
            obj.productid = arr1[i].productid;//产品id
            obj.money = arr1[i].money;//跟投金额
            //obj.drsyl = (parseFloat(arr1[i].linkaccountmoney.jrsy)*100).toFixed(2);
            //obj.ljsyl = (parseFloat(arr1[i].linkaccountmoney.ljsy)*100).toFixed(2);
            obj.drsyl = parseFloat(arr1[i].jrsy);
            obj.drsy = arr1[i].dqyk;
            obj.ljsyl = parseFloat(arr1[i].ljsy);
            obj.ljsy = arr1[i].ljyk;
            //var str = arr1[i].endgentoutime.toString();
            //obj.jssj = str;
            var cwstr = arr1[i].cw;
            if(parseFloat(cwstr) == 0)
            {
                obj.cw = "空仓";//当前仓位
            }
            else if(parseFloat(cwstr) == 1)
            {
                obj.cw = "满仓";//当前仓位
            }
            else
            {
                obj.cw = (parseFloat(arr1[i].cw)*100).toFixed(0) + "%";//当前仓位
            }
            obj.buycount = arr1[i].buycount;
            obj.sellcount = arr1[i].sellcount;
            $scope.spzArray.push(obj);
        }
    }

    $scope.getspz = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selecttradingaccountlink", message, $scope.getspzCallBack);
    }

    $scope.getjczCallBack = function(_data)
    {
        //console.log("解除中", _data);
        $scope.jczArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr1 = _data.accountlinklist;
            for(var i = 0; i<arr1.length;i++)
            {
                var obj = {};
                obj.status = "gt2";
                obj.mbsy = arr1[i].targetprofit;
                obj.linkaccount = arr1[i].linkaccount;//当前跟投的账户
                obj.linkid = arr1[i].id;
                var bgtuser = arr1[i].linkeduser.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.bgtuserid = bgtuser.f_id;
                obj.productname = arr1[i].productname;//产品id
                obj.productid = arr1[i].productid;//产品id
                obj.money = arr1[i].money;//跟投金额
                //obj.drsyl = (parseFloat(arr1[i].linkaccountmoney.jrsy)*100).toFixed(2);
                //obj.ljsyl = (parseFloat(arr1[i].linkaccountmoney.ljsy)*100).toFixed(2);
                //obj.drsyl = parseFloat(arr1[i].linkaccountmoney.jrsy);
                //obj.ljsyl = parseFloat(arr1[i].linkaccountmoney.ljsy);
                obj.drsyl = parseFloat(arr1[i].jrsy);
                obj.drsy = arr1[i].dqyk;
                obj.ljsyl = parseFloat(arr1[i].ljsy);
                obj.ljsy = arr1[i].ljyk;
                //var str = arr1[i].endgentoutime.toString();
                //obj.jssj = str;
                var cwstr = arr1[i].cw;
                if(parseFloat(cwstr) == 0)
                {
                    obj.cw = "空仓";//当前仓位
                }
                else if(parseFloat(cwstr) == 1)
                {
                    obj.cw = "满仓";//当前仓位
                }
                else
                {
                    obj.cw = (parseFloat(arr1[i].cw)*100).toFixed(0) + "%";//当前仓位
                }
                obj.buycount = arr1[i].buycount;
                obj.sellcount = arr1[i].sellcount;
                $scope.jczArray.push(obj);
            }
        }
    }

    $scope.getjcz = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectremovingaccountlink", message, $scope.getjczCallBack);
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
        //console.log($scope.histype);
            //1：已报名，2：实盘中；3：解除中；4：未支付；5：未评分；6：已结束
            if($scope.histype == "1")
            {
                $scope.titlestr = "已报名";
                $scope.getybm();
            }
            else if($scope.histype == "2")
            {
                $scope.titlestr = "实盘中";
                $scope.getspz();
            }
            else if($scope.histype == "3")
            {
                $scope.titlestr = "解除中";
                $scope.getjcz();
            }
            else if($scope.histype == "4")
            {
                $scope.titlestr = "未支付";
                $scope.getwzf();
            }
            else if($scope.histype == "5")
            {
                $scope.titlestr = "未评分";
                $scope.getwpf();
            }
            else if($scope.histype == "6")
            {
                $scope.titlestr = "已结束";
                $scope.getlsallinfo();
                $scope.getlsgt();
            }
    }

    $scope.fbzInit();

    //评分
    $scope.wpfpfClick = function(_obj)
    {
        $scope.chooseplObj = _obj;
        $scope.pmzzhow = true;
        $scope.wpjpjDivShow = true;
        $scope.pjscore = 4;
        $scope.pfcontetArray = setsunflowerpf(4);
        $scope.pjscorestr = "满意";
        document.getElementById('pjcancelBtn').focus();
    }
    //取消评论
    $scope.cancelplClick = function()
    {
        if($scope.ispftjing == false)
        {
            $scope.pmzzhow = false;
            $scope.wpjpjDivShow = false;
            $scope.chooseplObj = null;
            $scope.pjscore = 0;
            $scope.pjdesc = "";
            $scope.pjscorestr = "";
        }
    }

    //评论提交
    $scope.sureplClick = function()
    {
        if($scope.ispftjing == false)
        {
            //if($scope.pjscore == 0)
            //{
            //    myAlert("请给服务评分！");
            //    return;
            //}
            $scope.ispftjing = true;//提交中
            var message = {};
            message['userid'] =  $scope.userObj.f_id;
            message['productid'] =  $scope.chooseplObj.productid;
            message['score'] =  $scope.pjscore;
            message['desc'] =  $scope.pjdesc;
            message['linkid'] =  $scope.chooseplObj.linkid;
            //console.log(message);
            ajaxService.sendMessage("sunflower.p_lcsscore", message, $scope.p_lcsscoreCallBack);
        }
    }

    $scope.p_lcsscoreCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.pmzzhow = false;
            $scope.wpjpjDivShow = false;
            //$scope.chooseplObj = null;
            //$scope.pjscore = 0;
            $scope.pjdesc = "";
            if($scope.histype == "5")
            {
                $scope.updatewpf();
            }
            if($scope.histype == "6")
            {
                $scope.updatlsgt();
            }
        }
        else
        {
            myAlert("评价失败，请重试！");
        }
        $scope.ispftjing = false;
    }

    //评分
    $scope.pfchooseClick = function(_obj)
    {
        //console.log("va", _obj.value);
        //console.log("343", $scope.pjscore, _obj.value);
        if(_obj.value == $scope.pjscore)
        {
            $scope.pjscore = $scope.pjscore - 1;
        }
        else
        {
            $scope.pjscore = _obj.value;
        }
        $scope.pfcontetArray = setsunflowerpf($scope.pjscore);

        if($scope.pjscore == 5)
        {
            $scope.pjscorestr = "非常满意";
        }
        else if($scope.pjscore == 4)
        {
            $scope.pjscorestr = "满意";
        }
        else if($scope.pjscore == 3)
        {
            $scope.pjscorestr = "可以";
        }
        else if($scope.pjscore == 2)
        {
            $scope.pjscorestr = "马马虎虎";
        }
        else if($scope.pjscore == 1)
        {
            $scope.pjscorestr = "不满意";
        }
        else if($scope.pjscore == 0)
        {
            $scope.pjscorestr = "非常不满意";
        }
    }

    //去支付
    $scope.gotozf = function(_obj)
    {
        $scope.chooseplObj = _obj;
        //zfhupdate();
        //window.location.href="gtb/jiesuandan-pay.html?settleno=" + _obj.settleno+"&paymoney=" + Number(_obj.shouldpaymoney).toFixed(2) + "&productid=" + _obj.productid + "&linkid=" + _obj.linkid + "&backurl=../gt_allstatuslist.html?" +"opentype="+ $scope.opentype + "&&type=" + $scope.histype  + "&&backtitle=我";
        //window.location.href="gtb/gt_jsd.html?linkid=" + _obj.linkid;
        xinyuNewBrowser("gtb/gt_jsd.html?linkid=" + _obj.linkid + "&opentype=newwebview" , "zfhupdate");
    }

    //打开支付后返回，界面数据更新
    zfhupdate = function()
    {
        //查询是否已支付
        if($scope.histype == '4')
        {
            var message = {};
            message['settleid'] =  $scope.chooseplObj.settleid;
            //console.log(message);
            ajaxService.sendMessage("gentou.issettlepayedrule", message, $scope.issettlepayedruleCallBack);
        }
        else
        {
            var message = {};
            message['id'] =  $scope.chooseplObj.linkid;
            //console.log(message);
            ajaxService.sendMessage("gentou.getaccountlinkaction", message, $scope.getaccountlinkactionCallBack);

        }
    }

    $scope.issettlepayedruleCallBack = function(_data)
    {
        //console.log("ddf", _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = {};
            obj = $scope.chooseplObj;
            obj.status = "E";
            obj.statusstr = "已支付";

            if($scope.histype == '4')
            {
                for(var i = 0;i< $scope.wzfArray.length;i++)
                {
                    if($scope.wzfArray[i].linkid == obj.linkid)
                    {
                        $scope.wzfArray[i] = obj;
                        break;
                    }
                }
            }
            $scope.chooseplObj = null;
        }
    }

    //历史
    $scope.getaccountlinkactionCallBack = function(_data)
    {
        //console.log("dd", _data);
        if(_data.op.code.toString() == "Y")
        {
            try
            {
                var obj = {};
                obj.name = _data.linkeduser.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = _data.linkeduser.user.f_head;
                obj.bgtuserid = _data.linkeduser.user.f_id;
                obj.gtstatus = "0";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                obj.linkaccount = _data.linkaccount;//跟投的账户
                obj.productid = _data.productid;
                obj.productname = _data.productname;
                obj.linkid = _data.id;
                obj.money = _data.money;
                obj.ljsyl = parseFloat(_data.ljsy);//累计收益
                obj.ljsy = _data.ljyk;
                obj.status = _data.status.toString();
                //var sharestr = _data.share;
                //var fc = parseInt(sharestr)/10;
                //obj.share = fc +":" +(10-fc) ;
                obj.gradeflat = _data.gradeflat.toString();
                if(obj.status == "D")
                {
                    obj.statusstr = "未支付";
                }
                else if(obj.status == "E")
                {
                    if(obj.gradeflat == "N")
                    {
                        obj.statusstr = "未评分";
                    }
                    else
                    {
                        obj.statusstr = "已结束";
                        obj.score = _data.score;
                        if(obj.score == undefined || obj.score == null || obj.score == "")
                        {
                            obj.score = 0;
                        }
                        obj.scoreArray = setsunflowerpf(parseInt(obj.score));
                    }
                }
                var str = _data.endtime.toString();
                //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.jssj = str;
                obj.shouldpaymoney = _data.shouldpaymoney;
                obj.rundays = _data.rundays;
                obj.settleno = _data.settleno;
                obj.settleid = _data.settleid;

                for(var i = 0;i<$scope.lsgtlistArray.length;i++)
                {
                    if($scope.lsgtlistArray[i].linkid == obj.linkid)
                    {
                        $scope.lsgtlistArray[i] = obj;
                        break;
                    }
                }
            }catch (e){}
        }
        $scope.chooseplObj = null;

    }

    //进入某个历史信息
    $scope.hisItemClick = function(_obj)
    {
        setbackList(window.location.href);
        window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;

        //xinyuNewBrowser("gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" , "xqbackupdate");
    }

    //xqbackupdate = function()
    //{
    //    if($scope.histype == "4")
    //    {
    //        var message = {};
    //        message['settleid'] =  $scope.chooseplObj.settleid;
    //        //console.log(message);
    //        ajaxService.sendMessage("gentou.issettlepayedrule", message, $scope.issettlepayedruleCallBack);
    //    }
    //    else if($scope.histype == "5")
    //    {
    //        var message = {};
    //        message['id'] =  $scope.chooseplObj.linkid;
    //        //console.log(message);
    //        ajaxService.sendMessage("gentou.getaccountlinkaction", message, $scope.getaccountlinkactionCallBack);
    //    }
    //    else if($scope.histype == "6")
    //    {
    //        var message = {};
    //        message['id'] =  $scope.chooseplObj.linkid;
    //        //console.log(message);
    //        ajaxService.sendMessage("gentou.getaccountlinkaction", message, $scope.getaccountlinkactionCallBack);
    //    }
    //}

    //跟投list点击
    $scope.gtlistItemClick = function(_obj)
    {
        if(_obj.status == "ybm")
        {
            //setbackList(window.location.href);
            //window.location = "gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" , "dqgtupdate");
        }
        else  if(_obj.status == "gt1")
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview", "dqgtupdate");
        }
        else  if(_obj.status == "gt2")
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview", "dqgtupdate");
        }
    }

    dqgtupdate = function()
    {
        if($scope.histype == "1")
        {
            $scope.getybm();
        }
        else if($scope.histype == "2")
        {
            $scope.getspz();
        }
        else if($scope.histype == "3")
        {
            $scope.getjcz();
        }
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview");
    }

    $scope.gtlistBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }

}



