
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_history_gtzCtrl($scope, ajaxService, $cookieStore) {

    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.linkid = "";
    $scope.index = "1";//默认显示收益
    $scope.isgtz = true;
    $scope.isyk = false;//是否是游客
    $scope.identity = "";//查看者的身份
    $scope.plCount = "--";

    $scope.tabOneShow = true;
    $scope.tabTwoShow = false;
    $scope.tabThreeShow = false;
    $scope.tabFourShow = false;
    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，跟投结束时间



    $scope.productname = "";//产品名
    $scope.productid = "--";//产品id
    $scope.headurl = "--";//用户头像
    $scope.name = "--";//用户名字
    $scope.zxgtje = "--";//最小跟投金额
    $scope.zyx = "--";//止盈线
    $scope.zsx = "--";//止损线
    $scope.gtje = "--";//跟投金额
    $scope.gtjssj = "--";//跟投结束时间
    $scope.lcjhdesc = "--";//理财计划
    $scope.gtzhzqgs = "";//跟投账户证券公司
    $scope.gtzhzqgsstr = "";//跟投账户证券公司
    $scope.gtzhzqzh = "--";//跟投账户证券账户

    $scope.dqgtInfo = {};
    $scope.dqgtInfo.rundays = "--";//实盘天数

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通
    $scope.fcfsArray = [];//分成方式

    //服务设置
    $scope.assetopenflaggentou = "N";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "N";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "N";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "N";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "N";//对跟投者，交易指令公开

    $scope.account = "";//账户

    $scope.accountShowValue = "";//跟投主账号，界面显示用
    $scope.settleid = "";//结算单编号
    $scope.jsdInfo = null;//结算单

    $scope.isfwpf = false;//是否评分
    $scope.fwpfArray = [];//评分显示
    $scope.fwpf = "0";//评分
    $scope.fwpj = "";//评价
    $scope.gtztString = "";//跟投状态：未支付/已结束（已支付）


    $scope.ztcaption = "";
    $scope.productid = getParameter("productid");
    $scope.account = getParameter("linkaccount");
    $scope.linkid = getParameter("linkid");//当前跟投账户的id
    $scope.bgtuserid = getParameter("bgtuserid");//被跟投账户的id
    $scope.identity = getParameter("identity");
    $scope.opentype = getParameter("opentype");

    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;

    });

    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品信息："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.headurl = product.user.user.f_head;
            $scope.name = product.user.user.f_nickname;//用户名字
            $scope.userid = product.user.user.f_id;
            $scope.zxgtje = product.minmoney;
            $scope.lcjhdesc = product.desc;//说明，理财计划
            //var str = product.endapplyday;
            //$scope.bmjzsj = str;//报名截止日期
            //var str2 = product.endgentouday;
            //$scope.fwjssj = str2;//服务结束时间
            //var str3 = product.gentouday;
            //$scope.fwkssj = str3;//服务开始时间
            //var str4 = product.createtime;
            //$scope.fwfbsj = str4;//服务发布时间
            //$scope.kssjstr = $scope.fwkssj.toString().substr(0,8);
            $scope.kssjstr = "";

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }
            //var sharearr = product.share;
            ////console.log("分成比例" +product.share);
            //for(var i = 0;i<sharearr.length;i++)
            //{
            //    var obj = {};
            //    obj.downprofit = sharearr[i].downprofit;//目标收益
            //    obj.share = sharearr[i].share;
            //    var fc = parseInt(obj.share)/10;
            //    obj.label = fc +":" +(10-fc) ;
            //    //obj.desc = "目标收益" +  sharearr[i].downprofit + "%后，跟投收益部分按照" + obj.label + "分成";\
            //    if(fc == 2)
            //    {
            //        obj.desc = "跟投用户实际收益超出平台基准收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；没有超出平台基准收益，理财师不分成";
            //    }
            //    else
            //    {
            //        obj.desc = "跟投用户实际收益超出理财包目标收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；若未达到目标收益，按二八分成方式结算";
            //    }
            //    obj.status = true;
            //    $scope.fcfsArray.push(obj);
            //}

        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.checkisgtjjCallBack = function(_data)
    {
        //console.log("判断是否是跟投基金", _data);
        if(_data.op.code.toString() == "Y")//是跟投基金
        {
            $scope.gtzhzqgs = "跟投基金";
        }
        else//不是跟投基金
        {
            $scope.gtzhzqgs = $scope.gtzhzqgsstr;
        }
    }

    //判断是否是跟投基金
    $scope.checkisgtjj = function()
    {
        var message = {};
        message['account'] = $scope.gtzhzqzh;
        ajaxService.sendMessage("sunflower.isexperienceaccountrule", message, $scope.checkisgtjjCallBack);
    }

    $scope.p_getgentouinfobyidCallBack = function(_data)
    {
        //console.log("跟投id3243243："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.accountlink;
            if(obj.stopprofit != null && obj.stopprofit != "" && obj.stopprofit != undefined)
            {
                $scope.zyx = obj.stopprofit;
            }
            if(obj.stoploss != null && obj.stoploss != "" && obj.stoploss != undefined)
            {
                $scope.zsx = obj.stoploss;
            }

            $scope.gtje = parseFloat(obj.money);
            $scope.gtjssj = obj.endtime.toString();

            var linkObj = obj.linkaccountmoney;
            $scope.gtzhzqzh = linkObj.belongaccount;
            //$scope.gtzhzqgs = linkObj.companyname;
            $scope.checkisgtjj();
            $scope.gtzhzqgsstr = linkObj.companyname;
            var tm = obj.endtime.toString();
            $scope.jssjstr = tm.substr(0,4) + tm.substr(5,2) + tm.substr(8,2);
            $scope.dqgtInfo.fwjssj = $scope.jssjstr + "1500";//跟投结束时间

            //$scope.dqgtInfo.rundays = obj.rundays;//实盘天数

            //console.log("$scope.jssjstr",$scope.jssjstr);
            if(obj.status.toString() == "D")
            {
                $scope.gtztString = "未支付";

            } else if(obj.status.toString() == "E")
            {
                $scope.gtztString = "已结束";
            }

            //console.log("跟投结束日", $scope.jssjstr);

            var cstr  = {"account":$scope.account, "caption": 'gtsynthetical'};
            $scope.$broadcast("setParameters", cstr);

        }
    }

    $scope.getgtinfo = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        //console.log("跟投id", message['linkid']);
        //ajaxService.sendMessage("gentou.p_getgentouinfobyid", message, $scope.p_getgentouinfobyidCallBack);
        ajaxService.sendMessage("gentou.p_gethisgentouinfobyid", message, $scope.p_getgentouinfobyidCallBack);
    }

    //评价
    $scope.setfwpf = function()
    {
        $scope.fwpfArray = [];
        if($scope.fwpf != null && $scope.fwpf != undefined && $scope.fwpf != "" && $scope.fwpf !="0" && $scope.fwpf !="0.0")
        {
            var pointindex = $scope.fwpf.indexOf(".",0);
            if(pointindex == -1 || (pointindex != -1 && $scope.fwpf.substr(pointindex+1,1)=="0"))//无小数点，整数，有小数点，小数点后为0
            {
                var num = parseFloat($scope.fwpf);
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.fwpfArray.push(obj);
                }
                for(var i = num+1;i<6;i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star2.png";
                    $scope.fwpfArray.push(obj);
                }
            }
            else//有小数点
            {
                var num = Math.floor(parseFloat($scope.fwpf));
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.fwpfArray.push(obj);
                }
                if(num<5)
                {
                    var obj = {};
                    obj.value = $scope.fwpfArray.length+1;
                    obj.djsrc = "images/star3.png";
                    $scope.fwpfArray.push(obj);
                }
                if(num+1<5)
                {
                    for(var i = num+2;i<6;i++)
                    {
                        var obj = {};
                        obj.value = i;
                        obj.djsrc = "images/star2.png";
                        $scope.fwpfArray.push(obj);
                    }
                }
            }
        }
        else
        {
            for(var i = 1;i<6;i++)
            {
                var obj = {};
                obj.value = i;
                obj.djsrc = "images/star2.png";
                $scope.fwpfArray.push(obj);
            }
        }
    }

    $scope.p_selectlcsscoreCallBack = function(_data)
    {
        //console.log("评分", _data.toString());
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.productgradelist;
            if(arr.length>0)
            {
                $scope.isfwpf = true;
                $scope.fwpf = arr[0].score;
                if($scope.fwpf == undefined || $scope.fwpf == null || $scope.fwpf == "")
                {
                    $scope.fwpf = "0";
                }
                $scope.fwpj = arr[0].desc;//评价
                if($scope.fwpj == undefined || $scope.fwpj == null || $scope.fwpj == "")
                {
                    $scope.fwpj = "";
                }
                $scope.setfwpf();
            }
        }
    }

    $scope.getfwpf = function()
    {
        //var message = {};
        //message['userid'] = $scope.userObj.f_id;
        //message['productid'] = $scope.productid;
        //message['lcsuserid'] = "";
        //message['page.size'] = "max";
        //message['page.no'] = "";
        //ajaxService.sendMessage("sunflower.p_selectlcsscore", message, $scope.p_selectlcsscoreCallBack);

        var message = {};
        message['accountlinkid'] = $scope.linkid;
        //message['productid'] = $scope.productid;
        message['page.size'] = "max";
        message['page.no'] = "";
        ajaxService.sendMessage("gentou.selectproductgradeaction", message, $scope.p_selectlcsscoreCallBack);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;

        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr2  = {"account":$scope.account, "caption": 'gtsyjyjl'};
            $scope.$broadcast("setParameters", cstr2);
        }
        else if(_str == "3")//跟投
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;

            var cstr2  = {"account":$scope.account, "caption": 'gtsypl'};
            $scope.$broadcast("setParameters", cstr2);

            $scope.plmark = false;
        }
        else if(_str == "4")//跟投
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;
        }
    }

    //结算单
    $scope.p_getsettleinfoCallBack = function(_data)
    {
        //$scope.jsdInfo = {};
        //console.log("结算单", _data)
        //if(_data.op.code.toString() == "Y")
        //{
        //    var obj = _data.settleinfo;
        //    $scope.jsdInfo.syl = parseFloat(obj.profit)/parseFloat(obj.money);//收益率
        //    var str = obj.day.toString();
        //    $scope.jsdInfo.jsr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//结算日
        //    $scope.jsdInfo.productname = obj.productname;//跟投账户名称
        //    $scope.jsdInfo.sr = obj.profit;//收入
        //    var sharestr = obj.share;//分成
        //    if(sharestr == undefined || sharestr == null || sharestr == "")
        //    {
        //        $scope.jsdInfo.fc = 0;
        //    }
        //    else
        //    {
        //        $scope.jsdInfo.fc = sharestr;
        //    }
        //    $scope.jsdInfo.dqzf = obj.paymoney;//当期支付
        //    var str2 = obj.lastpayday.toString();
        //    $scope.jsdInfo.jzrq = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//截止日期
        //}
    }

    $scope.getjsdinfo = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        //console.log("结算单", message['linkid']);
        ajaxService.sendMessage("gentou.p_getsettleinfobylinkid", message, $scope.p_getsettleinfoCallBack);
    }

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflaggentou = _data.assetopenflaggentou.toString();
            $scope.clearpositionopenflaggentou = _data.clearpositionopenflaggentou.toString();
            $scope.positionamountopenflaggentou = _data.positionamountopenflaggentou.toString();
            $scope.positionvarietyopenflaggentou = _data.positionvarietyopenflaggentou.toString();
            $scope.tradecommandopenflaggentou = _data.tradecommandopenflaggentou.toString();
        }
        $scope.getdqgtInfo();
        $scope.getgtinfo();
        //$scope.getjsdinfo();
        $scope.changeTab($scope.index);
        $scope.getfwpf();
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    //初始相关操作界面
    $scope.gtzInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.getcpsz();
            $scope.getplcount();


        }catch (e){}
    }

    //$scope.gtzInit();

    $scope.appInit = function()
    {
        document.addEventListener('deviceready', function()
        {
            $scope.gtzInit();
        }, false);
    }
    $scope.appInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        xinyuNewBrowser("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }


    $scope.backtoPreviousLevel = function()
    {
        $scope.fbgtBackto();
    }

    $scope.fbgtBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }


    //结算单
    $scope.jsdClick = function()
    {
        //console.log("结算单2");
        setbackList("../gt_history_gtz.html?index=1&&productid=" + $scope.productid + "&&linkaccount=" + $scope.account +"&&linkid=" + $scope.linkid + "&bgtuserid=" + $scope.bgtuserid);
        //window.location = "gtb/gtb-jiesuandan.html?linkid="+$scope.linkid;
        window.location.href="gtb/gt_jsd.html?linkid=" + $scope.linkid;
    }

    //读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    if(res.rows.length == 0){

                        $scope.hasReadNum = 0;

                    }else
                    {
                        $scope.hasReadNum = res.rows.item(0).readnum;

                    }

                    //alert("已读取评论数" + $scope.hasReadNum);

                    if($scope.hasReadNum < $scope.plCount)
                    {
                        $scope.plmark = true;
                    }
                    else
                    {
                        $scope.plmark = false;
                    }
                });
        })
    }

}



