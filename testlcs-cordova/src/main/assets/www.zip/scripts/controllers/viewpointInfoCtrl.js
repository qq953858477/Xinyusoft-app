
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function viewpointInfoCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.headstr = "";//当前用户

    
    $scope.peopleID = "";//观点发布者id
    $scope.peopleName = "";//观点发布者用户名
    $scope.peoplehead = "";//观点发布者用户头像
    $scope.peopleInfo = null;//观点发布者
    $scope.isxrklcs = true;//观点发布者是否是理财师

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    $scope.peopleID = getParameter("peopleID");
    $scope.isFlower = false;
    $scope.imgSrc = "";
    $scope.whichClick = "";//发送图片或者文字
    $scope.bigPicShow = false;//大图是否显示
    $scope.bigPicUrl = "";//大图url

    $scope.sftype = "";
    $scope.page = 1;

    $scope.gdListArray = [];//显示的观点数组

    $scope.tjMark = true;//是否可以提交
    $scope.plcontentstr = "";//当前在发送的评论内容
    $scope.plcontent = "";//内容
    $scope.fullGdArray = [];//所有观点
    $scope.lasttime = "";
    $scope.t = "";
    $scope.m = "";
    var newInsert = 0;
    //var cHeight = $('body').height()-95;
    var cHeight = $('body').height();//获取当前页面的高度
    $("#content").height(cHeight-95);//设置评论div的高度
    var isDown = false;
    $scope.isMore = true;//是否还有更多数据
    
  //点击评论关闭键盘
    $scope.closePop2 = function(){
     	//alert(1);
        //console.log("222");
     		document.getElementById("inputview").blur();
     };
     
  //iscroll
	var myScroll,
	pullDownEl, pullDownOffset,
	generatedCount = 0;
		
	function pullDownAction(){
        /*var length1 = parseInt($scope.gdListArray.length-newInsert);
        var length2 = parseInt($scope.fullGdArray.length);
        if((length2-length1)>0){
            if((length2-length1)>10){
                for(var i = length1;i < (length1+10);i++){
                    $scope.gdListArray.unshift($scope.fullGdArray[i]);
                    $scope.$apply();
                }
            }else{
                for(var i = length1;i < $scope.fullGdArray.length;i++){
                    $scope.gdListArray.unshift($scope.fullGdArray[i]);
                    $scope.$apply();
                }
            }
        }
        timeCheck($scope.gdListArray);
        //myScroll.scrollToElement('div:nth-child(10)', 200);*/
		if($scope.isMore){
			$scope.getgd();
		}
		
	}

	
		pullDownEl = document.getElementById('pullDown');
		pullDownOffset = pullDownEl.offsetHeight;
		
		myScroll = new iScroll('wrapper', {
			useTransition: true,
			checkDOMChanges:true,//检查dom是否更新
			topOffset: pullDownOffset,
			onRefresh: function () {
				if (pullDownEl.className.match('loading')) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
				} 
			},
			onScrollMove: function () {
				if (this.y > 5 && !pullDownEl.className.match('flip')) {
					pullDownEl.className = 'flip';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '释放更新';
					this.minScrollY = 0;
				} else if (this.y < 5 && pullDownEl.className.match('flip')) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
					this.minScrollY = -pullDownOffset;
				}
			},
			onScrollEnd: function () {
				if (pullDownEl.className.match('flip')) {
					pullDownEl.className = 'loading';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '加载中';				
					pullDownAction();	
				} 
			}
		});
		
		setTimeout(function () { document.getElementById('wrapper').style.left = '0'; }, 800);

    //时间处理
    function isshowTime(pretime)
    {
        //数据库中须处理的时间
        preyear = pretime.substring(0,4);
        premouth = pretime.substring(4,6)-1;
        preday = pretime.substring(6,8);
        prehour = pretime.substring(8,10);
        premin = pretime.substring(10,12);
        presec = pretime.substring(12,14);
        var predate = new Date(preyear,premouth,preday,prehour,premin,presec);
        //当前时间
        var nowtime = new Date();
        var curmouth = nowtime.getMonth();
        var curday = nowtime.getDate();
        var curyear = nowtime.getFullYear();
        var curhour = nowtime.getHours();
        var curmin = nowtime.getMinutes();
        var cursec = nowtime.getSeconds();

        if(preyear==curyear&&premouth==curmouth&&preday==curday){
            return prehour+":"+premin;
        }else
        if(preyear==curyear&&premouth==curmouth&&(curday-preday)==1){
            return "昨天"+" "+prehour+":"+premin;
        }else
        if((nowtime.getTime()-predate.getTime())-(7 * 24 * 3600 * 1000)<0){
            var day = predate.getDay();
            if(day == 0){
                return "星期天"+" "+prehour+":"+premin;
            }
            if(day == 1){
                return "星期一"+" "+prehour+":"+premin;
            }
            if(day == 2){
                return "星期二"+" "+prehour+":"+premin;
            }
            if(day == 3){
                return "星期三"+" "+prehour+":"+premin;
            }
            if(day == 4){
                return "星期四"+" "+prehour+":"+premin;
            }
            if(day == 5){
                return "星期五"+" "+prehour+":"+premin;
            }
            if(day == 6){
                return "星期六"+" "+prehour+":"+premin;
            }
        }else{
            return preyear+"年"+(premouth+1)+"月"+preday+"日"+" "+prehour+":"+premin;
        }

    }

    function timeTrans(t){
        //obj.time = t.substr(0,4) + "-" +  t.substr(4,2) + "-" +  t.substr(6,2) + " " + t.substr(8,2) + ":" + t.substr(10,2) + ":" + t.substr(12,2);
        var year = t.substr(0,4);
        var mouth = t.substr(4,2)-1;
        var day = t.substr(6,2);
        var hour = t.substr(8,2);
        var minute = t.substr(10,2);
        var second = t.substr(12,2);
        var tDate = new Date(year,mouth,day,hour,minute,second);
        return Number(tDate);
    }

    $scope.gdlistCallBack = function(_data)
    {
        console.log("观点列表", _data);
        //$scope.gdListArray =[];

        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.list;
            if(arr.length<10){
            	$scope.isMore = false;
            }
            for(var i = 0;i<arr.length;i++)
            {
            	//alert(angular.toJson(arr));
                var obj = {};
                obj.name = arr[i].f_nickname;
                obj.content = arr[i].f_cnt;
                obj.isPic = false;
                obj.isnotnull = false;
                if(obj.content == "//flower//"){
                	obj.isPic = true;
                	obj.content = "";
                	obj.isFlower = true;
                	obj.isImg = false;
                	obj.imgSrc = "images/sendflower.png";
                }else if((arr[i].f_imgurl != "")&&(arr[i].f_imgurl != undefined)&&(arr[i].f_imgurl != null)){
                	obj.isPic = true;
                	obj.isFlower = false;
                	obj.isImg = true;
                	obj.imgSrc = arr[i].f_imgurl;
                	if(obj.content != ""){
                		obj.isnotnull = true;
                	}
                }
                obj.headurl = arr[i].f_head;
                var t = arr[i].f_createtime.toString();
                obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
                obj.time = isshowTime(obj.t);

                if(arr[i].f_userid.toString() == $scope.peopleID)
                {
                    obj.ispeople = true;
                }
                else
                {
                    obj.ispeople = false;
                }
                //obj.timeisshow = false;
                $scope.fullGdArray.push(obj);

            }
            //$scope.fullGdArray.reverse();
            for(var i = 0;i < $scope.fullGdArray.length;i++){
                    $scope.gdListArray.unshift($scope.fullGdArray[i]);
                    //$("#content").scrollTop($("#content")[0].scrollHeight);
            }
            //$("#content").scrollTop($("#content")[0].scrollHeight);
        }
        timeCheck($scope.gdListArray);
        $scope.m = setTimeout(isDownCheck,500);
        $scope.page = $scope.page+1;
        $scope.fullGdArray = [];
        //isDown = true;
        /*if($scope.gdListArray.length>0)
        {
            for(var i=0;i<$scope.gdListArray.length;i++)
            {
                if(i==0)
                {
                    $scope.gdListArray[i].timeisshow = true;
                    $scope.lasttime = $scope.gdListArray[i].t;
                }else{
                    var timejump = parseInt(timeTrans($scope.gdListArray[i].t)-timeTrans($scope.lasttime));
                    //alert("timejump="+timejump);
                    if(timejump>300000){
                        $scope.gdListArray[i].timeisshow = true;
                        $scope.lasttime = $scope.gdListArray[i].t;
                    }else{
                        $scope.gdListArray[i].timeisshow = false;
                    }
                }
            }
        }*/
        //$("#content").scrollTop($("#content")[0].scrollHeight);
        //myScroll.scrollToElement('div:nth-child('+divNum+')', 200);
    };

    function isDownCheck(){
    	isDown = true;
    	clearTimeout($scope.m);
    }
    //时间显示
    function timeCheck(obj){
        if(obj.length>0)
        {
            for(var i=0;i<obj.length;i++)
            {
                if(i==0)
                {
                    obj[i].timeisshow = true;
                    $scope.lasttime = obj[i].t;
                }else{
                    var timejump = parseInt(timeTrans(obj[i].t)-timeTrans($scope.lasttime));
                    //alert("timejump="+timejump);
                    if(timejump>300000){
                        obj[i].timeisshow = true;
                        $scope.lasttime = obj[i].t;
                    }else{
                        obj.timeisshow = false;
                    }
                }
            }
        }
        //alert("time="+angular.toJson(obj));
    }

    $scope.getgd = function()
    {
        var message = {};
        message['page.pagesize'] = "10";
        message['page.pageno'] = $scope.page;
        message['userid'] = $scope.peopleID;

        console.log("观点列表", message);
        ajaxService.sendMessage("user.selectviewponitandcommentbyuseridaction", message, $scope.gdlistCallBack);
    };

    $scope.getPeopleInfoCallBack = function(_data) {
        //console.log("个人信息", _data);
        if (_data.op.code.toString() == "Y") {
            $scope.peopleInfo = _data.user;
            $scope.peopleName = $scope.peopleInfo.f_nickname;
            $scope.peoplehead = $scope.peopleInfo.f_head;

            $scope.getgd();
        }
    };

    $scope.getPeopleInfo = function()
    {
        var message = {};
        message['user.id'] = $scope.peopleID;
        //console.log($scope.peopleID);
        ajaxService.sendMessage("user.usercheck", message, $scope.getPeopleInfoCallBack) ;
    };

    //初始相关操作界面
    $scope.vpInit = function()
    {
        var localStorage = window.localStorage;
        $scope.sftype = localStorage.getItem("lcsstatus");//当前用户是否是理财师
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }

        $scope.getPeopleInfo();

    };

    $scope.vpInit();

    //发送
    $scope.sendplClick = function(param)
    {
    	$scope.whichClick = param;
        if($scope.tjMark)
        {
        	if(param == "notflower"){
        		if($scope.plcontent == "")
                {
                    myAlert("请输入评论内容");
                    return;
                }
        	}
            $scope.tjMark = false;
            var message = {};
            message['subjectid'] = "0";//观点id
            message['subjectuserid'] = $scope.peopleID;//观点发布者id
            message['userid'] = $scope.userObj.f_id;
            if(param == "flower"){
            	//alert("flower");
            	message['cnt'] = "//flower//";
            }else{
            	message['cnt'] = $scope.plcontent;
            }
            $scope.plcontentstr = message['cnt'];
            console.log("观点列表", message);
            ajaxService.sendMessage("user.addcommentaction", message, $scope.addcommentactionCallBack);
        }
    };
    //评论
    var iscrollCheck = function(){
    	var divlength = $scope.gdListArray.length+1;
    	//alert(divlength);
        myScroll.scrollToElement('div:nth-child('+divlength+')', 200);
        //myScroll.scrollToElement('div:nth-child(10)', 200);
        var top = myScroll.maxScrollY;
    	$("#scroller").css("transform","translate(0px, "+top+"px) scale(1) translateZ(0px)");
    	clearTimeout($scope.t);
    }
    
    $scope.addcommentactionCallBack = function(_data)
    {
    	//alert(angular.toJson(_data));
        //console.log("评论", _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = {};
            obj.name = $scope.userName;
            obj.content = $scope.plcontent;
            obj.isPic = false;
            if($scope.whichClick == "flower"){
            	//alert("sendflower");
            	obj.isPic = true;
            	obj.content = "";
            	obj.isFlower = true;
            	obj.imgSrc = "images/sendflower.png";
            }
            obj.headurl = $scope.headstr;
            if($scope.userObj.f_id.toString() == $scope.peopleID)
            {
                obj.ispeople = true;
            }
            else
            {
                obj.ispeople = false;
            }
            var t = _data.op.timestamp.toString();
            obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
            obj.time = isshowTime(obj.t);
            obj.timeisshow = false;
            $scope.gdListArray.push(obj);
            //$("#content").scrollTop($("#content")[0].scrollHeight+45);
            //myScroll.scrollToElement('div:nth-child('+divNum+')', 200);
            //$scope.tjMark = true;
            newInsert++;

            if($scope.gdListArray.length == 1)
            {
                $scope.gdListArray[$scope.gdListArray.length-1].timeisshow = true;
                $scope.lasttime = $scope.gdListArray[$scope.gdListArray.length-1].t;
            }
            else
            {
                var timejump = parseInt(timeTrans($scope.gdListArray[$scope.gdListArray.length-1].t)-timeTrans($scope.lasttime));
                //alert("timejump="+timejump);
                if(timejump>300000){
                    $scope.gdListArray[$scope.gdListArray.length-1].timeisshow = true;
                    $scope.lasttime = $scope.gdListArray[$scope.gdListArray.length-1].t;
                }else{
                    $scope.gdListArray[$scope.gdListArray.length-1].timeisshow = false;
                }
            }

            if(checkisFlower($scope.plcontentstr) == true)//不是花等图标
            {
                $scope.plcontent = "";
            }
        }
        else
        {
            myAlert("评论失败，原因" + _data.op.info);
        }
        $("#content").scrollTop($("#content")[0].scrollHeight);
        //
        myScroll.refresh();
        //var divlength = $scope.gdListArray.length+1;
        //myScroll.scrollToElement('div:nth-child('+divlength+')', 200);
        //alert("top2="+top);
        //alert(divlength);
        //$.scrollTo('#'+divlength,200);
        var top = myScroll.maxScrollY;
    	$("#scroller").css("transform","translate(0px, "+top+"px) scale(1) translateZ(0px)");
        $scope.tjMark = true;
        $scope.plcontentstr = "";
        $scope.t = setTimeout(iscrollCheck,500);
    };
    
    //开户返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    };

    
    

    //input获取焦点时页面滚动到最底部
    $scope.inputfocus = function(){
    	var cm = cHeight-95;
    	if(isDown&&(myScroll.maxScrollY>cm))
    	{
    		var top = myScroll.maxScrollY;
        	//alert(top);
        	$("#scroller").css("transform","translate(0px, "+top+"px) scale(1) translateZ(0px)");
    	}
    };
    
    //点击显示大图
    $scope.bigPic = function(url){
    	//if(url != "images/sendflower.png"){
        //$scope.gdtposition = $('#scroller').scrollTop();
        console.log("222", url);
        if(url != "" && url != undefined && url != null)
        {

    		$scope.bigPicUrl = url;
    		var img = new Image();
    		img.src = url;
    		var windowHeight = window.innerHeight;
    		var windowWidth = window.innerWidth;
    		var leftmove = img.width;
    		var topmove = img.height;
    		$('#imgPs').css({"height":img.height});
    		$('#imgPs').css({"width":img.width});
    		var changeHeight = img.height;
    		var top = 0;
    		var left = 0;
    		console.log("windowwith="+windowWidth+"windowheight="+windowHeight+"imgw"+img.width+"imgh="+img.height);
    		/*if(windowHeight<img.height){
    			$('#imgPs').css({"height":windowHeight});
    			leftmove = img.width*(windowHeight/img.height);
    			//var left = (windowWidth-img.width)/2;
    			left = (windowWidth-leftmove)/2;
    			top = 0;
    		}else*/

        if(windowWidth<img.width)
        {
            $('#imgPs').css({"width":"100%"});
            changeHeight = img.height*(windowWidth/img.width);
            //topmove = img.height*(windowWidth/img.width);
            //top = (windowHeight-topmove)/2;
            //left = 0;
            //var top = (windowHeight-img.height)/2;
        }
        else
        {
            $('#imgPs').css({"width":"auto"});
        }
    		if(windowHeight>img.height)
            {
    			$('#imgPs').css({"height":"auto"});
    			//topmove = img.height*(windowWidth/img.width);
    			//top = (windowHeight-topmove)/2;
    			//left = 0;
    			//var top = (windowHeight-img.height)/2;
                var margin = (windowHeight-changeHeight)/2;
                $('#imgPs').css({"margin-top":margin});
    		}
            else
            {
                $('#imgPs').css({"height":windowHeight});
                $('#imgPs').css({"margin-top":0});
            }

        //
        //
        //console.log(windowHeight, img.height);
        //
        //
        //console.log(margin);
        //

                
    		//$('#imgPs').css({"top":top,"left":left});

            //$scope.bigPicShow = true;
            //$scope.mainShow = false;

    	}
    	
    };
    //点击关闭大图
    $scope.closePic = function(){
        //$scope.bigPicShow = false;
        //$scope.mainShow = true;
        //console.log($scope.gdtposition);
        //$("#scroller").css("transform","translate(0px, "+$scope.gdtposition+"px) scale(1) translateZ(0px)");
    };
    
}



