﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */


function optionalBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.applyforFPshow = false;//是否可申请理财师
    $scope.userObj = {};//客户信息
    $scope.zxlistDivShow = true;//自选股列表
    $scope.stockDiv = false;//股票搜索

    $scope.allSearchStockListArray = [];//搜索出的股票列表数组
    $scope.searchStockValue = "";//搜索输入框内容
    $scope.confirmEnable = true;//提交中，不可再操作
    $scope.oneStockInfo = {};//当前添加的自选股
    $scope.zxgintervalId;
    $scope.zxgintervalDuration = 5000;//间隔时间，3000毫秒
    $scope.websocketurl = {};//websocket地址
    $scope.cookiezxgList = [];//存放入cookie的自选股列表

    $scope.stocklist = [];
    $scope.order = "0";//0-不排序 1-升序 2-降序
    $scope.orderobj = "";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

    $scope.oneStockHQBaseShow = false;//股票
    $scope.indexbaseShow = false;//指数
    $scope.dqxzstock = {};//当前选中
    $scope.zxgztShow = false;//自选股状态是否显示供操作

    $scope.zxggksetStatus = "N";//自选股是否公开 公开：Y；不公开：N
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    //去除
    $scope.optionhqthisClearInterval = function () {
        if ($scope.zxgintervalId != undefined) {
            clearInterval($scope.zxgintervalId);
        }
    }

    $scope.getSelfStock =function()
    {
        //console.log("自选股列表：", $scope.userObj.f_id);
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        message["ordeCol"] = "";
        message["ordeBy"] = "";

        ajaxService.sendMessage("hq.getzxghqaction",message,function(_data)
        {
            //console.log("自选股列表：" + _data);
            $scope.stocklist = [];
            $scope.cookiezxgList = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.data;
                console.log(arr);
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.index = i;
                    obj.asset = arr[i].asset;//类型
                    obj.gpdm = arr[i].symbol;
                    obj.zqjc = arr[i].name;
                    obj.exchange = arr[i].exchange.toString();
                    obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                    obj.zxj = parseFloat(arr[i].price.toString());
                    obj.status = arr[i].stockstatus.toString();
                    //console.log("状态：" + arr[i].stockstatus.toString())
                    obj.xzzt = "1";//选中状态，样式更改
                    obj.zd = parseFloat(arr[i].zd.toString());
                    obj.zdf = parseFloat(arr[i].zdf.toString());
                    //if (obj.status == '3')
                    //{
                    //    obj.zdf = -10000;
                    //    obj.zd = -10000;
                    //}
                    var obj2 = {};
                    obj2.tc =  obj.tc;
                    $scope.cookiezxgList.push(obj2);
                    $scope.stocklist.push(obj);
                }
            }
            $scope.optionhqthisClearInterval();
            $scope.zxgintervalId = setInterval($scope.getSelfStock, $scope.zxgintervalDuration);
        })
    }

    $scope.getzxglist =function()
    {
        //console.log("自选股列表：", $scope.userObj.f_id);
        var message = {};
        message["userid"] = $scope.userObj.f_id;
        message["ordeCol"] = "";
        message["ordeBy"] = "";

        ajaxService.sendMessage("hq.getzxghqaction",message,function(_data)
        {
            //console.log("自选股列表：" + _data);
            $scope.cookiezxgList = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.data;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj2 = {};
                    obj2.tc =  arr[i].exchange.toString().toUpperCase() + arr[i].symbol;
                    $scope.cookiezxgList.push(obj2);
                }
            }
            var localStorage = window.localStorage;
            localStorage.setItem("cookiezxgList", JSON.stringify($scope.cookiezxgList));
            //$cookieStore.put('cookiezxgList', $scope.cookiezxgList);
        })
    }

    $scope.getzxgszztCallBack = function(_data)
    {
        console.log("自选股状态：" + _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}

        if(_data.op.code.toString() == "Y")
        {
            if(_data.gkzxg.toString() == "Y")
            {
                $scope.zxggksetStatus = true;
            }
            else
            {
                $scope.zxggksetStatus = false;
            }
        }
        $scope.zxgztShow = true;
    }

    $scope.getzxgszzt = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getzxggkset", message, $scope.getzxgszztCallBack) ;
    }


    $scope.opinit = function()
    {
        //$scope.userObj = $cookieStore.get('user');
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        //$scope.userObj.f_id = "3";
        $scope.getSelfStock();
        $scope.getzxglist();//存cookie
        //自选股设置的状态
        $scope.getzxgszzt();
    }

    $scope.opinit();

    //自选股公开设置
    $scope.zxggksetStatusClick = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        var str = "";
        if($scope.zxggksetStatus)
        {
            str = "N";
        }
        else
        {
            str = "Y";
        }
        message['gk'] = str;
        ajaxService.sendMessage("sunflower.p_setzxggk", message, $scope.setzxgszztCallBack) ;

    }

    $scope.setzxgszztCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            $scope.zxggksetStatus = !$scope.zxggksetStatus;
        }
        else
        {
            myAlert("设置失败");
        }
    }


    $scope.sortStock = function (obj)
    {
        if($scope.orderobj == "")//初始化，未排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else if($scope.orderobj == "+index")//回复原数据排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else
        {
            var str = obj.substr(0,1);//取出符号 ：+ ，-
            obj = obj.substr(1, obj.length-1);
            if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
            {
                if($scope.order == "1")//升序
                {
                    $scope.orderobj = "+index"; //下标升序
                    $scope.order = "0";//回复原序列
                }
                else if($scope.order == "2")
                {
                    $scope.orderobj = "+" + obj;
                    $scope.order = "1";//升序
                }
                else
                {
                    $scope.orderobj = "-" + obj;
                    $scope.order = "2";//降序
                }
            }
            else//不同排序字段
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        }

    }

    //进入自选股添加界面
    $scope.zxgnewClick = function()
    {
        $scope.zxlistDivShow = false;
        $scope.stockDiv = true;
        $scope.allSearchStockListArray = [];
        $scope.searchStockValue = "";
        $scope.optionhqthisClearInterval();
    }

    //返回自选股列表
    $scope.closeaddStockDiv = function()
    {
        $scope.zxlistDivShow = true;
        $scope.stockDiv = false;
        $scope.allSearchStockListArray = [];
        $scope.searchStockValue = "";
        $scope.getSelfStock();
    }

    //股票搜索框改变
    $scope.searchinputChange = function()
    {
        if($scope.searchStockValue != "")
        {
            $scope.checkContent();
        }
        else
        {
            $scope.allSearchStockListArray = [];
        }
    }

    //判断并显示搜索股票
    $scope.checkContent = function()
    {
        //匹配
        //ajaxService.searchStock($scope.searchStockValue, $scope.searchStockCallBack);
        var message = {};
        message['key'] = $scope.searchStockValue.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        //message['stockcode'] = $scope.searchStockValue;
        //console.log($scope.searchStockValue)
        //ajaxService.sendMessage('model.getStockcodeListAction', message, $scope.searchStockCallBack);
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.searchStockCallBack);

    }
    //搜索股票返回
    $scope.searchStockCallBack = function(_data)
    {
        //console.log("搜索");
        //console.log(_data);
        $scope.allSearchStockListArray = [];
        if($scope.searchStockValue == "")
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.searchStockValue.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数，5：基金
                        obj.gpdm = element[i]['symbol'].toString();
                        //var p = /\s+/g;
                        //var namestr = element[i]['name'].toString();
                        //namestr = namestr.replace(p, "");

                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        //obj.dqj = (parseFloat(element[i]['now'].toString())).toFixed(2);//当前价
                        //obj.zdf = (parseFloat(element[i]['zdf'].toString())).toFixed(2);//涨跌幅
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "4" || obj.asset == "5") {
                            arr.push(obj);
                        }
                    }
                    $scope.allSearchStockListArray = arr;
                }
                else {
                    $scope.allSearchStockListArray = [];
                    return;
                }
            }
        }
        else
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        for(var i = 0;i<$scope.allSearchStockListArray.length;i++)
        {
            var mark = false;
            for(var j = 0;j<$scope.stocklist.length;j++)
            {
                if($scope.stocklist[j].tc == $scope.allSearchStockListArray[i].tc)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == true)//已经存在  0：未加，1：已加
            {
                $scope.allSearchStockListArray[i].status = "1";
                $scope.allSearchStockListArray[i].statusstr = "已添加";
            }
            else
            {
                $scope.allSearchStockListArray[i].status = "0";
                $scope.allSearchStockListArray[i].statusstr = " 添加";
            }
        }
    }

    //添加一只股票
    $scope.addOneStockClick = function(_obj)
    {
        if(_obj.status == "0")
        {
            if($scope.confirmEnable)
            {
                $scope.confirmEnable = false;
                $scope.oneStockInfo = _obj;

                var message = {};
                message['exchange'] = _obj.exchange;
                message['symbol'] = _obj.gpdm;
                message['source'] = "xrk";
                message['userid'] = $scope.userObj.f_id;
                //console.log(message['exchange'], message['symbol'], message['source'], message['userid']);
                ajaxService.sendMessage('hq.addzxgaction', message, $scope.addSelfStockActionCallBack);
            }
        }
    }

    $scope.addSelfStockActionCallBack = function(_data)
    {
        //console.log("添加自选股", _data);
        if(_data.op.code.toString() == "Y")
        {
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if($scope.oneStockInfo.tc == $scope.allSearchStockListArray[i].tc)
                {
                    $scope.allSearchStockListArray[i].status = "1";
                    $scope.allSearchStockListArray[i].statusstr = "已添加";
                    $scope.oneStockInfo.index = $scope.stocklist.length;
                    $scope.stocklist.push($scope.oneStockInfo);
                    break;
                }
            }
        }
        var obj2 = {};
        obj2.tc = $scope.oneStockInfo.tc;
        $scope.zxglist.push(obj2);
        var localStorage = window.localStorage;
        localStorage.setItem("cookiezxgList", JSON.stringify($scope.zxglist));

        //$cookieStore.put('cookiezxgList', $scope.zxglist);

        $scope.confirmEnable = true;
        $scope.oneStockInfo = {};
    }

    //个股
    $scope.ggClick = function(_obj)
    {
        _obj.xzzt = "0";
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = _obj.asset;
        obj.back = "zxglist";
        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        //window.location.href = "oneStockHQBase.html";

        $scope.dqxzstock = obj;

        $scope.optionhqthisClearInterval();
        $scope.zxlistDivShow = false;
        if(_obj.asset == "0" || _obj.asset == "5")//股票
        {
            $scope.oneStockHQBaseShow = true;
        }
        else
        {
            $scope.indexbaseShow = true;
        }
        gotoUp();

    }

    $scope.onestockhqbaseBacktoggList = function()
    {
        $scope.oneStockHQBaseShow = false;
        $scope.zxlistDivShow = true;
        $scope.dqxzstock = null;
        $scope.getSelfStock();
    }

    $scope.onestockhqbaseBacktoSearchList = function()
    {
        $scope.oneStockHQBaseShow = false;
        $scope.stockDiv = true;
        $scope.dqxzstock = null;

        for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
        {
            if($scope.allSearchStockListArray[i].xzzt == "0")
            {
                $scope.allSearchStockListArray[i].xzzt = "1";
                break;
            }
        }
    }

    //添加自选股界面
    $scope.addzxgItmeClick = function(_obj)
    {
        _obj.xzzt = "0";
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = _obj.asset;
        obj.back = "searchlist";

        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        //window.location.href = "oneStockHQBase.html";
        $scope.dqxzstock = obj;
        $scope.optionhqthisClearInterval();
        $scope.stockDiv = false;
        if(_obj.asset == "0" || _obj.asset == "5" )//股票
        {
            $scope.oneStockHQBaseShow = true;
        }
        else
        {
            $scope.indexbaseShow = true;
        }
        gotoUp();
    }

    //大盘指数返回
    $scope.indexbaseBackto = function()
    {
        //console.log("大盘指数返回");
        $scope.indexbaseShow = false;
        if($scope.dqxzstock.back == "zxglist")
        {
            $scope.zxlistDivShow = true;
            $scope.getSelfStock();
        }
        else
        {
            $scope.stockDiv = true;
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if($scope.allSearchStockListArray[i].xzzt == "0")
                {
                    $scope.allSearchStockListArray[i].xzzt = "1";
                    break;
                }
            }
        }
        $scope.dqxzstock = null;
    }

    //自选股返回
    $scope.zsgback = function ()
    {
        //window.location.href = "uufpBase.html?baseindex=4";
        //window.location = getbackList();
        //window.location.href = "back";
        closeNewBrowser();
    }
}







