/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */

function addNewStockPoolCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.firstshow = true;//创建组合第一步显示
    $scope.secondshow = false;//第二步
    $scope.stocklistArray = [];//当前新建股票池添加的股票
    $scope.userObj = {};//客户信息
    $scope.createInfo = "";//创建时提示信息
    $scope.mxgksetStatus = false;//模型是否公开

    $scope.stockDiv = false;//搜索股票Div
    $scope.changePositionReasonShow = false;//调仓说明

    $scope.newPoolName = "";//新建股票池名称
    $scope.newPoolStrategy = "";//新建股票池策略
    $scope.newPoolID = "";//新建股票池的ID
    $scope.tcID = "";//调仓ID,调仓说明用
    //$scope.newPoolMoney = 0;//新建股票池金额

    $scope.qdjctsChooseShow = false;//是否建仓弹出提示

    $scope.hcsValue = "私密";//私密：private；好友公开：protected；完全公开：public
    $scope.allSearchStockListArray = [];//搜索出的股票列表数组
    $scope.searchStockValue = "";//搜索输入框内容
    $scope.changeStockZBShow = false;//修改占比界面显示
    $scope.changePositionDesc = "";//调仓说明
    $scope.oldzb = 0.00;//修改前占比
    $scope.oneStockInfo = null;//当前操作股票
    $scope.oneStockPoolPercent = 0.00;//当前股票池的总比例
    $scope.oldStockPoolPercent = 0.00;//当前股票池的剩余总比例，调整不改变，显示用
    $scope.stockPoolPercentChangeShow = false;//是否显示改变
    $scope.stockPoolPercentChangeValue = ""; //股票池的剩余总比例变化区间;

    $scope.confirmEnable = true;//是否能提交创建请求

    $scope.voteforCombinationArray = [];//跟投组合
    $scope.createdStockPool = [];//当前自己创建的股票组合//$scope.listArr

    $scope.secondoneShow = false;//进入调仓界面
    $scope.secondtwoShow = false;//添加股票后界面
    $scope.secondthreeShow = false;//调仓后是否填入调仓说明界面

    $scope.addstockInfo = "";//添加股票时提示
    $scope.changePositionDesc = "";//调仓说明
    $scope.tcsmInfo = "";//调仓说明错误提示

    $scope.tcDivShow = true;//调仓是否给操作

    //$scope.userObj = $cookieStore.get('user');
    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));

    //-0.00改为0.00
    $scope.changeValue = function(_str)
    {
        var str = "";
        if(_str == "-0.00")
        {
            str = "0.00";
        }
        else
        {
            str = _str;
        }
        return str;
    }

    //返回组合列表
    $scope.addNewBack = function()
    {
        //window.location.href = getParameter('backurl');
        window.location = getbackList();
    }

    //模型是否公开
    $scope.mxgksetStatusClick = function()
    {
        $scope.mxgksetStatus = !$scope.mxgksetStatus;
    }

    //新建股票池
    $scope.newStockPoolConfirm = function()
    {
        if($scope.newPoolName == "")
        {
            $scope.createInfo = "请输入股票池名称";
            return;
        }
        if($scope.newPoolName.length>8)
        {
            $scope.createInfo = "好名字不超过8个字，请重新输入";
            return;
        }
        if($scope.confirmEnable)
        {
            $scope.createInfo = "提交中，请稍候...";
            //提交股票池信息
            $scope.confirmStockPool();
        }
        else
        {
            $scope.createInfo = "提交中，请稍候...";
        }
    }
    //提交股票池信息
    $scope.confirmStockPool = function()
    {
        $scope.confirmEnable = false;//提交中，不可再操作
        //var str = "";
        //for(var i = 0;i<$scope.stocklistArray.length;i++)
        //{
        //    if(i == 0)
        //    {
        //        str = $scope.stocklistArray[i].gpdm + "," + ($scope.stocklistArray[i].newzb/100).toFixed(2);
        //    }
        //    else
        //    {
        //        str = str + ";" + $scope.stocklistArray[i].gpdm + "," + ($scope.stocklistArray[i].newzb/100).toFixed(2);
        //    }
        //
        //}
        //console.log(str);
        //创建股票池
        var message = {};
        message['poolname'] = $scope.newPoolName;
        message['policydesc'] = $scope.newPoolStrategy;
        message['positions'] = "";
        message['userid'] = $scope.userObj.f_id;
        var propertyStr = "";
        if($scope.hcsValue == "私密")
        {
            propertyStr = "private";
        }
        else if($scope.hcsValue == "好友公开")
        {
            propertyStr = "protected";
        }
        else
        {
            propertyStr = "public";
        }
        message['property'] = propertyStr;
        //console.log("property", propertyStr);
        ajaxService.sendMessage('sunflower.p_addmodel', message, $scope.addmystockpoolCallBack);

        //$scope.addNewTwo();
    }

    $scope.addmystockpoolCallBack = function(_data)
    {
        //console.log("45354");
        console.log(_data);
        if(_data.op.code.toString() == "Y")//添加成功
        {
            $scope.newPoolID = _data.modelid.toString();
            if($scope.mxgksetStatus)//设置公开
            {
                var message = {};
                message['userid'] = $scope.userObj.f_id;
                message['modelid'] = $scope.newPoolID;
                message['gk'] = "Y";
                ajaxService.sendMessage("sunflower.p_setmodelgk", message, $scope.p_setmodelgkCallBack) ;
            }
            else
            {
                $scope.addNewTwo();
                $scope.confirmEnable = true;//不公开
            }

        }
        else
        {
            $scope.createInfo = "创建失败，原因：" + _data.op.info;
            $scope.confirmEnable = true;
        }

    }

    $scope.p_setmodelgkCallBack = function(_data)
    {
        //if (_data.op.code.toString() != "Y")
        //{
        //
        //}
        $scope.addNewTwo();
        $scope.confirmEnable = true;//不公开
    }


    //创建组合第二步
    $scope.addNewTwo = function()
    {
        $scope.confirmEnable = true;
        $scope.firstshow = false;
        $scope.secondshow = true;
        $scope.secondoneShow = true;
        $scope.secondtwoShow = false;
        $scope.secondthreeShow = false;
        $scope.oneStockPoolPercent = 100.00;
        $scope.oldStockPoolPercent = 100.00;
        $scope.stockPoolPercentChangeShow = false;
        $scope.stockPoolPercentChangeValue = "";
        $scope.addstockInfo = "";
        $scope.tcID = "";
        $scope.tcDivShow = true;

        $scope.stocklistArray = [];

        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }
    //返回第一步
    $scope.addNewTwoBack = function()
    {
        $scope.firstshow = true;
        $scope.secondshow = false;
        $scope.secondoneShow = true;
        $scope.secondtwoShow = false;
        $scope.secondthreeShow = false;
    }

    //显示添加股票Div
    $scope.addStockClick = function()
    {
        $scope.secondshow = false;
        $scope.stockDiv = true;
        $scope.addstockInfo = "";
    }

    //关闭股票添加Div
    $scope.closeaddStockDiv = function()
    {
        $scope.secondshow = true;
        $scope.stockDiv = false;
        //情况搜索输入框
        $scope.allSearchStockListArray = [];
        $scope.searchStockValue = "";
        $scope.addstockInfo = "";
    }

    //股票搜索框改变
    $scope.searchinputChange = function()
    {
        if($scope.searchStockValue != "")
        {
            $scope.checkContent();
        }
        else
        {
            $scope.allSearchStockListArray = [];
        }
    }

    //判断并显示搜索股票
    $scope.checkContent = function()
    {
        //匹配
        //ajaxService.searchStock($scope.searchStockValue, $scope.searchStockCallBack);
        var message = {};
        message['key'] = $scope.searchStockValue.toUpperCase();
        message['isprice'] ="price";
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.searchStockCallBack);
    }

    //搜索股票返回
    $scope.searchStockCallBack = function(_data)
    {
        //console.log("搜索");
        //console.log(_data);
        if($scope.searchStockValue == "")
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.searchStockValue.toUpperCase()) {
                var element = _data.data;
                if (element.length > 0) {
                    var arr = [];
                    for (var item in element) {
                        var obj = {};
                        obj.asset = element[item]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[item]['symbol'];
                        obj.gpmc = element[item]['name'];
                        obj.market = element[item]['exchange'].toUpperCase();//交易所
                        obj.label = obj.market + obj.gpdm;
                        obj.dqj = (parseFloat(element[item]['price'].toString())).toFixed(2);//当前价
                        obj.zdf = (parseFloat(element[item]['zdf'].toString())).toFixed(2);//涨跌幅
                        if(obj.asset == "0")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.allSearchStockListArray = arr;
                }
                else {
                    $scope.allSearchStockListArray = [];
                    return;
                }
            }
        }
        else
        {
            $scope.allSearchStockListArray = [];
            return;
        }
        for(var i = 0;i<$scope.allSearchStockListArray.length;i++)
        {
            var mark = false;
            for(var j = 0;j<$scope.stocklistArray.length;j++)
            {
                //if($scope.stocklistArray[j].gpdm == $scope.allSearchStockListArray[i].gpdm && $scope.stocklistArray[j].market == $scope.allSearchStockListArray[i].market)
                if($scope.stocklistArray[j].label == $scope.allSearchStockListArray[i].label)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == true)//已经存在  0：未加，1：已加
            {
                $scope.allSearchStockListArray[i].status = "1";
                $scope.allSearchStockListArray[i].statusstr = "已添加";
            }
            else
            {
                $scope.allSearchStockListArray[i].status = "0";
                $scope.allSearchStockListArray[i].statusstr = " 添加";
            }
        }
    }

    //添加一只股票
    $scope.addOneStockClick = function(_obj)
    {
        //console.log(obj);
        if(_obj.status == "0")
        {
            //在当前股票池列表中添加此股票
            for(var i= 0; i< $scope.allSearchStockListArray.length;i++)
            {
                if(_obj.label == $scope.allSearchStockListArray[i].label)
                {
                    //股票池股票更新
                    var obj = new Object();
                    //obj = $scope.allSearchStockListArray[i];
                    obj.gpdm = $scope.allSearchStockListArray[i].gpdm;
                    obj.gpmc = $scope.allSearchStockListArray[i].gpmc;
                    obj.label = $scope.allSearchStockListArray[i].label;
                    obj.market = $scope.allSearchStockListArray[i].market;
                    obj.zb = 0.00;//占比
                    obj.zbstr = obj.zb.toFixed(2);
                    obj.changezbstr = "";
                    obj.changeShow = false;//是否显示调整值;
                    obj.newzb = 0.00;//调整后的占比
                    obj.newzbstr = "0.00";
                    obj.selectValue = $scope.getSelectValue(obj.newzb);//$scope.zbarr;//可选择区间数组

                    //$scope.allSearchStockListArray[i].statusBoolean = true;
                    //console.log($scope.allSearchStockListArray[i].statusBoolean)
                    $scope.allSearchStockListArray[i].status = "1";
                    $scope.allSearchStockListArray[i].statusstr = "已添加";
                    obj.dqj = $scope.allSearchStockListArray[i].dqj;//当前价
                    obj.zdf = $scope.allSearchStockListArray[i].zdf;//涨跌幅

                    //console.log("当前价", obj.dqj, obj.zdf)
                    $scope.stocklistArray.push(obj);
                    break;
                }
            }
        }

        if($scope.secondoneShow && $scope.stocklistArray.length>0)
        {
            $scope.secondoneShow = false;
            $scope.secondtwoShow = true;
            $scope.secondthreeShow = false;
        }
    };

    //取消添加股票
    $scope.cancelClick = function()
    {
        $scope.secondoneShow = true;
        $scope.secondtwoShow = false;
        $scope.secondthreeShow = false;

        $scope.stocklistArray = [];
        $scope.oneStockPoolPercent = 100.00;
        $scope.stockPoolPercentChangeShow = false;
        $scope.stockPoolPercentChangeValue = "";
        $scope.addstockInfo = "";
        $scope.tcID = "";
    }

    //确定添加股票
    $scope.qdAddStockClick = function()
    {
        if($scope.stocklistArray.length<=0)
        {
            $scope.addstockInfo = "请调入股票";
            return;
        }
        if($scope.confirmEnable)
        {
            var mark = false;
            for(var i = 0;i<$scope.stocklistArray.length;i++)
            {
                var str = $scope.stocklistArray[i].newzb.toString();
                if(str.length>0)
                {
                    var str2 = str.substr(0,1);
                    if( str2 == "0" ||  str2 == " ")
                    {
                        mark = true;
                        break;
                    }
                }
            }
            if(mark)//有为0的
            {
                //var str = "持仓中占比为0的股票将被移除，确定继续吗？"
                $scope.qdjctsChooseShow = true;//显示提示
                //if(confirm(str))//确定创建
                //{
                //    //去掉占比为0的股票
                //    var arr = new Array();
                //    for(var i = 0;i<$scope.stocklistArray.length;i++)
                //    {
                //        var str = $scope.stocklistArray[i].newzb.toString();
                //        if(str.length>0)
                //        {
                //            var str2 = str.substr(0,1);
                //            if( str2 != "0" &&  str2 != " ")
                //            {
                //                arr.push($scope.stocklistArray[i]);
                //                break;
                //            }
                //        }
                //    }
                //    $scope.stocklistArray = arr;
                //    if($scope.stocklistArray.length>0)
                //    {
                //        //提交股票池信息
                //        $scope.submitStocklist();
                //    }
                //    else
                //    {
                //        $scope.addstockInfo = "移除持仓中占比为0的股票后持仓为空，请重新添加";
                //    }
                //}
            }
            else
            {
                //提交股票池信息
                $scope.submitStocklist();
            }
        }
        else
        {
            $scope.addstockInfo = "提交中，请稍候...";
        }
    }

    $scope.surejxClick = function()
    {
        $scope.qdjctsChooseShow = false;
            //去掉占比为0的股票
        var arr = new Array();
        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            var str = $scope.stocklistArray[i].newzb.toString();
            if(str.length>0)
            {
                var str2 = str.substr(0,1);
                if( str2 != "0" &&  str2 != " ")
                {
                    arr.push($scope.stocklistArray[i]);
                    break;
                }
            }
        }
        $scope.stocklistArray = arr;
        if($scope.stocklistArray.length>0)
        {
            //提交股票池信息
            $scope.submitStocklist();
        }
        else
        {
            $scope.addstockInfo = "移除持仓中占比为0的股票后持仓为空，请重新添加";
        }
    }

    $scope.canceljxClick = function()
    {
        $scope.qdjctsChooseShow = false;
    }

    //提交股票池
    $scope.submitStocklist = function()
    {
        $scope.addstockInfo = "提交中，请稍候...";

        var str2 = "";
        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            if(i == 0)
            {
                str2 = $scope.stocklistArray[i].gpdm + "," + ($scope.stocklistArray[i].newzb/100).toFixed(2);
            }
            else
            {
                str2 = str2 + ";" + $scope.stocklistArray[i].gpdm + "," + ($scope.stocklistArray[i].newzb/100).toFixed(2);
            }
        }

        //更新股票池信息
        var message = {};
        message['modelid'] = $scope.newPoolID;
        message['positions'] = str2;
        message['desc'] = "";//调仓说明
        ajaxService.sendMessage('model.changepositionaction', message, $scope.completeSubmitStock)
    }

    //更新股票池信息
    $scope.completeSubmitStock = function(_data)
    {
        console.log(_data)
        if(_data.op.code.toString() == "Y")//调仓成功
        {
            //调仓成功
            $scope.tcDivShow = false;




            $scope.tcID = _data.modelchangerecordid.toString();
            $scope.addstockInfo = "";
            $scope.secondoneShow = false;
            $scope.secondtwoShow = false;
            $scope.secondthreeShow = true;
        }
        else
        {
            $scope.addstockInfo = "调仓失败，请重试";
        }
        $scope.confirmEnable = true;
    }

    //调仓说明
    $scope.tcsmClick = function()
    {
        $scope.secondshow = false;
        $scope.changePositionReasonShow = true;
        $scope.changePositionDesc = "";
        $scope.tcsmInfo = "";
    }

    //调仓说明返回
    $scope.closechangePositionReasonDiv = function()
    {
        $scope.secondshow = true;
        $scope.changePositionReasonShow = false;
        $scope.changePositionDesc = "";
        $scope.tcsmInfo = "";
    }

    $scope.confirmtcsm =  function()
    {
        if($scope.changePositionDesc == "")
        {
            $scope.tcsmInfo = "请输入调仓说明";
        }
        else
        {
            //提交
            //更新股票池信息
            $scope.tcsmInfo = "";
            var message = {};
            message['id'] = $scope.tcID;
            message['desc'] = $scope.changePositionDesc;//调仓说明
            ajaxService.sendMessage('model.updatemodelchangerecordaction', message, $scope.updatemodelchangerecordactionCallBack);

        }
    }

    $scope.updatemodelchangerecordactionCallBack = function(data)
    {
        if(data.op.code.toString() == "Y")
        {
            //提交完成后返回
            $scope.closechangePositionReasonDiv();
        }
        else
        {
            $scope.tcsmInfo = "调仓说明提交失败，请重试";
        }
    }



    //返回可选择的区间
    $scope.getSelectValue = function(_data)
    {
        var arr = [];
        var n = Math.floor($scope.oneStockPoolPercent + _data);
        for(var i = 0;i<=n;i++)
        {
            var obj = {};
            obj.value = i;
            arr.push(obj);
        }
        return arr;
    };

    //改变占比
    $scope.selectChange = function(_obj)
    {
       // console.log(_obj.selectedIndex);
        _obj.changeShow = false;//是否显示调整值;
        $scope.oldzb = _obj.newzb;
       // console.log(_obj.zbstr)
        //var newzb = parseFloat(document.getElementById('newzbstr').value);
        var newzb = parseFloat(_obj.newzbstr);

        _obj.newzb = newzb;
        _obj.changezbstr = (parseFloat(_obj.zb.toString())).toFixed(2) + "%→"+  newzb.toFixed(2) + "%";
        //alert(_obj.changezbstr);
        _obj.changeShow = true;//是否显示调整值;
        //$scope.$apply($scope.stocklistArray);
        var n =  newzb - $scope.oldzb;
        $scope.oneStockPoolPercent = parseFloat(($scope.oneStockPoolPercent - n).toFixed(2));
        $scope.stockPoolPercentChangeShow = true;
        $scope.stockPoolPercentChangeValue = $scope.oldStockPoolPercent.toFixed(2)+"% → " + $scope.oneStockPoolPercent.toFixed(2) + "%";

        for(var i = 0;i<$scope.stocklistArray.length;i++)
        {
            //console.log($scope.oneStockPoolPercent);
            //console.log($scope.stocklistArray[i].newzb);
            $scope.stocklistArray[i].selectValue = $scope.getSelectValue($scope.stocklistArray[i].newzb)///可选择区间数组
        }
    };

    //完成
    $scope.finishedClick = function()
    {
        $scope.secondshow = false;
        $scope.newPoolName = "";
        $scope.newPoolStrategy = "";
        $scope.newPoolID = "";
        $scope.tcID = "";
        $scope.stocklistArray = [];
        $scope.secondoneShow = false;
        $scope.secondtwoShow = false;
        $scope.secondthreeShow = false;
        $scope.tcDivShow = true;
        $scope.addNewBack();
    }

}