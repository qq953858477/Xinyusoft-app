
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function tradingliveCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.headstr = "";//当前用户
    $scope.firstheadshow = true;

    $scope.tabOneShow = true;//交易直播
    $scope.tabTwoShow = false;//评论

    $scope.plCount = "";//评论数量
    $scope.subjectid = "-100";//交易播报评论的id
    $scope.subjecttype = "yhjybb";//交易播报评论的type
    $scope.hasReadNum = 0;//用户已读信息
    $scope.plingMark = true;//评论中
    $scope.plcontentstr = "";//当前在发送的评论内容
    $scope.plListArray = [];

    $scope.opentype = "";//打开类型
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    $scope.isFlower = false;
    $scope.imgSrc = "";
    $scope.whichClick = "";//发送图片或者文字

    $scope.sftype = "";
    $scope.page = 1;

    $scope.startnyr = "";
    $scope.startdate = "";
    $scope.enddate = "";

    $scope.plcontent = "";//内容
    $scope.lasttime = "20151101000000";//上一次显示的时间;
    $scope.t = "";
    $scope.m = "";
    var newInsert = 0;
    //var cHeight = $('body').height()-95;
    var cHeight = $('body').height();//获取当前页面的高度
    $("#content").height(cHeight-50);//设置评论div的高度




    //开户返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    };

    //input获取焦点时页面滚动到最底部
    $scope.inputfocus = function(){
    	var cm = cHeight-50;
    	if(isDown&&(myScroll.maxScrollY>cm))
    	{
    		var top = myScroll.maxScrollY;
        	//alert(top);
        	$("#scroller").css("transform","translate(0px, "+top+"px) scale(1) translateZ(0px)");
    	}
    };

    $scope.drjybbArray = [];//当日交易播报

    $scope.getlcsjybbCallBack = function(_data)
    {
        console.log("232", _data);
        $scope.drjybbArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.traderecord;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.headurl = arr[i].userhead;
                obj.name = arr[i].username;
                obj.productname = arr[i].productname;
                obj.stockcode = arr[i].code;
                obj.stockname = arr[i].stockname;
                obj.exchange = arr[i].exchange;
                obj.timestr = arr[i].cjsj;
                obj.cjj = parseFloat(arr[i].cjjj).toFixed(2) + "元";//成交价
                obj.cjsl = arr[i].cjsl + "股";//成交数量
                obj.type = arr[i].side;//委托类型
                obj.account = arr[i].account;

                $scope.drjybbArray.push(obj);
            }
        }

    }

    //当日交易播报
    $scope.getlcsjybb = function()
    {
        //console.log("4343");
        var message = {};
        ajaxService.sendMessage('sunflower.getLcsTradeRecordAction', message, $scope.getlcsjybbCallBack);
    }

    $scope.getplCallBack = function(_data)
    {
        console.log("消息",_data);
        $scope.plListArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.list;
            var length = arr.length;
            //var str = length + "," + $scope.startnyr;
            var str = $scope.startnyr + length;
            selectRead($scope.subjectid, $scope.userObj.f_id, str);
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.content = arr[i].f_cnt;
                obj.isPic = false;
                if(obj.content == "//flower//")
                {
                    obj.content = "";
                    obj.isFlower = true;
                    obj.isPic = true;
                    obj.imgSrc = "images/sendflower.png";
                }
                var t = arr[i].f_createtime.toString();
                obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
                obj.time = isshowTime(obj.t);
                obj.id = arr[i].f_userid.toString();
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
                var str = arr[i].f_role.toString();
                if(str.indexOf("V",0) == -1)
                {
                    obj.islcs = false;
                }
                else
                {
                    obj.islcs = true;
                }
                $scope.plListArray.push(obj);
                //$scope.$apply();
                $("#content").scrollTop($("#content")[0].scrollHeight);
            }
            //该条评论是否显示时间
            if($scope.plListArray.length>0)
            {
                $scope.plListArray.reverse();
                for(var i=0;i<$scope.plListArray.length;i++)
                {
                    if(i==0)
                    {
                        $scope.plListArray[i].isshow = true;
                        $scope.lasttime = $scope.plListArray[i].t;
                    }
                    else
                    {
                        //alert("time1="+timeTrans($scope.plListArray[i].t)+"time2="+timeTrans($scope.lasttime));
                        var timejump = parseInt(timeTrans($scope.plListArray[i].t)-timeTrans($scope.lasttime));
                        if(timejump>300000){
                            $scope.plListArray[i].isshow = true;
                            $scope.lasttime = $scope.plListArray[i].t;
                        }else{
                            $scope.plListArray[i].isshow = false;
                        }
                    }
                    $("#content").scrollTop($("#content")[0].scrollHeight);
                }
                $("#content").scrollTop($("#content")[0].scrollHeight);
            }
            $scope.plCount = $scope.plListArray.length;
            $scope.$apply();
            $("#content").scrollTop($("#content")[0].scrollHeight);
        }
    }

    $scope.check = function(){
        $("#content").scrollTop($("#content")[0].scrollHeight);
    }
    setInterval($scope.check(),500);

    $scope.getpl = function()
    {
        var message = {};
        //message['contenttype'] = "text";
        //message['lastmsgid'] = 0;
        //message['msgamount'] = "";
        message['startdate'] = $scope.startdate;
        message['enddate'] = $scope.enddate;
        message['subjectid'] = $scope.subjectid;
        message['subjecttype'] = $scope.subjecttype;
        console.log("产品评论",message);
        ajaxService.sendMessage("user.selectcommentbydateaction", message, $scope.getplCallBack);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.firstheadshow = true;
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.getlcsjybb();
        }
        else if(_str == "2")//交易
        {
            $scope.firstheadshow = false;
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.plmark = false;

            $scope.getpl();
        }
    }

    $scope.getplcountCallBack = function(_data)
    {
        console.log("评论数量",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            //alert("消息数量：" + $scope.plCount);
            selectHasRead($scope.subjectid, $scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.subjectid;
        message['subjecttype'] = $scope.subjecttype;
        message['startdate'] = $scope.startdate;
        message['enddate'] = $scope.enddate;
        //console.log("获取评论数量", message);
        ajaxService.sendMessage("user.selectcommentnumbydateaction", message, $scope.getplcountCallBack);
    }

    //初始相关操作界面
    $scope.getinfo = function()
    {
        var localStorage = window.localStorage;
        $scope.sftype = localStorage.getItem("lcsstatus");//当前用户是否是理财师
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }
        var datestr = gettoday();
        $scope.startnyr = gettodayno();
        $scope.startdate =  datestr+ " 00:00:00";
        $scope.enddate = datestr + " 23:59:59";
        $scope.getplcount();
    };

    $scope.tradeInit = function()
    {
        $scope.getinfo();
        $scope.changeTab("1");
    }

    //$scope.tradeInit();

    $scope.appinit = function()
    {
        document.addEventListener('deviceready', function()
        {
            $scope.tradeInit();
        }, false);
    }
    $scope.appinit();

    //发送消息
    $scope.sendplClick = function(param)
    {
        //$scope.whichClick = param;
        if($scope.plingMark)
        {
            if(param == "notflower"){
                if($scope.plcontent == "")
                {
                    myAlert("请输入评论内容");
                    return;
                }
            }
            $scope.plingMark = false;
            var message = {};
            //message['contenttype'] = "text";
            if(param == "flower"){
                //alert("flower");
                message['cnt'] = "//flower//";
                if($scope.tabOneShow == true && $scope.tabTwoShow == false)
                {
                    $scope.changeTab("2");
                }
            }else{
                message['cnt'] = $scope.plcontent;
            }
            $scope.plcontentstr = message['cnt'];
            message['subjectid'] = $scope.subjectid;
            message['subjecttype'] = $scope.subjecttype;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendplCallBack);
        }
        else
        {
            myAlert("评论提交中，请稍候");
        }
    }

    $scope.sendplCallBack = function(_data)
    {
        //console.log("发送消息",_data)
        if(_data.op.code.toString() == "Y")
        {
            //myAlert("评论成功");
            if(checkisFlower($scope.plcontentstr) == true)//不是花等图标
            {
                $scope.plcontent = "";
            }

            $scope.getpl();
        }
        else
        {
            myAlert("评论发送失败");
        }
        $scope.plingMark = true;
        $scope.plcontentstr = "";
    }

    //点击评论关闭键盘
    $scope.closePop2 = function(){
        //alert(1);
        //console.log("222");
        document.getElementById("inputview").blur();
    };

    //查看个股行情
    $scope.drjybbItemClick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toLowerCase();
        obj.account = _obj.account;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //window.location.href = "tradinglive_info.html";
        xinyuNewBrowser("tradinglive_info.html?opentype=newwebview");
    }

    //评论返回
    $scope.plBackto = function()
    {
        $scope.changeTab("1");
    }

    //时间处理
    function isshowTime(pretime)
    {
        //数据库中须处理的时间
        preyear = pretime.substring(0,4);
        premouth = pretime.substring(4,6)-1;
        preday = pretime.substring(6,8);
        prehour = pretime.substring(8,10);
        premin = pretime.substring(10,12);
        presec = pretime.substring(12,14);
        var predate = new Date(preyear,premouth,preday,prehour,premin,presec);
        //当前时间
        var nowtime = new Date();
        var curmouth = nowtime.getMonth();
        var curday = nowtime.getDate();
        var curyear = nowtime.getFullYear();
        var curhour = nowtime.getHours();
        var curmin = nowtime.getMinutes();
        var cursec = nowtime.getSeconds();

        if(preyear==curyear&&premouth==curmouth&&preday==curday){
            return prehour+":"+premin;
        }else
        if(preyear==curyear&&premouth==curmouth&&(curday-preday)==1){
            return "昨天"+" "+prehour+":"+premin;
        }else
        if((nowtime.getTime()-predate.getTime())-(7 * 24 * 3600 * 1000)<0){
            var day = predate.getDay();
            if(day == 0){
                return "星期天"+" "+prehour+":"+premin;
            }
            if(day == 1){
                return "星期一"+" "+prehour+":"+premin;
            }
            if(day == 2){
                return "星期二"+" "+prehour+":"+premin;
            }
            if(day == 3){
                return "星期三"+" "+prehour+":"+premin;
            }
            if(day == 4){
                return "星期四"+" "+prehour+":"+premin;
            }
            if(day == 5){
                return "星期五"+" "+prehour+":"+premin;
            }
            if(day == 6){
                return "星期六"+" "+prehour+":"+premin;
            }
        }else{
            return preyear+"年"+(premouth+1)+"月"+preday+"日"+" "+prehour+":"+premin;
        }

    }

    function timeTrans(t){
        //obj.time = t.substr(0,4) + "-" +  t.substr(4,2) + "-" +  t.substr(6,2) + " " + t.substr(8,2) + ":" + t.substr(10,2) + ":" + t.substr(12,2);
        var year = t.substr(0,4);
        var mouth = t.substr(4,2)-1;
        var day = t.substr(6,2);
        var hour = t.substr(8,2);
        var minute = t.substr(10,2);
        var second = t.substr(12,2);
        var tDate = new Date(year,mouth,day,hour,minute,second);
        return Number(tDate);
    }

    $scope.inputfocus = function(){
        $("#content").scrollTop($("#content")[0].scrollHeight);
        if($scope.tabOneShow == true && $scope.tabTwoShow == false)
        {
            $scope.changeTab("2");
        }
    }
    //失去焦点改变评论div样式
    $scope.inputblur = function(){
        $("#content").scrollTop($("#content")[0].scrollHeight);
    }

    //插入用户读取记
    function insertRead(productid,userid,readnum) {
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        db.transaction(function(tx) {
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql(
                "INSERT INTO read (productid, userid, readnum) VALUES (?,?,?)",
                [productid,userid,readnum],function(tx,res){

                });
        });
    }
    //更新用户读取记录
    function updateRead(productid,userid,readnum){
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        db.transaction(function(tx){
            tx.executeSql(
                "UPDATE read SET readnum = "+readnum+" WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res){

                });
        })
    }

    //查询用户读取记录
    function selectRead(productid,userid,readnum){
        //alert("读取");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){
            //alert(tx.toString);
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");

            //alert("productid" + productid);
            //alert("userid" + userid);
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res){
                    //alert(res.rows.length);
                    if(res.rows.length == 0){
                        insertRead(productid,userid,readnum);
                        //alert("INSERThasRead");
                    }else{
                        updateRead(productid,userid,readnum);
                        //alert("UPDATEhasRead");
                    }
                });
        },function(e) {
            //alert("ERROR: " + e.message);
        })
    }


    //读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx)
        {
            //alert(tx.toString);
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            //alert("productid" + productid);
            //alert("userid" + userid);
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    //alert("rows" + res.rows.length);
                    var datestr = ""
                    if(res.rows.length == 0)
                    {
                        $scope.hasReadNum = 0;

                    }else
                    {
                        var str = res.rows.item(0).readnum;
                        if(str.length>0)
                        {
                            datestr = str.substr(0,8);
                            $scope.hasReadNum = str.substr(8);
                        }
                        else
                        {
                            $scope.hasReadNum = str;
                        }
                        //alert($scope.hasReadNum + " " + datestr);
                    }

                    //alert("已读取评论数" + $scope.hasReadNum);
                    if(datestr == "")
                    {
                        if($scope.hasReadNum < $scope.plCount)
                        {
                            $scope.plmark = true;
                        }
                        else
                        {
                            $scope.plmark = false;
                        }
                    }
                    else
                    {
                        if(datestr != $scope.startnyr)//存储的日期不是当前日期，表示当前日期还未读过
                        {
                            $scope.plmark = true;
                        }
                        else
                        {
                            if($scope.hasReadNum < $scope.plCount)
                            {
                                $scope.plmark = true;
                            }
                            else
                            {
                                $scope.plmark = false;
                            }
                        }
                    }

                    //alert("mark" + $scope.plmark);
                    $scope.$apply();
                });
        },function(e) {
            //alert("ERROR: " + e.message);
        })
    }
    
}



