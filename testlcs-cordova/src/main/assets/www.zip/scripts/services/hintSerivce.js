/**
 * Created by wangtao on 2015/8/20 0020.
 */

function hintSerivce($rootScope)
{
    //$stateParams = $location.search();
    //var changeTab = function (id) {
    //    var currentTab;
    //    //console.log(id);
    //    //$scope.showTab = id;
    //    for (var i = 0; i < tabs.length; i++) {
    //        var tabTemp = tabs[i];
    //        if (tabTemp.id == id) {
    //            tabTemp.isactive = true;
    //            tabTemp['typeLastId'] = "";
    //            currentTab = tabTemp;
    //            //currentTab["params"]=$location.search();
    //            //$state.go(""+id, $stateParams);
    //        } else {
    //            tabTemp.isactive = false;
    //        }
    //    }
    //
    //    return currentTab;
    //};

}