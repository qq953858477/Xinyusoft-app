var jsonp = true;
var jsonpUrl = "http://192.168.0.200:8086/uuFinancialPlanner/JSONP";
//var jsonpUrl = "http://120.26.117.113:8080/uuFinancialPlanner/JSONP";
//var jsonpUrl = "http://test.xinyusoft.com:8080/uuFinancialPlanner/JSONP";//测试环境
function jpajaxService($http)
{
    var checkSystemInterval = null;

    var queryList = {};
    var queryList1 = {};

    var checkSystem = function () {
        if (!checkSystemInterval)
        {
            checkSystemInterval = setInterval(function(){
                send("",{command:'counter.GetSystemStatusAction'},function(data){},true);
            },60*1000);

        }
    }

    var send = function (url, message, callback)
    {
        console.log("message",message);
        var par = {};
        for (var key in message) {
            par[key + ""] = encodeURI(encodeURI(message[key + ""]))
        }
        //console.log(par);
        if (jsonp) {
            myUrl = jsonpUrl + "?rmd="+new Date().getTime()+"&shopid=-1&callback=JSON_CALLBACK";
            //var requestUrl = "";
            for (var key in message)
            {
                myUrl += ("&" + key + "=" + encodeURI(encodeURI(encodeURI(message[key + ""]))));
                //requestUrl += ("&" + key + "=" + encodeURI(encodeURI(encodeURI(message[key + ""]))));
            }
            var action = "";
            if(message != null && message!= undefined)
            {
                action = message.command;
            }
            //console.log("url", myUrl);
            //console.log("返回", callback);
            queryList[action+"#$$#"+JSON.stringify(message)] = callback;
            queryList1[callback] = action+"#$$#"+JSON.stringify(message);

            var obj = $http.jsonp(myUrl).success(
                function (data)
                {
                    if(data.op.code == 'upgrading') {

                        var upgradingDiv = document.getElementById("upgrading");
                        if (!upgradingDiv) {
                            // 升级div浮层不存在
                            //var bodyHeight = document.body.clientHeight;
                            //var bodyWidth = document.body.clientWidth;
                            var bodyHeight = window.innerHeight;
                            var bodyWidth = window.innerWidth;
                            upgradingDiv = document.createElement("div");
                            upgradingDiv.id = "upgrading";
                            upgradingDiv.style.position = 'fixed';
                            upgradingDiv.style.zIndex = 99999;
                            upgradingDiv.style.backgroundImage = "url(images/qd.png)";
                            upgradingDiv.style.backgroundRepeat = "no-repeat";
                            upgradingDiv.style.backgroundSize = "100% auto";
                            upgradingDiv.style.top = 0;
                            upgradingDiv.style.left = 0 ;
                            upgradingDiv.style.width = bodyWidth + "px";
                            upgradingDiv.style.height = bodyHeight + "px";

                            document.body.appendChild(upgradingDiv);

                            // var upgradingImg = document.createElement("img");
                            // upgradingImg.src = "images/qd.png";
                            // upgradingImg.style.width = bodyWidth + "px";
                            // upgradingImg.style.height = bodyHeight + "px";
                            // upgradingDiv.appendChild(upgradingImg);

                            var contentDiv = document.createElement("h2");
                            contentDiv.style.fontSize = "18px";
                            contentDiv.style.width = bodyWidth + "px";
                            contentDiv.style.color = "#FFFFFF";
                            contentDiv.style.textAlign = "center";
                            contentDiv.style.marginTop = bodyHeight * 0.8 + "px";
                            contentDiv.innerHTML = "系统升级中，请稍候...";

                            upgradingDiv.appendChild(contentDiv);

                            checkSystem();

                        }
                    }else{
                        queryList[queryList1[callback]] = null;

                        var upgradingDiv = document.getElementById("upgrading");
                        if (upgradingDiv) {
                            // 删除元素
                            document.body.removeChild(upgradingDiv);
                            // 停止定时器
                            if (checkSystemInterval)
                            {

                                clearInterval(checkSystemInterval);
                                checkSystemInterval = null;
                                console.log("#########\r\n"+queryList);
                                //window.location.reload();
                                for ( var i in queryList) {
                                    var _cb = queryList[i];
                                    if(_cb != null)
                                    {
                                        var _action = i.split("#$$#")[0];
                                        var _message = i.split("#$$#")[1];
                                        console.log("send after upgrading "+_action +" "+_message);
                                        send("JSONP",JSON.parse(_message),_cb);
                                    }
                                }
                            }
                        }

                        try{
                            callback(data);
                        }catch (e)
                        {}
                    };
                }

            );
        } else {
            $http({
                method: 'POST',
                url: url,
                params: par,
                headers: {'Content-Type': 'application/x-www-form-urlencoded;charset:UTF-8'},
                async: true
            })
                .success(function (json, status, headers, config) {
                    callback(json);
                });
        }

    };
    var simpleSend = function (url, message, callback) {
        if (jsonp) {
            myUrl = jsonpUrl + "?rmd="+new Date().getTime()+"&shopid=-1&callback=JSON_CALLBACK";
            for (var key in message) {
                myUrl += ("&" + key + "=" + message[key + ""]);
            }
            var obj = $http.jsonp(myUrl).success(
                function (data) {
                    if (data.op.errortype != null && data.op.errortype == 'nologin') {
                        //TODO:�ɵ������¼
                        //window.location.href = "login.html";
                    } else {
                        try{
                            callback(data);
                        }catch (e)
                        {}

                    }
                }
            );
        } else {
            $http({
                method: 'POST',
                url: url,
                params: message,
                headers: {'Content-Type': 'application/x-www-form-urlencoded;charset:UTF-8'},
                async: true
            })
                .success(function (json, status, headers, config) {
                    callback(json);
                });
        }
    };
    return {
        sendMessage: function (url, message, callback) {
            send(url, message, callback);
        },
        sendESBReq: function (action, message, callback) {
            message["command"] = action;
            send('ESBServlet', message, callback);
        },
        simpleSend: function (url, message, callback) {
            simpleSend(url, message, callback);
        }
    }
}