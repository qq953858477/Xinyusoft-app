/**
 * Created by qw1 on 2014/12/7.
 */
var mygtbModule = angular.module('mygtbApp',['ngCookies', 'ngRoute','ngTouch']);
mygtbModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
mygtbModule.directive('autohq', autohq);

/** 控制器*/
mygtbModule.controller('mygtbCtrl',['$scope','ajaxService', '$cookieStore',mygtbCtrl]);

/**过滤器*/
mygtbModule.filter('numberFormatFilter',numberFormatFilter);


mygtbModule.run(function() {
    document.getElementById("mygtbMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['mygtbApp']);
});
