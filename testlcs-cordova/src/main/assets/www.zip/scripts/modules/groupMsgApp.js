/**
 * Created by zl
 */
var groupMsgModule = angular.module('groupMsgApp',['ngCookies']);
groupMsgModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** ������*/
groupMsgModule.controller('groupMsgCtrl',['$scope','ajaxService', '$cookieStore','$sce',groupMsgCtrl]);

groupMsgModule.run(function() {
    document.getElementById("groupMsgMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['groupMsgApp']);
});
