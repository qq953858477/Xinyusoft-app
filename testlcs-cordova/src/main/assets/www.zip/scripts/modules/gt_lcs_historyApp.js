/**
 * Created by qw1 on 2014/12/7.
 */
var gt_lcs_historyModule = angular.module('gt_lcs_historyApp',['ngCookies']);
gt_lcs_historyModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

/** 控制器*/
gt_lcs_historyModule.controller('gt_lcs_historyCtrl',['$scope','ajaxService', '$cookieStore', gt_lcs_historyCtrl]);

/**过滤器*/
gt_lcs_historyModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_lcs_historyMain").style.display = "";
}

gt_lcs_historyModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_lcs_historyApp']);
});
