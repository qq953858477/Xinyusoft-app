/**
 * Created by qw1 on 2014/12/7.
 */
var addnewAccountsModule = angular.module('addnewAccountsApp',['ngCookies']);
addnewAccountsModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
addnewAccountsModule.controller('addnewAccountsCtrl',['$scope','ajaxService', '$cookieStore', addnewAccountsCtrl]);


/**过滤器*/
addnewAccountsModule.filter('numberFormatFilter', numberFormatFilter);

addnewAccountsModule.run(function() {
    document.getElementById("addnewAccountsMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['addnewAccountsApp']);
});
