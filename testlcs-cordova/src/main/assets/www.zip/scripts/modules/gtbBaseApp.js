/**
 * Created by qw1 on 2014/12/7.
 */
var gtbBaseModule = angular.module('gtbBaseApp',['ngCookies']);
gtbBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
gtbBaseModule.controller('gtbBaseCtrl',['$scope','ajaxService', '$cookieStore', gtbBaseCtrl]);

/**过滤器*/
gtbBaseModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gtbBaseMain").style.display = "";
}

gtbBaseModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtbBaseApp']);
});
