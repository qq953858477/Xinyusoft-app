/**
 * Created by qw1 on 2014/12/7.
 */
var tradeBase_bgtzzhModule = angular.module('tradeBase_bgtzzhApp',['ngCookies', 'ngRoute','ngTouch']);
tradeBase_bgtzzhModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
tradeBase_bgtzzhModule.directive('autohq', autohq);

tradeBase_bgtzzhModule.directive('zhassetbgtzzh', zhassetbgtzzh);
tradeBase_bgtzzhModule.directive('tradeinfowgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_info_wgt.html',
        controller:['$scope','ajaxService','$cookieStore',tradeinfowgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});
tradeBase_bgtzzhModule.directive('tradequerywgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_query_wgt.html',
        controller:['$scope','ajaxService','$cookieStore', tradequerywgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});

tradeBase_bgtzzhModule.controller('zh_asset_bgtzzhCtrl',['$scope','ajaxService', '$cookieStore', zh_asset_bgtzzhCtrl]);
tradeBase_bgtzzhModule.controller('tradeinfowgtCtrl',['$scope','ajaxService', '$cookieStore', tradeinfowgtCtrl]);
tradeBase_bgtzzhModule.controller('tradequerywgtCtrl',['$scope','ajaxService', '$cookieStore', tradequerywgtCtrl]);

/** 控制器*/
tradeBase_bgtzzhModule.controller('tradeBase_bgtzzhCtrl',['$scope','ajaxService', '$cookieStore', tradeBase_bgtzzhCtrl]);
/**空白 控制器*/
tradeBase_bgtzzhModule.controller('emptyCtrl',['$scope', 'ajaxService', '$cookieStore', emptyCtrl]);
/** 控制器*/
tradeBase_bgtzzhModule.controller('buysellwgtCtrl',['$scope','ajaxService', '$cookieStore', buysellwgtCtrl]);
/**撤单 控制器*/
tradeBase_bgtzzhModule.controller('cancellationCtrl',['$scope', 'ajaxService', '$cookieStore', cancellationCtrl]);
/**预埋单 控制器*/
tradeBase_bgtzzhModule.controller('prepaywgtCtrl',['$scope', 'ajaxService', '$cookieStore', prepaywgtCtrl]);

/**银证转账 控制器*/
tradeBase_bgtzzhModule.controller('yzzzCtrl',['$scope', 'ajaxService', '$cookieStore', yzzzCtrl]);
/**一键清仓 控制器*/
tradeBase_bgtzzhModule.controller('yjqcwgtCtrl',['$scope', 'ajaxService', '$cookieStore', yjqcwgtCtrl]);
/**一键建仓调仓 控制器*/
tradeBase_bgtzzhModule.controller('yjjctcwgtCtrl',['$scope', 'ajaxService', '$cookieStore', yjjctcwgtCtrl]);



/**持仓 控制器*/
//tradeBaseModule.controller('cccxCtrl',['$scope', 'ajaxService', '$cookieStore',
//    function($scope, ajaxService, $cookieStore) {
//        console.log("查询持仓2222");
//    }
//])

tradeBase_bgtzzhModule.controller('cccxwgtCtrl',['$scope', 'ajaxService', '$cookieStore', cccxwgtCtrl]);
/**当日成交 控制器*/
tradeBase_bgtzzhModule.controller('drcjCtrl',['$scope', 'ajaxService', '$cookieStore', drcjCtrl]);
/**当日委托 控制器*/
tradeBase_bgtzzhModule.controller('drwtCtrl',['$scope', 'ajaxService', '$cookieStore', drwtCtrl]);
/**历史成交 控制器*/
tradeBase_bgtzzhModule.controller('lscjCtrl',['$scope', 'ajaxService', '$cookieStore', lscjCtrl]);
/**历史委托 控制器*/
tradeBase_bgtzzhModule.controller('lswtCtrl',['$scope', 'ajaxService', '$cookieStore', lswtCtrl]);
/**历史资金流水 控制器*/
tradeBase_bgtzzhModule.controller('lszjlsCtrl',['$scope', 'ajaxService', '$cookieStore', lszjlsCtrl]);




/**过滤器*/
tradeBase_bgtzzhModule.filter('numberFormatFilter',numberFormatFilter);

/**路由管理器*/
tradeBase_bgtzzhModule.
    config(['$routeProvider', function($routeProvider) {
        $routeProvider.
            when('/buysell', {templateUrl: 'views/buysell_wgt.html', controller: 'buysellwgtCtrl'}).
            when('/cancellation', {templateUrl: 'views/cancellation.html', controller: 'cancellationCtrl'}).
            when('/prepay', {templateUrl: 'views/prepay_wgt.html', controller: 'prepaywgtCtrl'}).
            when('/yjqc', {templateUrl: 'views/yjqc_wgt.html', controller: 'yjqcwgtCtrl'}).
            when('/yjjctc', {templateUrl: 'views/yjjctc_wgt.html', controller: 'yjjctcwgtCtrl'}).
            when('/yzzz', {templateUrl: 'views/yzzz.html', controller: 'yzzzCtrl'}).

            when('/cccx', {templateUrl: 'views/cccx_wgt.html', controller: 'cccxwgtCtrl'}).
            when('/drcj', {templateUrl: 'views/drcj.html', controller: 'drcjCtrl'}).
            when('/drwt', {templateUrl: 'views/drwt.html', controller: 'drwtCtrl'}).
            when('/lscj', {templateUrl: 'views/lscj.html', controller: 'lscjCtrl'}).
            when('/lswt', {templateUrl: 'views/lswt.html', controller: 'lswtCtrl'}).
            when('/lszjls', {templateUrl: 'views/lszjls.html', controller: 'lszjlsCtrl'}).
            otherwise({redirectTo: '/empty'});
    }]);


tradeBase_bgtzzhModule.run(function() {
    document.getElementById("tradeBase_bgtzzhMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradeBase_bgtzzhApp']);
});
