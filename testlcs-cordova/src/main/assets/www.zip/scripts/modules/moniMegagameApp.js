/**
 * Created by qw1 on 2014/12/7.
 */
var moniMegagameModule = angular.module('moniMegagameApp',['ngCookies']);
moniMegagameModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
moniMegagameModule.controller('moniMegagameCtrl',['$scope','ajaxService', '$cookieStore', moniMegagameCtrl]);

/**过滤器*/
moniMegagameModule.filter('numberFormatFilter', numberFormatFilter);

moniMegagameModule.run(function() {
    document.getElementById("moniMegagameMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['moniMegagameApp']);
});
