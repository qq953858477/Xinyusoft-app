/**
 * Created by qw1 on 2014/12/7.
 */
var tradeBase_gtjjModule = angular.module('tradeBase_gtjjApp',['ngCookies', 'ngRoute','ngTouch']);
tradeBase_gtjjModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
tradeBase_gtjjModule.directive('autohq', autohq);
tradeBase_gtjjModule.directive('zhassetgtjj', zhassetgtjj);

tradeBase_gtjjModule.controller('zh_asset_gtjjCtrl',['$scope','ajaxService', '$cookieStore', zh_asset_gtjjCtrl]);

/** 控制器*/
tradeBase_gtjjModule.controller('tradeBase_gtjjCtrl',['$scope','ajaxService', '$cookieStore',tradeBase_ggjjCtrl]);

/**过滤器*/
tradeBase_gtjjModule.filter('numberFormatFilter',numberFormatFilter);


tradeBase_gtjjModule.run(function() {
    document.getElementById("tradeBase_gtjjMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradeBase_gtjjApp']);
});
