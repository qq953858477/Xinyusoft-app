/**
 * Created by qw1 on 2014/12/7.
 */
//var gt_fwz_gtzModule = angular.module('gt_fwz_gtzApp',['ngCookies','ngTouch']);
var gt_fwz_gtzModule = angular.module('gt_fwz_gtzApp',['ngCookies']);
gt_fwz_gtzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_fwz_gtzModule.directive('gtsyntheticalycc', gtsyntheticalycc);
gt_fwz_gtzModule.directive('gtsycc', gtsycc);
gt_fwz_gtzModule.directive('gtsyjyjl', gtsyjyjl);
gt_fwz_gtzModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
gt_fwz_gtzModule.directive('gtsypl', gtsypl);
/** 控制器*/
gt_fwz_gtzModule.controller('gtsyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyccCtrl]);
gt_fwz_gtzModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_fwz_gtzModule.controller('gtsyntheticalyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalyccCtrl]);
gt_fwz_gtzModule.controller('gt_fwz_gtzCtrl',['$scope','ajaxService', '$cookieStore', gt_fwz_gtzCtrl]);
gt_fwz_gtzModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);

/**过滤器*/
gt_fwz_gtzModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_fwz_gtzMain").style.display = "";
}


gt_fwz_gtzModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_fwz_gtzApp']);
});
