/**
 * Created by qw1 on 2015/4/17.
 */
var onePersonWinModule = angular.module('onePersonWinApp',['ngCookies']);
onePersonWinModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
onePersonWinModule.controller('onePersonWinCtrl',['$scope','ajaxService', '$cookieStore','$sce',onePersonWinCtrl]);

onePersonWinModule.run(function() {
    document.getElementById("onePersonWinmain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['onePersonWinApp']);
});
