/**
 * Created by wangtao on 2015/8/20 0020.
 */
var jiepanApp = angular.module("jiepanApp", ['ui.router', 'ngAnimate', 'infinite-scroll', 'ngCookies']);
jiepanApp.run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            //document.getElementById("jiepanApp").style.display = "";
            //FastClick.attach(document.body);
        }
    ]
);

jiepanApp.factory('jpajaxService', ['$http', jpajaxService]);
jiepanApp.factory('tabService', ['$stateParams', '$location', '$state', tabService]);
/** 控制器*/
jiepanApp.controller('jiepanMainCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanMainCtrl]);
jiepanApp.controller('jiepanListCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanListCtrl]);

jiepanApp.directive('jiepan', function () {
    return {
        restrict: 'E',
        templateUrl: 'template/jiepanTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: jiepanMainCtrl
    }
});
jiepanApp.directive('relative', function () {
    return {
        restrict: 'E',
        templateUrl: 'template/relativeTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: jiepanMainCtrl
    }
})

jiepanApp.directive("ggjp", ggJpDirective);
jiepanApp.directive("dpjp", dpJpDirective);
jiepanApp.directive("gnjp", gnJpDirective);

//行情
jiepanApp.directive('jponestockhqbase', jponestockhqbase);

jiepanApp.factory('ajaxService', ['$rootScope', '$http', '$cookieStore', ajaxService]);

jiepanApp.filter('dateFilter', function () {
    return function (dateInput) {
        //2015-08-21 15:06:59.0
        var returndate = '';
        returndate = dateInput.substr(0, dateInput.length - 5);
        return returndate;

    }

});
jiepanApp.config(
    ['$stateProvider', '$urlRouterProvider', '$locationProvider', function ($stateProvider, $urlRouterProvider, $locationProvider) {
        //$locationProvider.html5Mode(true).hashPrefix('!');
        $stateProvider
            .state("0", {
                url: "/0",
                templateUrl: 'view/gg.html',
                controller: ['$scope', 'ajaxService', 'tabService', jiepanListCtrl]
            })
            .state("1", {
                url: "/1",
                templateUrl: 'view/dp.html',
                controller: ['$scope', 'ajaxService', 'tabService', jiepanListCtrl]
            })
            .state("2", {
                url: "/2",
                templateUrl: 'view/hy.html',
                controller: ['$scope', 'ajaxService', 'tabService', jiepanListCtrl]
            })
            .state("3", {
                url: "/3",
                templateUrl: 'view/gn.html',
                controller: ['$scope', 'ajaxService', 'tabService', jiepanListCtrl]
            })
    }]
);

angular.element(document).ready(function () {
    angular.bootstrap(document, ['jiepanApp']);
});