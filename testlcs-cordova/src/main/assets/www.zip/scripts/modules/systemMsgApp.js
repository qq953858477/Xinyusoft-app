/**
 * Created by zl
 */
var systemMsgModule = angular.module('systemMsgApp',['ngCookies','ngTouch']);
systemMsgModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** ������*/
systemMsgModule.controller('systemMsgCtrl',['$scope','ajaxService', '$cookieStore','$sce',systemMsgCtrl]);

systemMsgModule.run(function() {
    document.getElementById("systemMsgMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['systemMsgApp']);
});
