/**
 * Created by qw1 on 2014/12/7.
 */
var tradinglive_infoModule = angular.module('tradinglive_infoApp',['ngCookies','ngTouch']);
tradinglive_infoModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
tradinglive_infoModule.controller('tradinglive_infoCtrl',['$scope','ajaxService', '$cookieStore','$sce', tradinglive_infoCtrl]);

/**过滤器*/
tradinglive_infoModule.filter('numberFormatFilter', numberFormatFilter);

tradinglive_infoModule.run(function() {
    document.getElementById("tradinglive_infoMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradinglive_infoApp']);
});
