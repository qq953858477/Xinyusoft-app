/**
 * Created by qw1 on 2014/12/7.
 */
var gtCircleModule = angular.module('gtCircleApp',['ngCookies', 'ngRoute','ngTouch']);
gtCircleModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gtCircleModule.directive('autohq', autohq);

/** 控制器*/
gtCircleModule.controller('gtCircleCtrl',['$scope','ajaxService', '$cookieStore',gtCircleCtrl]);

/**过滤器*/
gtCircleModule.filter('numberFormatFilter',numberFormatFilter);


gtCircleModule.run(function() {
    document.getElementById("gtCircleMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtCircleApp']);
});
