/**
 * Created by qw1 on 2014/12/7.
 */
var gt_syModule = angular.module('gt_sy_historyApp',['ngCookies']);
gt_syModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_syModule.directive('gtsyjyjl', gtsyjyjl);
gt_syModule.directive('gtsypl', gtsypl);;
gt_syModule.directive('gtsyntheticalhistory', gtsyntheticalhistory);
gt_syModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
/** 控制器*/
gt_syModule.controller('gtsyntheticalhistoryCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalhistoryCtrl]);
gt_syModule.controller('gt_sy_historyCtrl',['$scope','ajaxService', '$cookieStore', gt_sy_historyCtrl]);
gt_syModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_syModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);

/**过滤器*/
gt_syModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_sy_historyMain").style.display = "";
}

gt_syModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_sy_historyApp']);
});
