/**
 * Created by qw1 on 2014/12/7.
 */
var gtbonlineBaseModule = angular.module('gtbonlineBaseApp',['ngCookies']);
gtbonlineBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
gtbonlineBaseModule.controller('gtbonlineBaseCtrl',['$scope','ajaxService', '$cookieStore', gtbonlineBaseCtrl]);


/**过滤器*/
gtbonlineBaseModule.filter('numberFormatFilter', numberFormatFilter);

gtbonlineBaseModule.run(function() {
    document.getElementById("gtbonlineBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtbonlineBaseApp']);
});
