/**
 * Created by qw1 on 2014/12/7.
 */
var gt_allstatuslistModule = angular.module('gt_allstatuslistApp',['ngCookies']);
gt_allstatuslistModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

/** 控制器*/
gt_allstatuslistModule.controller('gt_allstatuslistCtrl',['$scope','ajaxService', '$cookieStore', gt_allstatuslistCtrl]);

/**过滤器*/
gt_allstatuslistModule.filter('numberFormatFilter', numberFormatFilter);

gt_allstatuslistModule.run(function() {
    document.getElementById("gt_allstatuslistMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_allstatuslistApp']);
});
