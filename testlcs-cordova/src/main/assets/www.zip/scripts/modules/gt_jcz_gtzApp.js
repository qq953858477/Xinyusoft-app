/**
 * Created by qw1 on 2014/12/7.
 */
var gt_jcz_gtzModule = angular.module('gt_jcz_gtzApp',['ngCookies']);
gt_jcz_gtzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_jcz_gtzModule.directive('gtsyntheticalycc', gtsyntheticalycc);
gt_jcz_gtzModule.directive('gtsycc', gtsycc);
gt_jcz_gtzModule.directive('gtsyjyjl', gtsyjyjl);
gt_jcz_gtzModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
gt_jcz_gtzModule.directive('gtsypl', gtsypl);
/** 控制器*/
gt_jcz_gtzModule.controller('gtsyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyccCtrl]);
gt_jcz_gtzModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_jcz_gtzModule.controller('gtsyntheticalyccCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalyccCtrl]);
gt_jcz_gtzModule.controller('gt_jcz_gtzCtrl',['$scope','ajaxService', '$cookieStore', gt_jcz_gtzCtrl]);
gt_jcz_gtzModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);

/**过滤器*/
gt_jcz_gtzModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_jcz_gtzMain").style.display = "";
}

gt_jcz_gtzModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_jcz_gtzApp']);
});
