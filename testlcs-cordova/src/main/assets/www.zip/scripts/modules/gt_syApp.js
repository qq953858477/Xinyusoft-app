/**
 * Created by qw1 on 2014/12/7.
 */
var gt_syModule = angular.module('gt_syApp',['ngCookies','ngTouch']);
gt_syModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_syModule.directive('gtsykykwcc', gtsykykwcc);
gt_syModule.directive('gtsyjrjyjl', gtsyjrjyjl);
gt_syModule.directive('gtsyjyjl', gtsyjyjl);
gt_syModule.directive('gtplshow', gtplshow);
gt_syModule.directive('gtplinput', gtplinput);
gt_syModule.directive('gtsyntheticalwcc', gtsyntheticalwcc);
gt_syModule.directive('gtsysyt', gtsysyt);
gt_syModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);

/** 控制器*/
gt_syModule.controller('gtsyntheticalwccCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalwccCtrl]);
gt_syModule.controller('gtsysytCtrl',['$scope','ajaxService', '$cookieStore', gtsysytCtrl]);
gt_syModule.controller('gt_syCtrl',['$scope','ajaxService', '$cookieStore', '$sce', gt_syCtrl]);
gt_syModule.controller('gtsykykwccCtrl',['$scope','ajaxService', '$cookieStore', gtsykykwccCtrl]);
gt_syModule.controller('gtsyjrjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjrjyjlCtrl]);
gt_syModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_syModule.controller('gtplshowCtrl',['$scope','ajaxService', '$cookieStore', gtplshowCtrl]);
gt_syModule.controller('gtplinputCtrl',['$scope','ajaxService', '$cookieStore', gtplinputCtrl]);

/**过滤器*/
gt_syModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_syMain").style.display = "";
}

gt_syModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_syApp']);
});
