function zhassetbgtzzh()
{
     return {
         restrict: 'E',
         templateUrl: 'html/zh_asset_bgtzzh.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function zh_asset_bgtzzhCtrl($scope, ajaxService, $cookieStore) {
    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.orderClumn = 'f_ljykbl';
    $scope.dqspzArray = [];//当前跟投者实盘中
    $scope.dqgtbmArray = [];//当前跟投报名的产品信息
    $scope.dqjczArray = [];//当前解除中

    $scope.zcmain = true;//资产界面
    $scope.zcrsyfxDivShow = false;//日收益分析


    $scope.refreshbtn = false;//刷新按钮是否显示

    $scope.ccrefreshintervalDuration = 5000;//间隔时间，5000毫秒;
    $scope.ccrefreshID;

    //去除
    $scope.ccrefreshClearInterval = function () {
        if ($scope.ccrefreshID != undefined) {
            clearInterval($scope.ccrefreshID);
        }
    }


    $scope.getzzcCallBack = function(_data)
    {
        //console.log("总资产", _data);
        //总资产
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.money;
            $scope.cczzc = parseFloat(arr.zzc.toString());
        }
    }

    $scope.getzzc = function()
    {
        //获取总资产
        var message = {};
        message['account'] = $scope.accountShowValue;
        //console.log("$scope.accountShowValue", $scope.accountShowValue);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.getzzcCallBack)
    }
    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("可用资金", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.money;
            $scope.cckyzj = parseFloat(arr.kyzj.toString());
            //$scope.cczzc = parseFloat(arr.zzc.toString());
            $scope.cczsz = parseFloat(arr.zsz.toString());
            //console.log("累计出入金",arr.ljcrj.toString());
            //$scope.ccljyk = parseFloat((parseFloat(arr.zzc.toString()) - parseFloat(arr.ljcrj.toString())).toFixed(2));
        }

    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        //console.log("可用资金：" ,  message['account']);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;

    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            console.log("持仓",result);
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                $scope.ccljyk = parseFloat(result.ccyk.toString());
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = parseFloat(arr[i].dqj).toFixed(2);
                        obj.yk = arr[i].fdyk;
                        obj.zdf = parseFloat(arr[i].zdf).toFixed(2) + "%";
                        obj.cbj = parseFloat(arr[i].cbj);
                        var zdfv = parseFloat(parseFloat(arr[i].zdf).toFixed(2));
                        if(zdfv >0)
                        {
                            obj.zdfflag = "1";
                        }
                        else if(zdfv <0)
                        {
                            obj.zdfflag = "-1";
                        }
                        else
                        {
                            obj.zdfflag = "0";
                        }
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        obj.asset = getzqStatus(arr[i].basetype);
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

            $scope.ccrefreshClearInterval();
            //console.log("状态：", $scope.tabOneShow);
            if($scope.wtList.length>0 && $scope.tabOneShow)
            {
                //$scope.ccrefreshID = setInterval($scope.zhqueryall, $scope.ccrefreshintervalDuration);
            }
        });
    };

    $scope.dqzhcpCallBack = function(_data)
    {
        $scope.dqgtbmArray = [];
        $scope.dqspzArray = [];
        $scope.dqjczArray = [];
        //console.log("当前产品", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            for(var i = 0;i<arr.length;i++)
            {

                var obj = {};
                var bgtuser = arr[i].user.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.fbzuserid = bgtuser.f_id;
                obj.productname = arr[i].name;
                obj.productid = arr[i].id;
                obj.zq = arr[i].gentouperiod;//周期
                obj.mbsy = arr[i].targetprofit;
                obj.tradeaccount = arr[i].account;
                if(arr[i].status == "A")
                {
                    obj.status = "cp1";
                    obj.bmrs = arr[i].applycount;//报名人数
                    obj.beginapplytime = arr[i].beginapplytime;
                    var str = arr[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr[i].endapplytimedesc;//报名截止日期
                    $scope.dqgtbmArray.push(obj);
                }
                else if(arr[i].status == "G")
                {
                    obj.status = "cp4";
                    obj.bmrs = arr[i].applycount;//报名人数
                    obj.beginapplytime = arr[i].beginapplytime;
                    var str = arr[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr[i].endapplytimedesc;//报名截止日期
                    $scope.dqgtbmArray.push(obj);
                }
                else if(arr[i].status == "B")
                {
                    obj.status = "cp2";
                    obj.gentoucount =  arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    var str = arr[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;
                    $scope.dqspzArray.push(obj);
                }
                else if(arr[i].status == "D")
                {
                    obj.status = "cp3";
                    obj.gentoucount =  arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.endgentoutime = arr[i].endgentoutime + "解除";//多久前解除跟投
                    $scope.dqjczArray.push(obj);
                }
            }
        }
    }

    //当前账户的产品
    $scope.dqzhcp = function()
    {
        var message = {};
        message['account'] = $scope.accountShowValue;
        message['userid'] = $scope.userObj.f_id;
        message['status'] = "A,G,B,D";
        message['shopid'] = $scope.bcid;
        message['page.size'] = "max";
        message['page.no'] = "";
        //console.log("当前产品",message);
        ajaxService.sendMessage("sunflower.p_selectgentouproduct", message, $scope.dqzhcpCallBack) ;
    }

    $scope.zhqueryall = function()
    {
        $scope.getzzc();
        $scope.getccinfo();
        $scope.query();
    }


    $scope.ccquery = function()
    {
        //console.log("获取信息");
        //获取资产信息
        $scope.getzzc();
        $scope.getccinfo();
        $scope.query();
        $scope.dqzhcp();
        //$scope.dqgtzinfo();
        //$scope.dqgtbminfo();

        //console.log($scope.accountcompany);
        if($scope.accountcompany == "moni")
        {
            $scope.refreshbtn = false;
        }
        else
        {
            $scope.refreshbtn = true;
        }
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradequery获取参数", _data.account);
        //console.log(_data.caption);
        if(_data.caption == "zh_asset_bgtzzh")
        {
            //console.log(12132, _data.account);
            $scope.childaccount = _data.account;
            $scope.ccquery();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    var cstr  = {"caption": "zh_asset_bgtzzh"};
    $scope.$emit("getParameters", cstr);

    //$scope.zhinit = function(newValue, oldValue, scope) {
    //    //console.log("me", newValue, oldValue);
    //    if (newValue) {
    //        console.log(111111111);
    //        $scope.ccquery();
    //    }
    //}
    //$scope.$watch('tabOneShow', $scope.zhinit);

    //跟投者
    $scope.gtItemClick = function(_obj)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", _obj.tradeaccount);
        localStorage.setItem("accountcompany", $scope.accountcompany);//证券公司id
        localStorage.setItem("accountName", encodeURIComponent($scope.accountzqgs));
        localStorage.setItem("accountShow", $scope.accountShowValue);
        localStorage.setItem("accountzlValue", $scope.account);//当前自留账户
        if(_obj.status == "cp2" || _obj.status == "cp3")
        {
            setbackList(window.location.href);
            window.location.href = "tradeBase_bgt.html";
        }
    }


    //查看行情
    $scope.hqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        obj.account = $scope.childaccount;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        //window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        //window.location.href = "tradinglive_info.html";
        xinyuNewBrowser("tradinglive_info.html?opentype=newwebview");
    }

    //数据刷新
    $scope.refreshClick = function()
    {
        var message = {};
        message['account'] = $scope.accountShowValue;//主账号
        ajaxService.sendMessage("counter.synctradeaccountaction", message, $scope.synctradeaccountactionCallBack);
    }

    $scope.synctradeaccountactionCallBack = function(_data)
    {
        //console.log("刷新", _data);
        $scope.ccquery();
    }

    //日收益分析
    $scope.gotorsyfx = function()
    {
        $scope.zcmain = false;//资产界面
        $scope.zcrsyfxDivShow = true;//日收益分析
        $scope.zcgetrsyfx();
    }

    $scope.zcgetrsyfx = function()
    {
        $scope.sytjfxArray = [];

        var message = {};
        message['account'] = $scope.accountShowValue;
        message['kssj'] = "";
        message['jssj'] = gettodayno();
        //console.log("收益分析 sunflower.getSytjAction",$scope.childaccount, message['kssj']);
        ajaxService.sendMessage("sunflower.getSytjAction", message, $scope.p_selecthissecuritymoneyCallBack) ;
    }

    $scope.p_selecthissecuritymoneyCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.sytj;
            //var syarr = [];
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.syl = parseFloat(arr[i].monsyl)*100;
                if(obj.syl > 0)
                {
                    obj.flag = "1";
                }
                else if(obj.syl <0)
                {
                    obj.flag = "-1";
                }
                else
                {
                    obj.flag = "0";
                }
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用
                obj.changemoney = parseFloat(arr[i].monchangemoney);

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    obj2.changemoney = parseFloat(arr3[j].changemoney);

                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
        }
    }

    $scope.zcrsyfxbackto = function()
    {
        $scope.zcmain = true;//资产界面
        $scope.zcrsyfxDivShow = false;//日收益分析
    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }

    //日收益分析详情
    $scope.rsyfxItem = function(_obj)
    {
        //console.log(_obj.sj);
        //setbackList(window.location.href);
        //window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate);
        xinyuNewBrowser("rsyfxinfo.html?account=" + $scope.accountShowValue + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=newwebview");
    }

    //买卖
    $scope.buysellClick = function(_obj)
    {
        //console.log("cdcad");
        //window.location.href = "tradeBase_buysell.html?account=" + $scope.childaccount + "&accountcompany=" + $scope.accountcompany + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.accountzqgs) + "&stock=" + _obj.stockcodeall + "&isbgt=1&opentype=newwebview";
        xinyuNewBrowser("tradeBase_buysell.html?account=" + $scope.childaccount + "&accountcompany=" + $scope.accountcompany + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.accountzqgs) + "&stock=" + _obj.stockcodeall + "&isbgt=1&opentype=newwebview");
    }
}
