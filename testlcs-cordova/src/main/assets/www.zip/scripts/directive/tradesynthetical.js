function tradesynthetical()
{
     return {
         restrict: 'E',
         templateUrl: 'html/trade_synthetical.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function tradesyntheticalCtrl($scope, ajaxService, $cookieStore) {
    $scope.zhInfo = {};
    $scope.childaccount = "";
    $scope.childaccountStr = "";
    $scope.zhInfo.dqcw = "--";//当前仓位
    //$scope.zhInfo.dysyl = "--";//当月收益率
    //$scope.zhInfo.jrsy = "--";//当日收益率
    $scope.zhInfo.qssj = "--";//起始时间
    //$scope.zhInfo.ljsyl = "--";//累计收益率
    $scope.sylArray = [];//历史净值
    $scope.sylshowmaxlen = 30;//判断显示的最大个数，大于此值，则处理显示
    $scope.sylChartArray = new Object();//收益率图
    $scope.sylscaleSteps = 4;//Y轴刻度个数
    $scope.sylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.sylscaleStartValue = -20;//y轴的起始值
    $scope.sylstep = 10;//计算步长
    $scope.zhmianShow = true;//主界面
    $scope.sylListShow = false;//历史净值

    $scope.ztList = [];//涨停列表
    $scope.dtList = [];//跌停列表

    //$scope.account = getParameter("account");

    //置顶
    $scope.gotoUp = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        console.log("tradesynthetical可用资金", _data);
        var arr = _data.money;
        if(arr != null && arr != undefined)
        {
            if(parseFloat(arr.zsz.toString()) == 0)
            {
                $scope.zhInfo.dqcw = "空仓";//当前仓位
            }
            else if(parseFloat(arr.zsz.toString()) == parseFloat(arr.zzc.toString()))
            {
                $scope.zhInfo.dqcw = "满仓";//当前仓位
            }
            else
            {
                $scope.zhInfo.dqcw = (parseFloat(arr.zsz.toString())/parseFloat(arr.zzc.toString())*100).toFixed(0) + "%";//当前仓位
            }
            $scope.zhInfo.jrsy = parseFloat(arr.jrsy);//当日收益率
            //console.log("当日收益："+ arr.jrsy, arr.ljsy);
            $scope.zhInfo.dysyl = "--";//当月收益率
            $scope.zhInfo.qssj = arr.createtime.toString().substr(0,10);//起始时间
            $scope.zhInfo.ljsyl = parseFloat(arr.ljsy);//累计收益率
        }
        //   //$scope.zhInfo = {};
        //   ////console.log(parseFloat(arr[0].zzc.toString()) - parseFloat(arr[0].drcrj.toString()) - parseFloat(arr[0].srjc.toString()));
        //   //$scope.zhInfo.zzc = (parseFloat(arr[0].zzc.toString())).toFixed(2);
        //   //$scope.zhInfo.zsz = (parseFloat(arr[0].zsz.toString())).toFixed(2);
        //   //$scope.zhInfo.zyk = (parseFloat(arr[0].zzc.toString()) - parseFloat(arr[0].ljcrj.toString())).toFixed(2);
        //   //$scope.zhInfo.drckyk = (parseFloat(arr[0].zzc.toString()) - parseFloat(arr[0].drcrj.toString()) - parseFloat(arr[0].srjc.toString())).toFixed(2);
        //   //$scope.zhInfo.kyzj = (parseFloat(arr[0].kyzj.toString())).toFixed(2);
        //

        //}
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    $scope.getsecurityhisnetactionCallBack = function(_data)
    {
        console.log("tradesynthetical历史净值", _data);
        $scope.sylArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.netlist;
            for (var item in element)
            {
                var obj = {};
                var str = element[item]['day'].toString();
                obj.label= str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.value = (parseFloat(element[item]['net'])).toFixed(4);//净值
                //console.log(obj.value);
                obj.zzc = (parseFloat(element[item]['net'])).toFixed(4);//净值
                obj.ny = str.substr(0,6);//年月
                obj.status = "0";//0：显示，1：不显示，界面显示用处理
                obj.ym = "1";//是否是月末 0：是，1：不是，界面显示处理
                obj.ymshow = "1";//是否展开 0：展开，1：没有展开 ，界面显示用
                $scope.sylArray.push(obj);
            }

            var labarr = [];//收益率图label
            var dataarr = [];//收益率图data
            var sylmax = 0;//最大值
            //var sylmin = 0//最小值
            if($scope.sylArray.length>0)
            {
                sylmax = Math.abs($scope.sylArray[0].value);
            }

            for(var i = 0;i<$scope.sylArray.length;i++)
            {
                labarr.push($scope.sylArray[i].label);
                dataarr.push($scope.sylArray[i].value);
                sylmax = Math.max(sylmax, Math.abs($scope.sylArray[i].value));
                //sylmin = Math.min(sylmin, Math.abs($scope.sylArray[i].value));
            }
            //console.log(sylmax);
            if((sylmax.toString()).indexOf(".",0) != -1)
            {
                //console.log((sylmax.toString()).indexOf(".",0));
                $scope.sylstep = (sylmax.toString()).indexOf(".",0) *10;
            }
            else
            {
                $scope.sylstep = sylmax.toString().length * 10;
            }
            //console.log($scope.sylstep);
            var max = (Math.floor(sylmax/$scope.sylstep) + 1)*$scope.sylstep;
            // console.log(max)
            $scope.sylscaleStepWidth = max/2;
            $scope.sylscaleStartValue = -1*max;

            $scope.sylChartArray = new Object();

            var valueObj = new Object();
            valueObj.fillColor = "rgba(220,220,220,0.5)";
            valueObj.strokeColor = "rgba(220,220,220,0.8)";
            valueObj.highlightFill = "rgba(220,220,220,0.75)";
            valueObj.highlightFill = "rgba(220,220,220,1)";
            valueObj.data = dataarr;

            var datasetsArr = [];
            datasetsArr.push(valueObj);
            $scope.sylChartArray.labels = labarr;
            $scope.sylChartArray.datasets = datasetsArr;

            //曲线图
            var ctx = document.getElementById("chart_line").getContext("2d");
            document.getElementById("chart_line").style.width = document.getElementById("cvsDiv").style.width;
            document.getElementById("chart_line").style.height = 170;
            var myNewChart = new Chart(ctx).Line($scope.sylChartArray, {
                //scaleShowLabels: false, //纵坐标是否显示
                //scaleOverride :true ,   //是否用硬编码重写y轴网格线
                //scaleSteps : 4,        //y轴刻度的个数
                //scaleStepWidth : 300,   //y轴每个刻度的宽度
                //scaleStartValue : 0,    //y轴的起始值
                responsive : false,//是否响应，移动到图形上，出现相应的点值
                animation: false ,//是否有动画效果
                //scaleLabel : "<%=value%>%",//显示百分比
                showTooltips: false,
                pointDot : false,      //是否显示点
                scaleOverride :true ,   //是否用硬编码重写y轴网格线
                scaleSteps : $scope.sylscaleSteps,       //y轴刻度的个数
                scaleStepWidth : $scope.sylscaleStepWidth,   //y轴每个刻度的宽度
                scaleStartValue : $scope.sylscaleStartValue   //y轴的起始值
                //animationSteps : 60    //动画的步数
                //pointDot : true,        //是否显示点
                //pointDotRadius : 5,     //点的半径
                //pointDotStrokeWidth : 1,//点的线宽
                //datasetStrokeWidth : 3 //数据线的线宽

            });

            //处理是否显示
            if($scope.sylArray.length > $scope.sylshowmaxlen)//一个月内，全部显示<=30则不处理
            {
                for(var i = 0;i<$scope.sylArray.length-1; i++)
                {
                    if($scope.sylArray[i].ny == $scope.sylArray[i+1].ny)//与下一个日期的年月相同，表示不是月最后一天，不显示
                    {
                        $scope.sylArray[i].status = "1";//不显示
                    }
                    else
                    {
                        $scope.sylArray[i].ym = "0";//月末
                    }
                }
                //第一天和最后一天显示
                $scope.sylArray[0].status = "0";
                $scope.sylArray[$scope.sylArray.length - 1].status = "0";
                //最后一天作为月末数据，点击显示相同月份其他数据
                $scope.sylArray[$scope.sylArray.length - 1].ym = "0";
            }
        }
    }

    $scope.getlsjz = function()
    {
        //获取资产信息
        $scope.ztList = [];//涨停
        $scope.dtList = [];//跌停
        var message = {};
        message['account'] = $scope.childaccount;
        //console.log($scope.childaccount, "sunflower.p_getaccountnettrend");
        ajaxService.sendMessage("sunflower.p_getaccountnettrend", message, $scope.getsecurityhisnetactionCallBack) ;
    }

    $scope.p_getaccountupdownCallBack = function(_data)
    {
        console.log("涨跌停", _data);
        $scope.ztList = [];//涨停
        $scope.dtList = [];//跌停

        if(_data.op.code.toString() == "Y")
        {
            var element = _data.limitup;
            for (var item in element)
            {
                var obj = {};
                obj.stockcode = element[item]['stockcode'].toString();
                obj.stockname = element[item]['name'].toString();
                obj.exchange = element[item]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element[item]['industry'].toString();
                var str = element[item]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                $scope.ztList.push(obj);
            }

            var element2 = _data.limitdown;
            for (var item2 in element2)
            {
                var obj = {};
                obj.stockcode = element2[item2]['stockcode'].toString();
                obj.stockname = element2[item2]['name'].toString();
                obj.exchange = element2[item2]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element2[item2]['industry'].toString();
                var str = element2[item2]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                $scope.dtList.push(obj);
            }
        }
    }

    //获取涨跌停
    $scope.getzdt = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        message['kssj'] = "0";
        ajaxService.sendMessage("sunflower.p_getaccountupdown", message, $scope.p_getaccountupdownCallBack) ;

    }

    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        if(_data.caption == "tradesynthetical")
        {
            $scope.childaccount = _data.account;
            $scope.childaccountStr = "***" + $scope.childaccount.substr($scope.childaccount.length-4);
            $scope.getccinfo();
            $scope.getlsjz();
            $scope.getzdt();
        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "tradesynthetical"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);

    //历史净值点击显示
    $scope.sylItemClick = function(_obj)
    {
        //console.log("月份", _obj.ym);
        if(_obj.ym == "0")//为月末，点击后显示对应月全部
        {
            for(var i = 1;i<$scope.sylArray.length;i++)//第一个无需处理，一直显示
            {
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "1")//同一月份且不为月末的状态切换
                {
                    if($scope.sylArray[i].status == "0")
                    {
                        $scope.sylArray[i].status = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].status = "0";
                    }
                }
                if($scope.sylArray[i].ny == _obj.ny && $scope.sylArray[i].ym == "0")//月末
                {
                    if($scope.sylArray[i].ymshow == "0")
                    {
                        $scope.sylArray[i].ymshow = "1";
                    }
                    else
                    {
                        $scope.sylArray[i].ymshow = "0";
                    }
                }
            }
        }
    }

    //显示历史净值列表
    $scope.gotoYield = function()
    {
        $scope.zhmianShow = false;
        $scope.sylListShow = true;
        $scope.gotoUp();
    }

    //返回上一级
    $scope.sylbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.sylListShow = false;
        $scope.gotoUp();
    }
}
