
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gtbdetectiveCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    //$scope.userObj = {};//客户信息
    $scope.index = "2";//默认显示理财服务
    $scope.tabOneShow = true;//理财服务
    $scope.tabTwoShow = false;//跟投
    $scope.dqgtArray = [];//当前跟投数组
    $scope.dqlcbArray = [];//当前发布的、被跟投的理财包

    $scope.tabdivShow = true;
    $scope.allrsyfxDivShow = false;
    //console.log($scope.opentype);

    $scope.gtbobj = {};//跟投宝相关数据
    $scope.gtbobj.bgtAccount = "--";//理财包个数
    $scope.gtbobj.lcbljsyfc = "--";//理财包累计收益分成
    $scope.gtbobj.lcbljsy = "--";//理财包累计收益，给客户创造的收益的累计
    $scope.gtbobj.lcbljgtje = "--";//理财包累计跟投金额
    $scope.gtbobj.gtAccount = "--";//跟投理财包个数
    $scope.gtbobj.gtljsy = "--";//跟投累计收益
    $scope.gtbobj.gtljgtje = "--";//跟投累计跟投金额
    $scope.historylcfwAccount = "--";//历史理财包个数
    $scope.historygtAccount = "--";//历史理财包个数

    $scope.dqgtObj = {};
    $scope.dqgtObj.signcount = "--";//当前跟投单数
    $scope.dqgtObj.signmoney = "--";//当前跟投金额
    $scope.dqgtObj.drsy = "--";//当日总收益
    $scope.dqgtObj.drsyl = "--";//当日总收益率
    $scope.dqgtObj.ljsy = "--";//实盘中跟投累计收益
    $scope.dqgtObj.ljsyl = "--";//实盘中跟投累计收益率
    $scope.dqgtObj.applycount = "--";//报名数
    $scope.dqgtObj.removecount = "--";//解除中数
    $scope.dqgtObj.tradecount = "--";//实盘中数
    $scope.dqgtObj.unpaycount = "--";//未付款数
    $scope.dqgtObj.ungradecount = "--";//未评论数
    $scope.dqgtObj.endcount = "--";//已结束数（已结束包括未付款和未评论）



    //产品 预售期（报名期）：cp1(A)； 交易期：cp2(B)；解除中：cp3(D)
    //跟投  跟投中：gt1 (B)； 解除中：gt2(C)
    //报名 ybm

    //console.log("hash",window.location.hash);

    //if (window.location.hash == "#index=1")
    //{
    //    $scope.index = '1';
    //}
    //else if (window.location.hash == "#index=2")
    //{
    //    $scope.index = '2';
    //}
    //if($scope.lcsstatus != "2")
    //{
    //    $scope.index = "2";
    //}

    $scope.p_selectrelativeproductsCallBack = function(_data)
    {
        //console.log("当前跟投",_data);
        $scope.dqgtArray = [];
        if(_data.gentoulist.length>0)//跟投中
        {
            var arr1 = _data.gentoulist;
            for(var i = 0; i<arr1.length;i++)
            {
                var obj = {};
                if(arr1[i].status == "B")//跟投中：gt1 (B)； 解除中：gt2(C)
                {
                    obj.status = "gt1";
                }
                else if(arr1[i].status == "C")
                {
                    obj.status = "gt2";
                    obj.mbsy = arr1[i].targetprofit;
                }
                obj.linkaccount = arr1[i].linkaccount;//当前跟投的账户
                obj.linkid = arr1[i].id;
                var bgtuser = arr1[i].linkeduser.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.bgtuserid = bgtuser.f_id;
                obj.productname = arr1[i].productname;//产品id
                obj.productid = arr1[i].productid;//产品id
                obj.zq = arr1[i].gentouperiod;//周期
                //obj.drsyl = (parseFloat(arr1[i].linkaccountmoney.jrsy)*100).toFixed(2);
                //obj.ljsyl = (parseFloat(arr1[i].linkaccountmoney.ljsy)*100).toFixed(2);
                obj.drsyl = parseFloat(arr1[i].linkaccountmoney.jrsy);
                obj.ljsyl = parseFloat(arr1[i].linkaccountmoney.ljsy);
                var str = arr1[i].endgentoutime.toString();
                //obj.jssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                obj.jssj = str;
                $scope.dqgtArray.push(obj);
            }
            //console.log("length", $scope.dqgtArray);
        }
        if(_data.applylist.length>0)//跟投申请
        {
            var arr2 = _data.applylist;
            //console.log("已报名",arr2.length);
            for(var i = 0;i<arr2.length;i++)
            {
                var obj = {};
                obj.status = "ybm";
                var bgtuser = arr2[i].linkuser.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.bgtuserid = bgtuser.f_id;
                obj.applyid = arr2[i].id;
                obj.productname = arr2[i].productname;
                obj.productid = arr2[i].productid;//产品id
                obj.productname = arr2[i].productname;//产品id
                obj.zq = arr2[i].gentouperiod;//周期
                obj.gtje = arr2[i].money;//跟投金额
                obj.mbsy = arr2[i].targetprofit;
                var str = arr2[i].gentouday;
                obj.gtrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//跟投日期
                //var str2 = arr2[i].endapplytime.toString();//跟投报名截止时间
                //obj.bmjzsj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                //console.log(arr2[i].endapplytime.toString());
                obj.bmjzsj = arr2[i].endapplytime.toString();//跟投报名截止时间
                obj.bmjzsjstr = arr2[i].endapplytimedesc.toString();
                $scope.dqgtArray.push(obj);
            }
        }
    }

    //当前跟投
    $scope.getdqgt = function()
    {
        //console.log("1")
        //$scope.dqgtArray = [];
        //var obj = {};
        //obj.status = "0";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";//发布者信息
        //obj.username = "黄磊";
        //obj.productname = "招财一号";
        //obj.productid = "cpid";//产品id
        //obj.zq = "三个月";//周期
        //obj.bmrs = "8";//报名人数
        //obj.jzrq = "2015-09-03";//报名截止日期
        //
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "0";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "黄磊";
        //obj.productname = "招财二号";
        //obj.productid = "cpid2";//产品id
        //obj.zq = "三个月";//周期
        //obj.bmrs = "10";//报名人数
        //obj.jzrq = "2015-09-06";//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "1";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升";
        //obj.productid = "cpid3";//产品id
        //obj.zq = "半年";//周期
        //obj.gtje = 100000;//跟投金额
        //obj.jzrq = "2015-09-06";//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "2";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.account = "13143143";
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升2号";
        //obj.productid = "cpid4";//产品id
        //obj.zq = "一年";//周期
        //obj.drsyl = 10.12;//跟投金额
        //obj.ljsyl = 20.12;//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "3";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升3号";
        //obj.productid = "cpid5";//产品id
        //obj.zq = "一年";//周期
        //obj.drsyl = 10.12;//跟投金额
        //obj.ljsyl = 20.12;//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //console.log($scope.dqgtArray.length);

        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_selectrelativeproducts", message, $scope.p_selectrelativeproductsCallBack);

    }

    $scope.getlcfwCallBack = function(_data)
    {
        $scope.dqlcbArray = [];

        //console.log("当前理财包",_data);
        if(_data.productlist.length>0)//自己的产品：发布中、被跟投中
        {
            var arr3 = _data.productlist;
            for(var i = 0;i<arr3.length;i++)
            {
                if(arr3[i].status.toString() == "A")//预售期（已发布，报名期）：cp1(A)； 交易期：cp2(B)；解除中：cp3(D)
                {
                    var obj = {};
                    obj.status = "cp1";
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.mbsy = arr3[i].targetprofit;
                    obj.beginapplytime = arr3[i].beginapplytime;

                    var str = arr3[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr3[i].endapplytimedesc;//报名截止日期

                    $scope.dqlcbArray.push(obj);
                }
                if(arr3[i].status.toString() == "G")//预售期（已发布，报名期）：cp1(A)； 交易期：cp2(B)；解除中：cp3(D)；服务开始延期cp4(G)
                {
                    var obj = {}
                    obj.status = "cp4";
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.mbsy = arr3[i].targetprofit;
                    obj.beginapplytime = arr3[i].beginapplytime;

                    var str = arr3[i].endapplyday;
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
                    obj.jzrq = str;//报名截止日期
                    obj.jzrqstr = arr3[i].endapplytimedesc;//报名截止日期

                    $scope.dqlcbArray.push(obj);
                }
                else if(arr3[i].status.toString() == "B")//被跟投中
                {
                    var obj = {};
                    obj.status = "cp2";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    var str = arr3[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr3[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;

                    $scope.dqlcbArray.push(obj);
                }
                else if(arr3[i].status.toString() == "D")//解除中
                {
                    var obj = {};
                    obj.status = "cp3";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //console.log("kec", obj.gentoucount);
                    obj.endgentoutime = arr3[i].endgentoutime + "解除";//多久前解除跟投
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    obj.mbsy = arr3[i].targetprofit;
                    $scope.dqlcbArray.push(obj);
                }
            }
        }
    }

    $scope.getlcfw = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_selectrelativeproducts", message, $scope.getlcfwCallBack);
    }

    $scope.p_getgentoustatisticsCallBack = function(_data)
    {
        //console.log("累计数据：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.gtbobj = {};//跟投宝相关数据
            $scope.gtbobj.bgtAccount = _data.gentoustatistic.bgtcount + "单";//理财包个数
            $scope.gtbobj.lcbljsyfc = parseFloat(_data.gentoustatistic.bgtljsy);//理财包累计收益
            $scope.gtbobj.lcbljgtje = parseFloat(_data.gentoustatistic.bgtljgtje);//理财包累计跟投金额
            $scope.gtbobj.lcbljsy = parseFloat(_data.gentoustatistic.bgtwyhcssy);
            $scope.gtbobj.gtAccount = _data.gentoustatistic.gtcount + "单";//跟投理财包个数
            $scope.gtbobj.gtljsy = parseFloat(_data.gentoustatistic.gtljsy);//跟投累计收益
            $scope.gtbobj.gtljgtje = parseFloat(_data.gentoustatistic.gtljgtje);//跟投累计跟投金额
        }
    }

    $scope.getgtbInfo = function()
    {
        //console.log("累计");
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_getgentoustatistics", message, $scope.p_getgentoustatisticsCallBack);

    }

    $scope.linkedhisgentouCallBack = function(_data)
    {
        //console.log("历史被跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            $scope.historylcfwAccount = arr.length;
        }
    }

    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);

    }

    $scope.p_selecthisgentouCallBack = function(_data)
    {
        //console.log("历史跟投其他人", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.historygtAccount = _data.hisaccountlinklist.length;
        }
    }

    //跟投其他人
    $scope.getlsgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("gentou.p_selecthisgentou", message, $scope.p_selecthisgentouCallBack);
    }

    $scope.gtinfoCallBack = function(_data)
    {
        //console.log("跟投信息", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.dqgtObj.signcount = _data.gentoustats.signcount;
            if($scope.dqgtObj.signcount == "" || $scope.dqgtObj.signcount == undefined || $scope.dqgtObj.signcount == null)
            {
                $scope.dqgtObj.signcount = 0;
            }
            $scope.dqgtObj.signmoney = _data.gentoustats.signmoney;
            if($scope.dqgtObj.signmoney == "" || $scope.dqgtObj.signmoney == undefined || $scope.dqgtObj.signmoney == null)
            {
                $scope.dqgtObj.signmoney = 0;
            }
            $scope.dqgtObj.drsy = _data.gentoustats.drsy;
            if($scope.dqgtObj.drsy == "" || $scope.dqgtObj.drsy == undefined || $scope.dqgtObj.drsy == null)
            {
                $scope.dqgtObj.drsy = 0;
            }
            $scope.dqgtObj.drsyl = _data.gentoustats.drsyl;
            if($scope.dqgtObj.drsyl == "" || $scope.dqgtObj.drsyl == undefined || $scope.dqgtObj.drsyl == null)
            {
                $scope.dqgtObj.drsyl = 0;
            }
            $scope.dqgtObj.ljsy = _data.gentoustats.ljsy;
            if($scope.dqgtObj.ljsy == "" || $scope.dqgtObj.ljsy == undefined || $scope.dqgtObj.ljsy == null)
            {
                $scope.dqgtObj.ljsy = 0;
            }
            $scope.dqgtObj.ljsyl = _data.gentoustats.ljsyl;
            if($scope.dqgtObj.ljsyl == "" || $scope.dqgtObj.ljsyl == undefined || $scope.dqgtObj.ljsyl == null)
            {
                $scope.dqgtObj.ljsyl = 0;
            }
            $scope.dqgtObj.applycount = _data.gentoustats.applycount;
            $scope.dqgtObj.removecount = _data.gentoustats.removecount;
            $scope.dqgtObj.tradecount = _data.gentoustats.tradecount;
            $scope.dqgtObj.unpaycount = _data.gentoustats.unpaycount;
            $scope.dqgtObj.ungradecount = _data.gentoustats.ungradecount;
            $scope.dqgtObj.endcount = _data.gentoustats.endcount;
        }

    }

    $scope.gtinfo = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        console.log("获取跟投信息", $scope.userObj.f_id)
        ajaxService.sendMessage("sunflower.p_getmyinfobycustomer", message, $scope.gtinfoCallBack);

    }



    $scope.gtbjeCallBack = function(_data)
    {
        //console.log("跟投宝", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.gtbky = _data.moneyinfo.zzj;
        }
    }

    $scope.gtbje = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getgentoubaomoney", message, $scope.gtbjeCallBack);
    }

    //理财服务、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//理财服务
        {
            //$scope.tabOneShow = true;
            //$scope.tabTwoShow = false;
            //$scope.tabThreeShow = false;
            ////window.location.href = "#index=1";
            //$scope.index = "1";
            //
            //$scope.getlcfw();
            //$scope.getlsbgtList();//历史理财包
        }
        else if(_str == "2")//跟投
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
	        $scope.tabThreeShow = false;
            $scope.index = "2";
            //window.location.href = "#index=2";
            $scope.gtinfo();
            $scope.gtbje();
            //$scope.getdqgt();
            //$scope.getlsgtList();//历史跟投其他人
        }
        $scope.getgtbInfo();
    }


    //初始相关操作界面
    $scope.gtbInit = function()
    {
        //console.log(11);
        try
        {
            $scope.changeTab($scope.index);
            //$scope.getdqgt();
        }catch (e){}
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("caption", _data.caption);
        if(_data.caption == "gtbdirective")
        {
            $scope.gtbInit();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtbdirective"};
    $scope.$emit("gtbdirective", cstr);


    //进入跟投日收益分析
    $scope.allsyfxshowClick = function()
    {
        $scope.tabdivShow = false;
        $scope.allrsyfxDivShow = true;
        $scope.baseBottomVisible(false);
        $scope.getrsyfx();
    }

    $scope.getrsyfx = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['shopid'] = $scope.bcidstr;
        //console.log("收益分析", message);
        ajaxService.sendMessage("gentou.selecthisgentousyaction", message, $scope.getrsyfxCallBack) ;
    }

    $scope.getrsyfxCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.sytj;
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.gtje = parseFloat(arr[i].mongentoumoney);
                //obj.syl = parseFloat(arr[i].monsyl)*100;
                //if(obj.syl > 0)
                //{
                //    obj.flag = "1";
                //}
                //else if(obj.syl <0)
                //{
                //    obj.flag = "-1";
                //}
                //else
                //{
                //    obj.flag = "0";
                //}
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    obj2.changemoney = parseFloat(arr3[j].changemoney);

                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
        }

    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }

    $scope.allrsyfxbackto = function()
    {
        $scope.tabdivShow = true;
        $scope.allrsyfxDivShow = false;
        $scope.baseBottomVisible(true);

        $scope.gtinfo();
    }

    //跟投list点击
    $scope.gtlistItemClick = function(_obj)
    {
        if(_obj.status == "cp1")
        {
            //setbackList(window.location.href);
            //window.location = "gt_yfb.html?productid=" + _obj.productid;
            xinyuNewBrowser("gt_yfb.html?productid=" + _obj.productid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
        }
        else if(_obj.status == "cp4")
        {
            //setbackList(window.location.href);
            //window.location = "gt_yfb.html?productid=" + _obj.productid;
            xinyuNewBrowser("gt_yfb.html?productid=" + _obj.productid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
        }
        else if(_obj.status == "ybm")
        {
            //setbackList(window.location.href);
            //window.location = "gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我") , "dqgtupdate");
        }
        else if(_obj.status == "cp2")
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
        }
        else if(_obj.status == "cp3")
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            xinyuNewBrowser("gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
        }
        else  if(_obj.status == "gt1")
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqgtupdate");
        }
        else  if(_obj.status == "gt2")
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            xinyuNewBrowser("gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqgtupdate");
        }
    }

    //当前理财服务刷新
    dqlcbupdate = function()
    {
        $scope.getlcfw();
    }

    //当前跟投刷新
    dqgtupdate = function()
    {
        $scope.getdqgt();
    }

    //各状态服务
    $scope.gtstatusClick = function(_str)
    {
        //setbackList(window.location.href);
        //window.location = "gt_allstatuslist.html?type=" + _str + "&&backtitle=" + encodeURI("我") + "&&opentype=newwebview";
        xinyuNewBrowser("gt_allstatuslist.html?type=" + _str + "&&opentype=newwebview"+ "&&backtitle=" + encodeURI("我"), "updategtztinfo");
    }

    updategtztinfo = function()
    {
        //alert("121321");
        $scope.gtinfo();
        $scope.getgtjj();
        $scope.gtbje();
    }

    //历史跟投，理财服务（用户自己发布的理财包）
    $scope.gtb_tab1lsgtClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "gt_history.html?type=1";
        xinyuNewBrowser("gt_history.html?type=1" + "&&opentype=newwebview"+ "&&backtitle=" + encodeURI("我"));
    }
    //历史跟投，跟投（跟投其他人的服务）
    $scope.gtb_tab2lsgtClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "gt_history.html?type=2";
        xinyuNewBrowser("gt_history.html?type=2" + "&&opentype=newwebview"+ "&&backtitle=" + encodeURI("我"));
    }

    //发布跟投
    $scope.gtb_fbgtClick = function()
    {
        //window.location = "gtrelease.html?backurl=gtbBase.html";
        //setbackList(window.location.href);
        //window.location = "gtrelease.html";
        xinyuNewBrowser("gtrelease.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
    }

    //跟投资金
    $scope.gtb_tab1gtzjClick = function()
    {
        //window.location = "gtb/gtb-index.html?backurl=../gtbBase.html?opentype=newwebview#index=1";
        //window.location = "gtb/gtb-index.html?backurl=../gtbBase.html?opentype=newwebview#index=1";

        xinyuNewBrowser("gtb/gtb-index.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }
    //充值
    $scope.gtb_tab2czClick = function()
    {
        //window.location = "gtb/gtb-czindex.html?backurl=../gtbBase.html?opentype=newwebview#index=2";
        xinyuNewBrowser("gtb/gtb-czindex.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }

    //圈子跟投
    $scope.me_qzgtClick = function()
    {
        //window.location = "gtCircle.html" + "?backtitle=" + encodeURI("我");
        xinyuNewBrowser("gtCircle.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview", "updategtztinfo");
    }


    //跟投持仓一览
    $scope.me_gtccyl = function()
    {
        //window.location = "gtPosition.html" + "?backtitle=" + encodeURI("我");
        xinyuNewBrowser("gtPosition.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview");
    }

    //我的跟投宝

    $scope.me_gtb = function()
    {
        //window.location = "mygtb.html" + "?backtitle=" + encodeURI("我");
        xinyuNewBrowser("mygtb.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview", "updategtztinfo");
    }
}



