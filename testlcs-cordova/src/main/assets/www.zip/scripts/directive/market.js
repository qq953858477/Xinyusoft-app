/**
 * Created by wangtao on 2015/9/3 0003.
 */
function marketTabService($scope) {
    var tabs = [
        {
            id: 'sh000001',
            name: '上证指数',
            directUrl: '',
            isActive: false
        },
        {
            id: 'sz399001',
            name: '深证成指',
            directUrl: '',
            isActive: false
        },
        {
            id: 'sz399006',
            name: '创业板指',
            directUrl: '',
            isActive: false
        }
    ];


    function changeTab(tab) {
        for (var i = 0; i < tabs.length; i++) {
            var tempTab = tabs[i];
            if (tempTab.id == tab['id']) {
                tempTab.isActive = true;
                window.location.href = tempTab.directUrl;
            } else {
                tempTab.isActive = false;
            }
        }
    }

    return {
        tabs: tabs,
        changeTab: changeTab
    }
}

function marketController($scope, ajaxService, marketTabService) {
    $scope.homesshqintervalDuration = 5000;//间隔时间，8000毫秒
    $scope.homesshqintervalId;

    //去除
    $scope.myhomeClearInterval = function () {
        if ($scope.homesshqintervalId != undefined) {
            clearInterval($scope.homesshqintervalId);
        }
    }
    //alert(1);
    $scope.markettabs = marketTabService.tabs;
    $scope.getSSHQ = function () {
        var message = {};
        message['code'] = '';//"sh000001,sz399001,sz399006";
        for (var i = 0; i < marketTabService.tabs.length; i++) {
            message['code'] += marketTabService.tabs[i].id;
            if (i != marketTabService.tabs.length - 1) {
                message['code'] += ',';
            }
        }
        ajaxService.sendMessage('hq.getindexhqaction', message, $scope.marketCallBack);
    };

    $scope.marketCallBack = function (_data)
    {
        $scope.myhomeClearInterval();
        //console.log("指数", _data);
        if (_data.op.code.toString() == "Y")
        {
            if (_data.datalist.length > 0)
            {
                for (var i = 0; i < marketTabService.tabs.length; i++)
                {
                    var tab = marketTabService.tabs[i];
                    // 指数
                    tab.zs = parseFloat(_data.datalist[i].close.toString()).toFixed(2);
                    var zd = parseFloat(_data.datalist[i].netchange.toString());
                    if (zd > 0) {
                        tab.zd = "+" + zd.toFixed(2);
                        tab.status = "1";//1:红，2：绿，3：白
                        tab.bz = "↑";
                    }
                    else {
                        tab.zd = zd.toFixed(2);
                        if (zd < 0) {
                            tab.status = "2";
                            tab.bz = "↓";
                        }
                        else {
                            tab.status = "3";
                            tab.bz = "";
                        }
                    }
                    var zdf = parseFloat(_data.datalist[i].netchangeratio.toString());
                    if (zdf > 0) {
                        tab.zdf = "+" + zdf.toFixed(2) + "%";
                    }
                    else {
                        tab.zdf = zdf.toFixed(2) + "%";
                    }
                    //console.log("状态",tab.status);
                }
                $scope.homesshqintervalId = setInterval($scope.getSSHQ, $scope.homesshqintervalDuration);
            }
        }
    }


    $scope.martetinit = function(newValue, oldValue, scope)
    {
        //console.log("12212", newValue, oldValue);
        if(newValue)
        {
            $scope.getSSHQ();
        }
        else
        {
            $scope.myhomeClearInterval();
        }
    }

    $scope.$watch('basetabOneShow', $scope.martetinit);


    $scope.zsClickgotohqhome = function()
    {
        //window.location = "hqBase.html?backurl=uufpBase.html";
        //try
        //{
        //    var str = "hqBase.html?backurl=uufpBase.html";
        //    var ref = cordova.InAppBrowser.open(str, '_blank', 'location=no,toolbar=no');
        //    ref.addEventListener("exit", $scope.zxgupdateCallBack);
        //}
        //catch (e){
        //    window.location = "hqBase.html?backurl=uufpBase.html";
        //}

        xinyuNewBrowser("hqBase.html?backurl=uufpBase.html", "zxgupdateCallBack");
    }

    zxgupdateCallBack = function()
    {
        $scope.basezxgUpdate();
    }
}
function market() {
    return {
        restrict: 'E',
        templateUrl: 'template/marketSurvey.html',
        //template: '<span>Hi there</span>',
        replace: true,
        //transclude: true,
        controller: marketController
    };
}