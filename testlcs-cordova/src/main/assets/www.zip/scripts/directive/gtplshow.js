function gtplshow()
{
	return {
		restrict: 'E',
		templateUrl: 'html/gt_pl_show.html',
		//template: '<span>Hi there</span>',
		replace: true,
		transclude: true
	};
}
function gtplshowCtrl($scope, ajaxService, $cookieStore) {
    $scope.plListArray = [];
    $scope.plcontent = "";
    $scope.plingMark = true;//评论中
	$scope.plcontentstr = "";//当前在发送的评论内容
    $scope.length = $scope.plListArray.length;
	$scope.curLcsid = "";//当前产品的理财师id;
	$scope.lasttime = "20151101000000";//上一次显示的时间;
    //var cHeight = $('body').height();//获取当前页面的高度
    //$("#content").height(cHeight-147);//设置评论div的高度
    $scope.isFlower = false;
    $scope.imgSrc = "";
    //$scope.whichClick = "";//发送图片或者文字
	
    $scope.getplCallBack = function(_data)
    {
        //console.log("消息",_data);
        $scope.plListArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.list;
            var length = arr.length;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.content = arr[i].f_cnt;
                if(obj.content == "//flower//"){
                	obj.content = "";
                	obj.isFlower = true;
                	obj.imgSrc = "images/sendflower.png";
                }
                //var t = arr[i].f_createtime.toString();
                //obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
                //obj.time = isshowTime(obj.t);
				obj.time = arr[i].spacetime;
				obj.id = arr[i].f_userid.toString();
				//if(obj.id == $scope.curLcsid){
				//	obj.ifLcs = true;
				//}else{
				//	obj.ifLcs = false;
				//}
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
				if($scope.curLcsid == obj.id)
				{
					obj.islcsself = true;
				}
				else
				{
					obj.islcsself = false;
				}
                $scope.plListArray.push(obj);
                //$scope.$apply();
                //$("#content").scrollTop($("#content")[0].scrollHeight);
            }
            //if($scope.plListArray.length>0)
			//{
             //   $scope.plListArray.reverse();
			//}
            //$scope.plCount = $scope.plListArray.length;
            //$scope.$apply();
            //$("#content").scrollTop($("#content")[0].scrollHeight);
        }
    }
    
    //$scope.check = function(){
    //	$("#content").scrollTop($("#content")[0].scrollHeight);
    //}
    //setInterval($scope.check(),500);
    
    $scope.getpl = function()
    {
        var message = {};
        //message['contenttype'] = "text";
        //message['lastmsgid'] = 0;
        //message['msgamount'] = "";
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        message['page.pagesize'] = "max";
        message['page.pageno'] = "";

        //message['userid'] = $scope.userObj.f_id;

        //console.log("产品评论",message);
        ajaxService.sendMessage("user.getcommnetbysubjectidaction", message, $scope.getplCallBack);
    }

	//获取理财师回调函数
	$scope.getCurlcsCallBack = function(_data){
		//console.log("获取产品理财师"+_data);
		if(_data.op.code.toString() == "Y")
		{
			$scope.curLcsid = _data.product.user.user.f_id;
			//alert(_data.product.user.user.f_id);
			$scope.getpl();
		}
		else
		{
			//alert("error");
		}
	}

	//获取当前产品理财师
	$scope.getCurlcs = function(){
		var message = {};
		message['productid'] = $scope.productid;
		//console.log("产品信息",$scope.productid);
		ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getCurlcsCallBack);
	}

    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtplshow")
        {
            $scope.getCurlcs();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsypl"};
    $scope.$emit("getParameters", cstr);

	//个人空间
	$scope.gotogrkj = function(_obj)
	{
		var localStorage = window.localStorage;
		localStorage.setItem("peopleID", _obj.id);
		//setbackList(window.location.href);
		//window.location.href="peopleSpaceBase.html";
		xinyuNewBrowser("peopleSpaceBase.html?opentype=newwebview&page=list");
	}

}
