function gtsyccfw()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_sy_cc_fw.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyccfwCtrl($scope, ajaxService, $cookieStore) {
    $scope.ccmainShow = true;
    $scope.lccjjlShow = false;
    $scope.zhInfo = {};
    $scope.childaccount = "";

    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.ccrefreshintervalDuration = 5000;//间隔时间，5000毫秒;
    $scope.ccrefreshID;

    //去除
    $scope.ccrefreshClearInterval = function () {
        if ($scope.ccrefreshID != undefined) {
            clearInterval($scope.ccrefreshID);
        }
    }

    //侦听获取参数，并请求数据
    //console.log("侦听");
    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
    });

    $scope.ccselectsecuritymoneyactionCallBack2 = function(_data)
    {
        //console.log("可用资金", _data);
        var arr = _data.money;
        $scope.cckyzj = parseFloat(arr.kyzj.toString());
        $scope.cczzc = parseFloat(arr.zzc.toString());
        $scope.cczsz = parseFloat(arr.zsz.toString());
    }

    $scope.getccinfo2 = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack2) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;

    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            //console.log("持仓",result);
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                $scope.ccljyk = parseFloat(result.ccyk.toString());
                if($scope.ccljyk >0)
                {
                    $scope.flag = "1";
                }
                else if($scope.ccljyk <0)
                {
                    $scope.flag = "-1";
                }
                else
                {
                    $scope.flag = "0";
                }
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = parseFloat(arr[i].dqj).toFixed(2);
                        obj.cbj = parseFloat(arr[i].cbj);
                        obj.yk = arr[i].fdyk;
                        obj.zdf = parseFloat(arr[i].zdf).toFixed(2) + "%";
                        var zdfv = parseFloat(parseFloat(arr[i].zdf).toFixed(2));
                        if(zdfv >0)
                        {
                            obj.zdfflag = "1";
                        }
                        else if(zdfv <0)
                        {
                            obj.zdfflag = "-1";
                        }
                        else
                        {
                            obj.zdfflag = "0";
                        }
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        obj.asset = getzqStatus(arr[i].basetype);
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

            $scope.ccrefreshClearInterval();
            //console.log("状态：", $scope.tabOneShow);
            //if($scope.wtList.length>0)
            //{
                $scope.ccrefreshID = setInterval($scope.zhqueryall, $scope.ccrefreshintervalDuration);
            //}
        });
    };

    //产品盈亏
    $scope.p_getykCallBack = function(_data) {
        //console.log("产品2222：" + _data);
        if (_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.ccljyk = parseFloat(product.ljyk);
            if($scope.ccljyk >0)
            {
                $scope.flag = "1";
            }
            else if($scope.ccljyk <0)
            {
                $scope.flag = "-1";
            }
            else
            {
                $scope.flag = "0";
            }
        }
    }

    $scope.getcpyk = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getykCallBack);
    }


    $scope.zhqueryall = function()
    {
        $scope.getccinfo2();
        $scope.query();
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsycc")
        {
            $scope.childaccount = _data.account;
            //获取资产信息
            $scope.getccinfo2();
            $scope.query();
            //不是跟投者取产品的盈亏
            //if($scope.isgtz == false)
            //{
            //    $scope.getcpyk();
            //}
        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsycc"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);

    //查看行情
    $scope.hqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        obj.account = $scope.childaccount;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        //window.location.href = "tradinglive_info.html";
        openNewInterface("tradinglive_info.html?opentype=newwebview");
    }

    //查看行情
    $scope.drjyjlhqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.gpmc);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            openNewInterface("onestockHQHtml.html?opentype=newwebview");
        }

    }

    //异常仓位处理
    $scope.gotoyccwcl = function()
    {
        //window.location.href = "exceptionHandling_cw.html?productid="+ $scope.productid;
        openNewInterface("exceptionHandling_cw.html?productid="+ $scope.productid +"&&opentype=newwebview");
    }

    //买卖
    $scope.buysellClick = function(_obj)
    {
        //console.log("cdcad");
        //window.location.href = "tradeBase_buysell.html?account=" + $scope.childaccount + "&accountcompany=" + $scope.accountcompany + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.accountzqgs) + "&tradetype=" + _tradetype + "&stock=" + _obj.stockcodeall;
        openNewInterface("tradeBase_buysell.html?account=" + $scope.childaccount  + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.zqgsname) + "&stock=" + _obj.stockcodeall + "&isbgt=0&opentype=newwebview", "updateccjyjl");
    }

    updateccjyjl = function()
    {
        //alert("取交易记录");
        $scope.getdrjyjl();
    }
}
