function gtplinput()
{
	return {
		restrict: 'E',
		templateUrl: 'html/gt_pl_input.html',
		//template: '<span>Hi there</span>',
		replace: true,
		transclude: true
	};
}
function gtplinputCtrl($scope, ajaxService, $cookieStore) {
    $scope.plListArray = [];
    $scope.plcontent = "";
    $scope.plingMark = true;//评论中
	$scope.plcontentstr = "";//当前在发送的评论内容
    $scope.length = $scope.plListArray.length;
	$scope.curLcsid = "";//当前产品的理财师id;
	$scope.lasttime = "20151101000000";//上一次显示的时间;
    $scope.isFlower = false;
    $scope.imgSrc = "";
    //$scope.whichClick = "";//发送图片或者文字
	
    //发送消息
    $scope.sendplClick = function(param)
    {
    	//$scope.whichClick = param;
        if($scope.plingMark)
        {
        	if(param == "notflower"){
        		if($scope.plcontent == "")
                {
                    myAlert("请输入评论内容");
                    return;
                }
        	}
            $scope.plingMark = false;
            var message = {};
            //message['contenttype'] = "text";
            if(param == "flower"){
            	//alert("flower");
            	message['cnt'] = "//flower//";
            }else{
            	message['cnt'] = $scope.plcontent;
            }
			$scope.plcontentstr = message['cnt'];
            //message['content'] = $scope.plcontent;
            message['subjectid'] = $scope.productid;
            message['subjecttype'] = "product";
			message['subjectuserid'] = $scope.curLcsid;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendplCallBack);
        }
        else
        {
            myAlert("评论提交中，请稍候");
        }
    }

    $scope.sendplCallBack = function(_data)
    {
        //console.log("发送消息",_data)
        if(_data.op.code.toString() == "Y")
        {
            //myAlert("评论成功");
			if(checkisFlower($scope.plcontentstr) == true)//不是花等图标
			{
				$scope.plcontent = "";
			}
            $scope.getpl();
        }
        else
        {
            myAlert("评论发送失败");
        }
        $scope.plingMark = true;
		$scope.plcontentstr = "";
    }
	
	//点击评论关闭键盘
    function closePopClick (id){
    	if(id!="foot"){
    		document.getElementById("inputview").blur();
    	}
    };

	$scope.gtplinputbackClick = function()
	{
		$scope.plinputbackto();
	}
}
