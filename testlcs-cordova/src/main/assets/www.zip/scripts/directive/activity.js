/**
 * Created by wangtao on 2015/9/3 0003.
 */

function activity() {
    return {
        restrict: 'E',
        templateUrl: 'template/activity.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: activityController
    };
}

function activityController($scope, ajaxService)
{
    // 设置轮播图图片间隔
    // 轮播图数据初始化
    $scope.slides = [];
    // 添加轮播图源
    $scope.slides.push({id: 0, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc1.png', text: '分成说明', active: true, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc1_info.png', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc1_info.png'});
    $scope.slides.push({id: 1, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc2.png', text: '分成说明', active: false, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc2_info.png', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_fc2_info.png'});
    //$scope.slides.push({id: 2, image: 'images/sqlcs_icon.png', text: '', active: false, directUrl: ''});



    $scope.openActivityUrl = function (_obj)
    {
        //if(url != "")
        //{
        //    //console.log("活动", url);
        //    //setbackList("../uufpBase.html?baseindex=1");
        //    //window.location.href = url + "?backtitle=" + encodeURI("实盘");
        //    if(url == "newfpBase.html")
        //    {
        //        //setbackList("uufpBase.html?baseindex=1&" + "backtitle=" + encodeURI("实盘"));
        //        //window.location = "newfpBase.html?backtitle=" + encodeURI("实盘");
        //        xinyuNewBrowser("newfpBase.html?backtitle=" + encodeURI("实盘"));
        //    }
        //    else
        //    {
        //        window.location.href = url +"?backurl=../uufpBase.html?baseindex=1" + "&backtitle=" + encodeURI("实盘");
        //    }
        //
        //}
        //console.log(_obj.text);
        //window.location = "activitydh/firstactivity.html?backtitle=" + encodeURI("实盘") + "&imgurl=" + encodeURI(_obj.directUrl) + "&shareurl=" + encodeURI(_obj.shareurl) + "&titlevalue=" + encodeURI(_obj.text) + "&opentype=newwebview";
        xinyuNewBrowser("activitydh/firstactivity.html?backtitle=" + encodeURI("跟投") + "&imgurl=" + encodeURI(_obj.directUrl) + "&shareurl=" + encodeURI(_obj.shareurl) + "&titlevalue=" + encodeURI(_obj.text) + "&opentype=newwebview");
    }
    //var message = {};
    //message['page.size'] = 'max';//"sh000001,sz399001,sz399006";
    //message['isactive'] = 'Y';//"sh000001,sz399001,sz399006";
    //ajaxService.sendMessage('sunflower.selectActivityAction', message, function (data) {
    //        console.log("活动", data);
    //        if (data['op']['code'] == 'Y') {
    //            var tempList = data['activitylist'];
    //            $scope.slides = [];
    //            for (var i = 0; i < tempList.length; i++) {
    //                var temp = tempList[i];
    //
    //                var activity = {
    //                    'id': i,
    //                    image: temp['picurl'],
    //                    directUrl: temp['url'],
    //                    active: i == 0
    //                }
    //                $scope.slides.push(activity);
    //            }
    //            try {
    //                //$('#myCarousel').carousel({
    //                //    interval: 6000
    //                //});
    //            } catch (e) {
    //                console.log(e);
    //            }
    //        }
    //    }
    //)
}


