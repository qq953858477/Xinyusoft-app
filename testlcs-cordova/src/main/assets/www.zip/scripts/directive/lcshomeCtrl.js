function lcshome()
{
    return {
        restrict: 'E',
        //templateUrl: 'index.html',
        templateUrl: 'html/lcshome.html',
        controller:['$scope','ajaxService','$cookieStore', lcshomeCtrl],
        //template: '<span>Hi there444</span>',
        //replace: true,
        transclude: true
    };
}

/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function lcshomeCtrl($scope, ajaxService, $cookieStore) {
    $scope.lcsindex = "1";//默认显示综合
    $scope.lcshomeDivShow = true;//主界面信息
    $scope.lcshometabOneShow = true;//综合
    $scope.lcshometabTwoShow = false;//交易
    $scope.lcshometabFourShow = false;//查询
    $scope.lcslistArray = [];//理财师
    $scope.lcslistIndex = 0;

    $scope.ccylintervalId;
    $scope.ccylintervalDuration = 5000;//间隔时间，3000毫秒

    $scope.getlcsMark = true;//是否可以获取数据

    //去除
    $scope.ccylthisClearInterval = function () {
        if ($scope.ccylintervalId != undefined) {
            clearInterval($scope.ccylintervalId);
        }
    }


    //今日收益榜
    $scope.lcsjrsyb = function()
    {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductjrsyrank', message, function (data) {
            //console.log("收益",data);
            if (data.op.code.toString() == 'Y')
            {
                $scope.lcsjrsybList = [];
                //$scope.lcsjrsybList = data['gentouproductlist'];
                //for(var i = 0;i<$scope.lcsjrsybList.length;i++)
                //{
                //    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                //    //console.log("ff", ff);
                //    $scope.lcsjrsybList[i].jrsy= parseFloat($scope.lcsjrsybList[i].jrsy);
                //    $scope.lcsjrsybList[i].ljsy= parseFloat($scope.lcsjrsybList[i].ljsy);
                //
                //    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                //    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                //}

                var arr = data.gentouproductlist;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.account = arr[i].account;//当前被跟投的账户
                    var bgtuser = arr[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    obj.productid = arr[i].id;
                    //obj.zq = arr[i].gentouperiod;//周期
                    obj.gentoucount = arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.rundays = arr[i].rundays;
                    var cwstr = arr[i].cw;
                    if(parseFloat(cwstr) == 0)
                    {
                        obj.cw = "空仓";//当前仓位
                    }
                    else if(parseFloat(cwstr) == 1)
                    {
                        obj.cw = "满仓";//当前仓位
                    }
                    else
                    {
                        obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                    }

                    $scope.lcsjrsybList.push(obj);
                }
            }
        });
    }

    $scope.ljsyb = function () {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductljsyrank', message, function (data) {
            //console.log("累计收益",data);
            if (data.op.code.toString() == "Y") {
                $scope.gtljsybList = [];
                var arr = data.gentouproductlist;
                //for(var i = 0;i<$scope.gtjrsybList.length;i++)
                //{
                //    //var ff = parseFloat($scope.gtjrsybList[i].jrsy);
                //    //console.log("ff", ff);
                //    $scope.gtjrsybList[i].jrsy= parseFloat($scope.gtjrsybList[i].jrsy);
                //    $scope.gtjrsybList[i].ljsy= parseFloat($scope.gtjrsybList[i].ljsy);
                //
                //    //var str = $scope.gtjrsybList[i].endapplyday.toString();
                //    //$scope.gtjrsybList[i].endapplyday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                //}

                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.status = "cp2";
                    obj.account = arr[i].account;//当前被跟投的账户
                    var bgtuser = arr[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    obj.productid = arr[i].id;
                    //obj.zq = arr[i].gentouperiod;//周期
                    obj.gentoucount = arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.rundays = arr[i].rundays;
                    var cwstr = arr[i].cw;
                    if(parseFloat(cwstr) == 0)
                    {
                        obj.cw = "空仓";//当前仓位
                    }
                    else if(parseFloat(cwstr) == 1)
                    {
                        obj.cw = "满仓";//当前仓位
                    }
                    else
                    {
                        obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                    }
                    $scope.gtljsybList.push(obj);
                }
            }
        });
    };



    $scope.lcshomegetlcsapplyinfoCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            if(_data.lcsapplyinfo.isexist.toString() == "true")
            {
                var lcsInformation = {};
                lcsInformation.lcshearurl = _data.lcsapplyinfo.user.user.f_head;
                //if(_data.lcsapplyinfo.user.user.f_nickname.length >3)
                //{
                //    lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname.toString().substr(0,3);
                //}
                //else
                //{
                lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname;
                if(lcsInformation.lcsname.length>3)
                {
                    lcsInformation.lcsname = lcsInformation.lcsname.substr(0,3);
                }

                if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city == undefined)
                {
                    lcsInformation.dq = "";
                }
                else if(_data.lcsapplyinfo.user.user.f_province != undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_province + _data.lcsapplyinfo.user.user.f_city;
                }
                else if(_data.lcsapplyinfo.user.user.f_province == undefined && _data.lcsapplyinfo.user.user.f_city != undefined)
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_city;
                }
                else
                {
                    lcsInformation.dq = _data.lcsapplyinfo.user.user.f_province;
                }
                //}
                lcsInformation.lcsid = _data.lcsapplyinfo.userid;
                lcsInformation.lcslszj = _data.lcsapplyinfo.lszj;
                lcsInformation.lcstzsc = _data.lcsapplyinfo.tzsc;
                lcsInformation.lcstzln = _data.lcsapplyinfo.tzln;
                if(lcsInformation.lcstzln.length>30)
                {
                    lcsInformation.lcstzln = lcsInformation.lcstzln.substr(0,30);
                }
                var sclystr = _data.lcsapplyinfo.scly;
                //console.log("sclystr",sclystr);
                var ind = sclystr.indexOf("|",0);
                if(ind == -1)//无|
                {
                    lcsInformation.lcsscly = sclystr;
                }
                else//有|
                {
                    var sclyarr = sclystr.split("|");
                    var str2 = "";
                    for(var i = 0;i<sclyarr.length;i++)
                    {
                        if(str2 == "")
                        {
                            if(sclyarr[i]!="")
                            {
                                str2 = sclyarr[i];
                            }

                        }
                        else
                        {
                            if(sclyarr[i]!="")
                            {
                                str2 = str2 + "," + sclyarr[i];
                            }
                        }
                    }
                    lcsInformation.lcsscly = str2;
                }

                var us = _data.lcsapplyinfo.user.user;
                if(us.f_weixinhao != undefined && us.f_weixinhao != null)
                {
                    lcsInformation.wxh = us.f_weixinhao;
                }
                else
                {
                    lcsInformation.wxh = "";
                }
                if(us.f_qq != undefined && us.f_qq != null)
                {
                    lcsInformation.qq = us.f_qq;
                }
                else
                {
                    lcsInformation.qq = "";
                }
                $scope.lcslistArray[$scope.lcslistIndex].lcsInformation = lcsInformation;


                $scope.lcslistIndex +=1;
                //console.log("有", $scope.lcslistIndex, $scope.lcslistArray.length);
                if($scope.lcslistIndex<$scope.lcslistArray.length)
                {
                    $scope.getoneInfo();
                }
                else
                {
                    $scope.getlcsMark = true;
                }
            }
        }
    }

    $scope.getoneInfo = function()
    {
        var message = {};
        message['userid'] = $scope.lcslistArray[$scope.lcslistIndex].id;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, $scope.lcshomegetlcsapplyinfoCallBack);
    }


    //获取账户列表
    $scope.getNewLcsActionCallBack = function(_data)
    {
        $scope.lcslistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            $scope.lcsCount = _data.count;
            var arr = _data.newlcs;
            for (var i = 0;i < arr.length; i++)
            {
                var obj = {};
                obj.id = arr[i];
                $scope.lcslistArray.push(obj);
            }
        }

        if($scope.lcslistArray.length >0)
        {
            $scope.lcslistIndex = 0;
            $scope.getoneInfo();
        }
        else
        {
            $scope.getlcsMark = true;
        }
    }

    $scope.getlcslist = function()
    {
        if($scope.getlcsMark)
        {
            $scope.getlcsMark = false;
            var message = {};
            ajaxService.sendMessage("sunflower.getNewLcsAction", message, $scope.getNewLcsActionCallBack);
        }
    }

    //综合、交易/查询、关联切换
    $scope.lcshomechangeTab = function(_str)
    {
        if(_str == "1")//交易
        {
            $scope.lcshometabOneShow = true;
            $scope.lcshometabTwoShow = false;
            $scope.lcshometabFourShow = false;
            $scope.lcsjrsyb();
        }
        else if(_str == "2")//交易
        {
            $scope.lcshometabOneShow = false;
            $scope.lcshometabTwoShow = true;
            $scope.lcshometabFourShow = false;
            $scope.ljsyb();
        }
        else//查询
        {
            $scope.lcshometabOneShow = false;
            $scope.lcshometabTwoShow = false;
            $scope.lcshometabFourShow = true;
            $scope.getlcslist();
        }
        $scope.lcsindex = _str;
    }


    $scope.lcshomeinit = function(newValue, oldValue, scope)
    {
        if(newValue) {
            $scope.lcshomechangeTab($scope.lcsindex);
        }
    }

    $scope.$watch('basetabThreeShow', $scope.lcshomeinit);


    //排行榜
    $scope.gtsyphbItemClick = function(_obj)
    {
        //console.log($scope.userObj.f_id, _obj.fbzuserid);
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            openNewInterface("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview", "",  "", "", window.location.href);
        }
        else
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            openNewInterface("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid + "&&opentype=newwebview", "",  "", "", window.location.href);
        }
    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList("uufpBase.html?baseindex=3");
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html" + "?opentype=newwebview", "",  "", "", window.location.href);
    }
}




