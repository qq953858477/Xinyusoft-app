function tradeinfo()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_info.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    };
}

function getEmptyHQ()
{
    var obj = {};
    obj.buyv1 = "-";
    obj.buyv2 = "-";
    obj.buyv3 = "-";
    obj.buyv4 = "-";
    obj.buyv5 = "-";
    obj.sellv1 = "-";
    obj.sellv2 = "-";
    obj.sellv3 = "-";
    obj.sellv4 = "-";
    obj.sellv5 = "-";

    obj.buyp1 = "-";
    obj.buyp2 = "-";
    obj.buyp3 = "-";
    obj.buyp4 = "-";
    obj.buyp5 = "-";

    obj.sellp1 = "-";
    obj.sellp2 = "-";
    obj.sellp3 = "-";
    obj.sellp4 = "-";
    obj.sellp5 = "-";

    obj.stockcode = "";
    obj.exchange = "";
    obj.lastprice = "";
    obj.name = "";
    return obj;
}

function tradeinfoCtrl($scope, ajaxService, $cookieStore) {
    $scope.zhmianShow = true;//主界面

    //侦听获取参数
    $scope.$on("setParameters", function(e, _data) {
       // console.log("tradeinfo获取参数",_data.account);
        $scope.childaccount = _data.account;
    });
    //console.log("tradeinfo侦听");
    //向父对象说明已经侦听，可以接受入参
    var cstr  = {"caption": "tradeinfo"};
    $scope.$emit("getParameters", cstr);
    //console.log("交易查询账号", $scope.childaccount);

    //显示查询/交易
    $scope.urlChange = function(_str)
    {
        $scope.urlShow = true;
        $scope.zhmianShow = false;
        window.location.href = _str;
    }

    $scope.backtoParent = function()
    {
        $scope.urlShow = false;
        $scope.zhmianShow = true;
        window.location.href = "#/empty";
    }
}

//空白
function emptyCtrl($scope, ajaxService, $cookieStore) {
}

/**买入控制器**/
function buyCtrl($scope, ajaxService, $cookieStore) {

    //console.log("w zhixing l w zhixingle");
    $scope.inputstockShow = true;//显示输入框并可操作
    $scope.hq = {};
    $scope.wtjg;
    $scope.wtsl;
    $scope.kysl;
    $scope.ddlx = "i";//报价方式
    $scope.buykyzj = 0;//可用资金
    $scope.zdkmShow = false;//最大可买是否显示
    $scope.buyfiveDivShow = false;
    $scope.flashbuyfiveDivShow = false;
    $scope.wtjgInput = document.getElementById("wtjg");

    $scope.buyfiveDivShowClick = function()
    {
        $scope.buyfiveDivShow = !$scope.buyfiveDivShow;
    }

    //点击不显示手机弹出的键盘
    $scope.buyClosePopClick = function(){
    };

    $scope.selectsecuritymoneyactionCallBack = function(_data)
    {
        var arr = _data.moneylist;
        if(arr.length>0)
        {
            $scope.buykyzj = parseFloat(arr[0].kyzj.toString());
            //console.log("可用资金", $scope.kyzj);
        }
    }

    $scope.getkyzj = function()
    {
        //获取可用资金
        var message = {};
        message['account'] = $scope.childaccount;
        message['moneytype'] ="R";
        ajaxService.sendMessage("counter.selectsecuritymoneyaction", message, $scope.selectsecuritymoneyactionCallBack) ;
    }

    //获取可用资金
    //$scope.getkyzj();

    //最大可用
    $scope.getkyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.kysl  = _data.kmsl;
        }
    }

    $scope.getkysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['exchange'] = $scope.stockcodeall.substring(0,2);
        message['account'] = $scope.childaccount;
        if($scope.wtjgInput == null)
        {
            message['price'] = 0;
            //console.log("price1：", message['price']);
        }
        else
        {
            message['price'] = $scope.wtjg;
            //console.log("price2：", message['price']);
        }
        //console.log("委托价格：" , message['price'] );
        ajaxService.sendMessage("counter.getZdkm", message, $scope.getkyslCallBack);

    }

    $scope.wtjgChange = function(_value)
    {
        $scope.getkysl();
    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        //console.log("11111", stockcode);
        //alert("stockcode"  + stockcode);
        if(stockcode != null && stockcode != "" && stockcode != undefined)
        {
            var message = {};
            if (stockcode.length == 8) stockcode = stockcode.substring(2);
            message['code'] = stockcode;
            //alert("查询：" + stockcode);
            ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack);
        }
        else
        {
            //alert("2");
            $scope.hq = getEmptyHQ();
            //alert("3");
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    };

    $scope.gpdmchange = function()
    {
        //alert("change");
        if($scope.hq.stockcode == "")
        {
            $scope.hq = getEmptyHQ();
            //alert("3");
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    }

    //股票行情
    $scope.sshqactionCallBack = function(result)
    {
        //console.log(result)
        //alert("查询返回：" + result.code.toString());
        if (result.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            //alert("查询返回：" + result.buyv.toString());
            var obj = {};
            var buyvarr = result.buyv;
            obj.buyv1 = Math.floor(Number(buyvarr[0])/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1])/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2])/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3])/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4])/100)+'手';
            var sellvarr = result.sellv;
            obj.sellv1 = Math.floor(Number(sellvarr[0])/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1])/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2])/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3])/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4])/100)+'手';

            var buyparr = result.buyp;
            obj.buyp1 = Number(buyparr[0]).toFixed(2);
            obj.buyp2 = Number(buyparr[1]).toFixed(2);
            obj.buyp3 = Number(buyparr[2]).toFixed(2);
            obj.buyp4 = Number(buyparr[3]).toFixed(2);
            obj.buyp5 = Number(buyparr[4]).toFixed(2);

            var sellparr = result.sellp;
            obj.sellp1 = Number(sellparr[0]).toFixed(2);
            obj.sellp2 = Number(sellparr[1]).toFixed(2);
            obj.sellp3 = Number(sellparr[2]).toFixed(2);
            obj.sellp4 = Number(sellparr[3]).toFixed(2);
            obj.sellp5 = Number(sellparr[4]).toFixed(2);

            obj.stockcode = result.code;
            obj.exchange = result.exchange;
            obj.lastprice = result.now;
            obj.name = result.zqjc;

            //if(obj.name != null && obj.name != "" && obj.name != undefined)
            //{
            //    $scope.inputstockShow = false;
            //}

            //console.log("交易所", obj.exchange);

            $scope.hq = obj;
            $scope.stockcodeall = $scope.hq.exchange + $scope.hq.stockcode;
            $scope.wtjg = Number($scope.hq.lastprice);

            $scope.zdkmShow = true;

            if($scope.stockcodeall.substring(0,2)=="SZ") {
                $scope.ddlxOptions = [
                    {label:"对方最优价格",data:"f"},
                    {label:"本方最优价格",data:"g"},
                    {label:"即时成交剩余撤销",data:"h"},
                    {label:"五档即时成交剩余撤销",data:"i"},
                    {label:"全额成交或撤销委托",data:"j"}
                ];
                //$scope.$apply();
            }else if($scope.stockcodeall.substring(0,2)=="SH") {
                $scope.ddlxOptions = [
                    {label:"五档即时成交剩余撤销",data:"i"},
                    {label:"五档即时成交剩余转限",data:"r"}
                ];
                //$scope.$apply();
            }
            //取可用数量
            $scope.getkysl();
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
        //$scope.queryKYSL();
        //$scope.$apply();
    }

    //委托价格改变
    $scope.changejg = function(_str)
    {
        if($scope.wtjg == "" || $scope.wtjg == undefined || $scope.wtjg == null)
        {
            $scope.wtjg = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtjg = (Number($scope.wtjg) - 0.01).toFixed(2);
        }
        else//加
        {
            $scope.wtjg = (Number($scope.wtjg) + 0.01).toFixed(2);
        }
        $scope.wtjgChange($scope.wtjg);

    }

    //委托数量改变
    $scope.changesl = function(_str)
    {
        if($scope.wtsl == "" || $scope.wtsl == undefined || $scope.wtsl == null)
        {
            $scope.wtsl = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtsl = (Number($scope.wtsl) - 100).toFixed(0);
        }
        else//加
        {
            $scope.wtsl = (Number($scope.wtsl) + 100).toFixed(0);
        }
    }

    $scope.limitbuy = function(obj)
    {
        //console.log("委托数量",$scope.wtsl);
        //if(!isNaN($scope.wtsl))//判断是否为数字
        //{
        //    alert("是数字");
        //}
        //else
        //{
        //    alert("不是数字");
        //}
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            alert('请输入有效的证券代码');
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            alert('请输入有效的买入数量');
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            alert('请输入有效的买入数量');
            return;
        }
        if($scope.wtsl <= 0)
        {
            alert('请输入有效的买入数量');
            return;
        }
        if($scope.wtsl%100!=0)
        {
            alert('买入数量必须为100的整数倍');
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            alert('委托数量大于可用数量，请重新输入');
            return;
        }
        if(r.test($scope.wtjg) == false)
        {
            alert('请输入有效的委托价格');
            return;
        }
        if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        {
            alert('请输入有效的委托价格');
            return;
        }
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2);
        message["ddlx"] = 'limit';
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = "1";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        // var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        if(confirm(str))//确定创建
        {
            ajaxService.sendMessage("counter.wtaction", message, function (result)
            {
                //console.log("交易", result);
                if(result.op.code == 'Y')
                {
                    alert("委托成功，合同编号：" + result.htbh);
                    $scope.wtsl = 0;
                    //取可用数量
                    $scope.getkysl();
                }
                else
                {
                    alert("委托失败，原因：" + result.op.info);
                }
            }, false);
        }

        //confirmMsg('交易确认','证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？', function() {

        /*var message = {};
         message["zczh.id"] = $scope.currentComb.comblist.id;
         message["gpwt.wtsl"] = $scope.wtsl;
         message["gpwt.wtjg"] = $scope.wtjg;
         message["gpwt.stockcode"] = $scope.stockcodeall;
         message["gpwt.ddlx"] = 'limit';

         if(message["gpwt.stockcode"]==null) { bubbleUpMsg('请输入有效的证券代码');return; }
         if(message["gpwt.wtsl"]==null||message["gpwt.wtsl"]<=0) { bubbleUpMsg('请输入有效的买入数量');return; }
         if(message["gpwt.wtsl"]%100!=0) { bubbleUpMsg('买入数量必须为100的整数倍');return; }
         if(message["gpwt.wtjg"]==null||message["gpwt.wtjg"]<=0) { bubbleUpMsg('请输入有效的买入价格');return; }

         confirmMsg('交易确认','产品名称：'+$scope.currentComb.comblist.productname+'<BR />证券代码：'+message["gpwt.stockcode"].substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+message["gpwt.wtjg"]+'元）</span><BR />买入数量：'+message["gpwt.wtsl"]+'股<BR />———————————————<BR />确认进行交易？', function() {
         amqService.sendMessage("aqm.p_xjmr", message, function (result) {

         if (result.op.code == 'Y') {

         bubbleUpMsg("委托成功，合同编号：" + result.gpwt.htbh);
         $scope.reQueryWalletData($scope.currenthzjgid,$scope.currentComb.comblist.id);
         //                    $scope.setZdkm($scope.wtjg);
         //                    $scope.$broadcast("queryCC","");
         $scope.wtsl = '';
         closeDialog($('#comfirmDiv'));
         }
         else {
         bubbleUpMsg("委托失败，原因：" + result.op.info);
         }
         //                $scope.$emit("querycomblist", "");
         //                $scope.$broadcast("queryDRWT","");
         }, false);
         });*/
    }



    $scope.flashbuyfiveDivShowClick = function()
    {
        $scope.flashbuyfiveDivShow = !$scope.flashbuyfiveDivShow;
    }

    //市价买入
    $scope.marketbuy = function()
    {
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            alert('请输入有效的证券代码');
            return;
        }
        if($scope.wtsl <= 0)
        {
            alert('请输入有效的买入数量');
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            alert('请输入有效的买入数量');
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            alert('请输入有效的买入数量');
            return;
        }
        if($scope.wtsl%100!=0)
        {
            alert('买入数量必须为100的整数倍');
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            alert('委托数量大于可用数量，请重新输入');
            return;
        }

        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2);
        if(($scope.stockcodeall.substr(0,2)).toLocaleUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = "1";

        console.log("买入", message)

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        if(confirm(str))//确定创建
        {
            ajaxService.sendMessage("counter.wtaction", message, function (result)
            {
                //console.log("交易", result);
                if(result.op.code == 'Y')
                {
                    alert("委托成功，合同编号：" + result.htbh);
                    $scope.wtsl = 0;
                    $scope.getkysl();
                }
                else
                {
                    alert("委托失败，原因：" + result.op.info);
                }
            }, false);
        }
    };
}

/**卖出 控制器**/
function sellCtrl($scope, ajaxService, $cookieStore)
{
    $scope.kysl = "-";//可卖数量
    $scope.wtjg = "";//委托价格
    $scope.excstockcode = "";//选中的股票
    $scope.ddlx = "i";
    $scope.wtsl = "";
    $scope.listShow = true;//显示列表或者显示操作界面
    $scope.selectdestock = {};//选中的股票

    $scope.sellfiveDivShow = false;
    $scope.flashsellfiveDivShow = false;


    var headerArray = [
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
        {code: 'dqj', name: '当前价', desc: '　', type: 'money'},
        {code: 'kysl', name: '可用数量', desc: '　', type: 'number'},
        {code: 'yk', name: '盈亏', desc: ' ', type: 'money'},
        {code: 'cz', name: '', desc: ' ', type: 'string', width: '16px', tclass:'dirStyle'}
    ];
    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    //显示和隐藏五档
    $scope.sellfiveDivShowClick = function()
    {
        $scope.sellfiveDivShow = !$scope.sellfiveDivShow;
    }

    $scope.sellItemClick = function(_obj)
    {
        $scope.listShow = false;
        $scope.selectdestock = _obj;
        $scope.excstockcode = _obj.stockcodeall;
        $scope.wtjg = Number(_obj.dqj);
        //console.log("价格",_obj.dqj,  $scope.wtjg);
        $scope.kysl = _obj.kysl;
        $scope.queryhq(_obj.stockcode);
    }

    //返回列表界面
    $scope.backtoSellList = function()
    {
        $scope.listShow = true;
        $scope.selectdestock = {};
        $scope.excstockcode = "";
        $scope.wtsl = "";
    }


    //查询持仓情况
    $scope.cclist = [];
    $scope.cclist.isLoading = true;
    $scope.p_cxcc_trade = function() {
        $scope.cclist = [];
        $scope.cclist.isLoading = true;
        var message = {};
        message["page.size"] = 'max';
        message['page.no'] = "";
        message['account'] = $scope.childaccount;
        message['combpositionid'] = "default";
        ajaxService.sendMessage("counter.selectsecuritypositionaction", message, function (result) {
            console.log("卖出查持仓",result )
            if (result.op.code == 'Y')
            {
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseFloat(arr[i].kysl) + parseFloat(obj.djsl);
                        obj.dqj = arr[i].dqj;
                        obj.yk = parseFloat(arr[i].fdyk);
                        obj.kysl = arr[i].kysl;
                        if(obj.yk >0)
                        {
                            obj.flag = "1";
                        }
                        else if(obj.yk <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        //if(obj.kysl != "" && obj.kysl != "0" || obj.kysl != 0)
                        //{
                            obj.cz = "〉";
                            $scope.cclist.push(obj);
                        //}
                    }
                }
            }
            else
            {
                alert("查询持仓失败!");
                $scope.cclist = [];
            }
            $scope.cclist.isLoading = false;
        });
    };
    $scope.p_cxcc_trade();

    //选中某一持仓
    $scope.stockSelected = function ()
    {
        console.log("change ", $scope.excstockcode);
        var mark = false;
        for(var i = 0;i<$scope.cclist.length;i++)
        {
            if($scope.excstockcode == $scope.cclist[i].stockcodeall)
            {
                mark = true;
                $scope.kysl = $scope.cclist[i].kysl;
                // $scope.wtjg = Number($scope.cclist[i].dqj);
                $scope.queryhq($scope.cclist[i].stockcode);
                break;
            }
        }
        //console.log($scope.kysl);
        if(mark == false)
        {
            $scope.kysl = "-";
        }

        //var stockcode = $('#stockcode').find("option:selected").attr('value');
        //$scope.queryhq(stockcode);
        //var kysl = $('#stockcode').find("option:selected").attr('kysl');
        //$('#kysl').html(kysl==null?'-':kysl);
    };

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        if(stockcode != null && stockcode != "" || stockcode != undefined)
        {
            var message = {};
            if(stockcode.length == 8) stockcode = stockcode.substring(2);
            message['code'] = stockcode;
            ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack) ;
        }
    };

    //股票行情
    $scope.sshqactionCallBack = function(result)
    {
        console.log("股票行情", result);
        if (result.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            var obj = {};
            var buyvarr = result.buyv;
            obj.buyv1 = Math.floor(Number(buyvarr[0])/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1])/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2])/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3])/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4])/100)+'手';
            var sellvarr = result.sellv;
            obj.sellv1 = Math.floor(Number(sellvarr[0])/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1])/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2])/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3])/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4])/100)+'手';

            var buyparr = result.buyp;
            obj.buyp1 = Number(buyparr[0]).toFixed(2);
            obj.buyp2 = Number(buyparr[1]).toFixed(2);
            obj.buyp3 = Number(buyparr[2]).toFixed(2);
            obj.buyp4 = Number(buyparr[3]).toFixed(2);
            obj.buyp5 = Number(buyparr[4]).toFixed(2);

            var sellparr = result.sellp;
            obj.sellp1 = Number(sellparr[0]).toFixed(2);
            obj.sellp2 = Number(sellparr[1]).toFixed(2);
            obj.sellp3 = Number(sellparr[2]).toFixed(2);
            obj.sellp4 = Number(sellparr[3]).toFixed(2);
            obj.sellp5 = Number(sellparr[4]).toFixed(2);

            obj.stockcode = result.code;
            obj.exchange = result.exchange;
            obj.lastprice = result.now;
            obj.name = result.zqjc;


            $scope.hq = obj;
            $scope.wtjg = Number($scope.hq.lastprice);

            if(obj.exchange =="SZ") {
                $scope.ddlxOptions = [
                    {label:"对方最优价格",data:"f"},
                    {label:"本方最优价格",data:"g"},
                    {label:"即时成交剩余撤销",data:"h"},
                    {label:"五档即时成交剩余撤销",data:"i"},
                    {label:"全额成交或撤销委托",data:"j"}
                ];
            }else if(obj.exchange=="SH") {
                $scope.ddlxOptions = [
                    {label:"五档即时成交剩余撤销",data:"i"},
                    {label:"五档即时成交剩余转限",data:"r"}
                ];
            }
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            //$scope.$apply();
        }
    }

    //委托价格改变
    $scope.changejg = function(_str)
    {
        if($scope.wtjg == "" || $scope.wtjg == undefined || $scope.wtjg == null)
        {
            $scope.wtjg = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtjg = (Number($scope.wtjg) - 0.01).toFixed(2);
        }
        else//加
        {
            $scope.wtjg = (Number($scope.wtjg) + 0.01).toFixed(2);
        }
    }

    //委托数量改变
    $scope.changesl = function(_str)
    {
        if($scope.wtsl == "" || $scope.wtsl == undefined || $scope.wtsl == null)
        {
            $scope.wtsl = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtsl = (Number($scope.wtsl) - 100).toFixed(0);
        }
        else//加
        {
            $scope.wtsl = (Number($scope.wtsl) + 100).toFixed(0);
        }
    }

    //显示和隐藏五档
    $scope.flashsellfiveDivShowClick = function()
    {
        $scope.flashsellfiveDivShow = !$scope.flashsellfiveDivShow;
    }

    $scope.limitsell = function()
    {
        if($scope.excstockcode == null ||  $scope.excstockcode == "")
        {
            alert('请输入有效的证券代码');
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if($scope.wtjg<=0)
        {
            alert('请输入有效的卖出价格');
            return;
        }
        if($scope.wtsl <= 0 || $scope.wtsl == "" || $scope.wtsl == null)
        {
            alert('请输入有效的卖出数量');
            return;
        }
        //console.log("数量", $scope.wtsl, $scope.kysl)

        if($scope.wtsl > Number($scope.kysl))
        {
            alert('委托数量大于可用数量，请重新输入');
            return;
        }
        if(r.test($scope.wtjg) == false)
        {
            alert('请输入有效的卖出价格');
            return;
        }
        if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        {
            alert('请输入有效的卖出价格');
            return;
        }
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.excstockcode.substring(2);
        message["exchange"] = $scope.excstockcode.substr(0,2);
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = "1";
        console.log(message);

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.selectdestock.stockname + "(" + $scope.excstockcode + ")   " + $scope.wtsl + "股吗？";
        if(confirm(str))//确定创建
        {
            ajaxService.sendMessage("counter.wtaction", message, function (result)
            {
                //console.log("交易", result);
                if(result.op.code == 'Y')
                {
                    alert("委托成功，合同编号：" + result.htbh);
                    $scope.wtsl = "";
                    $scope.kysl = "-";
                    $scope.backtoSellList();
                    $scope.p_cxcc_trade();
                }
                else
                {
                    alert("委托失败，原因：" + result.op.info);
                }
            }, false);
        }

    }

    //市价卖出
    $scope.marketsell = function()
    {
        if($scope.excstockcode == null ||  $scope.excstockcode == "")
        {
            alert('请输入有效的证券代码');
            return;
        }
        if($scope.wtsl <= 0 || $scope.wtsl == "" || $scope.wtsl == null)
        {
            alert('请输入有效的卖出数量');
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if($scope.wtsl > Number($scope.kysl))
        {
            alert('委托数量大于可用数量，请重新输入');
            return;
        }
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.excstockcode.substring(2);
        message["exchange"] = $scope.excstockcode.substr(0,2);
        if(($scope.excstockcode.substr(0,2)).toLocaleUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'S';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = "1";
        console.log(message);
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.hq.name + "(" + $scope.excstockcode + ")   " + $scope.wtsl + "股吗？";
        if(confirm(str))//确定创建
        {
            ajaxService.sendMessage("counter.wtaction", message, function (result)
            {
                //console.log("交易", result);
                if(result.op.code == 'Y')
                {
                    alert("委托成功，合同编号：" + result.htbh);
                    $scope.wtsl = "";
                    $scope.kysl = "-";
                    $scope.backtoSellList();
                    $scope.p_cxcc_trade();
                }
                else
                {
                    alert("委托失败，原因：" + result.op.info);
                }
            }, false);
        }
    }


    //点击不显示手机弹出的键盘
    $scope.sellClosePopClick = function(){
    };
}

/**市价买入**/
function flashbuyCtrl($scope, ajaxService, $cookieStore)
{
}

/**市价卖出**/
function flashsellCtrl($scope, ajaxService, $cookieStore)
{

}


/**撤单**/
function cancellationCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("i do,i do it");
    $scope.cancelMark = true;//是否可以进行撤销操作
    $scope.index = 0;//撤单位置
    var headerArray = [
        {code: 'wtsj', name: '委托时间', desc: '↓', type: 'shorttime'},
//        {code: 'gpwt.htbh', name: '合同编号', desc: ' ', type: 'number'},
//        {code: 'gpwt.productname', name: '产品名称', desc: '　', type: 'string'},
        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'gpwt.side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
//        {code: 'gpwt.wtjg', name: '委托价格', desc: '　', type: 'buypolicy'},
        {code: 'wtsl', name: '委托数量', desc: '　', type: 'number'}
//        {code: 'gpwt.djje', name: '委托金额', desc: ' ', type: 'money'},
//        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
//        {code: 'gpwt.cjsl', name: '成交数量', desc: '　', type: 'number'},
//        {code: 'gpwt.cjje', name: '成交金额', desc: '　', type: 'money'},
//        {code: 'gpwt.cdsl', name: '撤单数量', desc: '　', type: 'number'},
//        {code: 'gpwt.status', name: '委托状态', desc: '　', type: 'wtstatus'},
//        {code: 'gpwt.reason', name: '备注', desc: '　', type: 'string'}
    ];
    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];

        var message = {};
        message["page.size"] = 'max';
        message['page.no'] = "";
        message['account'] = $scope.childaccount;
        message['combpositionid'] = "default";
        ajaxService.sendMessage("counter.selectsecurityorderaction", message, function (result) {
            $scope.wtList = [];
            console.log("撤单查询当日委托",result);
            if (result.op.code == 'Y')
            {
                var arr = result.securityorderlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtsl = arr[i].wtsl;
                        obj.htbh = arr[i].htbh;
                        if(arr[i].status.toString() == "2" || arr[i].status.toString() == "7")
                        {
                            $scope.wtList.push(obj);
                        }
                    }

                    if($scope.wtList.length>0)
                    {
                        $scope.showNodata = false;
                        $scope.isLoading = false;
                    }
                    else
                    {
                        $scope.showNodata = true;
                        $scope.isLoading = false;
                    }
                }
                else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

        });
    };

    $scope.query();

    $scope.selectAllWt = false;
    $scope.chooseAllwt = function () {
        $scope.selectAllWt = !$scope.selectAllWt;

        if ($scope.selectAllWt)
        {
            $scope.htbhlist = [];
            for (var i = 0; i < $scope.wtList.length; i++)
            {
                $scope.htbhlist.push($scope.wtList[i]['htbh']);
            }
        }
        else
        {
            $scope.htbhlist = [];
        }

    }

    $scope.choosewt = function (id) {
//        id = Number(id);
        var idx = $scope.htbhlist.indexOf(id);
        // is currently selected
        if (idx > -1) {
            $scope.htbhlist.splice(idx, 1);
        }
        // is newly selected
        else {
            $scope.htbhlist.push(id);
        }
    }

    //撤销
    $scope.cancelWt = function ()
    {
        if($scope.cancelMark)
        {
            $scope.index = 0;
            $scope.Msgarr = [];
            if ($scope.htbhlist.length == 0)
            {
                alert("请选择委托");
                return;
            }
            var str = "确定撤销所选中的委托吗？";
            //console.log($scope.htbhlist.length);
            if(confirm(str))//确定撤销
            {
                $scope.cancelMark = false;
                $scope.cancelall();
            }
        }
    }

    $scope.cancelall = function()
    {
        var message = {};
        message['account'] = $scope.childaccount;
        message['htbh'] = $scope.htbhlist[$scope.index];
        ajaxService.sendMessage("counter.cancelaction", message, $scope.cancelactionCallBack);
    }

    $scope.cancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            var obj = {};
            obj.hybh = $scope.htbhlist[$scope.index];
            obj.info = "撤单成功";
            $scope.Msgarr.push(obj);
        }
        else
        {
            var obj = {};
            obj.hybh = $scope.htbhlist[$scope.index];
            obj.info = "撤单失败，" + result.op.info;
            $scope.Msgarr.push(obj);
        }
        $scope.index = $scope.index+1;
        if($scope.index < $scope.htbhlist.length)
        {
            $scope.cancelall();
        }
        else
        {
            var str = "";
            for(var i = 0;i<$scope.Msgarr.length;i++)
            {
                if(i == 0)
                {
                    str = "合约  " + $scope.Msgarr[i].hybh + "  " + $scope.Msgarr[i].info;
                }
                else
                {
                    str = str + "； 合约  " + $scope.Msgarr[i].hybh + "  " + $scope.Msgarr[i].info;
                }
            }
            alert(str);
            $scope.Msgarr = [];
            $scope.index = 0;
            $scope.query();
            $scope.cancelMark = true;
        }
    }

    $scope.cancelOneWt = function(_obj)
    {
        if($scope.cancelMark) {
            var str = "确定撤销此的委托吗？";
            //console.log($scope.htbhlist.length);
            if (confirm(str))//确定撤销
            {
                $scope.cancelMark = false;
                $scope.cancelOne(_obj);
            }
        }
    }

    $scope.cancelOne = function(_obj)
    {
        var message = {};
        message['account'] = $scope.childaccount;
        message['htbh'] = _obj.htbh;
        console.log("htbh", _obj.htbh)
        ajaxService.sendMessage("counter.cancelaction", message, $scope.onecancelactionCallBack);
    }

    $scope.onecancelactionCallBack = function(result)
    {
        if (result.op.code == 'Y')
        {
            alert("撤单成功");
        }
        else
        {
            alert( "撤单失败，原因：" + result.op.info);
        }
        $scope.cancelMark = true;
        $scope.query();
    }
}
