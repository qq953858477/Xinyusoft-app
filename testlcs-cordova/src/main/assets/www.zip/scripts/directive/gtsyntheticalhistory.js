function gtsyntheticalhistory()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_synthetical_history.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyntheticalhistoryCtrl($scope, ajaxService, $cookieStore) {
    //console.log("5345");
    $scope.zhInfo = {};
    $scope.childaccount = "";
    $scope.childaccountStr = "";
    $scope.zhInfo.dqcw = "--";//当前仓位
    //$scope.zhInfo.dysyl = "--";//当月收益率
    //$scope.zhInfo.jrsy = "--";//当日收益率
    $scope.zhInfo.qssj = "--";//起始时间
    $scope.zhInfo.qssjstr = "";//8位
    $scope.zhInfo.desc = "";//说明
    $scope.zhInfo.ljsyl = "--";//累计收益率
    $scope.sylArray = [];//历史净值
    $scope.sylshowmaxlen = 30;//判断显示的最大个数，大于此值，则处理显示
    $scope.sylChartArray = new Object();//收益率图
    $scope.sylscaleSteps = 4;//Y轴刻度个数
    $scope.sylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.sylscaleStartValue = -20;//y轴的起始值
    $scope.sylstep = 10;//计算步长
    $scope.nohqDivShow = true;
    $scope.zhmianShow = true;//主界面
    $scope.rsyfxDivShow = false;//日收益分析界面
    $scope.tcjlArray = []; //调仓记录
    $scope.gtyhlbDivShow = false;

    $scope.hqbaseoneStockHQBaseShow = false;//行情显示界面
    $scope.canadddel = true;//是否可以添加删除自选股


    $scope.ztList = [];//涨停列表
    $scope.ztaccount = 0;//涨停个数
    $scope.dtList = [];//跌停列表
    $scope.dtaccount = 0;//涨停个数
    $scope.zdttabOneShow = false;//涨停榜
    $scope.zdttabTwoShow = false;//跌停


    $scope.sytjfxArray = [];//收益分析
    $scope.sylfxShow = true;//是否显示

    $scope.info_zdhc = "--";//最大回撤
    $scope.info_zsdp = "--";//战胜大盘
    $scope.info_qjdpzdf = "--";//期间大盘涨跌幅

    //$scope.account = getParameter("account");

    //console.log("查询持仓");

    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];

    //置顶
    $scope.gotoUp = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    $scope.p_getaccountupdownCallBack = function(_data)
    {
        //console.log("涨跌停", _data);
        $scope.ztList = [];//涨停
        $scope.dtList = [];//跌停
        $scope.ztaccount = 0;
        $scope.dtaccount = 0;

        var ztarr = [];
        var dtarr = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.limitup;
            for (var item = 0;item< element.length;item++)
            {
                var obj = {};
                obj.stockcode = element[item]['stockcode'].toString();
                obj.stockname = element[item]['name'].toString();
                obj.exchange = element[item]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element[item]['industry'].toString();
                var str = element[item]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element[item]['basetype']);
                ztarr.push(obj);
            }

            var element2 = _data.limitdown;
            for (var item2 = 0;item2< element2.length;item2++)
            {
                var obj = {};
                obj.stockcode = element2[item2]['stockcode'].toString();
                obj.stockname = element2[item2]['name'].toString();
                obj.exchange = element2[item2]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element2[item2]['industry'].toString();
                var str = element2[item2]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element2[item2]['basetype']);
                dtarr.push(obj);
            }
        }
        $scope.ztaccount = ztarr.length;
        $scope.dtaccount = dtarr.length;
        for(var i = 0;i<ztarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.ztList.length;k++)
            {
                if($scope.ztList[k].sj == ztarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = ztarr[i].sj;
                var arr = [];
                for(var j = i;j<ztarr.length;j++)
                {
                    if(ztarr[j].sj == obj.sj)
                    {
                        arr.push(ztarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.ztList.push(obj);
            }
        }

        for(var i = 0;i<dtarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.dtList.length;k++)
            {
                if($scope.dtList[k].sj == dtarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = dtarr[i].sj;
                var arr = [];
                for(var j = i;j<dtarr.length;j++)
                {
                    if(dtarr[j].sj == obj.sj)
                    {
                        arr.push(dtarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.dtList.push(obj);
            }
        }
    }

    //获取涨跌停
    $scope.getzdt = function()
    {
        var message = {};
        message['account'] = $scope.childaccount;
        message['kssj'] = $scope.zhInfo.qssjstr;
        message['jssj'] = $scope.jssjstr;
        //console.log("jsrq", message['kssj'], message['jssj']);
        ajaxService.sendMessage("sunflower.p_getaccountupdown", message, $scope.p_getaccountupdownCallBack) ;

    }

    $scope.p_selecthissecuritymoneyCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.info_zdhc = parseFloat(_data.maxrollback);//最大回撤
            $scope.info_zsdp = _data.conquermarket;//战胜大盘
            $scope.info_qjdpzdf = parseFloat(_data.marketchange);//期间大盘涨跌幅
            var arr = _data.sytj;
            var gtts = 0;
            //var syarr = [];
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.syl = parseFloat(arr[i].monsyl)*100;
                if(obj.syl > 0)
                {
                    obj.flag = "1";
                }
                else if(obj.syl <0)
                {
                    obj.flag = "-1";
                }
                else
                {
                    obj.flag = "0";
                }
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    gtts = gtts +1;
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }
            }

            $scope.dqgtInfo.rundays = gtts;
        }
    }

    $scope.getsyfx = function()
    {
        $scope.sytjfxArray = [];

        var message = {};
        message['account'] = $scope.childaccount;
        message['productid'] = $scope.productid;
        message['kssj'] = $scope.zhInfo.qssjstr;
        message['jssj'] = $scope.jssjstr;
        //console.log("收益分析：" , message['kssj'], message['jssj']);
        //message['page.size'] = "max";
        //message['page.no'] = "";
        ajaxService.sendMessage("sunflower.getSytjAction", message, $scope.p_selecthissecuritymoneyCallBack) ;
        //console.log($scope.childaccount, "sunflower.p_getaccountnettrend");
        //ajaxService.sendMessage("sunflower.p_selecthissecuritymoney", message, $scope.p_selecthissecuritymoneyCallBack) ;
    }


    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("tradesynthetical可用资金", _data);
        var arr = _data.money;
        if(arr != null && arr != undefined)
        {
            if(parseFloat(arr.zsz.toString()) == 0)
            {
                $scope.zhInfo.dqcw = "空仓";//当前仓位
            }
            else if(parseFloat(arr.zsz.toString()) == parseFloat(arr.zzc.toString()))
            {
                $scope.zhInfo.dqcw = "满仓";//当前仓位
            }
            else
            {
                $scope.zhInfo.dqcw = (parseFloat(arr.zsz.toString())/parseFloat(arr.zzc.toString())*100).toFixed(0) + "%";//当前仓位
            }
            //console.log("leijishouyi", arr.ljsy);
            if($scope.isgtz)//作为跟投者
            {
                //console.log("leijishouyi", arr.ljsy);
                $scope.zhInfo.ljsyl = parseFloat(arr.ljsy);//累计收益率
                $scope.zhInfo.ljsyvalue = parseFloat(arr.ljyk);//累计收益

            }
        }
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack);
    }

    $scope.getcpinfoCallBack = function(_data)
    {
        //console.log("cpxx", _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.zhInfo.jrsy = parseFloat(product.jrsy);//当日收益率
            $scope.zhInfo.desc = product.desc;//说明
            $scope.cpfbzid = product.user.user.f_id;
            $scope.cpfbznameShow = product.user.user.f_nickname;//产品发布者name
            $scope.cpfbzheadShow = product.user.user.f_head;
            //if($scope.isgtz == false)//作为被跟投者或者他人看产品
            //{
            //    $scope.zhInfo.ljsyl = parseFloat(product.ljsy);//累计收益率
            //    $scope.zhInfo.ljsyvalue = parseFloat(product.ljyk);//累计收益
            //
            //    var str = product.gentouday.toString();
            //    $scope.zhInfo.qssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
            //    $scope.zhInfo.qssjstr = str.substr(0,8);
            //    $scope.getzdt();
            //    $scope.getsyfx();
            //}
        }
    }

    $scope.getcpinfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息收益",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getcpinfoCallBack);
    }

    $scope.getgtbgeindataCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.accountlink;
            //作为跟投者
            var str = obj.createtime.toString();
            $scope.zhInfo.qssj = str.substr(0,10);
            $scope.zhInfo.qssjstr = str.substr(0,4) + str.substr(5,2) + str.substr(8,2);
            $scope.getzdt();
            $scope.getsyfx();
        }
    }
    $scope.getgtbgeindata = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        ajaxService.sendMessage("gentou.p_getgentouinfobyid", message, $scope.getgtbgeindataCallBack);
    }

    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("123caption", _data.caption);
        if(_data.caption == "gtsynthetical")
        {
            $scope.childaccount = _data.account;

            $scope.getccinfo();
            $scope.getcpinfo();

            if($scope.isgtz)//跟投者，获取开始日期
            {
                $scope.getgtbgeindata();
            }


        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsynthetical"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);

    //获取日收益分析
    $scope.rsyfxShow = function()
    {
        $scope.zhmianShow = false;
        $scope.rsyfxDivShow = true;
    }

    $scope.rsyfxbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.rsyfxDivShow = false;
    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }
    //收益分析是否显示
    $scope.sylfxShowClick = function()
    {
        $scope.sylfxShow = !$scope.sylfxShow;
    }

    //日收益分析详情
    $scope.rsyfxItem = function(_obj)
    {
        //console.log(_obj.sj);
        //setbackList(window.location.href);
        //window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate);
        xinyuNewBrowser("rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=newwebview");
    }

    //涨跌停榜切换
    $scope.zdtchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = true;
            $scope.zdttabTwoShow = false;
        }
        else
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = false;
            $scope.zdttabTwoShow = true;
        }
        gotoUp();
    }

    $scope.zdtbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.zdttabOneShow = false;
        $scope.zdttabTwoShow = false;
        gotoUp();
    }

    $scope.gphqClick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;

        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.hqbaseoneStockHQBaseShow = true;
        $scope.nohqDivShow = false;
    }

    //个股返回
    $scope.oneStockHQBaseBackto = function()
    {
        $scope.hqbaseoneStockHQBaseShow = false;
        $scope.nohqDivShow = true;
    }

    //服务发布者个人空间
    $scope.gotolcsinfo = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", $scope.cpfbzid);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        xinyuNewBrowser("peopleSpaceBase.html?opentype=newwebview&page=list");
    }

}
