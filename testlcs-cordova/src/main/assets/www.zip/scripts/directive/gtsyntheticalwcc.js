function gtsyntheticalwcc()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_synthetical_wcc.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyntheticalwccCtrl($scope, ajaxService, $cookieStore) {
    //console.log("5345");
    $scope.zhInfo = {};
    $scope.productfwsc = "--";//服务时长
    $scope.childaccount = "";
    $scope.childaccountStr = "";

    $scope.peopleallInfo = {};
    $scope.peopleallInfo.dq = "";//地区
    $scope.peopleallInfo.lcslszj = "";
    $scope.peopleallInfo.lcstzsc = "";
    $scope.peopleallInfo.lcstzln = "";
    $scope.peopleallInfo.lcsscly = "";
    $scope.peopleallInfo.zfzlurl = "";//理财师专访资料地址

    $scope.jrsyShow = '0';//显示今日收益   0：都不显示，1：今日收益；2：累计收益
    $scope.zhInfo.dqcw = "--";//当前仓位
    $scope.zhInfo.zhdqsz = "--";//账户当前市值
    //$scope.zhInfo.dysyl = "--";//当月收益率
    //$scope.zhInfo.jrsy = "--";//当日收益率
    $scope.zhInfo.qssj = "--";//起始时间
    $scope.zhInfo.qssjstr = "";//8位
    $scope.zhInfo.desc = "";//说明
    //$scope.zhInfo.ljsyl = "--";//累计收益率
    $scope.sylArray = [];//历史净值
    $scope.sylshowmaxlen = 30;//判断显示的最大个数，大于此值，则处理显示
    $scope.sylChartArray = new Object();//收益率图
    $scope.sylscaleSteps = 4;//Y轴刻度个数
    $scope.sylscaleStepWidth = 10;//y轴每个刻度的宽度
    $scope.sylscaleStartValue = -20;//y轴的起始值
    $scope.sylstep = 10;//计算步长
    $scope.nohqDivShow = true;
    $scope.zhmianShow = false;//主界面
    $scope.rsyfxDivShow = false;//收益分析
    $scope.qylistShow = false;//签约

    $scope.hqbaseoneStockHQBaseShow = false;//行情显示界面
    $scope.canadddel = true;//是否可以添加删除自选股

    $scope.ztList = [];//涨停列表
    $scope.dtList = [];//跌停列表
    $scope.ztaccount = 0;
    $scope.dtaccount = 0;

    $scope.fxtabOneShow = false;
    $scope.fxtabTwoShow = false;
    $scope.fxtabThreeShow = false;

    $scope.zdttabOneShow = false;//涨停榜
    $scope.zdttabTwoShow = false;//跌停

    $scope.sytjfxArray = [];//收益分析
    $scope.sylfxShow = true;//是否显示

    $scope.info_zdhc = "--";//最大回撤
    $scope.info_zsdp = "--";//战胜大盘
    $scope.info_qjdpzdf = "--";//期间大盘涨跌幅
    $scope.cpfbzid = "";//产品发布者id
    $scope.productstatus = "";//服务的状态


    //$scope.account = getParameter("account");

    //置顶
    $scope.gotoUp = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }

    $scope.p_getaccountupdownCallBack = function(_data)
    {
        //console.log("涨跌停", _data);
        $scope.ztList = [];//涨停
        $scope.dtList = [];//跌停
        $scope.ztaccount = 0;
        $scope.dtaccount = 0;

        var ztarr = [];
        var dtarr = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.limitup;
            for (var item = 0;item< element.length;item++)
            {
                var obj = {};
                obj.stockcode = element[item]['stockcode'].toString();
                obj.stockname = element[item]['name'].toString();
                obj.exchange = element[item]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element[item]['industry'].toString();
                var str = element[item]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element[item]['basetype']);
                ztarr.push(obj);
            }

            var element2 = _data.limitdown;
            for (var item2 = 0;item2< element2.length;item2++)
            {
                var obj = {};
                obj.stockcode = element2[item2]['stockcode'].toString();
                obj.stockname = element2[item2]['name'].toString();
                obj.exchange = element2[item2]['exchange'].toString();
                //console.log(obj.value);
                obj.hy = element2[item2]['industry'].toString();
                var str = element2[item2]['day'].toString();
                obj.sj = str.substr(0,4) + "-" +str.substr(4,2) + "-" + str.substr(6,2);
                obj.asset = getzqStatus(element2[item2]['basetype']);
                dtarr.push(obj);
            }
        }

        $scope.ztaccount = ztarr.length;
        $scope.dtaccount = dtarr.length;

        for(var i = 0;i<ztarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.ztList.length;k++)
            {
                if($scope.ztList[k].sj == ztarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = ztarr[i].sj;
                var arr = [];
                for(var j = i;j<ztarr.length;j++)
                {
                    if(ztarr[j].sj == obj.sj)
                    {
                        arr.push(ztarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.ztList.push(obj);
            }
        }

        for(var i = 0;i<dtarr.length;i++)
        {
            var mark = false;//是否已经处理
            for(var k = 0;k<$scope.dtList.length;k++)
            {
                if($scope.dtList[k].sj == dtarr[i].sj)
                {
                    mark = true;
                    break;
                }
            }
            if(mark == false)
            {
                var obj = {};
                obj.sj = dtarr[i].sj;
                var arr = [];
                for(var j = i;j<dtarr.length;j++)
                {
                    if(dtarr[j].sj == obj.sj)
                    {
                        arr.push(dtarr[j]);
                    }
                }
                obj.dataArr = arr;
                $scope.dtList.push(obj);
            }
        }
    }

    //获取涨跌停
    $scope.getzdt = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['kssj'] = $scope.zhInfo.qssjstr;
        //if($scope.jssjstrsy != null && $scope.jssjstrsy != undefined && $scope.jssjstrsy != "")
        //{
        //    message['jssj'] = $scope.jssjstrsy;
        //}
        ajaxService.sendMessage("sunflower.p_getaccountupdown", message, $scope.p_getaccountupdownCallBack) ;

    }

    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("资产 ,可用资金", _data);
        var arr = _data.money;
        if(arr != null && arr != undefined)
        {
            if(parseFloat(arr.zsz.toString()) == 0)
            {
                $scope.zhInfo.dqcw = "空仓";//当前仓位
            }
            else if(parseFloat(arr.zsz.toString()) == parseFloat(arr.zzc.toString()))
            {
                $scope.zhInfo.dqcw = "满仓";//当前仓位
            }
            else
            {
                $scope.zhInfo.dqcw = (parseFloat(arr.zsz.toString())/parseFloat(arr.zzc.toString())*100).toFixed(0) + "%";//当前仓位
            }
            $scope.zhInfo.zhdqsz = parseFloat(arr.zsz);
        }
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //console.log("资产", message['account']);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack);
    }


    $scope.p_selecthissecuritymoneyCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.info_zdhc = parseFloat(_data.tradeanaysis.maxrollback);//最大回撤
            $scope.info_zsdp = _data.tradeanaysis.conquermarket;//战胜大盘
            $scope.info_qjdpzdf = parseFloat(_data.tradeanaysis.marketchange);//期间大盘涨跌幅
            var arr = _data.tradeanaysis.sytj;
            var gtts = 0;
            //var syarr = [];
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.syl = parseFloat(arr[i].monsyl)*100;
                if(obj.syl > 0)
                {
                    obj.flag = "1";
                }
                else if(obj.syl <0)
                {
                    obj.flag = "-1";
                }
                else
                {
                    obj.flag = "0";
                }
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    gtts = gtts +1;
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
            $scope.dqgtInfo.rundays = gtts;
        }
    }

    $scope.getsyfx = function()
    {
        $scope.sytjfxArray = [];

        var message = {};
        //message['account'] = $scope.childaccount;
        message['productid'] = $scope.productid;
        //message['kssj'] = $scope.zhInfo.qssjstr;
        //message['jssj'] = "";
        //message['page.size'] = "max";
        //message['page.no'] = "";
        //ajaxService.sendMessage("sunflower.getSytjAction", message, $scope.p_selecthissecuritymoneyCallBack) ;
        ajaxService.sendMessage("gentou.p_getGentouProductTradeAnaysis", message, $scope.p_selecthissecuritymoneyCallBack) ;
    }


    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        //console.log("理财师资料", _data);
        if (_data.op.code.toString() == "Y") {
            if (_data.lcsapplyinfo.isexist.toString() == "false") {
                $scope.isxrklcs = false;//未申请
            }
            else {
                if (_data.lcsapplyinfo.status.toString() == "A") {
                    $scope.isxrklcs = false;//1：申请中
                }
                else if (_data.lcsapplyinfo.status.toString() == "Y")
                {
                    $scope.isxrklcs = true;//1：申请通过，已是理财师

                    $scope.peopleallInfo.lcslszj = _data.lcsapplyinfo.lszj;
                    $scope.peopleallInfo.lcstzsc = _data.lcsapplyinfo.tzsc;
                    $scope.peopleallInfo.lcstzln = _data.lcsapplyinfo.tzln;

                    if(_data.lcsapplyinfo.interviewrecord != null && _data.lcsapplyinfo.interviewrecord != undefined && _data.lcsapplyinfo.interviewrecord != "")
                    {
                        $scope.peopleallInfo.zfzlurl =  _data.lcsapplyinfo.interviewrecord;//专访资料
                    }
                    else
                    {
                        $scope.peopleallInfo.zfzlurl = "";//"lcszfzl/interview_question1.html";
                    }
                    //console.log($scope.peopleallInfo.zfzlurl);
                    var sclystr = _data.lcsapplyinfo.scly;
                    //console.log("sclystr",sclystr);
                    var ind = sclystr.indexOf("|",0);
                    if(ind == -1)//无|
                    {
                        $scope.peopleallInfo.lcsscly = sclystr;
                    }
                    else//有|
                    {
                        var sclyarr = sclystr.split("|");
                        var str2 = "";
                        for(var i = 0;i<sclyarr.length;i++)
                        {
                            if(str2 == "")
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = sclyarr[i];
                                }

                            }
                            else
                            {
                                if(sclyarr[i]!="")
                                {
                                    str2 = str2 + "," + sclyarr[i];
                                }
                            }
                        }
                        $scope.peopleallInfo.lcsscly = str2;
                    }
                }
                else//N，申请未通过
                {
                    $scope.isxrklcs = false;//0：未申请
                }
            }
        }
    }

    //是否是理财师
    $scope.getislcs = function()
    {
        var message2 = {};
        message2["userid"] = $scope.cpfbzid;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message2, $scope.p_getlcsapplyinfoCallBack);
    }

    $scope.getPeopleInfoCallBack = function(_data)
    {
        //console.log("个人信息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.peopleInfo = _data.user;

            $scope.peopleName = $scope.peopleInfo.f_nickname;
            $scope.peoplehead = $scope.peopleInfo.f_head;
            $scope.peopleallInfo.dq = $scope.peopleInfo.f_head;

            if($scope.peopleInfo.f_province == undefined && $scope.peopleInfo.f_city == undefined)
            {
                $scope.peopleallInfo.dq = "";
            }
            else if($scope.peopleInfo.f_province != undefined && $scope.peopleInfo.f_city != undefined)
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_province + $scope.peopleInfo.f_city;
            }
            else if($scope.peopleInfo.f_province == undefined && $scope.peopleInfo.f_city != undefined)
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_city;
            }
            else
            {
                $scope.peopleallInfo.dq = $scope.peopleInfo.f_province;
            }

        }
    }


    $scope.getpeopleinfo = function()
    {
        var message = {};
        message['user.id'] = $scope.cpfbzid;
        //console.log($scope.peopleID);
        ajaxService.sendMessage("user.usercheck", message, $scope.getPeopleInfoCallBack) ;
    }


    $scope.getcpinfoCallBack = function(_data)
    {
        //console.log("cpxx", _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            if(product.jrsy != undefined && product.jrsy != "" && product.jrsy != null)
            {
                $scope.jrsyShow = "1";
            }
            else
            {
                $scope.jrsyShow = "2";
            }
            $scope.zhInfo.jrsy = parseFloat(product.jrsy);//当日收益率
            //console.log("今日收益", $scope.zhInfo.jrsy);
            //var str = product.gentouday.toString();
            //$scope.zhInfo.qssj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
            //$scope.zhInfo.qssjstr = str.substr(0,8);
            $scope.zhInfo.openday = product.openday.toString();//20160302
            $scope.zhInfo.ljsyl = parseFloat(product.ljsy);//累计收益率
            $scope.zhInfo.ljsyvalue = parseFloat(product.ljyk);//累计收益
            $scope.zhInfo.jryk =  parseFloat(product.dqyk);
            $scope.zhInfo.desc = product.desc;//说明
            $scope.cpfbzid = product.user.user.f_id;
            $scope.cpfbznameShow = product.user.user.f_nickname;//产品发布者name
            $scope.cpfbzheadShow = product.user.user.f_head;

            //$scope.getpeopleinfo();
            //$scope.getislcs();
            $scope.getzdt();
            $scope.getsyfx();
        }
    }

    $scope.getcpinfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息收益",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getcpinfoCallBack);
    }

    //涨跌停榜切换
    $scope.zdtchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = true;
            $scope.zdttabTwoShow = false;
        }
        else
        {
            $scope.zhmianShow = false;
            $scope.zdttabOneShow = false;
            $scope.zdttabTwoShow = true;
        }
        gotoUp();
    }

    $scope.zdtbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.zdttabOneShow = false;
        $scope.zdttabTwoShow = false;
        gotoUp();
    }

    $scope.fxchangeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.fxtabOneShow = true;
            $scope.fxtabTwoShow = false;
            $scope.fxtabThreeShow = false;
        }
        else if(_str == "2")
        {
            $scope.fxtabOneShow = false;
            $scope.fxtabTwoShow = true;
            $scope.fxtabThreeShow = false;
        }
        else if(_str == "3")
        {
            $scope.fxtabOneShow = false;
            $scope.fxtabTwoShow = false;
            $scope.fxtabThreeShow = true;
        }
    }

    //日收益分析
    $scope.rsyfxShow = function()
    {
        $scope.zhmianShow = false;
        $scope.rsyfxDivShow = true;
        $scope.fxchangeTab("1");
        if($scope.htmlType == "share")
        {
            window.location.href = "#index=5";
        }
    }


    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption, _data.account);
        if(_data.caption == "gtsynthetical")
        {
            $scope.childaccount = _data.account;
            $scope.getccinfo();
            $scope.getcpinfo();

            if($scope.shareindex == "5")
            {
                $scope.rsyfxShow();
            }
            else
            {
                $scope.rsyfxbackto();
            }

        }
    });
    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsynthetical"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);


    $scope.rsyfxbackto = function()
    {
        $scope.zhmianShow = true;
        $scope.rsyfxDivShow = false;
        if($scope.htmlType == "share") {
            window.location.href = "#index=1";
        }
    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }
    //收益分析是否显示
    $scope.sylfxShowClick = function()
    {
        $scope.sylfxShow = !$scope.sylfxShow;
    }

    //日收益分析详情
    $scope.rsyfxItem = function(_obj)
    {
        //console.log(_obj.sj);
        //setbackList(window.location.href);
        //window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate);
        if($scope.htmlType == "share")
        {
            window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=winlocbackhis";
        }
        else
        {
            openNewInterface("rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=newwebview");
        }

    }

    $scope.gphqClick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;

        //$cookieStore.put('stockInfo', obj);
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        $scope.hqbaseoneStockHQBaseShow = true;
        $scope.nohqDivShow = false;
    }

    //个股返回
    $scope.oneStockHQBaseBackto = function()
    {
        $scope.hqbaseoneStockHQBaseShow = false;
        $scope.nohqDivShow = true;
    }

    //跟投
    $scope.gotobmClick = function()
    {
        //window.location = "gtapply_fwz.html?productid=" + $scope.productid + "&&bgtuserid=" + $scope.cpfbzid;
        openNewInterface("gtapply_fwz.html?productid=" + $scope.productid + "&&bgtuserid=" + $scope.cpfbzid + "&opentype=newwebview", "dqgtqyupdate");
    }

    //服务发布者个人空间
    $scope.gotolcsinfo = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", $scope.cpfbzid);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
    }

    //签约
    $scope.gotoqyinfoClick = function()
    {
        //if($scope.gtqyArray.length>1)
        //{
            $scope.nohqDivShow = false;
            $scope.qylistShow = true;
        //}
        //else if($scope.gtqyArray.length == 1)
        //{
        //    $scope.qylistItemClick($scope.gtqyArray[0]);
        //}

    }

    $scope.ygtbackto = function()
    {
        $scope.nohqDivShow = true;
        $scope.qylistShow = false;
    }

    //签约
    $scope.qylistItemClick = function(_obj)
    {
        //setbackList(window.location.href);
        if(_obj.gtstatus == "gt1")
        {
            //window.location = "gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview", "dqgtqyupdate");
        }
        else if(_obj.gtstatus == "gt2")
        {
            //window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview", "dqgtqyupdate");
        }
        else if(_obj.gtstatus == "gt3")
        {
            //window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview", "dqgtqyupdate");
        }
    }

    dqgtqyupdate = function()
    {
        $scope.getisgtinfo();
    }
}
