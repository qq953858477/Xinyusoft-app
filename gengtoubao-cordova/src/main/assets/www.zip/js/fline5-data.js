var data5F = [];
var data5FDate = [];
var f5PreClose = 0;
var f5High = 0;
var f5Low = 0;
function getDate(){
	/*while(data5FDate.length<5){
		
		data5FDate.push(" ");
	}*/
	//alert(data5FDate.join())
	return data5FDate;
}
function getFiveQuote(chartObj,code) {
			var marketCode = code.substring(0,2);
			var stockCode = code.substring(2,code.length);
			//var url;
			//if(data5F.length==0){
			//	url = "../ESBServlet?command=hq.gettimelinefour&stockCode="+stockCode+"&marketCode="+marketCode+"";
			//}else{
			//	var date = data5F[data5F.length-1]["time"];
			//	url = "../ESBServlet?command=hq.gettimelinefour&stockCode="+stockCode+"&marketCode="+marketCode+"&dateTime="+date;
			//}
			//console.log(url);

			var gq = null;
			var message = {};
			message['stockCode'] = stockCode;
			message['marketCode'] = marketCode;
			if(data5F.length!=0)
			{
				var date = data5F[data5F.length-1]["time"];
				message['dateTime'] = date;
			}

			hqajaxService.sendMessage('hq.gettimelinefour', message, function(data) {
				//console.log("data", data)
				if (data.op.code.toString() == "Y") {
					

					if(data.datelist)
					{
						//alert(data.datelist.length)
						for(var i = 0; i < data.datelist.length;i++)
						{
							var datstr = data.datelist[i].date.substring(4,6)+"-"+data.datelist[i].date.substring(6,8);
							var isexist =false;
							for(var j = 0; j < data5FDate.length;j++)
							{
								if(data5FDate[j] ==datstr)
								{
									isexist =true;
									break;
								}
							}
							
							if(isexist)
							{
								continue;
							}
							data5FDate.push(datstr);
						}
						//alert(data5FDate.join())
						var loop = 5 - data5FDate.length;

						for(var i = 0;i < loop ;i++)
						{
							data5FDate.push(" ");

						}
						//alert(data5FDate.join())
						chartObj.xScaler.data = data5FDate;
					}
					
					for(var i = 0; i<data.datalist.length;i++)
					{
						
						if(data5F.length>0)
						{
							
							if(Number(data5F[data5F.length-1].date) > Number(data.datalist[i].date))
							{
								continue;
							}
							else if (Number(data5F[data5F.length-1].date) == Number(data.datalist[i].date) && Number(data5F[data5F.length-1].time) > Number(data.datalist[i].time))
							{
								continue;
							}
						}
					
						data5F.push(data.datalist[i]);
					}

					if(data.preclose)
					{
						f5PreClose = data.preclose;
					}

					if(data.fourhigh)
					{
						f5High = data.fourhigh;
					}

					if(data.fourlow)
					{
						f5Low = data.fourlow;
					}


					//data5FDate = data.date;
					gq = {quote: {
						time: 20111214150106,
						open: stock["open"],
						preClose: f5PreClose,
						highest: f5High,
						lowest: f5Low,
						price: stock["close"],
						volume: stock["volume"],
						amount: stock["amount"]
					},mins:data5F};

					chartObj.paint(gq);
				}
			});


            //$.ajax({
    		//	url:url,
    		//	type:"post",
    		//	dataType:"json",
    		//	cache:false,
    		//	async: true,
    		//	statusCode:{"200":function(data){
    		//		for(var i = 0; i<data.datalist.length;i++)
				//	{
    		//			data5F.push(data.datalist[i]);
    		//		}
				//
				//	if(data.datelist)
				//	{
				//		//alert(data.datelist.length)
				//		for(var i = 0; i < data.datelist.length;i++)
				//		{
				//			data5FDate.push(data.datelist[i].date.substring(4,6)+"-"+data.datelist[i].date.substring(6,8));
				//
				//
				//		}
				//		//alert(data5FDate.join())
				//		var loop = 5 - data5FDate.length;
				//
				//		for(var i = 0;i < loop ;i++)
				//		{
				//			data5FDate.push(" ");
				//
				//		}
				//		//alert(data5FDate.join())
				//		chartObj.xScaler.data = data5FDate;
				//	}
				//
				//	if(data.preclose)
				//	{
				//		f5PreClose = data.preclose;
				//	}
				//
				//	if(data.fourhigh)
				//	{
				//		f5High = data.fourhigh;
				//	}
				//
				//	if(data.fourlow)
				//	{
				//		f5Low = data.fourlow;
				//	}
				//
				//
    		//		//data5FDate = data.date;
    		//		gq = {quote: {
             //           time: 20111214150106,
             //           open: stock["open"],
             //           preClose: f5PreClose,
             //           highest: f5High,
             //           lowest: f5Low,
             //           price: stock["close"],
             //           volume: stock["volume"],
             //           amount: stock["amount"]
             //       },mins:data5F};
				//
				//	chartObj.paint(gq);
            //
				//	setTimeout(draw5F,1000 * 60);
            //
    		//	},"404":function(){
    		//		alert("您访问的地址不存在!");
    		//	},"500":function(){
    		//		alert("服务发生错误，请稍候再访问!");
    		//	}}
    		//});
        	return gq;
           
        }