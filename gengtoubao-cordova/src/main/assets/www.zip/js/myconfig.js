//websocket地址
var mywsConfig={
    //url: "ws://121.40.177.191:9988",//"ws://127.0.0.1:6688";
    url: "ws://121.40.129.195:9999/echo",
    channelID: "uulc",
    topic: "talk"
};