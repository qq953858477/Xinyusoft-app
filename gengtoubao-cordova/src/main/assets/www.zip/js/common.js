
/**
 * 是否当天
 * @param sdate yyyy-MM-dd HH:mm:ss
 */
function isToday(sdate)
{
    if(sdate==null || sdate.length==0 || typeof (sdate) =='undefined')
    {
        return false;
    }
    var today = new Date();
    var tmp1 = sdate.split(" ");
    var date = tmp1[0].split("-");

    if(Number(date[0]) == today.getFullYear() && Number(date[1]) == (today.getMonth()+1) && Number(date[2]) == today.getDate() )
    {
           return true;
    }
    else
    {
        return false;
    }
 }

//字符串（"20131220"）转日期
function stringToDay( str ) {
    if( str.length == 8 && Number(str) == str ) {
        var day = new Date();
        day.setUTCFullYear(str.substring(0,4));
        day.setMonth(str.substring(4,6)-1);
        day.setDate(str.substring(6,8));
//        alert(day.getUTCFullYear()+'-'+(day.getMonth()+1)+'-'+day.getDate());
        return day;
    }
}
//两个日期相差天数
function compareDay( day1, day2 ) {
    var result = (day1-day2)/1000/60/60/24;
    if(result>=0) return Math.ceil(result);
    else return Math.floor(result);
}
function toOneLayerJSONArray( obj ) {
    var resultList = [];
    for( var i =0 ; i<obj.length;i++) {
        var tempList = {};
        if (typeof obj[i] == "object") for (name1 in obj[i]) {
            if (typeof obj[i][name1] == "object") for (name2 in obj[i][name1]) {
                if (typeof obj[i][name1][name2] == "object") for (name3 in obj[i][name1][name2]) {
                    if (typeof obj[i][name1][name2][name3] == "object") {
                        continue;
                    } else {
                        tempList[name1 + "." + name2 + "." + name3] = obj[i][name1][name2][name3];
                    }
                } else {
                    tempList[name1 + "." + name2] = obj[i][name1][name2];
                }
            } else {
                tempList[name1] = obj[i][name1];
            }
        } else {
            tempList = obj[i];
        }
        resultList.push(tempList);
    }
    return resultList;

}
//var testJSON = { "layer1a": { "cd": { "ef": "some value." } }, "layer1b": { "gh": "some value." }, "layer1c": { "ij": { "kl": "some value" }, "mn": "some value." } };
function toOneLayerJSON( obj ) {
    var resultJSON = {};
    var resultList = [];
    for( list in obj ) {
        var tempList = {};
        if (typeof obj[list] == "object") for (name1 in obj[list]) {
            if (typeof obj[list][name1] == "object") for (name2 in obj[list][name1]) {
                if (typeof obj[list][name1][name2] == "object") for (name3 in obj[list][name1][name2]) {
                    if (typeof obj[list][name1][name2][name3] == "object") {
                        continue;
                    } else {
                        tempList[name1 + "." + name2 + "." + name3] = obj[list][name1][name2][name3];
                    }
                } else {
                    tempList[name1 + "." + name2] = obj[list][name1][name2];
                }
            } else {
                tempList[name1] = obj[list][name1];
            }
        } else {
            tempList = obj[list];
        }
        resultList.push(tempList);
    }
    for( list in resultList ) {
        resultJSON[list] = resultList[list];
    }
//    alert(JSON.stringify(result));
    return resultJSON;

}
//var datalist = toOneLayerJSON(testJSON);
//alert(JSON.stringify(datalist));

/**
 * 输入框限制
 */
function initInputLimit()
{
    $(".numberLimit").keydown(function(event){
            var k = event.keyCode;

            var value = $(this).val();
            if(isFunKey(k)) {
                return true;
            }
            var c = getChar(k);
            if( c == '.')
            {
                return true;
            }
            if(c == '-' || c == '+') {
                return true;
            }
            if(isNaN(value + getChar(k))) {
                return false;
            }
            return true;
        }
    );

    $(".numberLimit").keyup(function(event){
        var value = $(this).val();
        if(value == '-' || value == '+') {
            return true;
        }
        if(isNaN(value) ){
            $(this).val(0);
            $(this).focus();
        }
    })

}

function isFunKey(code) {
    // 8 --> Backspace
    // 35 --> End
    // 36 --> Home
    // 37 --> Left Arrow
    // 39 --> Right Arrow
    // 46 --> Delete
    // 112~123 --> F1~F12
    var funKeys = [8, 9, 35, 36, 37, 39, 46];
    for(var i = 112; i <= 123; i++) {
        funKeys.push(i);
    }
    for(var i = 0; i < funKeys.length; i++) {
        if(funKeys[i] == code) {
            return true;
        }
    }
    return false;
}

function getChar(k)
{
    if(k >= 48 && k <= 57) {
        return String.fromCharCode(k);
    }
    if(k >= 96 && k <= 105) {
        return String.fromCharCode(k - 48);
    }
    if(k == 110 || k == 190 || k== 188  || k==229) {
        return ".";
    }
    if(k == 109 || k == 189 || k==173) {
        return "-";
    }
    if(k == 107 || k == 187) {
        return "+";
    }
    return "#";
}


