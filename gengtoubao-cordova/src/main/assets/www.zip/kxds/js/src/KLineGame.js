var testInv;

var firstInit = true;
var flashTime = 0;
var flashInterval;
var actionBaned = false;

var thisnickName = "";
//获取入参
function getParameter(param) {
    var query = window.location.search;
    //console.log("getParameter", query);
    var iLen = param.length;
    var iStart = query.indexOf(param);
    if (iStart == -1) {
        return "";
    }
    iStart += iLen + 1;
    var iEnd = query.indexOf("&", iStart);
    if (iEnd == -1) {
        return query.substring(iStart);
    }
    else {
        return query.substring(iStart, iEnd);
    }
}

//判断是手机浏览器还是PC浏览器
var browserType = function isPcOrMobile() {
//    alert(navigator.userAgent);
    if ((navigator.userAgent.match(/(iPhone)/))) return "iPhone";
    if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|wOSBrowser|BrowserNG|WebOS)/i))) return 'mobile';
    else return 'pc';
}();

var markerImg = new Image();
markerImg.src = 'images/change_btn.png?ver=20141109001';

//定义游戏声音
var effectPauseTimeout;
audiojs.events.ready(function () {
    var audioIsReadyInterval = setInterval(function () {
        if (audioIsReady) {
            //alert("音乐文件初始化完毕");
            try {
                var as = audiojs.createAll();
                //buy_audio = audiojs.create(document.getElementById("buy_audio"));
                //hold_audio = audiojs.create(document.getElementById("hold_audio"));
                //change_audio = audiojs.create(document.getElementById("change_audio"));
                //rise_audio = audiojs.create(document.getElementById("rise_audio"));
                //fall_audio = audiojs.create(document.getElementById("fall_audio"));
            } catch (e) {
                //alert(e)
            }
            audioInit();
            clearInterval(audioIsReadyInterval);
        }
    }, 1000);
});
function audioInit() {
    try {
        $(".audiojs").css("z-index", "9");
        $(".audiojs").removeClass("audiojs").find(".time, .error, .error-message").hide();
        //初始化大涨音效（点击封面时）
        //if (browserType == 'mobile' || browserType == 'iPhone') {
        //    if ($(window).width() < $(window).height()) {
        //        $("#rise_audio").next().find(".play").attr('id', 'rise_btn_activation').removeClass("play").addClass('clickable')
        //            .css('position', 'absolute').width($(window).height()).height($(window).width()).css('left', '0').css('top', '0').css('z-index', '999999999').css('background-image', 'url("images/loading11.jpg?ver=20141109001")').css('background-size', '100% 100%');
        //    } else {
        //        $("#rise_audio").next().find(".play").attr('id', 'rise_btn_activation').removeClass("play").addClass('clickable')
        //            .css('position', 'absolute').width($(window).width()).height($(window).height()).css('left', '0').css('top', '0').css('z-index', '999999999').css('background-image', 'url("images/loading11.jpg?ver=20141109001")').css('background-size', '100% 100%');
        //    }
        //} else {
        //    $("#rise_audio").next().find(".play").attr('id', 'rise_btn_activation').removeClass("play").addClass('clickable')
        //        .css('position', 'absolute').width($(window).width()).height($(window).height()).css('left', '0').css('top', '0').css('z-index', '999999999').css('background-image', 'url("images/loading11.jpg?ver=20141109001")').css('background-size', '100% 100%');
        //}
        $("#rise_btn_activation").bind("click", function () {
            $("#rise_btn_activation").fadeOut(1200);
            setTimeout(function () {
                $("#audioContainer").css("z-index", "-1");
            }, 1200);
            document.getElementById("bodyContainer").style.display = "block";

            setTimeout(function () {
                waitingTime = 30;
                rise_audio.currentTime = 0;
                rise_audio.volume = 0.1;
                rise_audio.play();
                rise_audio.currentTime = 9.5;
                rise_audio.volume = 0.1;
                rise_audio.pause();
            }, 3000);
        });
    } catch (e) {
//        alert(e)
    }
}
function playSounds(soundName, delay) {
    setTimeout(function () {
        try {
            clearTimeout(effectPauseTimeout);
            rise_audio.pause();
            if (soundName == "buy") {
                rise_audio.currentTime = 3;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 1200);
//                $.mbAudio.play("effectSprite","buy");
//                $.mbAudio.play("buy","buy");
            }
            if (soundName == "sell") {
                rise_audio.currentTime = 3;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 1200);
//                $.mbAudio.play("effectSprite","sell");
//                $.mbAudio.play("sell","sell");
            }
            if (soundName == "hold") {
//                alert(rise_audio.currentTime)
                rise_audio.currentTime = 5.20;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 540);
//                $.mbAudio.play("effectSprite","hold");
//                $.mbAudio.play("hold","hold");
            }
            if (soundName == "change") {
                rise_audio.currentTime = 6.55;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 1000);
//                $.mbAudio.play("effectSprite","change");
//                $.mbAudio.play("change","change");
            }
            if (soundName == "largeRise") {
                rise_audio.currentTime = 8.35;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 1550);
//                $.mbAudio.play("effectSprite","largeRise");
//                $.mbAudio.play("largeRise","largeRise");
            }
            if (soundName == "largeFall") {
                rise_audio.currentTime = 10.6;
                rise_audio.play();
                effectPauseTimeout = setTimeout(function () {
                    rise_audio.pause();
                }, 850);
            }
        } catch (e) {
            console.log(e)
        }
    }, delay);
}

var klineUserTopic = "wttest"; // K线大师用户相关主题
// 历史战绩
function showHistry() {
    //alert(getParameter('openid'));
    var message = {
        openid: getParameter('openid')
    };
    myESBAjax("user.getKlineHistry",message,getHistryHandler);
}

function hideHistry() {
    $("#histryData").html("");
    $("#mainMiddle").show();
    $("#histryDiv").hide();
    $("#rotateDiv").show();
}

var stockInfo = {};

var userInfo = {};

function getHistryHandler(data) {
    //alert(json);
    //$("#displayData").html(json);
    try {
        console.log("===============");
        console.log(data);
        if (data['op']['code'] == 'Y') {
            // 处理历史战绩
            var tbody = '';
            if (data['history'].length == 0) {
                tbody = '<tbody width="100%" height="100%" style="text-align: center;text"><tr><td>还没有记录，先去玩两局。</td></tr></tbody>';
            } else {
                tbody = '<thead class="DataTableFS15"> ' +
                    '<tr style="color:#000000">' +
                    '<th>记录时间</th>' +
                    '<th>收益率</th>' +
                    '<th>交易次数</th>' +
                    '<th>胜率</th>' +
                    '</tr>' +
                    '</thead>';
                tbody += '<tbody>';
                for (var i = 0; i < data['history'].length; i++) {
                    var tempHistry = data['history'][i];
                    var time = tempHistry['f_date'].toString();
                    tbody += '<tr style="width: 100%"  class="DataTableFFArial">';
                    tbody += '<td>' + time.substring(0,time.lastIndexOf(":")) + '</td>' +
                        '<td>' + Number(tempHistry['f_syl']).toFixed(2) + '%</td>' +
                        '<td>' + tempHistry['f_jycs'] + '</td>' +
                        '<td>' + Number(tempHistry['f_sl']).toFixed(2) + '%</td>';
                    tbody += '</tr>';
                }
                tbody += '</tbody>';
            }
            $("#histryDiv").show();
            $("#mainMiddle").hide();
            $("#rotateDiv").hide();
            //alert(data['history'].length);
            //alert('show');
            $("#histryData").html(tbody);
            //alert(tbody);
        }
    } catch (e) {
        //alert(e);
    }
}
function getUserInfoHandler(data) {
    try {
        console.log(data);
        if (data['op']['code'] == 'Y') {
            userInfo = data['user'];
            console.log("====================================");
            console.log(userInfo);
            $("#headerPic").attr("src", userInfo['f_head']);
            $("#nickName").html(userInfo['f_nickname']);
            thisnickName = userInfo['f_nickname'];

            $("#headerPicHis").attr("src", userInfo['f_head']);
            $("#nickNameHis").html(userInfo['f_nickname']);
            $("#userInfoDIV").show();
        }
    } catch (e) {
        console.log(e);
    }
}
var myHandler = {
    prepareData: function (dataList) {
        console.log("receiveMessage_amq");

        candles_keyLine = [];
        lines_ma5 = [];
        lines_ma10 = [];
        lines_ma20 = [];
        lines_vol = [];
        lines_ma5_vol = [];
        lines_ma10_vol = [];
        lines_ma20_vol = [];
        track_riserates = [];
        track_exchangerates = [];

        //var json;
        //if (message) {
        //    for (h in message) {
        //        if (h == "wholeText") {
        //            json = message[h];
        //        }
        //    }
        //}
        ////$("#displayData").html(json);
        //var dataList = $.parseJSON(json);
        if (dataList['op']['code'] == "Y" && dataList.lines.length > 0) {
            // 提交标记
            $("#communionDiv_float").hide();
            $("#communion").hide();
            hasSubmit = false;
            $("#mainMiddle").css("opacity", "1");//显示画布
            stockInfo = dataList['stockinfo'];
            keyLine = eval(dataList.lines);
            //基础数据——序号、收、低、高、开、收MA5、收MA10、收MA20、成交量、成交量MA5、成交量MA10、成交量MA20、涨跌幅、换手率
            maxAmount = eval(keyLine).length;

            for (var i = 0; i < maxAmount; i++) {
                //准备绘制K线图的数据
                candles_keyLine.push([keyLine[i][0], keyLine[i][1], keyLine[i][2], keyLine[i][3], keyLine[i][4]]);
                //准备绘制K线图MA5、MA10、MA20的数据
                lines_ma5.push([keyLine[i][0], keyLine[i][5]]);
                lines_ma10.push([keyLine[i][0], keyLine[i][6]]);
                lines_ma20.push([keyLine[i][0], keyLine[i][7]]);
                //准备绘制成交量线图的数据
                lines_vol.push([keyLine[i][0], keyLine[i][8]]);
                //准备绘制交量柱图MA5、MA10、MA20的数据
                lines_ma5_vol.push([keyLine[i][0], keyLine[i][9]]);
                lines_ma10_vol.push([keyLine[i][0], keyLine[i][10]]);
                lines_ma20_vol.push([keyLine[i][0], keyLine[i][11]]);
                //准备涨跌幅的数据
                track_riserates.push([keyLine[i][0], keyLine[i][12]]);
                //准备跟踪换手率的数据
                track_exchangerates.push([keyLine[i][0], keyLine[i][13] != 0 ? keyLine[i][13] : 0.00001]);
            }
        }

        //初始化：
        operations = [];//交易操作队列
        bars_operation_top_red = [];//操作队列画布数组（上部、赚）
        bars_operation_top_green = [];//操作队列画布数组（上部、亏）
        bars_operation_bottom_red = [];//操作队列画布数组（下部、赚）
        bars_operation_bottom_green = [];//操作队列画布数组（下部、亏）
        markers_profitability = [];//用于显示每次买卖收益率的数组（下部、亏）

        curKline = 10;//当前操作对应的K线
        isHolding = false;//当前是否持有目标证券
        $('#holding').hide();
        $('#holding1').hide();
        $('#watching').show();
        $('#watching1').show();

        resizeAll();//初始化DOM元素高度

        toNextKline();//前进到第一根K线
        autoOperate(30);//设置等待操作解锁的时间
        firstInit = false;
    }
};
function changeKlineData() {
    try {
        playSounds('change', 100);
    } catch (e) {
        console.log(e);
    }
    getKlineData();
}
function getKlineData() {
    $("#mainMiddle").css("opacity", "0");//隐藏画布
    $("#mainMiddle canvas").remove();
    $("#mainDiv").fadeIn(0);
    communion_float("正在努力加载数据...");
    myESBAjax("klinegame.stockLines",{},myHandler.prepareData)
}

function myESBAjax(action, par, callback) {
    // alert(urls+" "+par+" "+func)
    //var message={command:action};
    //par['command'] = action;
    //$.ajax({
    //    url: "ESBServlet",
    //    type: "POST",
    //    data: par,
    //    async: false,
    //    dataType: "JSON",
    //    timeout: 60000,
    //    success: callback,
    //    error: function (XMLHttpRequest, textStatus, errorThrown) {
    //        if (XMLHttpRequest.readyState == 4) {
    //            alert(action + ":" + XMLHttpRequest.status);
    //            alert(textStatus + "  " + errorThrown);
    //        }
    //    }
    //});

    var jsonpUrl = "http://www.xinyusoft.com:8085/KLineMaster-wx/JSONP";
    par['command'] = action;
    $.ajax({
        type : "POST",
        data: par,
        url : jsonpUrl,
        dataType : "jsonp",
        async: false,
        //jsonp和jsonpCallback两参数可以不要，在请求WebService时，会自动加callback参数在url后面
        timeout: 60000,
        success: callback,
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (XMLHttpRequest.readyState == 4)
            {
                //alert(action + ":" + XMLHttpRequest.status);
                //alert(textStatus + "  " + errorThrown);
                console.log(action + ":" + XMLHttpRequest.status);
                console.log(textStatus + "  " + errorThrown);
            }
        }
    });
}

function getUserInfo() {
    var message = {
        "user.openid": getParameter('openid')
    };
    myESBAjax("user.usercheck",message,getUserInfoHandler);
}


/* 模拟的画布数据 */
var keyLine = [];
var candles_keyLine = [];
var lines_ma5 = [];
var lines_ma10 = [];
var lines_ma20 = [];
var volumes = [];
var lines_vol = [];
var lines_riserates = [];

var lines_ma5_vol = [];
var lines_ma10_vol = [];
var lines_ma20_vol = [];
var track_riserates = [];
var track_exchangerates = [];
/* 模拟的画布数据 */

/* 用于绘制画布的片段数据 */
var candles_keyLine_slice = [];
var lines_ma5_slice = [];
var lines_ma10_slice = [];
var lines_ma20_slice = [];
var lines_vol_slice = [];
var lines_exchangerates_slice = [];
var lines_TAI_slice = [];
/* 用于绘制画布的片段数据 */

var first_time_enter = true;//是否至今第一次进行游戏
var first_time_enter_today = true;//是否今天第一次进行游戏
var waitingTime = 0;//操作解锁剩余时间（秒）
var interval;//操作解锁时间递减的定时器
var capital = 10000;//每次买卖初始资金
var profitability = 0;//每次买卖收益率（%）
var wintimes = 0;
var profitability_change = 0;//每次买卖收益率变化（%）
var capital_total = 10000;//本次游戏初始资金
var profitability_total = 0;//总收益率率（%）
var riseCombo = 0;//是否5日连涨
var fallCombo = 0;//是否5日连跌

var operations = [];//交易操作队列
var bars_operation_top_red = [];//操作队列画布数组（上部、赚）
var bars_operation_top_green = [];//操作队列画布数组（上部、亏）
var bars_operation_bottom_red = [];//操作队列画布数组（下部、赚）
var bars_operation_bottom_green = [];//操作队列画布数组（下部、亏）
var markers_profitability = [];//用于显示每次买卖收益率的数组（下部、亏）

var curKline = 10;//当前操作对应的K线
var displayAmount = 25;//一并显示的K线数量
var maxAmount;//一并显示的K线数量
var mouseIndex = 9;//当前鼠标所在K线位置
var onTracking = false;//是否显示跟踪线
var dblclickTimout = 0;//双击触发倒计时
var isZoomIn = 0;//是否全屏
var optTimes = 0//交易次数
var minPrice = 999;//画布中股价最低值
var maxPrice = 0;//画布中股价最高值
var minPriceZoom = 999;//画布中股价最低值（缩放后）
var maxPriceZoom = 0;//画布中股价最高值（缩放后）
var maxTAI = 0;//所有已见指标数据中最高值
var isHolding = false;//当前是否持有目标证券
var TAIType = '成交量';//技术指标(technical analysis indicators)类型

var canvasTop, canvasTop_background, canvasBottom;//上部、上部背景、下部三个canvas对象

var windowWidth;//游戏窗口的宽度
var windowHeight;//游戏窗口的高度
var fontSize;

$(function () {
    if (browserType == 'mobile' || browserType == 'iPhone') {
        FastClick.attach(document.body);
        resizeAll();
    }

    setTimeout(function () {
        window.scrollTo(0, 1);
    }, 100);
    getKlineData();//获取K线数据
    getUserInfo();//获取用户数据
//    setTimeout(function() {
//        testInv = setInterval(function() {
//            wait();
//        },10)
//    },2500)
});

/* 进入下一条K线 */
function toNextKline() {

    $("#communionDiv_float").stop(true, true).clearQueue().fadeOut(0);
    $("#klineRemain").html((curKline + 1) + "／" + (maxAmount) + "");
    curKline++;//当前所在K线+1

//    封死涨停和封死跌停时自动观望或持有到下一日
//    if(candles_keyLine[curKline+2][1] != null
//            && candles_keyLine[curKline+2][1] == candles_keyLine[curKline+2][3]
//            && candles_keyLine[curKline+2][1] == candles_keyLine[curKline+2][4]
//            && candles_keyLine[curKline+2][1] == candles_keyLine[curKline+2][2]) {
////        alert(candles_keyLine[curKline-2][1]+"=="+candles_keyLine[curKline-2][2]+"=="+candles_keyLine[curKline-2][3]+"=="+candles_keyLine[curKline-2][4]);
//        clearInterval(testInv);
//    }
    if (candles_keyLine[curKline - 1][1] != null
        && candles_keyLine[curKline - 1][1] == candles_keyLine[curKline - 1][3]
        && candles_keyLine[curKline - 1][1] == candles_keyLine[curKline - 1][4]
        && candles_keyLine[curKline - 1][1] == candles_keyLine[curKline - 1][2]) {
//        alert(candles_keyLine[curKline-2][1]+"=="+candles_keyLine[curKline-2][2]+"=="+candles_keyLine[curKline-2][3]+"=="+candles_keyLine[curKline-2][4]);
//        alert(Math.round(candles_keyLine[curKline-1][1]*100)+"=="+Math.round(candles_keyLine[curKline-2][1]*1.1*100))
        if (isHolding == true) {
            if (Math.round(candles_keyLine[curKline - 1][1] * 100) == Math.round(candles_keyLine[curKline - 2][1] * 0.9 * 100) || Math.round(candles_keyLine[curKline - 1][1] * 100) == Math.round(candles_keyLine[curKline - 2][1] * 0.95 * 100)) {
                hold();
                communion_float("跌停了卖不掉，已自动持有至可卖时");
//                clearInterval(testInv);
            }
        }
        else {
            if (Math.round(candles_keyLine[curKline - 1][1] * 100) == Math.round(candles_keyLine[curKline - 2][1] * 1.1 * 100) || Math.round(candles_keyLine[curKline - 1][1] * 100) == Math.round(candles_keyLine[curKline - 2][1] * 1.05 * 100)) {
                wait();
                setTimeout(function () {
                    communion_float("涨停了买不了，已自动观望至可买时");
                }, 3000)
//                clearInterval(testInv);
            }
        }
    }

    //上涨市和下跌市判断
    riseCombo = 0;
    fallCombo = 0;
    var temp = '';
//    alert(curKline);
    for (var i = 0; i < curKline - 1; i++) {
        temp += keyLine[curKline - i - 2][1] + ',';
        if (track_riserates[curKline - i - 2][1] > 0) {
            if (fallCombo != 0) break;
            riseCombo++;
        } else {
            if (riseCombo != 0) break;
            fallCombo++;
        }
    }
//    alert("连涨："+riseCombo+"天，连跌"+fallCombo+"天\n"+temp);

    /* 准备行情数据 */

    /* 画布数据截取 */
    if (curKline < displayAmount) {

        candles_keyLine_slice = candles_keyLine.concat().slice(0, curKline);
        lines_ma5_slice = lines_ma5.concat().slice(0, curKline);
        lines_ma10_slice = lines_ma10.concat().slice(0, curKline);
        lines_ma20_slice = lines_ma20.concat().slice(0, curKline);
//        bars_volRise_slice = bars_volRise.concat().slice(0, curKline);
//        bars_volFall_slice = bars_volFall.concat().slice(0, curKline);
        lines_vol_slice = lines_vol.concat().slice(0, curKline);
        lines_exchangerates_slice = track_exchangerates.concat().slice(0, curKline);
        //        lines_ma5_vol_slice = lines_ma5_vol.concat().slice(0, curKline);
//        lines_ma10_vol_slice = lines_ma10_vol.concat().slice(0, curKline);
//        lines_ma20_vol_slice = lines_ma20_vol.concat().slice(0, curKline);
        for (var i = curKline; i < displayAmount; i++) {
            candles_keyLine_slice.push([i, null, null, null, null]);
            lines_ma5_slice.push([i, null]);
            lines_ma10_slice.push([i, null]);
            lines_ma20_slice.push([i, null]);
//            bars_volRise_slice.push([i,null]);
//            bars_volFall_slice.push([i,null]);
            lines_vol_slice.push([i, null]);
            lines_exchangerates_slice.push([i, null]);
//            lines_ma5_vol_slice.push([i,null]);
//            lines_ma10_vol_slice.push([i,null]);
//            lines_ma20_vol_slice.push([i,null]);
        }
        if (TAIType == '成交量') lines_TAI_slice = lines_vol_slice;
        else if (TAIType == '换手率') lines_TAI_slice = lines_exchangerates_slice;
//        alert(track_exchangerates)
    }
    if (curKline >= displayAmount) {
        candles_keyLine_slice = candles_keyLine.concat().slice(curKline - displayAmount, curKline);
        lines_ma5_slice = lines_ma5.concat().slice(curKline - displayAmount, curKline);
        lines_ma10_slice = lines_ma10.concat().slice(curKline - displayAmount, curKline);
        lines_ma20_slice = lines_ma20.concat().slice(curKline - displayAmount, curKline);
//        bars_volRise_slice = bars_volRise.concat().slice(curKline-displayAmount, curKline);
//        bars_volFall_slice = bars_volFall.concat().slice(curKline-displayAmount, curKline);
        lines_vol_slice = lines_vol.concat().slice(curKline - displayAmount, curKline);
        lines_exchangerates_slice = track_exchangerates.concat().slice(curKline - displayAmount, curKline);
//        lines_ma5_vol_slice = lines_ma5_vol.concat().slice(curKline-displayAmount, curKline);
//        lines_ma10_vol_slice = lines_ma10_vol.concat().slice(curKline-displayAmount, curKline);
//        lines_ma20_vol_slice = lines_ma20_vol.concat().slice(curKline-displayAmount, curKline);
        if (TAIType == '成交量') lines_TAI_slice = lines_vol_slice;
        else if (TAIType == '换手率') lines_TAI_slice = lines_exchangerates_slice;
    }
    /* 画布数据截取 */

    //计算画布坐标的最大值和最小值
    minPrice = 9999;
    maxPrice = 0;
    maxTAI = 0;
    for (var i = 0; i < displayAmount; i++) maxPrice = Math.max(maxPrice, candles_keyLine_slice[i][3], lines_ma5_slice[i][1]);
    for (var i = 0; i < displayAmount; i++) if (candles_keyLine_slice[i][2] > 0 && lines_ma5_slice[i][1] > 0) {
        minPrice = Math.min(minPrice, candles_keyLine_slice[i][2], lines_ma5_slice[i][1]);
    }
    maxPrice = eval(((maxPrice - minPrice) * 1.2 + minPrice).toFixed(1)) + 0.025;
    minPrice = eval((maxPrice - (maxPrice - minPrice) * 1.2).toFixed(1)) - 0.025;
//    for(var i=0; i<curKline; i++) maxTAI = Math.max(maxTAI, bars_volRise[i][1]);
//    for(var i=0; i<curKline; i++) maxTAI = Math.max(maxTAI, bars_volFall[i][1]);
    if (TAIType == "成交量") {
        for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, lines_vol[i][1]);
        if (maxTAI == 0.00001) maxTAI = 10000;
        maxTAI = maxTAI * 1.2;
    }
    else if (TAIType == "换手率") {
        for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, track_exchangerates[i][1]);
        if (maxTAI == 0.00001) maxTAI = 10000;
        maxTAI = maxTAI * 1.2;
    }

    if (isHolding == true) {
        //计算本次买卖收益
        capital *= (1 + track_riserates[curKline - 1][1]);
        profitability_change = ((1 + track_riserates[curKline - 1][1]) - 1) * 100;
        profitability = (capital / 10000 - 1) * 100;
        if (profitability > 0) {
            operations[Math.min(displayAmount + 1, curKline) - 1] = 'red';
            markers_profitability[Math.min(displayAmount + 1, curKline) - 1] = (profitability.toFixed(2)) + (browserType == 'mobile' ? '%' : '%');
            if (curKline >= displayAmount) markers_profitability[Math.min(displayAmount + 1, curKline) - 1] += '　　 　';
            for (var i = 0; i < 100; i++) {
                markers_profitability[Math.min(displayAmount + 1, curKline) - 2 - i] = null;
                if (operations[Math.min(displayAmount + 1, curKline) - 2 - i] == 'green') {
                    operations[Math.min(displayAmount + 1, curKline) - 2 - i] = 'red';
                }
                if (operations[Math.min(displayAmount + 1, curKline) - 2 - i] == null) {
                    break;
                }
            }
        }
        if (profitability <= 0) {
            operations[Math.min(displayAmount + 1, curKline) - 1] = 'green';
            markers_profitability[Math.min(displayAmount + 1, curKline) - 1] = (profitability.toFixed(2)) + (browserType == 'mobile' ? '%' : '%');
            if (curKline >= displayAmount) markers_profitability[Math.min(displayAmount + 1, curKline) - 1] += '　　　';
            for (var i = 0; i < 100; i++) {
                markers_profitability[Math.min(displayAmount + 1, curKline) - 2 - i] = null;
                if (operations[Math.min(displayAmount + 1, curKline) - 2 - i] == 'red') {
                    operations[Math.min(displayAmount + 1, curKline) - 2 - i] = 'green';
                }
                if (operations[Math.min(displayAmount + 1, curKline) - 2 - i] == null) {
                    break;
                }
            }
        }
        $('#optTimesSpan').html("交易次数：" + optTimes + "次");
//        $('#profitabilitySpan').html("本手收益：<span class='"+(profitability==0?'':(profitability>0?"red":"green"))+"'>"+(profitability.toFixed(2)+'%')+"</span>");
        capital_total *= (1 + track_riserates[curKline - 1][1]);
        profitability_total = (capital_total / 10000 - 1) * 100;
        $('#profitabilitySpan_total').html("总收益率：<span class='" + (profitability_total == 0 ? '' : (profitability_total > 0 ? "red" : "forestgreen")) + "'>" + (profitability_total.toFixed(2) + '%') + "</span>");
        if (profitability_total >= 30) $('#capitalImage').attr("src", "images/gold_4.png?ver=20141109001");
        if (profitability_total >= 10 && profitability_total < 30) $('#capitalImage').attr("src", "images/gold_3.png?ver=20141109001");
        else if (profitability_total >= -30 && profitability_total < 10) $('#capitalImage').attr("src", "images/gold_2.png?ver=20141109001");
        else if (profitability_total < -30) $('#capitalImage').attr("src", "images/gold_1.png?ver=20141109001");
    } else {
        if (markers_profitability[Math.min(displayAmount + 1, curKline) - 2] != null) {
            var temp_pos_start;
            var temp_pos_end;
            var temp_profit;
            temp_profit = markers_profitability[Math.min(displayAmount + 1, curKline) - 2];
            if (curKline >= displayAmount) temp_profit = temp_profit.trim();
            markers_profitability[Math.min(displayAmount + 1, curKline) - 2] = null;
            temp_pos_end = Math.min(displayAmount + 1, curKline) - 1;
            for (var i = 0; i < 100; i++) {
                if (operations[Math.min(displayAmount + 1, curKline) - 2 - i] == null) {
                    temp_pos_start = Math.min(displayAmount + 1, curKline) - 2 - i;
                    if (Math.round(temp_pos_end - temp_pos_start - 1) % 2 == 0) temp_profit += (browserType == 'mobile' ? '　　 ' : '　　　　 ');
                    else temp_profit += '';
                    markers_profitability[Math.round((temp_pos_start + temp_pos_end) / 2)] = (temp_pos_end - temp_pos_start) > 2 ? temp_profit : '';
                    break;
                }
            }
//            if( temp_pos_end-temp_pos_start==1 ) markers_profitability[Math.round((temp_pos_start+temp_pos_end)/2)] = temp_profit.trim();
        }

        //根据本次买卖收益，计算本局游戏收益中
//        $('#profitabilitySpan').html("本手收益：--");

        capital = 10000;
        $('#profitabilitySpan_total').html("总收益率：<span class='" + (profitability_total == 0 ? '' : (profitability_total > 0 ? "red" : "forestgreen")) + "'>" + (profitability_total.toFixed(2) + '%') + "</span>");
//        $('#profitabilitySpan').html("本手收益：--");
        $('#optTimesSpan').html("交易次数：" + optTimes + "次");
//        alert(profitability_total);
        if (profitability_total >= 30) $('#capitalImage').attr("src", "images/gold_4.png?ver=20141109001");
        if (profitability_total >= 10 && profitability_total < 30) $('#capitalImage').attr("src", "images/gold_3.png?ver=20141109001");
        else if (profitability_total >= -30 && profitability_total < 10) $('#capitalImage').attr("src", "images/gold_2.png?ver=20141109001");
        else if (profitability_total < -30) $('#capitalImage').attr("src", "images/gold_1.png?ver=20141109001");
    }
//    alert(operations+"\n"+markers_profitability+"\n"+Math.round((temp_pos_start+temp_pos_end)/2)+"\n"+temp_profit)
    if (curKline > displayAmount && curKline - 1 < maxAmount) {
        operations.splice(0, 1);
        markers_profitability.splice(0, 1);
    }

    //额外数组用于标记买卖记录
    bars_operation_top_red = [];//操作队列画布数组（上部、赚）
    bars_operation_top_green = [];//操作队列画布数组（上部、亏）
    bars_operation_bottom_red = [];//操作队列画布数组（下部、赚）
    bars_operation_bottom_green = [];//操作队列画布数组（下部、亏）

    for (i = 0; i < Math.min(displayAmount, curKline); i++) bars_operation_top_red.push([eval(candles_keyLine_slice[i][0]), operations[i] == 'red' ? maxPrice : 0]);
    for (i = 0; i < Math.min(displayAmount, curKline); i++) bars_operation_top_green.push([eval(candles_keyLine_slice[i][0]), operations[i] == 'green' ? maxPrice : 0]);
    for (i = 0; i < Math.min(displayAmount, curKline); i++) bars_operation_bottom_red.push([eval(lines_vol_slice[i][0]), operations[i] == 'red' ? maxTAI * 0.99 : 0]);
    for (i = 0; i < Math.min(displayAmount, curKline); i++) bars_operation_bottom_green.push([eval(lines_vol_slice[i][0]), operations[i] == 'green' ? maxTAI * 0.99 : 0]);

    //主画布方法
    document.getElementById("bodyContainer").style.display = "block";
    (function drawMain(canvas1_background, canvas1, canvas2) {
        actionBaned = true;
        flashTime = 400;
//        $("#mainMiddle canvas").remove();

        canvasTop_background = drawcanvasTop_background();

        function drawcanvasTop_background(opts) {
            $("#canvas1_background canvas").remove();

            //刷新行情-K线
            var datas1_background = [
                {
                    data: bars_operation_top_red, bars: {
                    fillColor: "#AA2222",
                    lineWidth: 0,
                    fillOpacity: 0.45,
                    show: true,
                    shadowSize: 0,
                    barWidth: 1,
                    centered: true
                }
                }
                , {
                    data: bars_operation_top_red, markers: {
                        show: true,           // => setting to true will show markers, false will hide
                        lineWidth: 1,          // => line width of the rectangle around the marker
                        color: 'red',      // => text color
                        fill: false,           // => fill or not the marekers' rectangles
                        fillColor: "#FFFFFF",  // => fill color
                        fillOpacity: 0.45,      // => fill opacity
                        stroke: false,         // => draw the rectangle around the markers
                        position: 'cb',        // => the markers position (vertical align: b, m, t, horizontal align: l, c, r)
                        verticalMargin: 14,     // => the margin between the point and the text.
                        labelFormatter: function (o) {
//                        alert()
                            return (o.x == null ? markerImg : (markers_profitability[o.x + Math.min(displayAmount, curKline) - curKline]) == null ? '' : markers_profitability[o.x + Math.min(displayAmount, curKline) - curKline]);
//                        return (o.x==null?markerImg: o.x);
                        },
                        fontSize: 9,
                        stacked: false,        // => true if markers should be stacked
                        stackingType: 'b',     // => define staching behavior, (b- bars like, a - area like) (see Issue 125 for details)
                        horizontal: false      // => true if markers should be horizontal (For now only in a case on horizontal stacked bars, stacks should be calculated horizontaly)
                    }, mouse: {track: false}
                }
                , {
                    data: bars_operation_top_green, bars: {
                        fillColor: "darkgreen",
                        lineWidth: 0,
                        fillOpacity: 0.4,
                        show: true,
                        shadowSize: 0,
                        barWidth: 1,
                        centered: true
                    }
                }
                , {
                    data: bars_operation_top_green, markers: {
                        show: true,           // => setting to true will show markers, false will hide
                        lineWidth: 1,          // => line width of the rectangle around the marker
                        color: '#12ff00',      // => text color
                        fill: false,           // => fill or not the marekers' rectangles
                        fillColor: "#FFFFFF",  // => fill color
                        fillOpacity: 0.4,      // => fill opacity
                        stroke: false,         // => draw the rectangle around the markers
                        position: 'cb',        // => the markers position (vertical align: b, m, t, horizontal align: l, c, r)
                        verticalMargin: 14,     // => the margin between the point and the text.
                        labelFormatter: function (o) {
                            return (o.x == null ? markerImg : (markers_profitability[o.x + Math.min(displayAmount, curKline) - curKline]) == null ? '' : markers_profitability[o.x + Math.min(displayAmount, curKline) - curKline]);
                        },
                        fontSize: 9,
                        stacked: false,        // => true if markers should be stacked
                        stackingType: 'b',     // => define staching behavior, (b- bars like, a - area like) (see Issue 125 for details)
                        horizontal: false      // => true if markers should be horizontal (For now only in a case on horizontal stacked bars, stacks should be calculated horizontaly)
                    }, mouse: {track: false}
                }
            ];
            var options1_background = {
                resolution: 1, shadowSize: 0,
                grid: {
                    color: 'rgba(49,110,169,.2)',
                    tickColor: "#500000",
                    outlineWidth: 2,
                    outline: 's',
                    verticalLines: false,
                    horizontalLines: false
                },
                xaxis: {
                    showLabels: false,
                    min: Math.max(0, curKline - displayAmount) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount),
                    max: Math.max(displayAmount, curKline) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount)
                },
                yaxis: {
                    showLabels: false,
                    noTicks: 5, tickFormatter: function (data) {
                        return '<div style="width: 42px;color: #ffffff;">' + eval(data).toFixed(2) + '</div>'
                    }, min: minPrice, max: maxPrice
                }
            };
            var o_background = Flotr._.extend(Flotr._.clone(options1_background), opts || {});
            return Flotr.draw(canvas1_background, datas1_background, o_background);
        }

        canvasTop = drawcanvasTop();

        function drawcanvasTop(opts) {
            $("#canvas1 canvas").remove();
            onTracking = false;

            //刷新行情-K线
            var datas1 = [
                {
                    data: candles_keyLine_slice,
                    candles: {
                        show: true,
                        verticalLines: false,
                        candleWidth: 0.73,
                        lineWidth: 2,
                        wickLineWidth: 2,
                        upFillColor: '#00CCFF',
                        downFillColor: '#ff1212',
                        fillOpacity: 1
                    }
                }
                , {data: lines_ma5_slice, lines: {color: "#FFFF00", lineWidth: 1.5}}
                , {data: lines_ma10_slice, lines: {color: "#FF00FF", lineWidth: 1.5}}
                , {data: lines_ma20_slice, lines: {color: "#00FF00", lineWidth: 1.5}}
            ];
            var options1 = {
                resolution: 1, shadowSize: 0,
                grid: {
                    color: '#316EA9',
                    tickColor: "#500000",
                    outlineWidth: 2,
                    outline: 'w',
                    verticalLines: false,
                    horizontalLines: false
                },
                xaxis: {
                    showLabels: false,
                    min: Math.max(0, curKline - displayAmount) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount),
                    max: Math.max(displayAmount, curKline) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount)
                },
                yaxis: {
                    showLabels: false,
                    noTicks: 5, tickFormatter: function (data) {
                        return '<div style="width: 42px;color: #ffffff;">' + eval(data).toFixed(2) + '</div>'
                    }, min: minPrice, max: maxPrice
                },
                crosshair: {
                    mode: 'x',            // => one of null, 'x', 'y' or 'xy'
                    color: 'yellow',      // => crosshair color
                    hideCursor: false       // => hide the cursor when the crosshair is shown
                },
                mouse: {
                    track: true,          // => true to track the mouse, no tracking otherwise
                    trackAll: true,
                    position: 's',        // => position of the value box (default south-east).  False disables.
                    relative: false,       // => next to the mouse cursor
                    trackFormatter: function (obj) {
//                        alert(obj.index)
                        mouseIndex = obj.index;
                        if (!onTracking) return;
                        else {
//                            if(isZoomIn) return '';
                            var temp = (track_riserates[Math.max(0, curKline - displayAmount) + obj.index][1] * 100).toFixed(2);
                            if (mouseIndex < 15) {
                                $(".flotr-mouse-value").addClass("flotr-mouse-value-right").removeClass("flotr-mouse-value-left");
                            }
                            if (mouseIndex > 15) {
                                $(".flotr-mouse-value").addClass("flotr-mouse-value-left").removeClass("flotr-mouse-value-right");
                            }
                            return ( '<div class="FS16 P8" style="text-align: left;">' +
                            '开盘：<div class="inline ' + (temp > 0 ? 'forestgreen' : 'red') + '">' + eval(candles_keyLine_slice[obj.index][4]).toFixed(2) + '</div><BR />' +
                            '收盘：<div class="inline ' + (temp > 0 ? 'red' : 'forestgreen') + '">' + eval(candles_keyLine_slice[obj.index][1]).toFixed(2) + '</div><BR />' +
                            '涨幅：<div class="inline ' + (temp > 0 ? 'red' : 'forestgreen') + '">' + temp + '%</div><BR />' +
                            '成交量：<div class="inline">' + (lines_vol_slice[obj.index][1] / 10000).toFixed(2) + '万</div><BR />' +
                            '换手率：<div class="inline">' + (track_exchangerates[Math.max(0, curKline - displayAmount) + obj.index][1] * 100).toFixed(2) + '%</div>' +
                            '</div>');

//                            Math.max(0,curKline-displayAmount)+obj.index;
                        }
                    }, // => formats the values in the value box
                    margin: 5,             // => margin in pixels of the valuebox
                    lineColor: 'rgba(255,255,255,0)',  // => line color of points that are drawn when mouse comes near a value of a series
                    trackDecimals: 1,      // => decimals for the track values
                    sensibility: 200,        // => the lower this number, the more precise you have to aim to show a value
                    trackY: true,          // => whether or not to track the mouse in the y axis
                    radius: 3,             // => radius of the track point
                    fillColor: null,       // => color to fill our select bar with only applies to bar and similar canvasTops (only bars for now)
                    fillOpacity: 0       // => opacity of the fill color, set to 1 for a solid fill, 0 hides the fill
                }
            };
            var o = Flotr._.extend(Flotr._.clone(options1), opts || {});
            return Flotr.draw(canvas1, datas1, o);
        }

        //注册一次性监听事件
        function doOnceRegister() {

            if (firstInit == false) return;
//            alert("reg")
            /* 定期取得“操作解锁所需时间” */
            setInterval(function () {
                if (curKline + 1 >= maxAmount + 1) {
                    waitingTime = 0;
                    $('#holding').hide();
                    $('#holding1').hide();
                    $('#watching').show();
                    $('#watching1').show();
                    $("#isWaitingSpan").html("&nbsp;" + waitingTime + "")
                }
                else if (waitingTime > 0) $("#isWaitingSpan").html("&nbsp;" + waitingTime + "");
                else if (waitingTime <= 0) {
                    if (isHolding) hold();
                    else wait();
                    waitingTime = 30;
                }
            }, 100);
            /* 定期取得“操作解锁所需时间” */

//            //改变窗口时重绘图形
            $(window).bind("resize", function () {
                resizeAll();
                $("#mainMiddle canvas").remove();
                setTimeout(function () {
                    drawcanvasTop();
                    drawcanvasTop_background();
                    drawcanvasBottom();
                }, 100);
            });
            $(window).bind("orientationchange", function () {
//                alert(window.orientation);
                setTimeout(function () {
                    window.scrollTo(0, 1);
                }, 0);
            });

            //双击区域时进行缩放
            //Flotr.EventAdapter.observe(canvas1, 'flotr:click', function () {
            //    if (actionBaned) return;
            //    //模拟双击事件（最大间隔500ms）
            //    if (dblclickTimout <= 0) {
            //        dblclickTimout = 600;
            //        var dblclickInterval = setInterval(function () {
            //            dblclickTimout -= 100;
            //            $("#dbl").html(dblclickTimout)
            //            if (dblclickTimout <= 0) {
            //                clearInterval(dblclickInterval);
            //                setTimeout(function () {
            //                    dblclickTimout = 0;
            //                }, 100);
            //            }
            //        }, 100);
            //    } else if (!isZoomIn) {
            //        dblclickTimout = 0;
            //        isZoomIn = true;
            //        onTracking = false;
            //
            //        //全屏化上部画布
            //        var windowHeight = $(window).height();
            //        var windowWidth = $(window).width();
            //        if ($(window).width() < $(window).height()) {
            //            windowHeight = $(window).width();
            //            windowWidth = $(window).height();
            //        }
            //        $("#mainMiddle").css("position", "absolute").css("left", "0").css("top", "2px");
            //        $("#canvasMain").height(windowHeight).width(windowWidth - 6).css("left", "0").css("top", "0");
            //        $("#canvas1").height(windowHeight * 0.7);
            //        $("#canvas1_background").height(windowHeight * 0.7);
            //        $("#canvas2").height(windowHeight * 0.3).css("top", "70%");
            //        $("#backgroundImage_zoomIn").show();
            //
            //        $("#mainMiddle canvas").remove();
            //        drawcanvasTop();
            //        drawcanvasTop_background();
            //        drawcanvasBottom();
            //
            //
            //    }
            //    else {
            //        dblclickTimout = 0;
            //        isZoomIn = false;
            //        $("#mainMiddle").css("position", "relative").css("left", "0").css("top", "2px");
            //        resizeAll();//重设DOM元素高度
            //
            //        $("#mainMiddle canvas").remove();
            //        drawcanvasTop();
            //        drawcanvasTop_background();
            //        drawcanvasBottom();
            //
            //    }
            //});

            //按下鼠标画布时显示跟踪，松开鼠标时隐藏跟踪
            Flotr.EventAdapter.observe(canvas1, 'flotr:mousedown', function (position) {
                if (actionBaned) return;
                onTracking = true;
            });
            Flotr.EventAdapter.observe(canvas1, 'flotr:mousemove', function (e, position) {
                if (actionBaned) return;
                if (onTracking) canvasTop.crosshair.drawCrosshair(position);
                else canvasTop.crosshair.clearCrosshair();
            });
            Flotr.EventAdapter.observe(canvas1, 'flotr:mouseup', function (position) {
                if (actionBaned) return;
                onTracking = false;
                if (browserType == 'mobile') {
                    if (!isZoomIn) drawcanvasTop();
                    else canvasTop.crosshair.clearCrosshair();
                }
                setTimeout(function () {
                    trackCurKline();
                    $("#canvas2 .flotr-overlay").each(function () {
                        $(this).attr("id", "canvas2-flotr-overlay");
                        var context = document.getElementById("canvas2-flotr-overlay").getContext("2d");
                        context.clearRect(0, 0, $(this).width(), $(this).height());
                    })
                }, 100);
            });
            Flotr.EventAdapter.observe(canvas2, 'flotr:mousemove', function (e, position) {
                if (actionBaned) return;
                onTracking = false;
            });
            Flotr.EventAdapter.observe(canvas2, 'flotr:click', function () {
                if (TAIType == "成交量") {
                    TAIType = "换手率";
                    $("#TAIType").html("换手率").css("color", "#FFFFFF");
                    lines_TAI_slice = lines_exchangerates_slice;
                    maxTAI = 0;
                    for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, track_exchangerates[i][1]);
                    if (maxTAI == 0.00001) maxTAI = 10000;
                    maxTAI = maxTAI * 1.2;
                    for (var i = 0; i < bars_operation_bottom_red.length; i++) {
                        if (bars_operation_bottom_red[i][1] != 0) bars_operation_bottom_red[i][1] = maxTAI * 0.99;
                    }
                    for (var i = 0; i < bars_operation_bottom_green.length; i++) {
                        if (bars_operation_bottom_green[i][1] != 0) bars_operation_bottom_green[i][1] = maxTAI * 0.99;
                    }
                }
                else if (TAIType == "换手率") {
                    TAIType = "成交量";
                    $("#TAIType").html("成交量").css("color", "#FFFF00");
                    lines_TAI_slice = lines_vol_slice;
                    maxTAI = 0;
                    for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, lines_vol[i][1]);
                    if (maxTAI == 0.00001) maxTAI = 10000;
                    maxTAI = maxTAI * 1.2;
                    for (var i = 0; i < bars_operation_bottom_red.length; i++) {
                        if (bars_operation_bottom_red[i][1] != 0) bars_operation_bottom_red[i][1] = maxTAI * 0.99;
                    }
                    for (var i = 0; i < bars_operation_bottom_green.length; i++) {
                        if (bars_operation_bottom_green[i][1] != 0) bars_operation_bottom_green[i][1] = maxTAI * 0.99;
                    }
                }
                $("#mainMiddle canvas").remove();
                drawcanvasTop();
                drawcanvasTop_background();
                drawcanvasBottom();
            });
            $("#ay_btn").bind("click", function () {
                if (TAIType == "成交量") {
                    TAIType = "换手率";
                    $("#TAIType").html("换手率").css("color", "#FFFFFF");
                    lines_TAI_slice = lines_exchangerates_slice;
                    maxTAI = 0;
                    for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, track_exchangerates[i][1]);
                    if (maxTAI == 0.00001) maxTAI = 10000;
                    maxTAI = maxTAI * 1.2;
                    for (var i = 0; i < bars_operation_bottom_red.length; i++) {
                        if (bars_operation_bottom_red[i][1] != 0) bars_operation_bottom_red[i][1] = maxTAI * 0.99;
                    }
                    for (var i = 0; i < bars_operation_bottom_green.length; i++) {
                        if (bars_operation_bottom_green[i][1] != 0) bars_operation_bottom_green[i][1] = maxTAI * 0.99;
                    }
                }
                else if (TAIType == "换手率") {
                    TAIType = "成交量";
                    $("#TAIType").html("成交量").css("color", "#FFFF00");
                    lines_TAI_slice = lines_vol_slice;
                    maxTAI = 0;
                    for (var i = 0; i < curKline; i++) maxTAI = Math.max(maxTAI, lines_vol[i][1]);
                    if (maxTAI == 0.00001) maxTAI = 10000;
                    maxTAI = maxTAI * 1.2;
                    for (var i = 0; i < bars_operation_bottom_red.length; i++) {
                        if (bars_operation_bottom_red[i][1] != 0) bars_operation_bottom_red[i][1] = maxTAI * 0.99;
                    }
                    for (var i = 0; i < bars_operation_bottom_green.length; i++) {
                        if (bars_operation_bottom_green[i][1] != 0) bars_operation_bottom_green[i][1] = maxTAI * 0.99;
                    }
                }
                $("#mainMiddle canvas").remove();
                drawcanvasTop();
                drawcanvasTop_background();
                drawcanvasBottom();
            });
        }

        canvasBottom = drawcanvasBottom();

        function drawcanvasBottom(opts) {
            $("#canvas2 canvas").remove();

            //刷新行情-成交金额
            var datas2 = [
                {
                    data: bars_operation_bottom_red, bars: {
                    fillColor: "#AA2222",
                    lineWidth: 0,
                    fillOpacity: 0.45,
                    show: true,
                    shadowSize: 0,
                    barWidth: 1,
                    centered: true
                }
                }
                , {
                    data: bars_operation_bottom_green, bars: {
                        fillColor: "darkgreen",
                        lineWidth: 0,
                        fillOpacity: 0.45,
                        show: true,
                        shadowSize: 0,
                        barWidth: 1,
                        centered: true
                    }
                }
                , {
                    data: lines_TAI_slice,
                    color: TAIType == '成交量' ? "gold" : TAIType == '换手率' ? "white" : null,
                    lines: {
                        show: true,           // => setting to true will show lines, false will hide
                        lineWidth: 1,         // => line width in pixels
                        fill: true
                    }
                }
            ];
            var options2 = {
                grid: {
                    color: '#316EA9',
                    tickColor: "#316EA9",
                    outlineWidth: 2,
                    outline: 'w',
                    verticalLines: false,
                    horizontalLines: false
                },
                xaxis: {
                    showLabels: false,
                    min: Math.max(0, curKline - displayAmount) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount),
                    max: Math.max(displayAmount, curKline) * 1.0027 - 0.081 * ( Math.max(displayAmount + 160, curKline + 160) / displayAmount)
                },
                yaxis: {
                    showLabels: false,
                    noTicks: 3, tickFormatter: function (data) {
                        return "<div style='width: 42px;color: #ffffff;'>" + "&nbsp;" + "</div>"
                    }, min: maxTAI / 70, max: maxTAI
                },
                crosshair: {
                    mode: 'x',            // => one of null, 'x', 'y' or 'xy'
                    color: 'yellow',      // => crosshair color
                    hideCursor: false       // => hide the cursor when the crosshair is shown
                },
                shadowSize: 0
            };
            var o = Flotr._.extend(Flotr._.clone(options2), opts || {});
            return Flotr.draw(canvas2, datas2, o);
        }

        doOnceRegister();

        clearInterval(flashInterval);
        flashInterval = setInterval(function () {
            flashTime -= 300;
            if (flashTime <= 0) {
                clearInterval(flashInterval);
                actionBaned = false;
            }
//            $("#mainMiddle canvas").remove();
            drawcanvasTop();
        }, 200);


        $("#communionDiv_float").hide();
        $("#communion").hide();
        $("#canvas2 canvas").hide();
        drawcanvasBottom();
        setTimeout(function () {
            $("#canvas1 canvas").css("z-index", "-1");
            //$("#canvas1 canvas").hide();
        }, 800);
    })(document.getElementById("canvas1_background"), document.getElementById("canvas1"), (document.getElementById("canvas2")));
    $("#zoomoutBtn").css("opacity", "0");
    trackCurKline();
//    $("#canvas1").find("canvas").each(function() { alert(111) })
    return true;
}
// 提交标记
var hasSubmit = false;
//跟踪最后一根K线数据
function trackCurKline() {
    var temp = "--";
    if (!!candles_keyLine_slice[Math.min(displayAmount, curKline) - 1 - 1]) temp = ((eval(candles_keyLine_slice[Math.min(displayAmount, curKline) - 1][1]) / eval(candles_keyLine_slice[Math.min(displayAmount, curKline) - 1 - 1][1]) - 1) * 100).toFixed(2);
    $('#openPrice').html('<span class="' + (temp > 0 ? 'forestgreen' : 'red') + '">' + eval(candles_keyLine_slice[Math.min(displayAmount, curKline) - 1][4]).toFixed(2) + '</span>');
    $('#closePrice').html('<span class="' + (temp > 0 ? 'red' : 'forestgreen') + '">' + eval(candles_keyLine_slice[Math.min(displayAmount, curKline) - 1][1]).toFixed(2) + '</span>');
    $('#riseRate').html('<span class="' + (temp > 0 ? 'red' : 'forestgreen') + '">' + temp + '%</span>');
    $('#volume').html(((lines_vol_slice[Math.min(displayAmount, curKline) - 1][1]) / 10000).toFixed(2) + '万');
//                        $('#MA5').html(eval(lines_ma5_slice[displayAmount-1][1]).toFixed(2)+'');
//                        $('#MA10').html(eval(lines_ma10_slice[displayAmount-1][1]).toFixed(2)+'');
//                        $('#MA20').html(eval(lines_ma20_slice[displayAmount-1][1]).toFixed(2)+'');
//    alert([Math.min(displayAmount, curKline)-1])
    $("#turnoverRate").html((track_exchangerates[curKline - 1][1] * 100).toFixed(2) + '%');
    $('#KLineSpan').html((curKline) + '/' + maxAmount);

    if (curKline == maxAmount && candles_keyLine.length > 0 && !hasSubmit) {
        // TODO 提交数据 战绩数据
        var params = {
            userid: userInfo['f_id'],
            openid: userInfo['f_openid'],
            jycs: optTimes,
            sl: (wintimes * 100 / (optTimes/2)).toFixed(2),
            syl: profitability_total.toFixed(2),
            stockcode: stockInfo['code'],
            stockname: !stockInfo['name'] ? '' : stockInfo['name'],
            startday: !stockInfo['startday'] ? '' : stockInfo['startday'],
            totalcount: maxAmount/*,
             startday:stockInfo['code'],
             endday:stockInfo['code']*/
        };
        console.log(params);
        myESBAjax('user.RecordKLineHistry',params,function(data){
            hasSubmit = true;
            console.log(data);
        });
    }
}

/* 买入、卖出、观望、持有操作 */
function buy() {
    if (curKline + 1 < maxAmount + 1) {
        try {
            playSounds('buy', 100);
        } catch (e) {
            console.log(e);
        }
        isHolding = true;
        $('#holding').show();
        $('#holding1').show();
        $('#watching').hide();
        $('#watching1').hide();
        $('#hold_btn_activation').show();
        autoOperate(30);
        //重置上下画布比例
//        resizeAll();//重设DOM元素高度
        optTimes++;
        toNextKline();
        communion("buy");
    } else if (candles_keyLine.length < 1) {
        communion_float("正在努力加载数据...");
    } else {
        communion_float("已经是最后一根K线了，<a href='#' onclick='changeKlineData();'>换只股票</a>吧？");

    }

}
function sell() {
//    communion();
    if (curKline + 1 < maxAmount + 1) {
        try {
            playSounds('sell', 100);
        } catch (e) {
            console.log(e);
        }
        isHolding = false;
        $('#holding').hide();
        $('#holding1').hide();
        $('#watching').show();
        $('#watching1').show();
        $("#hold_btn_activation").hide();
        autoOperate(30);
        optTimes++;
        if (profitability > 0) {
            wintimes++;
        }
        toNextKline();
        communion("sell");
    } else if (candles_keyLine.length < 1) {
        communion_float("正在努力加载数据...");
    } else {

        communion_float("已经是最后一根K线了，<a href='#' onclick='changeKlineData();'>换只股票</a>吧？");
    }
}
function wait() {
    if (curKline + 1 < maxAmount + 1) {
        autoOperate(30);

        toNextKline();
        communion("wait");
    } else if (candles_keyLine.length < 1) {
        communion_float("正在努力加载数据...");
    } else {
        communion_float("已经是最后一根K线了，<a href='#' onclick='changeKlineData();'>换只股票</a>吧？");
    }
}
function hold() {
    if (curKline + 1 == maxAmount) {
        if (isHolding) optTimes++;
        isHolding = false;
        $('#optTimesSpan').html("交易次数：" + optTimes + "次");
    }
    if (curKline + 1 < maxAmount + 1) {
        try {
            playSounds('hold', 100);
        } catch (e) {
            console.log(e);
        }
        autoOperate(30);

        toNextKline();
        communion("hold");
    } else if (candles_keyLine.length < 1) {
        communion_float("正在努力加载数据...");
    } else {
        communion_float("已经是最后一根K线了，<a href='#' onclick='changeKlineData();'>换只股票</a>吧？");
    }
}
/* 买入、卖出、观望、持有操作 */

//等待
function autoOperate(ms) {
    clearInterval(interval);
    waitingTime = ms//等待秒
    interval = setInterval(function () {
        waitingTime--;
    }, 1000);
}

function welcome() {
    if (1) communion_float("欢迎来到K线大师！锻炼盘感还可赢取大奖哦。");
    else if (0) communion_float("好久不见，这次定是有备而来！");
    else if (0) communion_float("几天不见，这次有信心冲击大奖了吗？");
    else if (0) communion_float("欢迎回来，快看看今天盘感如何？");
}

/* 交互提示的逻辑和显示方法 */
function communion(text) {
    if (text == 'wait') {
        if (0) showCommunion("出现5日和10日金叉，买入说不定能赚？");
        else if (0) showCommunion("出现5日和10日死叉，保守起见还是再观望一下吧。");
        else if (0) showCommunion("出现5日和20日金叉，买入说不定能赚？");
        else if (0) showCommunion("出现5日和20日死叉，保守起见还是再观望一下吧。");
        else if (candles_keyLine[curKline - 1][1] > candles_keyLine[curKline - 1][6]) showCommunion("涨过了10日均线，可能还有上涨空间。");
        else if (candles_keyLine[curKline - 1][1] < candles_keyLine[curKline - 1][6]) showCommunion("跌破了10日均线，或许还有下跌趋势。");
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] > 0.06) showCommunion("哎呀，错过了一次追涨的好机会！");
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) showCommunion("太悬了！想不到会有这样一次大跳水！");
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] > 0.06) showCommunion("可惜，没有抓住一次逆市大反弹！");
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) showCommunion("还好没有在这种逆市买入。");
        else if (riseCombo == 5) showCommunion("连涨5天，涨势平稳。");
        else if (fallCombo == 5) showCommunion("连跌5天，跌势难改。");
        else if (track_riserates[curKline - 1][1] > 0.06) showCommunion("可惜啊，错过了一次绝好的买入机会！");
        else if (track_riserates[curKline - 1][1] < -0.06) showCommunion("好险！刚才要是买了可就亏大了！");
    }
    else if (text == 'buy') {
        if (0) showCommunion("出现5日和10日金叉，买入说不定能赚？");
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] >= 0.06) {
            playSounds('largeRise', 100);
            showCommunion("逆市而为却大获丰收，胆识过人呐！");
        }
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] >= 0.06) {
            playSounds('largeRise', 100);
            showCommunion("风格稳健，顺势而动，果然稳赚！");
        }
        else if (track_riserates[curKline - 1][1] >= 0.06) {
            playSounds('largeRise', 100);
            showCommunion("喔哦，大赚一笔，恭喜！");
        }
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] >= 0.03 && track_riserates[curKline - 1][1] < 0.06) showCommunion("逆市而为，小有收获，难得哦！");
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] >= 0.03 && track_riserates[curKline - 1][1] < 0.06) showCommunion("顺势而动，有收获哦！");
        else if (track_riserates[curKline - 1][1] >= 0.03 && track_riserates[curKline - 1][1] < 0.06) showCommunion("嘿嘿，小赚一点啦！");
//        else if( track_riserates[curKline-1][1]>=-0.03 && track_riserates[curKline-1][1]<0.03 ) showCommunion("形势还不明朗，再等等看？");
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] >= -0.06 && track_riserates[curKline - 1][1] < -0.03) showCommunion("逆市而为，受点小挫折没关系！");
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] >= -0.06 && track_riserates[curKline - 1][1] < -0.03) showCommunion("小小失误，不足挂齿。");
        else if (track_riserates[curKline - 1][1] >= -0.06 && track_riserates[curKline - 1][1] < -0.03) showCommunion("小亏一些，关系不大！");
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) {
            playSounds('largeFall', 100);
            showCommunion("别灰心，总有雨过天晴的时候！");
        }
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) {
            playSounds('largeFall', 100);
            showCommunion("踩了一颗地雷，下次小心！");
        }
        else if (track_riserates[curKline - 1][1] < -0.06) {
            playSounds('largeFall', 100);
            showCommunion("涨涨跌跌总是有，hold住！");
        }
    }
    else if (text == 'hold') {
        if (0) showCommunion("出现5日和10日金叉，继续持有也许能多赚一些？");
        else if (0) showCommunion("出现5日和10日死叉，保守起见可以见好就收。");
        else if (0) showCommunion("出现5日和20日金叉，继续持有也许能多赚一些？");
        else if (0) showCommunion("出现5日和20日死叉，保守起见可以见好就收。");
        else if (candles_keyLine[curKline - 1][1] > candles_keyLine[curKline - 1][6]) showCommunion("涨过了10日均线，可能还有上涨空间。");
        else if (candles_keyLine[curKline - 1][1] < candles_keyLine[curKline - 1][6]) showCommunion("跌破了10日均线，或许还有下跌趋势。");
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] > 0.06) {
            playSounds('largeRise', 100);
            showCommunion("恭喜恭喜，要不要顺势持有再赚一些？");
        }
        else if (riseCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) {
            playSounds('largeFall', 100);
            showCommunion("这次跳水亏了不少，也许意味着什么？");
        }
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] > 0.06) {
            playSounds('largeRise', 100);
            showCommunion("赚了一笔反弹，或许还有希望？");
        }
        else if (fallCombo >= 5 && track_riserates[curKline - 1][1] < -0.06) {
            playSounds('largeFall', 100);
            showCommunion("一跌再跌，该考虑要不要忍痛割肉了。");
        }
        else if (riseCombo == 5) showCommunion("连涨5天，涨势平稳。");
        else if (fallCombo == 5) showCommunion("连跌5天，跌势难改。");
        else if (track_riserates[curKline - 1][1] > 0.06 && profitability >= 0) {
            playSounds('largeRise', 100);
            showCommunion("涨势好旺啊，恭喜恭喜！");
        }
        else if (track_riserates[curKline - 1][1] > 0.06 && profitability < 0) {
            playSounds('largeRise', 100);
            showCommunion("赚回了一大笔，真不容易。");
        }
        else if (track_riserates[curKline - 1][1] < -0.06 && profitability >= 0) {
            playSounds('largeFall', 100);
            showCommunion("到手的鸭子飞了，真可惜。");
        }
        else if (track_riserates[curKline - 1][1] < -0.06 && profitability < 0) {
            playSounds('largeFall', 100);
            showCommunion("跌的有点凶，要小心了！");
        }
    }
    else if (text == 'sell') {
        if (profitability >= 20) showCommunion("简直赚翻了！太给力了！");
        else if (profitability >= 10) showCommunion("进账了好大一笔，恭喜恭喜！");
        else if (profitability >= 5) showCommunion("进账不少，相当不错。");
        else if (profitability >= 0) showCommunion("有进账，还行。");
        else if (profitability >= -5) showCommunion("慢慢来，别急。");
        else if (profitability >= -10) showCommunion("吃点小亏而已，下次赚回来。");
        else if (profitability >= -20) showCommunion("吃一次大亏，长一次智慧，加油！");
        else if (profitability < -20) showCommunion("忍痛止损，有成大事之气量。");
    }
}
function showCommunion(text) {
    if (text == null) return;
    $("#communion").html(text);
    $('#communionDiv,#communion').stop(true, true).clearQueue().fadeIn(0).clearQueue().delay(4200).fadeOut(800);
}
function communion_float(text) {
    showCommunion(text);
    //setTimeout(function () {
    //    $("#canvas1 canvas").css("z-index", "-1");
    //    //$("#canvas1 canvas").hide();
    //}, 500);
    //if (text == null) return;
    //$("#communionDiv_float").html(text);
    //$("#communionDiv_float").stop(true, true).clearQueue().fadeIn(0).clearQueue().delay(4200).fadeOut(800);
    //$("#communion_float").stop(true, true).clearQueue().fadeIn(0).clearQueue().delay(4200).fadeOut(800);
}
/* 交互提示的逻辑和显示方法 */

//重设DOM元素高度
function resizeAll() {
    var windowWidth = $(window).width();
    var windowHeight = $(window).height();
    var canvasHeight = windowHeight * 0.775 - 8;
    fontSize = $(".FS14").css("font-size");
//    alert(fontSize)
    if (browserType == 'mobile' || browserType == 'iPhone') {
        if ($(window).width() < $(window).height()) {
            windowHeight = $(window).width();
            windowWidth = $(window).height();
            canvasHeight = windowHeight * 0.775 - 8;
            //,#histryDiv
            $("#rotateDiv, #audioContainer").width($(window).height()).height($(window).width()).css("top", ($(window).height() - $(window).width()) / 2 + "px").css("right", -($(window).height() - $(window).width()) / 2 + "px").css("left", "auto").addClass("rotate90");
            $("#rise_btn_activation").width($(window).height()).height($(window).width());
        }
        else {
            windowHeight = $(window).height();
            windowWidth = $(window).width();
            canvasHeight = windowHeight * 0.775 - 8;
        //,#histryDiv
            $("#rotateDiv, #audioContainer").width($(window).width()).height($(window).height()).css("top", "0px").css("right", "auto").css("left", "0px").removeClass("rotate90");
            $("#rise_btn_activation").width($(window).width()).height($(window).height());
        }
        if (browserType == "iPhone") {
            windowHeight += 1;
        }
        $("body").height(windowHeight);
        //$(window).height(windowHeight);
        $('#backgroundImage, #backgroundImage_zoomIn').height(windowHeight);
        $('#backgroundImage, #backgroundImage_zoomIn').height(windowHeight);
        $("#MainTop").height(windowHeight * 0.13);
        $("#mainMiddle").css("position", "relative").css("left", "0").css("top", "2px");
        $("#canvasMain").height(canvasHeight).width("60.5%").css("position", "absolute").css("top", "0");//.css("left", "19.5%")
        $("#canvas1").height(canvasHeight * 0.7);
        $("#canvas1_background").height(canvasHeight * 0.7);
        $("#canvas2").height(canvasHeight * 0.3).css("top", "70%").css("position", "relative").css("z-index", "0");
        $("#mainBottom").height(windowHeight * 0.121);
        $("#backgroundImage_zoomIn").hide();
    } else {
        $("#MainTop").height(windowHeight * 0.13);
        $("#mainMiddle").css("position", "relative").css("left", "0").css("top", "2px");
        $("#canvasMain").height(canvasHeight).width("60.5%").css("position", "absolute").css("top", "0");//.css("left", "19.5%")
        $("#canvas1").height(canvasHeight * 0.7);
        $("#canvas1_background").height(canvasHeight * 0.7);
        $("#canvas2").height(canvasHeight * 0.3).css("top", "70%").css("position", "relative").css("z-index", "0");
        $("#mainBottom").height(windowHeight * 0.121);
        $("#backgroundImage_zoomIn").hide();
    }
    var ratoteInterval = setInterval(function () {
        if (audioCountLoaded!=999 && audioCountLoaded == audioCountAll && $("#loadingArea").css("display") == "none") {
            //$("#audioContainer").show();
            $("#loadingArea").css("display","none");
            clearInterval(ratoteInterval);
        }
    })
}

//退出游戏
function exit() {
    //communion("");
    //window.location = getbackList();
    closeNewBrowser();
}

function sharethis()
{
    var title = thisnickName + " 邀请您玩转K线大师";
    var desc = '培养K线盘感，提高投资直觉';
    var _content = "http://www.xinyusoft.com:8085/KLineMaster-wx/KLineGame.html";
    shareUrlToDialog(_content, title, desc, function(data){
        //alert(JSON.stringify(data));
    },function(){
        //alert("微信邀请好友失败，请重试");
        myAlert("微信分享失败");
    })
}

//分享到微信
function weixinfx()
{
    var title = thisnickName + " 邀请您玩转K线大师";
    var desc = '培养K线盘感，提高投资直觉';
    var _content = "http://www.xinyusoft.com:8085/KLineMaster-wx/KLineGame.html";
    shareUrlToDialog(_content, title, desc, function(data){
        //alert(JSON.stringify(data));
    },function(){
        //alert("微信邀请好友失败，请重试");
        myAlert("微信分享失败");
    })

}

//分享到朋友圈
function pyqfx()
{
    var title = thisnickName + " 邀请您玩转K线大师";
    var desc = '培养K线盘感，提高投资直觉';
    var _content = "http://www.xinyusoft.com:8085/KLineMaster-wx/KLineGame.html";
    shareUrlToFriend(_content, title, desc, function(data){
        //alert(JSON.stringify(data));
    },function(){
        //alert("微信邀请好友失败，请重试");
        myAlert("朋友圈分享失败");
    })

}

var fzintervalId;

//复制链接
function codefans()
{
    //var box=document.getElementById("plk2");
    document.getElementById("plk2").style.display="block";
    fzintervalId = setInterval("deletefz()", 2000);
    setClipBoard("http://www.xinyusoft.com:8085/KLineMaster-wx/KLineGame.html");
}

function deletefz()
{
    document.getElementById("plk2").style.display="none";
    if (fzintervalId != undefined)
    {
        clearInterval(fzintervalId);
    }
}

function erwmShow()
{
    //document.getElementById("ewmDivShow").style.display="block";
    //document.getElementById("bodyContainer").style.display="none";
    //var dzstr = "http://www.xinyusoft.com:8085/KLineMaster-wx/KLineGame.html";
    //$("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    //window.location = "wx_ewma.html";
    xinyuNewBrowser("kxds/wx_ewma.html");
}

function ewmBackto()
{
    document.getElementById("ewmDivShow").style.display="none";
    document.getElementById("bodyContainer").style.display="block";
    $("#ewmimg").html("");
}

function mainhide()
{
    //document.getElementById("mainDiv").style.display="none";
}

