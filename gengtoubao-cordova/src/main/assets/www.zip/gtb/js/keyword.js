// JavaScript Document
        (function (exports) {
           	 	var KeyBoard = function (input, options) {
                var body = document.getElementsByTagName('body')[0];
                var DIV_ID = options && options.divId || '__w_l_h_v_c_z_e_r_o_divid';
                $(input).css("background-color","#ebecee");
                if (document.getElementById(DIV_ID)) {
                    body.removeChild(document.getElementById(DIV_ID));
                }

                this.input = input;
                this.el = document.createElement('div');

                var self = this;
                var zIndex = options && options.zIndex || 1000;
                var width = options && options.width || '100%';
                var height = options && options.height || '193px';
                var fontSize = options && options.fontSize || '15px';
                var backgroundColor = options && options.backgroundColor || '#fff';
                var TABLE_ID = options && options.table_id || 'table_0909099';
                var mobile = typeof orientation !== 'undefined';
                    var onchangeMethod = options && options.onchangeMethod || null;

                this.el.id = DIV_ID;
                this.el.style.position = 'fixed';
                this.el.style.left = 0;
                this.el.style.right = 0;
                this.el.style.bottom = 0;
                this.el.style.zIndex = zIndex;
                this.el.style.width = width;
                this.el.style.height = height;
                this.el.style.backgroundColor = backgroundColor;

                //样式
                var cssStr = '<style type="text/css">';
                cssStr += '#' + TABLE_ID + '{text-align:center;width:100%;height:193px;border-top:1px solid #CECDCE;background-color:#FFF;}';
                cssStr += '#' + TABLE_ID + ' td{width:19%;border:1px solid #ddd;border-right:0;border-top:0; font-size:20px}';
                if (!mobile) {
                    cssStr += '#' + TABLE_ID + ' td:hover{/*background-color:#1E69E4;color:#000;*/}';
                }
                cssStr += '</style>';

                //Button
                var btnStr = '<div style="width:60px;height:28px;background-color:#1FB9FF;';
                btnStr += 'float:right;margin-right:5px;text-align:center;color:#fff;';
                btnStr += 'line-height:28px;border-radius:3px;margin-bottom:5px;cursor:pointer;">完成</div>';

                //table
                var tableStr = '<table id="' + TABLE_ID + '" border="0" cellspacing="0" cellpadding="0">';
                tableStr += '<tr><td>600</td><td>1</td><td>2</td><td>3</td><td del="true" id="qk" style="background:url(imges/jp-ch.png) no-repeat center center #D3D9DF; background-size:25px 16px;"></td></tr>';
                tableStr += '<tr><td>601</td><td>4</td><td>5</td><td>6</td><td>002</td></tr>';
                tableStr += '<tr><td>000</td><td>7</td><td>8</td><td>9</td><td>300</td></tr>';
                tableStr += '<tr><td style="background-color:#D3D9DF;">ABC</td><td>00</td><td>0</td>';
                tableStr += '<td style="background-color:#D3D9DF;" id="qk2">清空</td>';
                tableStr += '<td id="qd" style="background-color:#1E69E4; color:#fff"><div>确定</div></td></tr>';
                tableStr += '</table>';
				this.hide=function(){
					$("#" + DIV_ID).hide();
                    $(self.input).css("background-color", "#fff");
					
				};

                //+ btnStr
                this.el.innerHTML = cssStr + tableStr;
                function addEvent(e) {
                    var ev = e || window.event;
                    var clickEl = ev.element || ev.target;
                    var value = clickEl.textContent || clickEl.innerText;
                    if (typeof(value) !== "undefined" && value === "ABC") {
                        body.removeChild(self.el);
                        new KeyBoard1(self.input,{"onchangeMethod":onchangeMethod});
                    } else if (typeof(value) !== "undefined" && value === "清空") {
                       input.innerHTML ="";
                        if(onchangeMethod)
                        {
                            onchangeMethod(self.input.innerHTML);
							ev.stopPropagation();
							return false;
                        }
                    }
                    else if (clickEl.tagName.toLocaleLowerCase() === 'td' && clickEl.tagName.toLocaleLowerCase() !== "img" && typeof(value) !== "undefined") {
                        if (self.input) {
                            if (value != "确定") {
                                var falg = validateInputLength(value,input);

                                if (falg == false) {
                                    $(".cw").show();
                                    return falg;
                                }

                              	self.input.innerHTML += value;
                                if(onchangeMethod)
                                {
                                    onchangeMethod(self.input.innerHTML);
									ev.stopPropagation();
									return false;
                                }

                                $(input).css("background-color","#ebecee");
                            } else {
                                /*$("#" + DIV_ID).hide();*/
                                $(input).css("background-color", "#ebecee");
								ev.stopPropagation();
								return false;
                            }


                        }
                    } else if (clickEl.tagName.toLocaleLowerCase() === 'div' && value === "确定") {
                        //$("#" + DIV_ID).hide();
                        $(input).css("background-color","#ebecee");
						ev.stopPropagation();
						return false;
                    } else if (value == "" || typeof(value) == "undefined") {

                    }
                }

                if (mobile) {
                    this.el.ontouchstart = addEvent;
                } else {
                    this.el.onclick = addEvent;
                }
                body.appendChild(this.el);
				
                 $("#"+TABLE_ID+" td").bind("touchstart",function(){
          			
                    document.getElementById("Audio").play();
					document.getElementById("Audio").volume=0.2;
                    $(input).addClass("srkbj");
                    $(this).css("background-color", "#1E69E4");
                    $(this).css("color", "#fff");
                    if ($(this).attr("del")) {
                        var num = input.innerHTML;
                        if (num) {
                            var newNum = num.substr(0, num.length - 1);
                            input.innerHTML = newNum;
                            if(onchangeMethod)
                            	{
                                onchangeMethod(self.input.innerHTML);
								ev.stopPropagation();
								return false;
                            	}
                        	}
                    	}
                	});
					
					 $("#"+TABLE_ID+" td").bind("touchend", function () {
						$(this).css("background-color", "#FFF");
						$(this).css("color", "#000");

					});
					
					$("#qd").bind("touchend", function () {
							$("#" + DIV_ID).hide();
						});
						
					$("#qk").bind("touchend", function () {
						$(this).css("background-color", "#D3D9DF");
	
					});
					
					$("#qk2").bind("touchend", function () {
						$(this).css("background-color", "#D3D9DF");
	
					});
					
					$("#"+TABLE_ID+" td").bind("touchmove", function () {
						$(this).css("background-color", "#FFF");
                        $(this).css("color", "#000");
					});
					
					$("#"+TABLE_ID+" td").bind("touchcancel", function () {
						$(this).css("background-color", "#FFF");
						$(this).css("color", "#000");
					});
            	}
				
            exports.KeyBoard = KeyBoard;

        })(window);


        (function (exports) {
            var KeyBoard1 = function (input, options) {
                var body = document.getElementsByTagName('body')[0];
                var DIV_ID = options && options.divId || '__w_l_h_v_c_z_e_r_o_divid';
                $(input).css("background-color","#ebecee");
                if (document.getElementById(DIV_ID)) {
                    body.removeChild(document.getElementById(DIV_ID));
                }

                this.input = input;
                this.el = document.createElement('div');

                var self = this;
                var zIndex = options && options.zIndex || 1000;
                var width = options && options.width || '100%';
                var height = options && options.height || '193px';
                var fontSize = options && options.fontSize || '15px';
                var backgroundColor = options && options.backgroundColor || '#fff';
                var TABLE_ID = options && options.table_id || 'table_0909099';
                var mobile = typeof orientation !== 'undefined';
                var onchangeMethod = options && options.onchangeMethod || null;

                this.el.id = DIV_ID;
                this.el.style.position = 'fixed';
                this.el.style.left = 0;
                this.el.style.right = 0;
                this.el.style.bottom = 0;
                this.el.style.zIndex = zIndex;
                this.el.style.width = width;
                this.el.style.height = height;
                this.el.style.backgroundColor = backgroundColor;

                //样式
                var cssStr = '<style type="text/css">';
                cssStr += '#' + TABLE_ID + '{text-align:center;width:100%;height:193px;border-top:1px solid #CECDCE;background-color:#FFF;}';
                cssStr += '#' + TABLE_ID + ' td{width:12%;border:1px solid #ddd;border-right:0;border-top:0; font-size:20px}';
                if (!mobile) {
                    cssStr += '#' + TABLE_ID + ' td:hover{/*background-color:#1E69E4;color:#FFF;*/}';
                }
                cssStr += '</style>';

                //Button
                var btnStr = '<div style="width:60px;height:28px;background-color:#1FB9FF;';
                btnStr += 'float:right;margin-right:5px;text-align:center;color:#fff;';
                btnStr += 'line-height:28px;border-radius:3px;margin-bottom:5px;cursor:pointer;">完成//</div>';

                //table
                var tableStr = '<table id="' + TABLE_ID + '" border="0" cellspacing="0" cellpadding="0">';
                tableStr += '<tr><td style="background-color:#D3D9DF; font-size:15px" id="qk">清空</td><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td><td del="true" id="qk2" style="background:url(imges/jp-ch.png) no-repeat center center #D3D9DF; background-size:25px 16px;"></td></tr>';
                tableStr += '<tr><td>G</td><td>H</td><td>I</td><td>J</td><td>K</td><td>L</td><td>M</td><td>N</td></tr>';
                tableStr += '<tr><td>O</td><td>P</td><td>Q</td><td>R</td><td>S</td><td>T</td><td>U</td><td>V</td></tr>';
                tableStr += '<tr><td style="background-color:#D3D9DF;" colspan="2">123</td><td>W</td></td><td>X</td><td>Y</td><td>Z</td>';
                tableStr += '<td id="qd" style="background-color:#1E69E4; color:#fff;"colspan="2"><div>确定</div></td>';
                tableStr += ' </tr>';
                tableStr += '</table>';
				
				this.hide=function(){
					$("#" + DIV_ID).hide();
                    $(self.input).css("background-color", "#fff");
					
				};
                //+ btnStr
                this.el.innerHTML = cssStr + tableStr;

                function addEvent(e) {
                    var ev = e || window.event;
                    var clickEl = ev.element || ev.target;
                    var value = clickEl.textContent || clickEl.innerText;
                    if (typeof(value) !== "undefined" && value === "123") {
                        body.removeChild(self.el);
                        new KeyBoard(self.input,{"onchangeMethod":onchangeMethod});
                    } else if (typeof(value) !== "undefined" && value === "清空") {
                        input.innerHTML ="";
                        if(onchangeMethod)
                        {
                            onchangeMethod(self.input.innerHTML);
							ev.stopPropagation();
							return false;
                        }
                    }
                    else if (clickEl.tagName.toLocaleLowerCase() === 'td' && clickEl.tagName.toLocaleLowerCase() !== "img" && typeof(value) !== "undefined") {
                        if (self.input) {
                            if (value != "确定") {
                                var falg = validateInputLength(value,input);

                                if (falg == false) {
                                    $(".cw").show();
                                    return falg;
                                }

                               	 self.input.innerHTML += value;
                                if(onchangeMethod)
                                {
                                    onchangeMethod(self.input.innerHTML);
									ev.stopPropagation();
									return false;
                                }
                                $(input).css("background-color","#ebecee");
                            } else {
                                /*$("#" + DIV_ID).hide();*/
                                $(input).css("background-color", "#ebecee");
								ev.stopPropagation();
								return false;
                            }

                        }
                    } else if (clickEl.tagName.toLocaleLowerCase() === 'div' && value === "确定") {
                        //$("#" + DIV_ID).hide();
                        $(input).css("background-color","#ebecee");
						ev.stopPropagation();
						return false;

                    } else if (value == "" || typeof(value) == "undefined") {
                        var num = input.innerHTML ; 
                        if(num)
                        {
                            input.innerHTML= num.substr(0,num.length())
                        }
                    }
                }

                if (mobile) {
                    this.el.ontouchstart = addEvent;
                } else {
                    this.el.onclick = addEvent;
                }
                body.appendChild(this.el);
				
                $("#" + TABLE_ID + " td").bind("touchstart", function () {
                    document.getElementById("Audio").play();
					document.getElementById("Audio").volume=0.2;
                    $(input).addClass("srkbj");
                    $(this).css("background-color", "#1E69E4");
                    $(this).css("color", "#fff");
                    if ($(this).attr("del")) {
                        var num = input.innerHTML;
                        if (num) {
                            var newNum = num.substr(0, num.length - 1);
                            input.innerHTML = newNum;

                            if(onchangeMethod)
                            {
                                onchangeMethod(self.input.innerHTML);
								ev.stopPropagation();
								return false;
                            }

                        }
                    }
                });
				
				$("#" + TABLE_ID + " td").bind("touchend", function () {
					$(this).css("background-color", "#FFF");
					$(this).css("color", "#000");

				});
				$("#qd").bind("touchend", function () {
					$("#" + DIV_ID).hide();
				});
				
				$("#qk").bind("touchend", function () {
					$(this).css("background-color", "#D3D9DF");

				});
				
				$("#qk2").bind("touchend", function () {
					$(this).css("background-color", "#D3D9DF");

				});
				
				$("#" + TABLE_ID + " td").bind("touchmove", function () {
					$(this).css("background-color", "#FFF");
					$(this).css("color", "#000");
				});
				
				$("#" + TABLE_ID + " td").bind("touchcancel", function () {
					$(this).css("background-color", "#FFF");
					$(this).css("color", "#000");
				});

            }
            exports.KeyBoard1 = KeyBoard1;
        })(window);
        var validateInputLength = function(newValue,obj){
		var newLength = newValue.length;
        var length = obj.innerHTML.length;
		if(length + newLength > 12) return false;
		return true;
}
 
 