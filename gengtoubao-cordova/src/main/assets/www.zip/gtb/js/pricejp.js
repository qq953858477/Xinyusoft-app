// JavaScript Document
 
	(function(exports){
     var KeyBoard = function(input, options){
     var body = document.getElementsByTagName('body')[0];
     var DIV_ID = options && options.divId || '__w_l_h_v_c_z_e_r_o_divid';
     $(input).css("background-color","#ddd");
    if(document.getElementById(DIV_ID)){
      body.removeChild(document.getElementById(DIV_ID));
    }
     
    this.input = input;
    this.el = document.createElement('div');
     
    var self = this;
    var zIndex = options && options.zIndex || 1000;
    var width = options && options.width || '100%';
    var height = options && options.height || '193px';
    var fontSize = options && options.fontSize || '15px';
    var backgroundColor = options && options.backgroundColor || '#fff';
    var TABLE_ID = options && options.table_id || 'table_0909099';
    var mobile = typeof orientation !== 'undefined';
    	var onchangeMethod = options && options.onchangeMethod || null;
    this.el.id = DIV_ID;
    this.el.style.position = 'fixed';
    this.el.style.left = 0;
    this.el.style.right = 0;
    this.el.style.bottom = 0;
    this.el.style.zIndex = zIndex;
    this.el.style.width = width;
    this.el.style.height = height;
    this.el.style.backgroundColor = backgroundColor;
     
    //样式
    var cssStr = '<style type="text/css">';
    cssStr += '#' + TABLE_ID + '{text-align:center;width:100%;height:193px;border-top:1px solid #CECDCE;background-color:#FFF;}';
    cssStr += '#' + TABLE_ID + ' td{width:24.5%;border:1px solid #ddd;border-right:0;border-top:0; font-size:20px}';
    if(!mobile){
      cssStr += '#' + TABLE_ID + ' td:hover{/*background-color:#1E69E4;color:#FFF;*/}';
    }
    cssStr += '</style>';
     
    //Button
    var btnStr = '<div style="width:60px;height:28px;background-color:#1FB9FF;';
    btnStr += 'float:right;margin-right:5px;text-align:center;color:#fff;';
   //btnStr += 'line-height:28px;border-radius:3px;margin-bottom:5px;cursor:pointer;">完成</div>';
     
    //table
    var tableStr = '<table id="' + TABLE_ID + '" border="0" cellspacing="0" cellpadding="0">';
      tableStr += '<tr><td>1</td><td>2</td><td>3</td><td del="true" id="qk" style="background:url(imges/jp-ch.png) no-repeat center center #D3D9DF; background-size:25px 16px;"></td></tr>';
      tableStr += '<tr><td>4</td><td>5</td><td>6</td><td>00</td></tr>';
      tableStr += '<tr><td>7</td><td>8</td><td>9</td><td>000</td></tr>';
      tableStr += '<tr><td style="background-color:#D3D9DF;" id="qk2">清空</td><td>0</td>';
      tableStr += '<td>.</td><td style="background-color:#1E69E4; color:#fff"><div>确定</div></td></tr>';
      tableStr += '</table>';
	
	  //+ btnStr
    this.el.innerHTML = cssStr  + tableStr;
	
   
     
	 function addEvent(e){
      var ev = e || window.event;
      var clickEl = ev.element || ev.target;
      var value = clickEl.textContent || clickEl.innerText ;
       if(typeof(value) !== "undefined" && value === "清空"){
		 //body.removeChild(self.el);
		//input.innerHTML ="";
		//$("#text1").removeClass("srkbj");
		input.innerHTML ="";
		if(onchangeMethod)
		{
			onchangeMethod(self.input.innerHTML);
			ev.stopPropagation();
			return false;
		}
	  }else if(clickEl.tagName.toLocaleLowerCase() === 'td' && clickEl.tagName.toLocaleLowerCase() !== "img"&&  typeof(value) !== "undefined"){
        if(self.input){
			if(value!="确定"){
          		var falg = validateInputLength(value,input);
				
				if(falg==false){
					$(".cw").show();
					return falg;
				}

                //self.input.innerHTML += value;
				self.input.innerHTML += value;
				if(onchangeMethod)
				{
					onchangeMethod(self.input.innerHTML);
					ev.stopPropagation();
					return false;
				}
                $(input).css("background-color","#ddd");
			}else{
				//$("#"+DIV_ID).hide();
				$(input).css("background-color", "#fff");
				ev.stopPropagation();
				return false;
			}
        }
      }
	  else if(clickEl.tagName.toLocaleLowerCase() === 'div' && value === '确定'){
		  //$("#"+DIV_ID).hide();
           $(input).css("background-color","#fff");
			ev.stopPropagation();
			return false;
       }
	  else if(clickEl.tagName.toLocaleLowerCase() === 'td' && clickEl.tagName.toLocaleLowerCase() !== "img"&&  typeof(value) !== "undefined"){
           var num = input.innerHTML;
        if(num){
            input.innerHTML= num.substr(0,num.length());
        }
      }		
	  
    }
	
    if(mobile){
      this.el.ontouchstart = addEvent;
    }else{
      this.el.onclick = addEvent;
    }
    body.appendChild(this.el);
	 $("#"+TABLE_ID+" td").bind("touchstart",function(){
          
		  document.getElementById("Audio").play();
		  	 
		 $(input).addClass("srkbj");
		 $(this).css("background-color","#1E69E4");
		 $(this).css("color","#fff");
		 if ($(this).attr("del")) {
             var num = input.innerHTML;
        if(num){
            var newNum = num.substr(0, num.length - 1);
           input.innerHTML = newNum;
		   
		   if(onchangeMethod)
			{
			onchangeMethod(self.input.innerHTML);
			ev.stopPropagation();
			return false;
			}
        } 
		}
	 })
	 .bind("touchend",function(){
	 	$(this).css("background-color","#FFF");
		$(this).css("color","#000");
		 
	 })
	 $("#qk").bind("touchend",function(){
	 	$(this).css("background-color","#D3D9DF");
		 
	 })
	 $("#qk2").bind("touchend",function(){
	 	$(this).css("background-color","#D3D9DF");
		 
	 })
	 .bind("touchmove",function(){
	 	$(this).css("background-color","#fff");
		$(this).css("color","#fff");
	 })
	 .bind("touchcancel",function(){
	 	$(this).css("background-color","#FFF");
		$(this).css("color","#000");
	 });

  }
   
  exports.KeyBoard = KeyBoard;
 
})(window);

var validateInputLength = function(newValue,obj){
		var newLength = newValue.length;
        var length = obj.innerHTML.length;
		if(length + newLength > 12) return false;
		return true;
}
 
 