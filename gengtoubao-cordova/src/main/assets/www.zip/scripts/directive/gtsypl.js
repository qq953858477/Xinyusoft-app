function gtsypl()
{
	return {
		restrict: 'E',
		templateUrl: 'html/gt_sy_pl.html',
		//template: '<span>Hi there</span>',
		replace: true,
		transclude: true
	};
}
function gtsyplCtrl($scope, ajaxService, $cookieStore) {
    $scope.plListArray = [];
    $scope.plcontent = "";
    $scope.plingMark = true;//评论中
	$scope.plcontentstr = "";//当前在发送的评论内容
    $scope.length = $scope.plListArray.length;
	$scope.curLcsid = "";//当前产品的理财师id;
	$scope.lasttime = "20151101000000";//上一次显示的时间;
	var cHeight = $('body').height();//获取当前页面的高度
    $("#content").height(cHeight-147);//设置评论div的高度
    $scope.isFlower = false;
    $scope.imgSrc = "";
    //$scope.whichClick = "";//发送图片或者文字
	
    $scope.getplCallBack = function(_data)
    {
        //console.log("消息",_data);
        $scope.plListArray = [];
		$scope.voiceListArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.list;
            var length = arr.length;
            selectRead($scope.productid,$scope.userObj.f_id,length);
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.content = arr[i].f_cnt;
				var cnttype = arr[i].f_cnttype;//1：文字评论；2：花；3：语音
				if(!!cnttype)
				{
					obj.cnttype = cnttype;
					if(obj.cnttype == '2')
					{
						obj.content = "";
						obj.imgSrc = "images/sendflower.png";
					}
				}
				else
				{
					if(obj.content == "//flower//")
					{
						obj.content = "";
						//obj.isFlower = true;
						obj.cnttype = "2";
						obj.imgSrc = "images/sendflower.png";
					}
					else
					{
						obj.cnttype = "1";
					}
				}
				if(obj.cnttype == '3')
				{
					obj.lastmsgid = "chartid" + new Date().getTime() + arr[i].f_id;
					if(obj.cnttype == '3') {
						if (!!arr[i].f_voicetime) {
							obj.duration = arr[i].f_voicetime + "''";
						}
						else {
							obj.duration = "";
						}
					}
						//console.log("语音id", obj.lastmsgid);
				}
                //var t = arr[i].f_createtime.toString();
                //obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
                //obj.time = isshowTime(obj.t);
				obj.time = arr[i].spacetime;
				obj.id = arr[i].f_userid.toString();
				//if(obj.id == $scope.curLcsid){
				//	obj.ifLcs = true;
				//}else{
				//	obj.ifLcs = false;
				//}
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
				if($scope.curLcsid == obj.id)
				{
					obj.islcsself = true;
				}
				else
				{
					obj.islcsself = false;
				}
                $scope.plListArray.push(obj);
				if(obj.cnttype == '3')
				{
					$scope.voiceListArray.push(obj);
				}
                //$scope.$apply();
                $("#content").scrollTop($("#content")[0].scrollHeight);
            }
			//该条评论是否显示时间
            if($scope.plListArray.length>0)
			{
                $scope.plListArray.reverse();
				//for(var i=0;i<$scope.plListArray.length;i++){
				//	if(i==0){
				//		$scope.plListArray[i].isshow = true;
				//		$scope.lasttime = $scope.plListArray[i].t;
				//	}else{
				//		//alert("time1="+timeTrans($scope.plListArray[i].t)+"time2="+timeTrans($scope.lasttime));
				//		var timejump = parseInt(timeTrans($scope.plListArray[i].t)-timeTrans($scope.lasttime));
				//		//alert("timejump="+timejump);
				//		if(timejump>300000){
				//			$scope.plListArray[i].isshow = true;
				//			$scope.lasttime = $scope.plListArray[i].t;
				//		}else{
				//			$scope.plListArray[i].isshow = false;
				//		}
				//	}
				//	$("#content").scrollTop($("#content")[0].scrollHeight);
				//}
				//$("#content").scrollTop($("#content")[0].scrollHeight);
			}
			//该条记录的头像和姓名
            //if($scope.plListArray.length>0)
            //{
                //var arr2 = _data.userlist;
                //for(var k = 0;k<$scope.plListArray.length;k++)
                //{
                //    for(var j = 0; j<arr2.length;j++)
                //    {
                //        if(arr2[j].f_id.toString() == $scope.plListArray[k].id)
                //        {
                //            if(arr2[j].f_head != undefined && arr2[j].f_head != "")
                //            {
                //                $scope.plListArray[k].headurl = arr2[j].f_head;
                //            }
                //            else
                //            {
                //                $scope.plListArray[k].headurl = "images/wutouxian.png";
                //            }
                //            $scope.plListArray[k].name = arr2[j].f_nickname;
                //            break;
                //        }
                //    }
                //}
                //$("#content").scrollTop($("#content")[0].scrollHeight);
            //}
            $scope.plCount = $scope.plListArray.length;
            $scope.$apply();
            $("#content").scrollTop($("#content")[0].scrollHeight);
        }
    }
    
    $scope.check = function(){
    	$("#content").scrollTop($("#content")[0].scrollHeight);
    }
    setInterval($scope.check(),500);
    
    $scope.getpl = function()
    {
        var message = {};
        //message['contenttype'] = "text";
        //message['lastmsgid'] = 0;
        //message['msgamount'] = "";
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        message['page.pagesize'] = "max";
        message['page.pageno'] = "";

        //message['userid'] = $scope.userObj.f_id;

        //console.log("产品评论",message);
        ajaxService.sendMessage("user.getcommnetbysubjectidaction", message, $scope.getplCallBack);
    }


    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsypl")
        {
            $scope.getCurlcs();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsypl"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);
	
    //发送消息
    $scope.sendplClick = function(param)
    {
    	//$scope.whichClick = param;
        if($scope.plingMark)
        {
        	if(param == "notflower"){
        		if($scope.plcontent == "")
                {
                    myAlert("请输入评论内容");
                    return;
                }
        	}
            $scope.plingMark = false;
            var message = {};
            //message['contenttype'] = "text";
            if(param == "flower"){
            	//alert("flower");
            	message['cnt'] = "//flower//";
            }else{
            	message['cnt'] = $scope.plcontent;
            }
			$scope.plcontentstr = message['cnt'];
            //message['content'] = $scope.plcontent;
            message['subjectid'] = $scope.productid;
            message['subjecttype'] = "product";
			message['subjectuserid'] = $scope.curLcsid;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            //console.log("flower", message);
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendplCallBack);
        }
        else
        {
            myAlert("评论提交中，请稍候");
        }
    }

    $scope.sendplCallBack = function(_data)
    {
        //console.log("发送消息",_data)
        if(_data.op.code.toString() == "Y")
        {
            //myAlert("评论成功");
			if(checkisFlower($scope.plcontentstr) == true)//不是花等图标
			{
				$scope.plcontent = "";
			}
            $scope.getpl();
        }
        else
        {
            myAlert("评论发送失败");
        }
        $scope.plingMark = true;
		$scope.plcontentstr = "";
    }
	
	//点击评论关闭键盘
    function closePopClick (id){
    	if(id!="foot"){
    		document.getElementById("inputview").blur();
    	}
    };
	
	//获取当前产品理财师
	$scope.getCurlcs = function(){
		var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getCurlcsCallBack);
	}
		
	//获取理财师回调函数
	$scope.getCurlcsCallBack = function(_data){
		//console.log("获取产品理财师"+_data);
		if(_data.op.code.toString() == "Y")
        {
			$scope.curLcsid = _data.product.user.user.f_id;
			//alert(_data.product.user.user.f_id);
            $scope.getpl();
        }
        else
        {
        	//alert("error");
        }
	}

	//个人空间
	$scope.gotogrkj = function(_obj)
	{
		var localStorage = window.localStorage;
		localStorage.setItem("peopleID", _obj.id);
		//setbackList(window.location.href);
		//window.location.href="peopleSpaceBase.html";
		openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
	}

	//当前聊天音频点击
	$scope.plshowlistaudioClick = function(obj)
	{
		//有正在播放的录音暂停播放并回到开始
		var chartaudio = document.getElementById(obj.lastmsgid);
		var mark = false;
		for(var i=0;i<$scope.voiceListArray.length;i++)
		{
			try
			{
				var chartaudio2 = document.getElementById($scope.voiceListArray[i].lastmsgid);
				if(chartaudio2!=null)
				{
					if (!chartaudio2.paused)//播放中
					{
						chartaudio2.pause();// 暂停
						if(obj.lastmsgid != $scope.voiceListArray[i].lastmsgid)//不是同一个
						{
							chartaudio.play();
						}
						mark = true;
						break;
					}
				}
			}
			catch(e){
			}
		}
		if(mark == false)
		{
			chartaudio.play();
		}
	}

	//评论
	$scope.plClick = function()
	{
		$scope.mainShow = false;
		$scope.plInputShow = true;
	}

	//评论返回
	$scope.plinputbackto = function()
	{
		$scope.mainShow = true;
		$scope.plInputShow = false;
		$scope.getpl();
	}


	//时间处理
	function isshowTime(pretime)
	{
		//数据库中须处理的时间
		preyear = pretime.substring(0,4);
		premouth = pretime.substring(4,6)-1;
		preday = pretime.substring(6,8);
		prehour = pretime.substring(8,10);
		premin = pretime.substring(10,12);
		presec = pretime.substring(12,14);
		var predate = new Date(preyear,premouth,preday,prehour,premin,presec);
		//当前时间
		var nowtime = new Date();
		var curmouth = nowtime.getMonth();
		var curday = nowtime.getDate();
		var curyear = nowtime.getFullYear();
		var curhour = nowtime.getHours();
		var curmin = nowtime.getMinutes();
		var cursec = nowtime.getSeconds();
		
		if(preyear==curyear&&premouth==curmouth&&preday==curday){
			return prehour+":"+premin;
		}else
			if(preyear==curyear&&premouth==curmouth&&(curday-preday)==1){
				return "昨天"+" "+prehour+":"+premin;
			}else
				if((nowtime.getTime()-predate.getTime())-(7 * 24 * 3600 * 1000)<0){
					var day = predate.getDay();
					if(day == 0){
						return "星期天"+" "+prehour+":"+premin;
					}
					if(day == 1){
						return "星期一"+" "+prehour+":"+premin;
					}
					if(day == 2){
						return "星期二"+" "+prehour+":"+premin;
					}
					if(day == 3){
						return "星期三"+" "+prehour+":"+premin;
					}
					if(day == 4){
						return "星期四"+" "+prehour+":"+premin;
					}
					if(day == 5){
						return "星期五"+" "+prehour+":"+premin;
					}
					if(day == 6){
						return "星期六"+" "+prehour+":"+premin;
					}
				}else{
					return preyear+"年"+(premouth+1)+"月"+preday+"日"+" "+prehour+":"+premin;
				}
				
	}
	
	function timeTrans(t){
		//obj.time = t.substr(0,4) + "-" +  t.substr(4,2) + "-" +  t.substr(6,2) + " " + t.substr(8,2) + ":" + t.substr(10,2) + ":" + t.substr(12,2);
		var year = t.substr(0,4);
		var mouth = t.substr(4,2)-1;
		var day = t.substr(6,2);
		var hour = t.substr(8,2);
		var minute = t.substr(10,2);
		var second = t.substr(12,2);
		var tDate = new Date(year,mouth,day,hour,minute,second);
		return Number(tDate);
	}
	
	$scope.inputfocus = function(){
    	$("#content").scrollTop($("#content")[0].scrollHeight);
    }
    //失去焦点改变评论div样式
    $scope.inputblur = function(){
    	$("#content").scrollTop($("#content")[0].scrollHeight);
    }
    
  //插入用户读取记录
	function insertRead(productid,userid,readnum) {
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
					tx.executeSql(
							"INSERT INTO read (productid, userid, readnum) VALUES (?,?,?)",
							[productid,userid,readnum],function(tx,res){
								
							});
				});
	}
	//更新用户读取记录
	function updateRead(productid,userid,readnum){
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx){
					tx.executeSql(
					"UPDATE read SET readnum = "+readnum+" WHERE productid = "+productid+" and userid = "+userid,[],
					function(tx,res){
						
					});
		})
	}
	
	//查询用户读取记录
	function selectRead(productid,userid,readnum){
		var db = window.sqlitePlugin.openDatabase({
			name : "data\\hDB",
			bgType : 1
		});
		db.transaction(function(tx){
						tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
						tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
								function(tx,res){
									if(res.rows.length == 0){
										insertRead(productid,userid,readnum);
										//alert("INSERThasRead");
									}else{
										updateRead(productid,userid,readnum);
										//alert("UPDATEhasRead");
									}
								});
		})
	}
	
}
