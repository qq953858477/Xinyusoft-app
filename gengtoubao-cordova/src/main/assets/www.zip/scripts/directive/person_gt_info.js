function persongtinfo()
{
     return {
         restrict: 'E',
         templateUrl: 'html/person_gt_info.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function person_gt_infoCtrl($scope, ajaxService, $cookieStore)
{
    $scope.bgtuserid = "";
    $scope.bmzArray = [];//报名中
    $scope.spzArray = [];//实盘中
    $scope.jczArray = [];//解除中
    $scope.dqgtArray = [];//当前理财师的跟投数组，只显示实盘中且是跟投者的信息
    $scope.kgtbmList = [];//当前理财师可被跟投报名的产品
    $scope.lsfwlistArray = [];//历史服务

    $scope.p_selectrelativeproductsCallBack = function(_data)
    {
        console.log("当前跟投",_data);
        $scope.bmzArray = [];//报名中
        $scope.spzArray = [];//实盘中
        $scope.jczArray = [];//解除中
        if(_data.productlist.length>0)//自己的产品：发布中、被跟投中
        {
            var arr3 = _data.productlist;
            for(var i = 0;i<arr3.length;i++)
            {
                if(arr3[i].status.toString() == "A")//发布中
                {
                    var obj = {};
                    obj.status = "cp1";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.beginapplytime = arr3[i].beginapplytime;//多久前发布
                    obj.targetprofit = arr3[i].targetprofit;//目标收益
                    var str = arr3[i].endapplyday;
                    obj.jzrq = arr3[i].endapplyday;
                    obj.jzrqstr = arr3[i].endapplytimedesc.toString();
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期

                    $scope.bmzArray.push(obj);
                }
                if(arr3[i].status.toString() == "G")//延期中
                {
                    var obj = {};
                    obj.status = "cp4";
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.beginapplytime = arr3[i].beginapplytime;//多久前发布
                    obj.targetprofit = arr3[i].targetprofit;//目标收益
                    var str = arr3[i].endapplyday;
                    obj.jzrq = arr3[i].endapplyday;
                    obj.jzrqstr = arr3[i].endapplytimedesc.toString();
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期

                    $scope.bmzArray.push(obj);
                }
                if(arr3[i].status.toString() == "B")//被跟投中
                {
                    var obj = {};
                    obj.status = "cp2";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);//跟投金额
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);//报名截止日期
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    var str = arr3[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr3[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;
                    $scope.spzArray.push(obj);
                }
                else if(arr3[i].status.toString() == "D")//解除中
                {
                    var obj = {};
                    obj.status = "cp3";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.endgentoutime = arr3[i].endgentoutime + "解除";//多久前解除跟投
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    obj.mbsy = arr3[i].targetprofit;
                    $scope.jczArray.push(obj);
                }
            }

        }

        //if($scope.bmzArray.length>0 || $scope.spzArray.length>0 || $scope.jczArray.length >0)
        //{
        //    $scope.setgtfwisShow(true);
        //}
    }

    //当前跟投
    $scope.getdqgt = function()
    {
        console.log("理财师id", $scope.bgtuserid);
        var message = {};
        message['userid'] = $scope.bgtuserid;//理财师id
        console.log("理财师id", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_selectrelativeproducts", message, $scope.p_selectrelativeproductsCallBack);

    }


    //可被跟投报名产品
    $scope.kbgtbmcpCallBack = function(_data)
    {
        //console.log("可被跟投产品",_data);
        $scope.kgtbmList = [];
        if (_data.op.code.toString() == 'Y')
        {
            $scope.kgtbmList = _data.gentouproductlist;
        }

        //if($scope.kgtbmList.length>0)
        //{
        //    $scope.setgtfwisShow(true);
        //}
    }

    $scope.kbgtbmcp = function()
    {
        var message = {};
        message['userid'] = $scope.bgtuserid;
        message['page.size'] = "max";
        message['page.no'] = "";
        //console.log("542542543", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_selectcanapplyproductsbyuser", message, $scope.kbgtbmcpCallBack);
    }

    $scope.linkedhisgentouCallBack = function(_data)
    {
        console.log("历史被跟投", _data);
        $scope.lsfwlistArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.gentouproductlist;
            for(var i= 0;i<arr.length;i++)
            {
                var obj = {};
                obj.name = arr[i].user.user.f_nickname;//被跟投用户的信息（理财师）
                obj.headurl = arr[i].user.user.f_head;
                obj.bgtuserid = arr[i].user.user.f_id;
                obj.productid = arr[i].id;
                obj.productname = arr[i].name;
                obj.account = arr[i].account;
                obj.zq = arr[i].gentouperiod;//周期
                obj.bmrs = arr[i].gentoucount;//跟投人数
                obj.mbsy = arr[i].targetprofit;//目标收益
                var str = arr[i].actualendgentouday.toString();
                obj.endgentoudaystr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                if(arr[i].endgentoutime != undefined && arr[i].endgentoutime != '' && arr[i].endgentoutime != null)
                {
                    obj.endgentoutime = arr[i].endgentoutime + "结束";//什么时候结束
                }
                else
                {
                    obj.endgentoutime = "";
                }

                obj.ljsyl = parseFloat(arr[i].ljsy);
                obj.gtstatus = "1";//跟投其他人：0；被其他人跟投：1
                obj.xzzt = "1"; //界面显示效果
                //console.log("累计收益率：" + obj.ljsyl);
                $scope.lsfwlistArray.push(obj);
            }
        }
    }

    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.bgtuserid;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);
    }

    $scope.persongtinfoinit = function()
    {
        $scope.getdqgt();
        $scope.kbgtbmcp();
        $scope.getlsbgtList();
    }

    //理财师的可跟投的产品和可用看收益的产品
    $scope.gtlistItemClick = function(_obj)
    {
        //被跟投中，点击进入看收益
        //if($scope.opentype == "newwebview")
        //{
        //    setbackList("peopleSpaceBase.html?index=1&&opentype=newwebview");
        //}
        //else
        //{
        //    setbackList("peopleSpaceBase.html?index=1");
        //}
        setbackList(window.location.href);
        //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }
        else
        {
            window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //解除中
    $scope.gtjczlistItemClick = function(_obj)
    {
        //if($scope.opentype == "newwebview")
        //{
        //    setbackList("peopleSpaceBase.html?index=1&&opentype=newwebview");
        //}
        //else
        //{
        //    setbackList("peopleSpaceBase.html?index=1");
        //}
        setbackList(window.location.href);
        if(_obj.fbzuserid == $scope.userObj.f_id)//当前用户自己的服务
        {
            window.location = "gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }
        else
        {
            window.location = "gt_jcz_yk.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //可报名的
    $scope.gtbmItemClick = function(_obj)
    {
        //if($scope.opentype == "newwebview")
        //{
        //    setbackList("peopleSpaceBase.html?index=1&&opentype=newwebview");
        //}
        //else
        //{
        //    setbackList("peopleSpaceBase.html?index=1");
        //}
        setbackList(window.location.href);
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            window.location = "gt_yfb.html?productid=" + _obj.productid;
        }
        else
        {
            window.location = "gtapply.html?productid=" + _obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //理财师的历史跟投
    $scope.gtb_lsgtClick = function()
    {
        //console.log(window.location.href + "&&index=2");
        //if($scope.opentype == "newwebview")
        //{
        //    setbackList("peopleSpaceBase.html?index=1&&opentype=newwebview");
        //}
        //else
        //{
        //    setbackList("peopleSpaceBase.html?index=1");
        //}
        setbackList(window.location.href);
        //console.log(window.location.href + "&&index=2");
        if($scope.bgtuserid == $scope.userObj.f_id)
        {
            window.location = "gt_history.html?type=1";
        }
        else
        {
            window.location = "gt_lcs_history.html?lcsuserid=" + $scope.bgtuserid;
        }
    }

    //进入某个历史信息
    $scope.hisItemClick = function(_obj)
    {
        setbackList(window.location.href);
        if($scope.bgtuserid == $scope.userObj.f_id)
        {
            window.location = "gt_history_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }
        else
        {
            window.location = "gt_sy_history.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + $scope.bgtuserid;
        }
    }

    $scope.$on("setParameters", function(e, _data)
    {
        //console.log("caption132132", _data.caption);
        if(_data.caption == "persongtinfo")
        {
            $scope.bgtuserid = _data.personid;
            $scope.persongtinfoinit();
        }
    });
    //向父对象说明已经侦听，可以接受入参
    var cstr  = {"caption": "persongtinfo"};
    $scope.$emit("getParameters", cstr);


    //console.log("接受入参");

}
