function autohq()
{
     return function(scope, element, attr)
     {
        element.bind('keyup', function(event)
        {
            //alert("length:" + element.val().length);
            //if(element.val().length==6 || element.val().length==0)
            if(element.val().length==6)
            {
                //alert("keyup");
                //console.log("key");
                scope.queryhq(element.val());
            }
        });
         
         element.bind('keydown', function(event) {
            var k = event.keyCode;
            var value = element.val();
            if(isFunKey(k)) {
                return true;
            }
            if(isNaN(value + getChar(k))) {
                return false;
            }
            return true;
          
        });
         
       
     };
}

function changeprice()
{
     return function(scope, element, attr) {

        element.bind('change', function(event) {
           
            if(!isNaN(element.val()) && element.val().length!=0 )
            {
              scope.setZdkm(Number(element.val()));  
            } 
          
        });
         element.bind('keyup', function(event) {
          
            if(!isNaN(element.val())  && element.val().length!=0)
            {
              scope.setZdkm(Number(element.val()));  
            } 
          
        })
     };
}