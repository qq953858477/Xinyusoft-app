function gtplshow()
{
	return {
		restrict: 'E',
		templateUrl: 'html/gt_pl_show.html',
		//template: '<span>Hi there</span>',
		replace: true,
		transclude: true
	};
}
function gtplshowCtrl($scope, ajaxService, $cookieStore) {
    $scope.plListArray = [];
    $scope.plcontent = "";
    $scope.plingMark = true;//评论中
	$scope.plcontentstr = "";//当前在发送的评论内容
    $scope.length = $scope.plListArray.length;
	$scope.curLcsid = "";//当前产品的理财师id;
	$scope.lasttime = "20151101000000";//上一次显示的时间;
    //var cHeight = $('body').height();//获取当前页面的高度
    //$("#content").height(cHeight-147);//设置评论div的高度
    $scope.isFlower = false;
    $scope.imgSrc = "";
    //$scope.whichClick = "";//发送图片或者文字
    $scope.voiceListArray = [];
	
    $scope.getplCallBack = function(_data)
    {
        //console.log("消息",_data);
        $scope.plListArray = [];
        $scope.voiceListArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.list;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.content = arr[i].f_cnt;
                var cnttype = arr[i].f_cnttype;//1：文字评论；2：花；3：语音
                if(!!cnttype)
                {
                    obj.cnttype = cnttype;
                    if(obj.cnttype == '2')
                    {
                        obj.content = "";
                        obj.imgSrc = "images/sendflower.png";
                    }
                }
                else
                {
                    if(obj.content == "//flower//")
                    {
                        obj.content = "";
                        //obj.isFlower = true;
                        obj.cnttype = "2";
                        obj.imgSrc = "images/sendflower.png";
                    }
                    else
                    {
                        obj.cnttype = "1";
                    }
                }
                if(obj.cnttype == '3')
                {
                    obj.lastmsgid = "chartid" + new Date().getTime() + arr[i].f_id;
                    if(obj.cnttype == '3')
                    {
                        if(!!arr[i].f_voicetime)
                        {
                            obj.duration = arr[i].f_voicetime + "''";
                        }
                        else
                        {
                            obj.duration = "";
                        }

                    }
                    //console.log("语音id", obj.lastmsgid);
                }
                //var t = arr[i].f_createtime.toString();
                //obj.t = t.substr(0,4) + t.substr(5,2) + t.substr(8,2) + t.substr(11,2) +t.substr(14,2) + t.substr(17,2);
                //obj.time = isshowTime(obj.t);
				obj.time = arr[i].spacetime;
				obj.id = arr[i].f_userid.toString();
				//if(obj.id == $scope.curLcsid){
				//	obj.ifLcs = true;
				//}else{
				//	obj.ifLcs = false;
				//}
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
				if($scope.curLcsid == obj.id)
				{
					obj.islcsself = true;
				}
				else
				{
					obj.islcsself = false;
				}
                $scope.plListArray.push(obj);
                if(obj.cnttype == '3')
                {
                    $scope.voiceListArray.push(obj);
                }
                //$scope.$apply();
                //$("#content").scrollTop($("#content")[0].scrollHeight);
            }
            //if($scope.plListArray.length>0)
			//{
             //   $scope.plListArray.reverse();
			//}
            //$scope.plCount = $scope.plListArray.length;
            //$scope.$apply();
            //$("#content").scrollTop($("#content")[0].scrollHeight);
        }
    }
    
    //$scope.check = function(){
    //	$("#content").scrollTop($("#content")[0].scrollHeight);
    //}
    //setInterval($scope.check(),500);
    
    $scope.getpl = function()
    {
        var message = {};
        //message['contenttype'] = "text";
        //message['lastmsgid'] = 0;
        //message['msgamount'] = "";
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        message['page.pagesize'] = "max";
        message['page.pageno'] = "";

        //message['userid'] = $scope.userObj.f_id;

        //console.log("产品评论",message);
        ajaxService.sendMessage("user.getcommnetbysubjectidaction", message, $scope.getplCallBack);
    }

	//获取理财师回调函数
	$scope.getCurlcsCallBack = function(_data){
		//console.log("获取产品理财师"+_data);
		if(_data.op.code.toString() == "Y")
		{
			$scope.curLcsid = _data.product.user.user.f_id;
			//alert(_data.product.user.user.f_id);
			$scope.getpl();
		}
		else
		{
			//alert("error");
		}
	}

	//获取当前产品理财师
	$scope.getCurlcs = function(){
		var message = {};
		message['productid'] = $scope.productid;
		//console.log("产品信息",$scope.productid);
		ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getCurlcsCallBack);
	}

    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtplshow")
        {
            $scope.getCurlcs();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsypl"};
    $scope.$emit("getParameters", cstr);

	//个人空间
	$scope.gotogrkj = function(_obj)
	{
		var localStorage = window.localStorage;
		localStorage.setItem("peopleID", _obj.id);
		//setbackList(window.location.href);
		//window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
	}

    //当前聊天音频点击
    $scope.plshowlistaudioClick = function(obj)
    {
        //有正在播放的录音暂停播放并回到开始
        var chartaudio = document.getElementById(obj.lastmsgid);
        var mark = false;
        for(var i=0;i<$scope.voiceListArray.length;i++)
        {
            try
            {
                var chartaudio2 = document.getElementById($scope.voiceListArray[i].lastmsgid);
                if(chartaudio2!=null)
                {
                    if (!chartaudio2.paused)//播放中
                    {
                        chartaudio2.pause();// 暂停
                        if(obj.lastmsgid != $scope.voiceListArray[i].lastmsgid)//不是同一个
                        {
                            chartaudio.play();
                        }
                        mark = true;
                        break;
                    }
                }
            }
            catch(e){
            }
        }
        if(mark == false)
        {
            chartaudio.play();
        }
    }

}
