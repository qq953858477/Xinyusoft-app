function lcsinfo()
{
     return {
         restrict: 'E',
         templateUrl: 'html/lcs_info.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function lcs_infoCtrl($scope, ajaxService, $cookieStore)
{
    $scope.islcs = false;//是否是理财师
    $scope.lcsInformation = {};
    $scope.lcsInformation.lcshearurl = "";
    $scope.lcsInformation.lcsname = "--";
    $scope.lcsInformation.lcsid = "";
    $scope.lcsInformation.lcstzsc = "--";
    $scope.lcsInformation.lcstzln = "--";
    $scope.lcsInformation.lcsscly = "--";
    $scope.lcsstatus = "0";//0：未申请，且不是理财师或者申请不通过；1：申请中；2：申请通过，已是理财师
    $scope.bgtz = {};
    $scope.bgtz.hearurl = "";
    $scope.bgtz.name = "--";
    $scope.lcslsbgtAccount = "--";

    $scope.bmzArray = [];//报名中
    $scope.spzArray = [];//实盘中
    $scope.jczArray = [];//解除中
    $scope.dqgtArray = [];//当前理财师的跟投数组，只显示实盘中且是跟投者的信息
    $scope.kgtbmList = [];//当前理财师可被跟投报名的产品

    $scope.lcsdjArray = [];//理财师等级图片数组
    $scope.lcspj = "0";//理财师评级
    $scope.bgtAccount = "--";//理财包个数

    $scope.p_selectrelativeproductsCallBack = function(_data)
    {
        console.log("当前跟投",_data);
        $scope.bmzArray = [];//报名中
        $scope.spzArray = [];//实盘中
        $scope.jczArray = [];//解除中
        if(_data.productlist.length>0)//自己的产品：发布中、被跟投中
        {
            var arr3 = _data.productlist;
            for(var i = 0;i<arr3.length;i++)
            {
                if(arr3[i].status.toString() == "A")//发布中
                {
                    var obj = {};
                    obj.status = "cp1";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.bmrs = arr3[i].applycount;//报名人数
                    obj.beginapplytime = arr3[i].beginapplytime;//多久前发布
                    obj.targetprofit = arr3[i].targetprofit;//目标收益
                    var str = arr3[i].endapplyday;
                    obj.jzrq = arr3[i].endapplyday;
                    obj.jzrqstr = arr3[i].endapplytimedesc.toString();
                    //obj.jzrq = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期

                    $scope.bmzArray.push(obj);
                }
                if(arr3[i].status.toString() == "B")//被跟投中
                {
                    var obj = {};
                    obj.status = "cp2";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);//跟投金额
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);//报名截止日期
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    var str = arr3[i].gentouday.toString();
                    //obj.gentouday = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);
                    obj.gentouday = str;
                    var str2 = arr3[i].endgentouday.toString();
                    //obj.endgentouday = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);
                    obj.endgentouday = str2;
                    $scope.spzArray.push(obj);
                }
                else if(arr3[i].status.toString() == "D")//解除中
                {
                    var obj = {};
                    obj.status = "cp3";
                    obj.account = arr3[i].account;//当前被跟投的账户
                    var bgtuser = arr3[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr3[i].name;
                    obj.productid = arr3[i].id;
                    obj.zq = arr3[i].gentouperiod;//周期
                    obj.endgentoutime = arr3[i].endgentoutime + "解除";//多久前解除跟投
                    obj.gentoucount = arr3[i].gentoucount;
                    //obj.drsyl = (parseFloat(arr3[i].jrsy)*100).toFixed(2);
                    //obj.ljsyl = (parseFloat(arr3[i].ljsy)*100).toFixed(2);
                    obj.drsyl = parseFloat(arr3[i].jrsy);
                    obj.ljsyl = parseFloat(arr3[i].ljsy);
                    obj.mbsy = arr3[i].targetprofit;
                    $scope.jczArray.push(obj);
                }
            }

        }

    }

    //当前跟投
    $scope.getdqgt = function()
    {
        //console.log("1")
        //$scope.dqgtArray = [];
        //var obj = {};
        //obj.status = "0";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";//发布者信息
        //obj.username = "黄磊";
        //obj.productname = "招财一号";
        //obj.productid = "cpid";//产品id
        //obj.zq = "三个月";//周期
        //obj.bmrs = "8";//报名人数
        //obj.jzrq = "2015-09-03";//报名截止日期
        //
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "0";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "黄磊";
        //obj.productname = "招财二号";
        //obj.productid = "cpid2";//产品id
        //obj.zq = "三个月";//周期
        //obj.bmrs = "10";//报名人数
        //obj.jzrq = "2015-09-06";//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "1";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升";
        //obj.productid = "cpid3";//产品id
        //obj.zq = "半年";//周期
        //obj.gtje = 100000;//跟投金额
        //obj.jzrq = "2015-09-06";//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "2";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.account = "13143143";
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升2号";
        //obj.productid = "cpid4";//产品id
        //obj.zq = "一年";//周期
        //obj.drsyl = 10.12;//跟投金额
        //obj.ljsyl = 20.12;//报名截止日期
        //$scope.dqgtArray.push(obj);
        //
        //var obj = {};
        //obj.status = "3";//已发布：0； 已报名：1；跟投中(被跟投)：2；跟投中(跟投)：3
        //obj.hearurl = "images/touxiang.png";
        //obj.username = "沈成伟";
        //obj.productname = "日日升3号";
        //obj.productid = "cpid5";//产品id
        //obj.zq = "一年";//周期
        //obj.drsyl = 10.12;//跟投金额
        //obj.ljsyl = 20.12;//报名截止日期
        //$scope.dqgtArray.push(obj);

        //console.log($scope.dqgtArray.length);

        var message = {};
        message['userid'] = $scope.bgtuserid;//理财师id
        console.log("理财师id", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_selectrelativeproducts", message, $scope.p_selectrelativeproductsCallBack);

    }

    $scope.getuserCallBack = function(_data)
    {
        console.log("用户", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.bgtz = {};
            $scope.bgtz.hearurl = _data.user.f_head;
            $scope.bgtz.name = _data.user.f_nickname;
        }
    }

    $scope.getptyh = function()
    {
        var message = {};
        message['user.id'] = $scope.bgtuserid;//理财师id
        console.log("用户id", $scope.bgtuserid);
        ajaxService.sendMessage("user.getuser", message, $scope.getuserCallBack);
    }

    //理财师评级
    $scope.setlcspj = function()
    {
        $scope.lcsdjArray = [];
        if($scope.lcspj != null && $scope.lcspj != undefined && $scope.lcspj != "" && $scope.lcspj !="0" && $scope.lcspj !="0.0")
        {
            var pointindex = $scope.lcspj.indexOf(".",0);
            if(pointindex == -1 || (pointindex != -1 && $scope.lcspj.substr(pointindex+1,1)=="0"))//无小数点，整数，有小数点，小数点后为0
            {
                var num = parseFloat($scope.lcspj);
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                for(var i = num+1;i<6;i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star2.png";
                    $scope.lcsdjArray.push(obj);
                }
            }
            else//有小数点
            {
                var num = Math.floor(parseFloat($scope.lcspj));
                for(var i = 1;i< num+1; i++)
                {
                    var obj = {};
                    obj.value = i;
                    obj.djsrc = "images/star1.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num<5)
                {
                    var obj = {};
                    obj.value = $scope.lcsdjArray.length+1;
                    obj.djsrc = "images/star3.png";
                    $scope.lcsdjArray.push(obj);
                }
                if(num+1<5)
                {
                    for(var i = num+2;i<6;i++)
                    {
                        var obj = {};
                        obj.value = i;
                        obj.djsrc = "images/star2.png";
                        $scope.lcsdjArray.push(obj);
                    }
                }
            }
            //for(var i = 0;i<parseFloat($scope.lcspj);i++)
            //{
            //    var obj = {};
            //    obj.value = i;
            //    $scope.lcsdjArray.push(obj);
            //}
        }
        else
        {
            for(var i = 1;i<6;i++)
            {
                var obj = {};
                obj.value = i;
                obj.djsrc = "images/star2.png";
                $scope.lcsdjArray.push(obj);
            }
        }
    }

    $scope.getLastest3ProductAvgScoreActionCallBack = function(_data)
    {
        console.log("理财师评级",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.lcspj = _data.avg.toString();
            $scope.setlcspj();
        }
    }

    $scope.getlcspj = function()
    {
        //$scope.lcspj = _data.lcsapplyinfo.level;
        //
        //$scope.setlcspj();

        var message = {};
        message['userid'] = $scope.bgtuserid;//理财师id
        console.log("用户id", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.getLastest3ProductAvgScoreAction", message, $scope.getLastest3ProductAvgScoreActionCallBack);
    }

    $scope.p_getlcsapplyinfoCallBack = function(_data)
    {
        console.log("理财师",_data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.lcsapplyinfo.isexist.toString() == "true")
            {
                if (_data.lcsapplyinfo.status.toString() == "Y")
                {
                    $scope.islcs = true;
                    $scope.lcsInformation = {};
                    $scope.lcsInformation.lcshearurl = _data.lcsapplyinfo.user.user.f_head;
                    $scope.lcsInformation.lcsname = _data.lcsapplyinfo.user.user.f_nickname;
                    $scope.lcsInformation.lcsid = _data.lcsapplyinfo.userid;
                    //$scope.lcsInformation.lcstzsc = _data.lcsapplyinfo.tzsc + "年";
                    //$scope.lcsInformation.lcstzln = _data.lcsapplyinfo.tzln;
                    //$scope.lcsInformation.lcsscly = _data.lcsapplyinfo.scly;
                    $scope.getlcspj();
                }
                else
                {
                    $scope.islcs = false;
                }
            }
            else
            {
                $scope.islcs = false;
            }
        }
    }

    $scope.getlcs = function()
    {
        var message = {};
        message['userid'] = $scope.bgtuserid;
        console.log("理财师idididi",$scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo", message, $scope.p_getlcsapplyinfoCallBack);
    }

    //可被跟投报名产品
    $scope.kbgtbmcpCallBack = function(_data)
    {
        //console.log("可被跟投产品",_data);
        $scope.kgtbmList = [];
        if (_data.op.code.toString() == 'Y')
        {
            $scope.kgtbmList = _data.gentouproductlist;
        }
    }

    $scope.kbgtbmcp = function()
    {
        var message = {};
        message['userid'] = $scope.bgtuserid;
        message['page.size'] = "max";
        message['page.no'] = "";
        //console.log("542542543", $scope.bgtuserid);
        ajaxService.sendMessage("sunflower.p_selectcanapplyproductsbyuser", message, $scope.kbgtbmcpCallBack);
    }

    //判断当前被跟投对象是否是理财师
    $scope.checklcs = function()
    {
        console.log("checklcs")
        var message = {};
        message["userid"] = $scope.bgtuserid;
        ajaxService.sendMessage("sunflower.p_getlcsapplyinfo",message,function(_data)
        {
            console.log("checklcs理财师：" + _data);
            if (_data.op.code.toString() == "Y")
            {
                if(_data.lcsapplyinfo.isexist.toString() == "false")
                {
                    $scope.lcsstatus = "0";//0：未申请
                }
                else
                {
                    if(_data.lcsapplyinfo.status.toString() == "A")
                    {
                        $scope.lcsstatus = "1";//1：申请中
                    }
                    else if(_data.lcsapplyinfo.status.toString() == "Y")
                    {
                        $scope.lcsstatus = "2";//1：申请通过，已是理财师
                    }
                    else//N，申请未通过
                    {
                        $scope.lcsstatus = "0";//0：未申请
                    }
                }
                if($scope.lcsstatus == "2")
                {
                    $scope.getlcs();
                }
                else
                {
                    $scope.islcs = false;
                    $scope.getptyh();
                }
            }
        })
    }

    //理财师跟投包
    $scope.p_getgentoustatisticsCallBack = function(_data)
    {
        //console.log("累计数据：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.bgtAccount = _data.gentoustatistic.bgtcount + "单";//理财包个数
        }
    }

    $scope.getgtbInfo = function()
    {
        //console.log("累计");
        var message = {};
        message['userid'] = $scope.bgtuserid;
        ajaxService.sendMessage("gentou.p_getgentoustatistics", message, $scope.p_getgentoustatisticsCallBack);

    }

    $scope.linkedhisgentouCallBack = function(_data)
    {
        console.log("历史被跟投", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.op.code.toString() == "Y")
            {
                $scope.lcslsbgtAccount = _data.gentouproductlist.length;
            }
        }
    }

    //被其他人跟投
    $scope.getlsbgtList = function()
    {
        var message = {};
        message['userid'] =  $scope.bgtuserid;
        message['page.size'] =  "max";
        message['page.no'] =  "";
        ajaxService.sendMessage("sunflower.p_selecthisproduct", message, $scope.linkedhisgentouCallBack);
    }


    //$scope.$on("setParameters", function(e, _data) {
    //    if(_data.caption == "lcs_info")
    //    {

    //    }
    //});

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    //var cstr  = {"caption": "lcs_info"};
    //$scope.$emit("getParameters", cstr);

    $scope.init = function()
    {
        $scope.checklcs();
        $scope.getdqgt()
        $scope.kbgtbmcp();
        //理财包个数
        $scope.getgtbInfo();
        $scope.getlsbgtList();
    }

    $scope.init();

    //理财师的可跟投的产品和可用看收益的产品
    $scope.gtlistItemClick = function(_obj)
    {
        //被跟投中，点击进入看收益
        setbackList(window.location.href + "&&index=2");
        //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }
        else
        {
            window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //解除中
    $scope.gtjczlistItemClick = function(_obj)
    {
        setbackList(window.location.href + "&&index=2");
        if(_obj.fbzuserid == $scope.userObj.f_id)//当前用户自己的服务
        {
            window.location = "gt_jcz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
        }
        else
        {
            window.location = "gt_jcz_yk.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //可报名的
    $scope.gtbmItemClick = function(_obj)
    {
        setbackList(window.location.href + "&&index=2");

        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            window.location = "gt_yfb.html?productid=" + _obj.productid;
        }
        else
        {
            window.location = "gtapply.html?productid=" + _obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
        }
    }

    //理财师的历史跟投
    $scope.gtb_lsgtClick = function()
    {
        //console.log(window.location.href + "&&index=2");
        setbackList(window.location.href + "&&index=2");
        //console.log(window.location.href + "&&index=2");
        if($scope.bgtuserid == $scope.userObj.f_id)
        {
            window.location = "gt_history.html?type=1";
        }
        else
        {
            window.location = "gt_lcs_history.html?lcsuserid=" + $scope.bgtuserid;
        }
    }


}
