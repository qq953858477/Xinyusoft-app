function tradequery()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_query.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    };
}

function tradequeryCtrl($scope, ajaxService, $cookieStore) {
    $scope.zhmianShow = true;//主界面
    $scope.childaccount = "";
    $scope.childaccountStr = "";//显示用
    //侦听获取参数
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradequery获取参数", _data.account);
        $scope.childaccount = _data.account;
        $scope.childaccountStr = "***" + $scope.childaccount.substr($scope.childaccount.length-4);
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    var cstr  = {"caption": "tradequery"};
    $scope.$emit("getParameters", cstr);
    //console.log("交易查询账号", $scope.childaccount);
    //显示查询/交易
    $scope.urlChange = function(_str)
    {
        $scope.urlShow = true;
        $scope.zhmianShow = false;
        window.location.href = _str;
    }

    $scope.backtoParent = function()
    {
        $scope.urlShow = false;
        $scope.zhmianShow = true;
        window.location.href = "#/empty";
    }
    console.log("tradequery主");
}

/**空白**/
function emptyCtrl($scope, ajaxService, $cookieStore) {
}

/**持仓**/

function cccxCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("查询持仓1");
    $scope.kysl = "-";//可卖数量
    $scope.wtjg = "";//委托价格
    $scope.excstockcode = "";//选中的股票
    $scope.ddlx = "j";
    $scope.wtsl = "";
    $scope.listShow = true;//显示列表或者显示操作界面
    $scope.selectdestock = {};//选中的股票
    $scope.ccsellfiveDivShow = false;

    //console.log("查询持仓");
    var headerArray = [
//        {code: 'cc.productname', name: '合约名称', desc: '↓', type: 'number'},
//        {code: 'cc.stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'cc.cbj', name: '成本价', desc: '　', type: 'money'},
        {code: 'dqj', name: '当前价', desc: '　', type: 'money'},
        {code: 'zqsl', name: '证券数量', desc: '　', type: 'number'},
//        {code: 'cc.kysl', name: '可用数量', desc: ' ', type: 'number'},
        {code: 'yk', name: '盈亏', desc: ' ', type: 'money'},
        {code: 'cz', name: '', desc: ' ', type: 'string', width: '16px', tclass:'dirStyle'}
//        {code: 'cc.sz', name: '市值', desc: '　', type: 'money'}
//        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
    ];

    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.orderClumn = 'f_ljykbl';
    $scope.headers = [];
    $scope.init = function () {
        for (var i = 0; i < headerArray.length; i++) {
            headerArray[i].id = i;
            if (headerArray[i].code == $scope.orderClumn) {
                headerArray[i].desc = "↓";
            } else {
                headerArray[i].desc = "";
            }
            $scope.headers.push(headerArray[i]);
        }
    };
    $scope.init();

    //五档是否显示
    $scope.ccsellfiveDivShowClick = function()
    {
        $scope.ccsellfiveDivShow = !$scope.ccsellfiveDivShow;
    }

    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        console.log("可用资金", _data);
        var arr = _data.moneylist;
        if(arr.length>0)
        {
            $scope.cckyzj = parseFloat(arr[0].kyzj.toString());
            $scope.cczzc = parseFloat(arr[0].zzc.toString());
            $scope.cczsz = parseFloat(arr[0].zsz.toString());
            $scope.ccljyk = parseFloat(arr[0].zzc.toString()) - parseFloat(arr[0].ljcrj.toString());
            if($scope.ccljyk >0)
            {
                $scope.flag = "1";
            }
            else if($scope.ccljyk <0)
            {
                $scope.flag = "-1";
            }
            else
            {
                $scope.flag = "0";
            }

        }
    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        message['moneytype'] ="R";
        ajaxService.sendMessage("counter.selectsecuritymoneyaction", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];

        var message = {};
        message["page.size"] = 'max';
        message['page.no'] = "";
        message['account'] = $scope.childaccount;
        message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        $scope.wtList = [];
        ajaxService.sendMessage("counter.selectsecuritypositionaction", message, function (result) {
            console.log("持仓",result)
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = arr[i].dqj;
                        obj.yk = arr[i].fdyk;
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.ccquery = function()
    {
        //获取资产信息
        $scope.getccinfo();
        $scope.query();
    }
    $scope.ccquery();

    $scope.sellItemClick = function(_obj)
    {
        $scope.listShow = false;
        $scope.selectdestock = _obj;
        $scope.excstockcode = _obj.stockcodeall;
        $scope.wtjg = Number(_obj.dqj);
        //console.log("价格",_obj.dqj,  $scope.wtjg);
        $scope.kysl = _obj.kysl;
        $scope.queryhq(_obj.stockcode);
    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        if(stockcode != null && stockcode != "" || stockcode != undefined)
        {
            var message = {};
            if(stockcode.length == 8) stockcode = stockcode.substring(2);
            message['code'] = stockcode;
            ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack) ;
        }
    };

    //股票行情
    $scope.sshqactionCallBack = function(result)
    {
        //console.log(result)
        if (result.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            var obj = {};
            var buyvarr = result.buyv;
            obj.buyv1 = Math.floor(Number(buyvarr[0])/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1])/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2])/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3])/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4])/100)+'手';
            var sellvarr = result.sellv;
            obj.sellv1 = Math.floor(Number(sellvarr[0])/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1])/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2])/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3])/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4])/100)+'手';

            var buyparr = result.buyp;
            obj.buyp1 = Number(buyparr[0]).toFixed(2);
            obj.buyp2 = Number(buyparr[1]).toFixed(2);
            obj.buyp3 = Number(buyparr[2]).toFixed(2);
            obj.buyp4 = Number(buyparr[3]).toFixed(2);
            obj.buyp5 = Number(buyparr[4]).toFixed(2);

            var sellparr = result.sellp;
            obj.sellp1 = Number(sellparr[0]).toFixed(2);
            obj.sellp2 = Number(sellparr[1]).toFixed(2);
            obj.sellp3 = Number(sellparr[2]).toFixed(2);
            obj.sellp4 = Number(sellparr[3]).toFixed(2);
            obj.sellp5 = Number(sellparr[4]).toFixed(2);

            obj.stockcode = result.code;
            obj.exchange = result.exchange;
            obj.lastprice = result.now;
            obj.name = result.zqjc;


            $scope.hq = obj;
            $scope.wtjg = Number($scope.hq.lastprice);

            if(obj.exchange =="SZ") {
                $scope.ddlxOptions = [
                    {label:"对方最优价格",data:"f"},
                    {label:"本方最优价格",data:"g"},
                    {label:"即时成交剩余撤销",data:"h"},
                    {label:"五档即时成交剩余撤销",data:"i"},
                    {label:"全额成交或撤销委托",data:"j"}
                ];
            }else if(obj.exchange=="SH") {
                $scope.ddlxOptions = [
                    {label:"全额成交或撤销委托",data:"j"},
                    {label:"五档即时成交剩余转限",data:"r"}
                ];
            }
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.wtjg = "";
            $scope.kysl = "-";
            //$scope.$apply();
        }
    }


    //委托价格改变
    $scope.changejg = function(_str)
    {
        if($scope.wtjg == "" || $scope.wtjg == undefined || $scope.wtjg == null)
        {
            $scope.wtjg = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtjg = (Number($scope.wtjg) - 0.01).toFixed(2);
        }
        else//加
        {
            $scope.wtjg = (Number($scope.wtjg) + 0.01).toFixed(2);
        }
    }

    //委托数量改变
    $scope.changesl = function(_str)
    {
        if($scope.wtsl == "" || $scope.wtsl == undefined || $scope.wtsl == null)
        {
            $scope.wtsl = "0";
        }
        if(_str == "1")//减
        {
            $scope.wtsl = (Number($scope.wtsl) - 100).toFixed(0);
        }
        else//加
        {
            $scope.wtsl = (Number($scope.wtsl) + 100).toFixed(0);
        }
    }


    $scope.limitsell = function() {
        if ($scope.excstockcode == null || $scope.excstockcode == "") {
            alert('请输入有效的证券代码');
            return;
        }
        if ($scope.wtjg <= 0) {
            alert('请输入有效的卖出价格');
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtjg) == false)
        {
            alert('请输入有效的卖出价格');
            return;
        }
        if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        {
            alert('请输入有效的卖出价格');
            return;
        }
        if ($scope.wtsl <= 0 || $scope.wtsl == "" || $scope.wtsl == null) {
            alert('请输入有效的卖出数量');
            return;
        }
        if(r.test($scope.wtsl) == false)
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            alert('请输入有效的卖出数量');
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            alert('委托数量大于可用数量，请重新输入');
            return;
        }
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.excstockcode.substring(2);
        message["exchange"] = $scope.excstockcode.substr(0, 2);
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = "1";

        console.log(message);

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.selectdestock.stockname + "(" + $scope.excstockcode + ")   " + $scope.wtsl + "股吗？";
        if (confirm(str))//确定创建
        {
            ajaxService.sendMessage("counter.wtaction", message, function (result) {
                //console.log("交易", result);
                if (result.op.code == 'Y') {
                    alert("委托成功，合同编号：" + result.htbh);
                    $scope.wtsl = "";
                    $scope.kysl = "-";
                    $scope.backtoSellList();
                    $scope.query();
                }
                else {
                    alert("委托失败，原因：" + result.op.info);
                }
            }, false);
        }
    }

    //返回列表界面
    $scope.backtoSellList = function()
    {
        $scope.listShow = true;
        $scope.selectdestock = {};
        $scope.excstockcode = "";
        $scope.wtsl = "";
    }

    //点击不显示手机弹出的键盘
    $scope.ccsellClosePopClick = function(){
    };
}

/**当日成交**/
function drcjCtrl($scope, ajaxService, $cookieStore)
{
    //var headerArray = [
    //    {code1: 'stockname', code2: 'cjsj', name:'成交时间' , type1: 'string', type2: 'shorttime'},
    //    {code1: 'cjjj', code2: '', name: '成交价' , type1: 'buypolicy', type2: ''},
    //    {code1: 'cjsl', code2: '', name: '成交量' , type1: 'number', type2: ''},
    //    {code1: 'side', code2: 'cjje', name: '成交额' , type1: 'exchangeflag', type2: 'money'}
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpcj.cjjj', name: '成交均价', desc: '　', type: 'buypolicy'},
//        {code: 'cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'}

        //{code: 'cjsj', name1: '成交时间',  name2: '代码3333', desc: '', type: 'shorttime'},
////        {code: 'gpcj.htbh', name: '合同编号', desc: ' ', type: 'number'},
////        {code: 'gpcj.cjbh', name: '成交编号', desc: ' ', type: 'number'},
////        {code: 'gpcj.productname', name: '产品名称', desc: '　', type: 'string'},
////        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpcj.cjjj', name: '成交均价', desc: '　', type: 'buypolicy'},
//        {code: 'cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'},
////        {code: 'gpcj.cjje', name: '成交金额', desc: ' ', type: 'money'}
   //];
    //$scope.headers = [];
    //$scope.init = function ()
    //{
    //    for (var i = 0; i < headerArray.length; i++) {
    //        headerArray[i].id = i;
    //        //if (headerArray[i].code == $scope.orderClumn) {
    //        //    headerArray[i].desc = "↓";
    //        //} else {
    //        //    headerArray[i].desc = "";
    //        //}
    //        $scope.headers.push(headerArray[i]);
    //    }
    //};
    //$scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {
        $scope.wtList = [];
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];

        var message = {};
        message["page.size"] = 'max';
        message['page.no'] = "";
        message['account'] = $scope.childaccount;
        message['combpositionid'] = "default";
        ajaxService.sendMessage("counter.selectsecuritycjaction", message, function (result) {
            console.log("当日成交", result);
            if (result.op.code == 'Y')
            {
                var arr = result.securitycjlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.cjsj = (arr[i].cjsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.cjjj = arr[i].cjjj;
                        obj.cjsl = arr[i].cjsl;
                        obj.side = arr[i].side;
                        obj.cjje = arr[i].cjje;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else
                {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.query();
}

/**当日委托**/
function drwtCtrl($scope, ajaxService, $cookieStore)
{
//    var headerArray = [
//        {code: 'wtsj', name: '委托时间', desc: '↓', type: 'shorttime'},
////        {code: 'gpwt.htbh', name: '合同编号', desc: ' ', type: 'number'},
////        {code: 'gpwt.productname', name: '产品名称', desc: '　', type: 'string'},
////        {code: 'stockcode', name: '证券代码', desc: '　', type: 'stockcode'},
//        {code: 'stockname', name: '证券名称', desc: '　', type: 'string'},
//        {code: 'side', name: '买卖标志', desc: '　', type: 'exchangeflag'},
////        {code: 'gpwt.wtjg', name: '委托价格', desc: '　', type: 'buypolicy'},
//        {code: 'wtsl', name: '委托数量', desc: '　', type: 'number'},
////        {code: 'gpwt.djje', name: '委托金额', desc: ' ', type: 'money'},
////        {code: 'gpwt.htbh', name: '委托编号', desc: '　', type: 'number'},
////        {code: 'gpwt.cjsl', name: '成交数量', desc: '　', type: 'number'},
////        {code: 'gpwt.cjje', name: '成交金额', desc: '　', type: 'money'},
////        {code: 'gpwt.cdsl', name: '撤单数量', desc: '　', type: 'number'},
////        {code: 'gpwt.status', name: '委托状态', desc: '　', type: 'wtstatus'},
////        {code: 'gpwt.reason', name: '备注', desc: '　', type: 'string'}
//    ];
//    $scope.orderClumn = 'f_ljykbl';
//    $scope.headers = [];
//    $scope.init = function ()
//    {
//        for (var i = 0; i < headerArray.length; i++) {
//            headerArray[i].id = i;
//            if (headerArray[i].code == $scope.orderClumn) {
//                headerArray[i].desc = "↓";
//            } else {
//                headerArray[i].desc = "";
//            }
//            $scope.headers.push(headerArray[i]);
//        }
//    };
//    $scope.init();

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];


    $scope.query = function () {
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.selectAllWt = false;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];

        var message = {};
        message["page.size"] = 'max';
        message['page.no'] = "";
        message['account'] = $scope.childaccount;
        message['combpositionid'] = "default";
        ajaxService.sendMessage("counter.selectsecurityorderaction", message, function (result) {
            console.log("当日委托",result);
            if (result.op.code == 'Y') {
                var arr = result.securityorderlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtjg = arr[i].wtjg;
                        obj.wtsl = arr[i].wtsl;
                        obj.side = arr[i].side;
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }
            else
            {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

        });
    };

    $scope.query();
}

/**历史成交**/
function lscjCtrl($scope, ajaxService, $cookieStore)
{
    $scope.showList = false;//列表是否显示
    $scope.showNodata = false;//无数据
    $scope.isLoading = false;//加载中
    $scope.startDateValue = "";//开始日期
    $scope.endDateValue = "";//结束日期

    //$scope.wtList = [];
    //$scope.showList = false;
    //$scope.showNodata = false;
    //$scope.isLoading = true;
    $scope.htbhlist = [];
    $scope.cdzhidlist = [];

    $scope.query = function () {

        //alert("start:" + document.getElementById("startDate").value);

        //alert($scope.startDateValue + "   " +$scope.endDateValue);
        if($scope.startDateValue == "" ||  $scope.endDateValue == "")
        {
            alert("请先输入开始日期和结束日期");
            return;
        }
        if($scope.cheackDate2() == false)
        {
            alert("结束日期应大于开始日期且都应小于当前日期");
            return;
        }
        $scope.showList = false;
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];
        $scope.startday = $scope.getDateFull($scope.startDateValue);
        $scope.endday = $scope.getDateFull($scope.endDateValue);
        //alert("333   " + $scope.startday +  $scope.endday);
        var message = {};
        message["page.pagesize"] = 'max';
        message['page.pageno'] = "";
        message['account'] = $scope.childaccount;
        message['combPositionId'] = "default";
        message["kssj"] = $scope.startday;
        message["jssj"] = $scope.endday;
        console.log($scope.startday, $scope.endday);
        ajaxService.sendMessage("counter.selecthissecuritycjaction", message, function (result) {
            console.log("历史成交", result);
            if (result.op.code == 'Y')
            {
                var arr = result.hiscjlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.cjsj = (arr[i].cjsj.toString()).substr(0,19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.cjjj = arr[i].cjjj;
                        obj.cjsl = arr[i].cjsl;
                        obj.side = arr[i].side;
                        obj.cjje = arr[i].cjje;
                        console.log(obj.cjjj,obj.cjsl);
                        $scope.wtList.push(obj);
                    }
                    $scope.showList = true;
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                }
                else
                {
                    $scope.showList = true;
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            }else {
                $scope.showList = true;
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    $scope.getDateFull = function(_str)
    {
        var yyyy = _str.getFullYear();
        var mm = _str.getMonth() + 1;
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        var dd = _str.getDate();
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }

        return yyyy + "" + mm + "" + dd;
    }

    //判断开始日期和结束日期
    $scope.cheackDate = function()
    {
        var mark = true;
        //alert("开始日期：" + $scope.startDateValue +  "   结束日期：" + $scope.endDateValue);
        try
        {
            var d1 = new Date($scope.startDateValue.replace(/-/g, "/"));
            var d2 = new Date($scope.endDateValue.replace(/-/g, "/"));
        }
        catch(e){}
        var today = new Date();
        if (Date.parse(d1) > Date.parse(today)) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if (Date.parse(d2) > Date.parse(today)) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if (Date.parse(d1) > Date.parse(d2)) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    //判断开始日期和结束日期
    $scope.cheackDate2 = function()
    {
        var mark = true;
        var today = new Date();
        if ($scope.startDateValue > today) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if ($scope.endDateValue > today) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if ($scope.startDateValue > $scope.endDateValue) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

}

/**历史委托**/
function lswtCtrl($scope, ajaxService, $cookieStore) {

    $scope.showList = false;//列表是否显示
    $scope.showNodata = false;//无数据
    $scope.isLoading = false;//加载中
    $scope.startDateValue = "";//开始日期
    $scope.endDateValue = "";//结束日期

    //var yourTime= "yyyy/mm/dd";
    //document.getElementById("startDate").attr('value',yourTime);

    $scope.query = function () {

        if($scope.startDateValue == "" ||  $scope.endDateValue == "")
        {
            alert("请先输入开始日期和结束日期");
            return;
        }
        if($scope.cheackDate2() == false)
        {
            alert("结束日期应大于开始日期且都应小于当前日期");
            return;
        }


        $scope.showList = false;
        $scope.showNodata = false;
        $scope.isLoading = true;
        $scope.htbhlist = [];
        $scope.cdzhidlist = [];
        $scope.wtList = [];
        $scope.startday = $scope.getDateFull($scope.startDateValue);
        $scope.endday = $scope.getDateFull($scope.endDateValue);

        var message = {};
        message["page.pagesize"] = 'max';
        message['page.pageno'] = "";
        message['account'] = $scope.childaccount;
        message['combPositionId'] = "default";
        message["kssj"] = $scope.startday;
        message["jssj"] = $scope.endday;
        console.log($scope.startday, $scope.endday, $scope.childaccount);
        ajaxService.sendMessage("counter.selecthissecurityorderaction", message, function (result) {
            console.log("历史委托", result)
            if (result.op.code == 'Y') {
                var arr = result.orderlist;
                if (arr.length > 0)
                {
                    for (var i = 0; i < arr.length; i++)
                    {
                        var obj = {};
                        obj.wtsj = (arr[i].wtsj.toString()).substr(0, 19);
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.wtjg = arr[i].wtjg;
                        obj.wtsl = arr[i].wtsl;
                        obj.side = arr[i].side;
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj)
                    }
                    $scope.showList = true;
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showList = true;
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                }
            } else {
                $scope.showList = true;
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }
        });
    };

    //判断开始日期和结束日期
    $scope.cheackDate = function()
    {
        var mark = true;
        //alert("开始日期：" + $scope.startDateValue +  "   开始日期：" + $scope.endDateValue)
        var d1 = new Date($scope.startDateValue.replace(/-/g, "/"));
        var d2 = new Date($scope.endDateValue.replace(/-/g, "/"));
        //alert($scope.startDateValue.replace(/-/g, "/") + "  "  +$scope.endDateValue.replace(/-/g, "/"));
        var today = new Date();
        if (Date.parse(d1) > Date.parse(today)) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if (Date.parse(d2) > Date.parse(today)) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if (Date.parse(d1) > Date.parse(d2)) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    //判断开始日期和结束日期
    $scope.cheackDate2 = function()
    {
        var mark = true;
        var today = new Date();
        if ($scope.startDateValue > today) {
            //alert("开始日期 大于 当前日期");
            mark = false;
        }
        if ($scope.endDateValue > today) {
            //alert("结束日期 大于 当前日期");
            mark = false;
        }
        //alert(d1 + "  " +  d2);
        if ($scope.startDateValue > $scope.endDateValue) {
            //alert("开始日期 大于 结束日期 ");
            mark = false;
        }

        return  mark;
    }

    $scope.getDateFull = function(_str)
    {
        var yyyy = _str.getFullYear();
        var mm = _str.getMonth() + 1;
        if(mm.toString().length == 1)
        {
            mm = "0" + mm;
        }
        var dd = _str.getDate();
        if(dd.toString().length == 1)
        {
            dd = "0" + dd;
        }

        return yyyy + "" + mm + "" + dd;
    }

    //点击不显示手机弹出的信息
    $scope.lswtClosePopClick = function()
    {

    }
}