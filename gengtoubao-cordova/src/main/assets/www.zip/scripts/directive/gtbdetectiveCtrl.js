
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gtbdetectiveCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.directivemain = true;//主界面
    $scope.alllcstjDivShow = false//更多专户推荐;
    $scope.me_stepone = false;//无账户、无跟投、未点击“我知道啦”
    $scope.me_steptwo = false;//无账户、无跟投、已点击“我知道啦”
    $scope.me_stepthree = false;//有账户、无跟投
    $scope.me_stepfour = false;//有跟投（即有账户）

    $scope.gtallacount = 0;//跟投总个数

    $scope.dqgtArray = [];//当前跟投数组

    $scope.tabdivShow = false;
    $scope.allrsyfxDivShow = false;
    //console.log($scope.opentype);

    $scope.gtbobj = {};//跟投宝相关数据
    $scope.gtbobj.gtAccount = "--";//跟投理财包个数
    $scope.gtbobj.gtljsy = "--";//跟投累计收益
    $scope.gtbobj.gtljgtje = "--";//跟投累计跟投金额
    $scope.historylcfwAccount = "--";//历史理财包个数
    //$scope.historygtAccount = "--";//历史理财包个数

    $scope.dqgtObj = {};
    $scope.dqgtObj.signcount = "--";//当前跟投单数
    $scope.dqgtObj.signmoney = "--";//当前跟投金额
    $scope.dqgtObj.drsy = "--";//当日总收益
    $scope.dqgtObj.drsyl = "--";//当日总收益率
    $scope.dqgtObj.ljsy = "--";//实盘中跟投累计收益
    $scope.dqgtObj.ljsyl = "--";//实盘中跟投累计收益率
    $scope.dqgtObj.applycount = "--";//报名数
    $scope.dqgtObj.removecount = "--";//解除中数
    $scope.dqgtObj.tradecount = "--";//实盘中数
    $scope.dqgtObj.unpaycount = "--";//未付款数
    $scope.dqgtObj.ungradecount = "--";//未评论数
    $scope.dqgtObj.endcount = "--";//已结束数（已结束包括未付款和未评论）

    $scope.littletjfwArray = [];//推荐的服务
    $scope.moretjfwArray = [];//推荐的服务

    $scope.spzArray = [];//实盘中
    $scope.jczArray = [];//解除中



    //产品 预售期（报名期）：cp1(A)； 交易期：cp2(B)；解除中：cp3(D)
    //跟投  跟投中：gt1 (B)； 解除中：gt2(C)
    //报名 ybm

    //if (window.location.hash == "#index=1")
    //{
    //    $scope.index = '1';
    //}
    //else if (window.location.hash == "#index=2")
    //{
    //    $scope.index = '2';
    //}
    //if($scope.lcsstatus != "2")
    //{
    //    $scope.index = "2";
    //}

    $scope.p_getgentoustatisticsCallBack = function(_data)
    {
        //console.log("累计数据：" + _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.gtbobj = {};//跟投宝相关数据
            $scope.gtbobj.gtAccount = _data.gentoustatistic.gtcount + "单";//跟投理财包个数
            $scope.gtbobj.gtljsy = parseFloat(_data.gentoustatistic.gtljsy);//跟投累计收益
            $scope.gtbobj.gtljgtje = parseFloat(_data.gentoustatistic.gtljgtje);//跟投累计跟投金额
        }
    }

    $scope.getgtbInfo = function()
    {
        //console.log("累计");
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_getgentoustatistics", message, $scope.p_getgentoustatisticsCallBack);

    }


    $scope.getzhmxCount = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log($scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getmyinfo", message, function (data)
        {
            if (data.op.code.toString() == "Y")
            {
                $scope.accountCount = data.myinfo.bindaccountcount;//账户个数
                if($scope.accountCount >0)
                {
                    $scope.accountCount = $scope.accountCount - 1;
                }
                //$scope.combCount = data.myinfo.modelcount;//模型个数
            }
            if($scope.gtallacount>0)//有跟投
            {
                $scope.checkstepShow("4");
            }
            else if($scope.accountCount>0)//有账户
            {
                $scope.checkstepShow("3");
            }
            else//无账户
            {
                var localStorage = window.localStorage;
                if(localStorage.getItem("isknowgt") == "1")//已经知道跟投
                {
                    $scope.checkstepShow("2");
                }
                else
                {
                    $scope.checkstepShow("1");
                }
            }
        });

    }

    $scope.iknowgtClick = function()
    {
        var localStorage = window.localStorage;
        localStorage.setItem("isknowgt", "1");
        $scope.checkstepShow("2");
    }

    $scope.gtinfoCallBack = function(_data)
    {
        //console.log("跟投信息", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.dqgtObj.signcount = _data.gentoustats.signcount;
            if($scope.dqgtObj.signcount == "" || $scope.dqgtObj.signcount == undefined || $scope.dqgtObj.signcount == null)
            {
                $scope.dqgtObj.signcount = 0;
            }
            $scope.dqgtObj.signmoney = _data.gentoustats.signmoney;
            if($scope.dqgtObj.signmoney == "" || $scope.dqgtObj.signmoney == undefined || $scope.dqgtObj.signmoney == null)
            {
                $scope.dqgtObj.signmoney = 0;
            }
            $scope.dqgtObj.drsy = _data.gentoustats.drsy;
            if($scope.dqgtObj.drsy == "" || $scope.dqgtObj.drsy == undefined || $scope.dqgtObj.drsy == null)
            {
                $scope.dqgtObj.drsy = 0;
            }
            $scope.dqgtObj.drsyl = _data.gentoustats.drsyl;
            if($scope.dqgtObj.drsyl == "" || $scope.dqgtObj.drsyl == undefined || $scope.dqgtObj.drsyl == null)
            {
                $scope.dqgtObj.drsyl = 0;
            }
            $scope.dqgtObj.ljsy = _data.gentoustats.ljsy;
            if($scope.dqgtObj.ljsy == "" || $scope.dqgtObj.ljsy == undefined || $scope.dqgtObj.ljsy == null)
            {
                $scope.dqgtObj.ljsy = 0;
            }
            $scope.dqgtObj.ljsyl = _data.gentoustats.ljsyl;
            if($scope.dqgtObj.ljsyl == "" || $scope.dqgtObj.ljsyl == undefined || $scope.dqgtObj.ljsyl == null)
            {
                $scope.dqgtObj.ljsyl = 0;
            }

            $scope.dqgtObj.applycount = _data.gentoustats.applycount;
            $scope.dqgtObj.removecount = _data.gentoustats.removecount;
            $scope.dqgtObj.tradecount = _data.gentoustats.tradecount;
            $scope.dqgtObj.unpaycount = _data.gentoustats.unpaycount;
            $scope.dqgtObj.ungradecount = _data.gentoustats.ungradecount;
            $scope.dqgtObj.endcount = _data.gentoustats.endcount;

            //是否有跟投
            if(!!$scope.dqgtObj.tradecount && $scope.dqgtObj.tradecount != "--")
            {
                $scope.gtallacount = $scope.gtallacount + parseInt($scope.dqgtObj.tradecount);
            }
            if(!!$scope.dqgtObj.removecount && $scope.dqgtObj.removecount != "--")
            {
                $scope.gtallacount = $scope.gtallacount + parseInt($scope.dqgtObj.removecount);
            }
            if(!!$scope.dqgtObj.endcount && $scope.dqgtObj.endcount != "--")
            {
                $scope.gtallacount = $scope.gtallacount + parseInt($scope.dqgtObj.endcount);
            }
        }
        //$scope.gtallacount = 0;
        if($scope.gtallacount>0)//有跟投
        {
            $scope.checkstepShow("4");
        }
        else//无跟投
        {
            //判断是否有账户
            $scope.getzhmxCount();
        }
    }

    $scope.gtinfo = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        //console.log("获取跟投信息", $scope.userObj.f_id)
        ajaxService.sendMessage("sunflower.p_getmyinfobycustomer", message, $scope.gtinfoCallBack);

    }

    //理财服务、跟投
    $scope.changeTab = function(_str)
    {
        //$scope.tabOneShow = false;
        //$scope.tabTwoShow = true;
        //$scope.index = "2";
        ////window.location.href = "#index=2";
        //$scope.gtinfo();
        //$scope.getgtbInfo();
    }

    //推荐的服务
    $scope.gettjfw = function()
    {
        var message = {};
        message['page.size'] = 'max';
        message['page.no'] = 1;
        ajaxService.sendMessage('sunflower.p_selectproductljsyrank', message, function (data) {
            //console.log("累计收益",data);
            $scope.littletjfwArray = [];
            $scope.moretjfwArray = [];
            if (data.op.code.toString() == "Y")
            {
                $scope.gtljsybList = [];
                var arr = data.gentouproductlist;
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.status = "cp2";
                    obj.account = arr[i].account;//当前被跟投的账户
                    var bgtuser = arr[i].user.user;
                    obj.hearurl = bgtuser.f_head;
                    obj.username = bgtuser.f_nickname;
                    obj.fbzuserid = bgtuser.f_id;
                    obj.productname = arr[i].name;
                    obj.productid = arr[i].id;
                    obj.gentoucount = arr[i].gentoucount;
                    obj.drsyl = parseFloat(arr[i].jrsy);
                    obj.ljsyl = parseFloat(arr[i].ljsy);
                    obj.rundays = arr[i].rundays;
                    var cwstr = arr[i].cw;
                    if(parseFloat(cwstr) == 0)
                    {
                        obj.cw = "空仓";//当前仓位
                    }
                    else if(parseFloat(cwstr) == 1)
                    {
                        obj.cw = "满仓";//当前仓位
                    }
                    else
                    {
                        obj.cw = (parseFloat(arr[i].cw)*100).toFixed(0) + "%";//当前仓位
                    }
                    if($scope.littletjfwArray.length<3)
                    {
                        $scope.littletjfwArray.push(obj);
                    }
                    $scope.moretjfwArray.push(obj);
                }
            }
        });
    }

    //获取账户列表

    $scope.p_getaccountlistCallBack = function(_data)
    {
        //console.log("获取账户列表", _data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.accountlist;
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item].id;
                obj.zqgs = element[item].company;
                obj.zqgsname = element[item].companyname;
                obj.account = element[item].account.toString();
                obj.zqgsiocnurl = getzqgsLogo(obj.zqgs);//公司logo
                obj.zhxm = element[item].name;//账户姓名，添加账户时输入信息
                obj.accountstatus = element[item].accountstatus.toString();
                obj.source = element[item].source.toString();//A：普通账户，G：大赛账户
                obj.experience = element[item].experience.toString();//是否是跟投基金，Y表示是跟投基金
                //if(obj.experience == "Y")
                //{
                //    $scope.gtjjzh = obj.account;
                //}
                obj.newflag = element[item].newflag;//是否已经转账操作
                if(obj.newflag == undefined || obj.newflag == null)
                {
                    obj.newflag = "";
                }
                if(obj.accountstatus == "a" )//a-普通账户（无跟投、无被跟投） b-跟投账户（跟投了其他账户） c-被跟投账户（被其他账户跟投）
                {
                    obj.tradeaccount = obj.account;
                    obj.sortindex = 1;
                }
                else
                {
                    if(obj.accountstatus == "b")
                    {
                        var zl = element[item].self;
                        if(zl == undefined || zl == null)
                        {
                            obj.tradeaccount = obj.account;
                        }
                        else
                        {
                            obj.tradeaccount = zl.account;//自留账户
                        }
                        obj.sortindex = 2;
                    }
                    else if(obj.accountstatus == "c")
                    {
                        obj.tradeaccount = obj.account;
                        obj.sortindex = 3;
                    }
                }
                if(obj.experience != "Y")
                {
                    $scope.zhListArray.push(obj);
                }
            }
        }

        //if($scope.zhListArray.length>0)
        //{
        //    $scope.zhListArray.sort(function (a, b) {
        //        return b.sortindex - a.sortindex;
        //    });
        //}
    }

    $scope.getzhlb = function()
    {
        $scope.zhListArray = [];
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.p_getaccountlist", message, $scope.p_getaccountlistCallBack);
    }

    updatezhlist = function()
    {
        $scope.getzhlb();
    }

    $scope.getspzCallBack = function(_data)
    {
        $scope.spzArray = [];
        //console.log("实盘中",_data);

        var arr1 = _data.accountlinklist;
        for(var i = 0; i<arr1.length;i++)
        {
            var obj = {};
            obj.status = "gt1";
            obj.linkaccount = arr1[i].linkaccount;//当前跟投的账户
            obj.linkid = arr1[i].id;
            var bgtuser = arr1[i].linkeduser.user;
            obj.hearurl = bgtuser.f_head;
            obj.username = bgtuser.f_nickname;
            obj.bgtuserid = bgtuser.f_id;
            obj.productname = arr1[i].productname;//产品name
            obj.productid = arr1[i].productid;//产品id
            obj.money = arr1[i].money;//跟投金额
            //obj.drsyl = (parseFloat(arr1[i].linkaccountmoney.jrsy)*100).toFixed(2);
            //obj.ljsyl = (parseFloat(arr1[i].linkaccountmoney.ljsy)*100).toFixed(2);
            obj.drsyl = parseFloat(arr1[i].jrsy);
            obj.drsy = arr1[i].dqyk;
            obj.ljsyl = parseFloat(arr1[i].ljsy);
            obj.ljsy = arr1[i].ljyk;
            //var str = arr1[i].endgentoutime.toString();
            //obj.jssj = str;
            var cwstr = arr1[i].cw;
            if(parseFloat(cwstr) == 0)
            {
                obj.cw = "空仓";//当前仓位
            }
            else if(parseFloat(cwstr) == 1)
            {
                obj.cw = "满仓";//当前仓位
            }
            else
            {
                obj.cw = (parseFloat(arr1[i].cw)*100).toFixed(0) + "%";//当前仓位
            }
            obj.buycount = arr1[i].buycount;
            obj.sellcount = arr1[i].sellcount;
            $scope.spzArray.push(obj);
        }
    }

    $scope.getspz = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        //console.log(message);
        ajaxService.sendMessage("gentou.p_selecttradingaccountlink", message, $scope.getspzCallBack);
    }

    $scope.getjczCallBack = function(_data)
    {
        //console.log("解除中", _data);
        $scope.jczArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr1 = _data.accountlinklist;
            for(var i = 0; i<arr1.length;i++)
            {
                var obj = {};
                obj.status = "gt2";
                obj.mbsy = arr1[i].targetprofit;
                obj.linkaccount = arr1[i].linkaccount;//当前跟投的账户
                obj.linkid = arr1[i].id;
                var bgtuser = arr1[i].linkeduser.user;
                obj.hearurl = bgtuser.f_head;
                obj.username = bgtuser.f_nickname;
                obj.bgtuserid = bgtuser.f_id;
                obj.productname = arr1[i].productname;//产品id
                obj.productid = arr1[i].productid;//产品id
                obj.money = arr1[i].money;//跟投金额
                //obj.drsyl = (parseFloat(arr1[i].linkaccountmoney.jrsy)*100).toFixed(2);
                //obj.ljsyl = (parseFloat(arr1[i].linkaccountmoney.ljsy)*100).toFixed(2);
                //obj.drsyl = parseFloat(arr1[i].linkaccountmoney.jrsy);
                //obj.ljsyl = parseFloat(arr1[i].linkaccountmoney.ljsy);
                obj.drsyl = parseFloat(arr1[i].jrsy);
                obj.drsy = arr1[i].dqyk;
                obj.ljsyl = parseFloat(arr1[i].ljsy);
                obj.ljsy = arr1[i].ljyk;
                //var str = arr1[i].endgentoutime.toString();
                //obj.jssj = str;
                var cwstr = arr1[i].cw;
                if(parseFloat(cwstr) == 0)
                {
                    obj.cw = "空仓";//当前仓位
                }
                else if(parseFloat(cwstr) == 1)
                {
                    obj.cw = "满仓";//当前仓位
                }
                else
                {
                    obj.cw = (parseFloat(arr1[i].cw)*100).toFixed(0) + "%";//当前仓位
                }
                obj.buycount = arr1[i].buycount;
                obj.sellcount = arr1[i].sellcount;
                $scope.jczArray.push(obj);
            }
        }
    }

    $scope.getjcz = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        ajaxService.sendMessage("gentou.p_selectremovingaccountlink", message, $scope.getjczCallBack);
    }

    $scope.checkstepShow = function(_str)
    {
        //console.log("_str", _str);
        if(_str == "1")
        {
            //第一步
            $scope.me_stepone = true;
            $scope.me_steptwo = false;
            $scope.me_stepthree = false;
            $scope.me_stepfour = false;
        }
        else if(_str == "2")
        {
            //第二步
            $scope.me_stepone = false;
            $scope.me_steptwo = true;
            $scope.me_stepthree = false;
            $scope.me_stepfour = false;
            //跟投基金
            //推荐服务
            $scope.gettjfw();
        }
        else if(_str == "3")
        {
            //第三步
            $scope.me_stepone = false;
            $scope.me_steptwo = false;
            $scope.me_stepthree = true;
            $scope.me_stepfour = false;
            //跟投基金
            //推荐服务
            $scope.gettjfw();
            //账户列表
            $scope.getzhlb();
        }
        else if(_str == "4")
        {
            //第四步
            $scope.me_stepone = false;
            $scope.me_steptwo = false;
            $scope.me_stepthree = false;
            $scope.me_stepfour = true;
            //跟投基金
            //推荐服务
            $scope.gettjfw();
            //账户列表
            $scope.getzhlb();
            //实盘中跟投
            $scope.getspz();
            //解除中跟投
            $scope.getjcz();
        }
    }

    //判断到哪一步
    $scope.checkstep = function()
    {
        //收益信息
        $scope.gtinfo();
    }


    //初始相关操作界面
    $scope.gtbInit = function(newValue, oldValue, scope)
    {
        if(newValue) {
            $scope.checkstep();
        }
    }

    $scope.$watch('basetabFourShow', $scope.gtbInit);

    //$scope.$on("setParameters", function(e, _data) {
    //    //console.log("caption", _data.caption);
    //    if(_data.caption == "gtbdirective")
    //    {
    //        $scope.gtbInit();
    //    }
    //});
    //
    ////向父对象说明已经侦听，可以接受入参
    ////console.log("tradesynthetical侦听");
    //var cstr  = {"caption": "gtbdirective"};
    //$scope.$emit("gtbdirective", cstr);

    $scope.zhlistItemClick = function(_obj)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("account", _obj.tradeaccount);
        localStorage.setItem("accountcompany", _obj.zqgs);//证券公司id
        localStorage.setItem("accountName", encodeURIComponent(_obj.zqgsname));
        localStorage.setItem("accountShow", encodeURIComponent(_obj.account));
        localStorage.setItem("newflag", encodeURIComponent(_obj.newflag));
        //console.log(_obj.tradeaccount, _obj.zqgs, _obj.zqgsname, _obj.account, _obj.newflag);

        //setbackList(window.location.href);
        if(_obj.source == "G")
        {
            openNewInterface("tradeBase_game.html?opentype=newwebview");
        }
        else
        {
            if(_obj.accountstatus == "a")//不带跟投的交易
            {
                //window.location.href = "tradeBase_wgt.html";
                openNewInterface("tradeBase_wgt.html" + "?opentype=newwebview");
            }
            else if(_obj.accountstatus == "c" )//a-普通账户（无跟投、无被跟投） b-跟投账户（跟投了其他账户） c-被跟投账户（被其他账户跟投）
            {
                //window.location.href = "tradeBase_bgtzzh.html";
                //window.location.href = "tradeBase_bgt.html";
                openNewInterface("tradeBase_bgt.html" + "?opentype=newwebview");
            }
            //else if(_obj.accountstatus == "b" )//跟投了其他账户
            else
            {
                if(_obj.tradeaccount == _obj.account)//跟投成功，但是跟投未开始
                {
                    //window.location.href = "tradeBase_wgt.html";
                    openNewInterface("tradeBase_wgt.html" + "?opentype=newwebview");
                }
                else
                {
                    //window.location.href = "tradeBase_gtz.html";
                    openNewInterface("tradeBase_gtz.html" + "?opentype=newwebview");
                }
            }
        }
    }


    //更多理财师推荐
    $scope.morelcstjClick = function()
    {
        $scope.directivemain = false;
        $scope.alllcstjDivShow = true;
        $scope.baseBottomVisible(false);
    }
    //更多专户返回
    $scope.alllcstjbackto = function()
    {
        $scope.directivemain = true;
        $scope.alllcstjDivShow = false;
        $scope.baseBottomVisible(true);
    }

    //进入跟投日收益分析
    $scope.allsyfxshowClick = function()
    {
        $scope.directivemain = false;
        $scope.allrsyfxDivShow = true;
        $scope.baseBottomVisible(false);
        $scope.getrsyfx();
    }

    $scope.getrsyfx = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['shopid'] = $scope.bcidstr;
        //console.log("收益分析", message);
        ajaxService.sendMessage("gentou.selecthisgentousyaction", message, $scope.getrsyfxCallBack) ;
    }

    $scope.getrsyfxCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.sytj;
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.gtje = parseFloat(arr[i].mongentoumoney);
                //obj.syl = parseFloat(arr[i].monsyl)*100;
                //if(obj.syl > 0)
                //{
                //    obj.flag = "1";
                //}
                //else if(obj.syl <0)
                //{
                //    obj.flag = "-1";
                //}
                //else
                //{
                //    obj.flag = "0";
                //}
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    obj2.changemoney = parseFloat(arr3[j].changemoney);

                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
        }

    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }

    $scope.allrsyfxbackto = function()
    {
        $scope.directivemain = true;
        $scope.allrsyfxDivShow = false;
        $scope.baseBottomVisible(true);

        $scope.gtinfo();
    }

    //跟投list点击
    $scope.gtlistItemClick = function(_obj)
    {
       if(_obj.status == "gt1")
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqgtupdate");
        }
        else  if(_obj.status == "gt2")
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqgtupdate");
        }
    }


    //当前跟投刷新
    dqgtupdate = function()
    {
        //实盘中跟投
        $scope.getspz();
        //解除中跟投
        $scope.getjcz();
        $scope.getlsgtList();
    }

    updategtztinfo = function()
    {
        //alert("121321");
        //$scope.gtinfo();
        //$scope.getgtjj();
    }

    //历史跟投，理财服务（用户自己发布的理财包）
    $scope.gtb_tab1lsgtClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "gt_history.html?type=1";
        openNewInterface("gt_history.html?type=1" + "&&opentype=newwebview"+ "&&backtitle=" + encodeURI("我"));
    }
    //历史跟投，跟投（跟投其他人的服务）
    $scope.gtb_tab2lsgtClick = function()
    {
        //setbackList(window.location.href);
        //window.location = "gt_history.html?type=2";
        openNewInterface("gt_history.html?type=2" + "&&opentype=newwebview"+ "&&backtitle=" + encodeURI("我"));
    }

    //发布跟投
    $scope.gtb_fbgtClick = function()
    {
        //window.location = "gtrelease.html?backurl=gtbBase.html";
        //setbackList(window.location.href);
        //window.location = "gtrelease.html";
        openNewInterface("gtrelease.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "dqlcbupdate");
    }

    //跟投资金
    $scope.gtb_tab1gtzjClick = function()
    {
        //window.location = "gtb/gtb-index.html?backurl=../gtbBase.html?opentype=newwebview#index=1";
        //window.location = "gtb/gtb-index.html?backurl=../gtbBase.html?opentype=newwebview#index=1";

        openNewInterface("gtb/gtb-index.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }
    //充值
    $scope.gtb_tab2czClick = function()
    {
        //window.location = "gtb/gtb-czindex.html?backurl=../gtbBase.html?opentype=newwebview#index=2";
        openNewInterface("gtb/gtb-czindex.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }

    //开户
    $scope.khClick = function()
    {
        openNewInterface("openAccounts.html?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));

    }

    //进入相应对象的空间
    $scope.personspaceClick = function(_id)
    {
        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("我"));
    }

    //进入专户
    $scope.gtsyphbItemClick = function(_obj)
    {
        //console.log($scope.userObj.f_id, _obj.fbzuserid);
        if(_obj.fbzuserid == $scope.userObj.f_id)
        {
            //window.location = "gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account;
            openNewInterface("gt_fwz_fbz.html?productid=" + _obj.productid + "&&account=" + _obj.account + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "updatezt");
        }
        else
        {
            //setbackList("uufpBase.html?baseindex=3");
            //window.location = "gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid;
            openNewInterface("gt_sy.html?account=" +_obj.account+"&&productid="+_obj.productid + "&&bgtuserid=" + _obj.fbzuserid + "&&opentype=newwebview" + "&&backtitle=" + encodeURI("我"), "updatezt");
        }
    }

    updatezt = function ()
    {
        $scope.checkstep();
    }

    //圈子跟投
    $scope.me_qzgtClick = function()
    {
        //window.location = "gtCircle.html" + "?backtitle=" + encodeURI("我");
        openNewInterface("gtCircle.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview", "updategtztinfo");
    }


    //跟投持仓一览
    $scope.me_gtccyl = function()
    {
        //window.location = "gtPosition.html" + "?backtitle=" + encodeURI("我");
        openNewInterface("gtPosition.html" + "?backtitle=" + encodeURI("我") + "&&opentype=newwebview");
    }

}



