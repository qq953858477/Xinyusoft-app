function gtsyjyjl()
{
     return {
         restrict: 'E',
         templateUrl: 'html/gt_sy_jyjl.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function gtsyjyjlCtrl($scope, ajaxService, $cookieStore) {
    //console.log("5345");
    //$scope.zhInfo = {};
    $scope.childaccount = "";
    //$scope.zhInfo.qssjstr = "";
    $scope.tcjlArray = []; //调仓记录


    $scope.p_selectaccountpositionchangerecordCallBack = function(_data)
    {
        $scope.tcjlArray = [];
        //console.log("调仓记录", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.changepositionlist;
            var arr2 = [];
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.time = arr[i].wtsj.toString().substr(0,10);
                obj.gpdm = arr[i].code;
                obj.exchange = arr[i].exchange;
                obj.gpmc = arr[i].name;
                obj.side = arr[i].side.toString();
                if(obj.side == "B")
                {
                    obj.sideStr = "买入";
                }
                else
                {
                    obj.sideStr = "卖出";
                }
                obj.wtsl = arr[i].wtsl + "股";//成交数量。原先是显示委托数量，后改成显示成交数量，前端未动，后端将成交数量命名为wtsl
                obj.wtjg = parseFloat(arr[i].wtjg).toFixed(2) + "元";//成交价格，原因同上。
                obj.asset = getzqStatus(arr[i].basetype);
                arr2.push(obj);
            }

            for(var i = 0;i<arr2.length;i++)
            {
                var mark = false;//是否已经处理
                for(var k = 0;k<$scope.tcjlArray.length;k++)
                {
                    if($scope.tcjlArray[k].time == arr2[i].time)
                    {
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    var obj = {};
                    obj.time = arr2[i].time;
                    obj.yfshow = true;//是否展开 0：展开，1：不展开 ，界面显示用
                    var arr3 = [];
                    for(var j = i;j<arr2.length;j++)
                    {
                        if(arr2[j].time == obj.time)
                        {
                            //obj.gpdm = arr2[i].code;
                            //obj.exchange = arr2[i].exchange;
                            //obj.gpmc = arr2[i].name;
                            //obj.side = arr2[i].side;
                            //obj.wtsl = arr2[i].wtsj;
                            arr3.push(arr2[j]);
                        }
                    }
                    obj.dataArr = arr3;
                    $scope.tcjlArray.push(obj);
                }
            }

            if($scope.tcjlArray.length>0)
            {
                $scope.tcjlArray[0].yfshow = true;//打开第一个月份
            }
        }
    }

    $scope.gettcjl = function()
    {
        //$scope.tcjlArray = [];
        var message = {};
        message['account'] = $scope.childaccount;
        message['kssj'] = $scope.kssjstr;
        //console.log("开始时间", $scope.kssjstr);
        if($scope.jssjstr != "" && $scope.jssjstr != undefined)
        {
            message['jssj'] = $scope.jssjstr;
        }
        //console.log("调仓记录222", message['kssj'], message['jssj']);
        ajaxService.sendMessage("sunflower.p_selectaccountpositionchangerecord", message, $scope.p_selectaccountpositionchangerecordCallBack) ;
    }

    //侦听获取参数，并请求数据
    //console.log("侦听");
    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradesynthetical获取参数", _data.account);
        //console.log("tradesynthetical获取参数", _data.caption);
        //console.log("caption", _data.caption);
        if(_data.caption == "gtsyjyjl")
        {
            $scope.childaccount = _data.account;
            $scope.gettcjl();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradesynthetical侦听");
    var cstr  = {"caption": "gtsyjyjl"};
    $scope.$emit("getParameters", cstr);
    //console.log("账号", $scope.childaccount);

    //调仓日期点击显示隐藏
    $scope.tclssjShowClick = function(_obj)
    {
        //_obj.yfshow = !_obj.yfshow;
    }

    //查看行情
    $scope.jyjlhqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.gpmc);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;

        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        //alert(obj.stockcode + obj.exchange + obj.stockname);
        //alert("onestockHQHtml.html?opentype=newwebview");
        //window.location.href = "onestockHQHtml.html?opentype=newwebview";

        if($scope.htmlType == "share")
        {
            window.location.href = "onestockHQHtml.html?opentype=winlocbackhis";
        }
        else
        {
            openNewInterface("onestockHQHtml.html?opentype=newwebview");
        }

    }

}
