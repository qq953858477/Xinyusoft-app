function zhassetgtz()
{
     return {
         restrict: 'E',
         templateUrl: 'html/zh_asset_gtz.html',
         //template: '<span>Hi there</span>',
         replace: true,
         transclude: true
     };
}

function zh_asset_gtzCtrl($scope, ajaxService, $cookieStore) {
    $scope.cckyzj = 0;//可用资金
    $scope.cczzc = 0;//总资产
    $scope.cczsz = 0;//总市值
    $scope.ccljyk = 0;//总盈亏
    $scope.flag = "0";//盈亏色标志

    $scope.orderClumn = 'f_ljykbl';
    $scope.dqgtzArray = [];//当前跟投者中的产品信息
    $scope.dqgtbmArray = [];//当前跟投报名的产品信息

    $scope.refreshbtn = false;//刷新按钮是否显示

    $scope.zcmain = true;//资产界面
    $scope.zcrsyfxDivShow = false;//日收益分析

    $scope.ccrefreshintervalDuration = 5000;//间隔时间，5000毫秒;
    $scope.ccrefreshID;

    //去除
    $scope.ccrefreshClearInterval = function () {
        if ($scope.ccrefreshID != undefined) {
            clearInterval($scope.ccrefreshID);
        }
    }

    $scope.getzzcCallBack = function(_data)
    {
        //console.log("总资产", _data);
        //总资产
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.money;
            $scope.cczzc = parseFloat(arr.zzc.toString());
        }
    }

    $scope.getzzc = function()
    {
        //获取总资产
        var message = {};
        message['account'] = $scope.accountShowValue;
        //console.log("$scope.accountShowValue", $scope.accountShowValue);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.getzzcCallBack)
    }
    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("可用资金", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.money;
            $scope.cckyzj = parseFloat(arr.kyzj.toString());
            //$scope.cczzc = parseFloat(arr.zzc.toString());
            $scope.cczsz = parseFloat(arr.zsz.toString());
            //console.log("累计出入金",arr.ljcrj.toString());
            //$scope.ccljyk = parseFloat((parseFloat(arr.zzc.toString()) - parseFloat(arr.ljcrj.toString())).toFixed(2));
        }

    }

    $scope.getccinfo = function()
    {
        //获取资产信息
        var message = {};
        message['account'] = $scope.childaccount;
        //message['moneytype'] ="R";
        //console.log("可用资金：" ,  message['account']);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack) ;
    }

    $scope.wtList = [];
    $scope.showNodata = false;
    $scope.isLoading = true;
    $scope.query = function ()
    {
        $scope.showNodata = false;
        $scope.isLoading = true;

        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.childaccount;
        //message['combpositionid'] = "default";
        //console.log("持仓", $scope.childaccount);
        //$scope.wtList = [];
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            //console.log("持仓",result)
            $scope.wtList = [];
            if (result.op.code == 'Y')
            {
                $scope.ccljyk = parseFloat(result.ccyk.toString());
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = parseFloat(arr[i].dqj).toFixed(2);
                        obj.yk = arr[i].fdyk;
                        obj.zdf = parseFloat(arr[i].zdf).toFixed(2) + "%";
                        obj.cbj = parseFloat(arr[i].cbj);
                        var zdfv = parseFloat(parseFloat(arr[i].zdf).toFixed(2));
                        if(zdfv >0)
                        {
                            obj.zdfflag = "1";
                        }
                        else if(zdfv <0)
                        {
                            obj.zdfflag = "-1";
                        }
                        else
                        {
                            obj.zdfflag = "0";
                        }
                        if(parseFloat(obj.yk) >0)
                        {
                            obj.flag = "1";
                        }
                        else if(parseFloat(obj.yk) <0)
                        {
                            obj.flag = "-1";
                        }
                        else
                        {
                            obj.flag = "0";
                        }
                        obj.cz = "〉";
                        obj.asset = getzqStatus(arr[i].basetype);
                        obj.status = arr[i].status;
                        $scope.wtList.push(obj);
                    }
                    $scope.showNodata = false;
                    $scope.isLoading = false;
                } else {
                    $scope.showNodata = true;
                    $scope.isLoading = false;
                    $scope.wtList = [];
                }
            } else {
                $scope.showNodata = true;
                $scope.isLoading = false;
                $scope.wtList = [];
            }

            $scope.ccrefreshClearInterval();
            //console.log("状态：", $scope.tabOneShow);
            if($scope.tabOneShow)
            {
                $scope.ccrefreshID = setInterval($scope.zhqueryall, $scope.ccrefreshintervalDuration);
            }
        });
    };


    $scope.getdqgtzinfoCallBack = function(_data)
    {
        //console.log("跟投中的产品", _data);
        $scope.dqgtzArray = [];//跟投中：gt1 (B)； 解除中：gt2(C)； 已结束/未支付：gt3(D)； 已结束/已支付：gt4(E)
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkeduser.user.f_head;
                obj.username = arr[i].linkeduser.user.f_nickname;
                obj.userid = arr[i].linkeduser.user.f_id;//被跟投者的用户信息
                obj.linkaccount = arr[i].linkaccount;//当前跟投的账户
                obj.linkid = arr[i].id;
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.gtje = parseFloat(arr[i].money);
                obj.drsyl = (parseFloat(arr[i].linkaccountmoney.jrsy) * 100).toFixed(2);
                obj.ljyk = parseFloat(arr[i].linkaccountmoney.ljyk);
                if(arr[i].status.toString() == "B")
                {
                    obj.status = "gt1";
                }
                else if(arr[i].status.toString() == "C")
                {
                    obj.status = "gt2";
                }
                else if(arr[i].status.toString() == "D")
                {
                    obj.status = "gt3";//未支付
                }
                else if(arr[i].status.toString() == "E")
                {
                    obj.status = "gt4";//已结束
                }
                $scope.dqgtzArray.push(obj);
            }
        }
    }

    //跟投中的产品信息
    $scope.dqgtzinfo = function()
    {
        $scope.dqgtzArray = [];
        var message = {};
        message['account'] = "";
        message['productid'] = "";
        message['userid'] = "";
        message['linkoriginalaccount'] = $scope.accountShowValue;
        message['page.size'] = "max";
        message['page.no'] = "";
        //console.log("$scope.linkoriginalaccount", $scope.account);
        ajaxService.sendMessage("gentou.p_selectgentou", message, $scope.getdqgtzinfoCallBack);
    }

    $scope.p_selectgentouapplyCallBack = function(_data)
    {
        $scope.dqgtbmArray = [];
        //console.log("报名", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinkapplylist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkuser.user.f_head;
                obj.username = arr[i].linkuser.user.f_nickname;
                obj.userid = arr[i].linkuser.user.f_id;//被跟投者的用户信息
                obj.applyaccount = arr[i].applyaccount;//当前跟投报名的账户
                obj.applyid = arr[i].id;
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.gtje = parseFloat(arr[i].money);
                obj.bmjzsj = arr[i].endapplytimedesc;
                $scope.dqgtbmArray.push(obj);
            }
        }

    }

    $scope.dqgtbminfo = function()
    {
        var message = {};
        message['applyaccount'] = $scope.accountShowValue;
        //console.log(message);
        ajaxService.sendMessage("gentou.p_selectgentouapply", message, $scope.p_selectgentouapplyCallBack);
    }

    $scope.zhqueryall = function()
    {
        $scope.getzzc();
        $scope.getccinfo();
        $scope.query();
    }


    $scope.ccquery = function()
    {
        //console.log("获取信息");
        //获取资产信息
        $scope.getzzc();
        $scope.getccinfo();
        $scope.query();
        $scope.dqgtzinfo();
        $scope.dqgtbminfo();

        //console.log($scope.accountcompany);
        if($scope.accountcompany == "moni")
        {
            $scope.refreshbtn = false;
        }
        else
        {
            $scope.refreshbtn = true;
        }
    }

    $scope.$on("setParameters", function(e, _data) {
        //console.log("tradequery获取参数", _data.account);
        //console.log(_data.caption);
        if(_data.caption == "zh_asset_gtz")
        {
            //console.log(12132, _data.account);
            $scope.childaccount = _data.account;
            $scope.ccquery();
        }
    });

    //向父对象说明已经侦听，可以接受入参
    //console.log("tradequery侦听");
    var cstr  = {"caption": "zh_asset_gtz"};
    $scope.$emit("getParameters", cstr);

    //$scope.zhinit = function(newValue, oldValue, scope) {
    //    //console.log("me", newValue, oldValue);
    //    if (newValue) {
    //        console.log(111111111);
    //        $scope.ccquery();
    //    }
    //}
    //$scope.$watch('tabOneShow', $scope.zhinit);

    //跟投者
    $scope.gtItemClick = function(_obj)
    {
        if(_obj.status == "gt1")
        {
            setbackList(window.location.href);
            window.location = "gt_fwz_gtz.html?linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
        else  if(_obj.status == "gt2")
        {
            setbackList(window.location.href);
            window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
        else if(_obj.status == "gt3"||_obj.status == "gt4")
        {
            setbackList(window.location.href);
            window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.userid;
        }
    }

    //报名
    $scope.gtbmItemClick = function(_obj)
    {
        setbackList(window.location.href);
        window.location = "gt_ybm.html?productid=" + _obj.productid + "&&applyid=" + _obj.applyid + "&&bgtuserid=" +_obj.userid;
    }

    //查看行情
    $scope.hqclick = function(_obj)
    {
        var obj = {};
        obj.stockcode = _obj.stockcode;
        obj.stockname = encodeURIComponent(_obj.stockname);
        obj.exchange = _obj.exchange.toString().toLowerCase();
        obj.asset = _obj.asset;
        obj.account = $scope.childaccount;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));

        //window.location.href = "onestockHQHtml.html?opentype=newwebview";
        //xinyuNewBrowser("onestockHQHtml.html?opentype=newwebview");
        //window.location.href = "tradinglive_info.html";
        openNewInterface("tradinglive_info.html?opentype=newwebview");
    }

    //数据刷新
    $scope.refreshClick = function()
    {
        var message = {};
        message['account'] = $scope.accountShowValue;//主账号
        ajaxService.sendMessage("counter.synctradeaccountaction", message, $scope.synctradeaccountactionCallBack);
    }

    $scope.synctradeaccountactionCallBack = function(_data)
    {
        //console.log("刷新", _data);
        $scope.ccquery();
    }

    //日收益分析
    $scope.gotorsyfx = function()
    {
        $scope.zcmain = false;//资产界面
        $scope.zcrsyfxDivShow = true;//日收益分析
        $scope.zcgetrsyfx();
    }

    $scope.zcgetrsyfx = function()
    {
        $scope.sytjfxArray = [];

        var message = {};
        message['account'] = $scope.accountShowValue;
        message['kssj'] = "";
        message['jssj'] = gettodayno();
        //console.log("收益分析 sunflower.getSytjAction",$scope.childaccount, message['kssj']);
        ajaxService.sendMessage("sunflower.getSytjAction", message, $scope.p_selecthissecuritymoneyCallBack) ;
    }

    $scope.p_selecthissecuritymoneyCallBack = function(_data)
    {
        $scope.sytjfxArray = [];
        //console.log("收益分析222233", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.sytj;
            //var syarr = [];
            for (var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.date = arr[i].mon.toString();
                var str2 = obj.date.substr(4,2);
                if(str2.substr(0,1) == "0")
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2.substr(1,1) + "月";
                }
                else
                {
                    obj.nyShow = obj.date.substr(0,4) + "年" + str2 + "月";
                }
                obj.sy = parseFloat(arr[i].monsy);
                obj.syl = parseFloat(arr[i].monsyl)*100;
                if(obj.syl > 0)
                {
                    obj.flag = "1";
                }
                else if(obj.syl <0)
                {
                    obj.flag = "-1";
                }
                else
                {
                    obj.flag = "0";
                }
                obj.yfshow = false;//是否展开 0：展开，1：不展开 ，界面显示用
                obj.changemoney = parseFloat(arr[i].monchangemoney);

                var arr2 = [];
                var arr3 = arr[i].daylist;
                for(var j = 0;j<arr3.length;j++)
                {
                    var obj2 = {};
                    var str2 = arr3[j].day.toString().substr(6,2);
                    if(str2.substr(0,1) == "0")
                    {
                        obj2.showdate = str2.substr(1,1) + "日";
                    }
                    else
                    {
                        obj2.showdate = str2 + "日";
                    }
                    obj2.sy = parseFloat(arr3[j].sy);
                    obj2.syl = parseFloat(arr3[j].syl)*100;
                    if(obj2.syl > 0)
                    {
                        obj2.flag = "1";
                    }
                    else if(obj2.syl <0)
                    {
                        obj2.flag = "-1";
                    }
                    else
                    {
                        obj2.flag = "0";
                    }
                    obj2.sj = arr3[j].day.toString();
                    obj2.changemoney = parseFloat(arr3[j].changemoney);

                    arr2.push(obj2);
                }
                obj.dataArr = arr2;
                $scope.sytjfxArray.push(obj);

            }
            if($scope.sytjfxArray.length>0)
            {
                var todayvalue = new Date();
                var yearstr = todayvalue.getFullYear().toString();
                var monthstr = (todayvalue.getMonth() + 1).toString();
                if(monthstr.length == 1)
                {
                    monthstr = "0" + monthstr;
                }
                var todaystr =  yearstr + monthstr;
                var mark = false;
                for(var i = 0;i<$scope.sytjfxArray.length;i++)
                {
                    //console.log($scope.sytjfxArray[i].date, todaystr);
                    if($scope.sytjfxArray[i].date == todaystr)
                    {
                        $scope.sytjfxArray[i].yfshow = true;//打开当前月份
                        mark = true;
                        break;
                    }
                }
                if(mark == false)
                {
                    $scope.sytjfxArray[0].yfshow = true;//打开第一个月份
                }

            }
        }
    }

    $scope.zcrsyfxbackto = function()
    {
        $scope.zcmain = true;//资产界面
        $scope.zcrsyfxDivShow = false;//日收益分析
    }

    //收益分析月份点击
    $scope.yfShowClick = function(_obj)
    {
        _obj.yfshow = !_obj.yfshow;
    }

    //日收益分析详情
    $scope.rsyfxItem = function(_obj)
    {
        //console.log(_obj.sj);
        //setbackList(window.location.href);
        //window.location.href = "rsyfxinfo.html?account=" + $scope.childaccount + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate);
        openNewInterface("rsyfxinfo.html?account=" + $scope.accountShowValue + "&kssj=" + _obj.sj + "&jssj=" + _obj.sj + "&datestr=" + encodeURI(_obj.showdate) + "&opentype=newwebview");
    }

    //买卖
    $scope.buysellClick = function(_obj)
    {
        //console.log("cdcad");
        //window.location.href = "tradeBase_buysell.html?account=" + $scope.childaccount + "&accountcompany=" + $scope.accountcompany + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.accountzqgs) + "&tradetype=" + _tradetype + "&stock=" + _obj.stockcodeall;
        openNewInterface("tradeBase_buysell.html?account=" + $scope.childaccount + "&accountcompany=" + $scope.accountcompany + "&accountShow=" + $scope.accountShowValue + "&accountName=" + encodeURI($scope.accountzqgs) + "&stock=" + _obj.stockcodeall + "&isbgt=1&opentype=newwebview");
    }

}
