/**
 * Created by qw1 on 2014/12/7.
 */
var addNewStockPoolModule = angular.module('addNewStockPoolApp',['ngCookies','ngTouch']);
addNewStockPoolModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
addNewStockPoolModule.controller('addNewStockPoolCtrl',['$scope','ajaxService', '$cookieStore', addNewStockPoolCtrl]);

addNewStockPoolModule.run(function() {
    document.getElementById("addNewStockPoolMain").style.display = "";
});


angular.element(document).ready(function() {
    angular.bootstrap(document, ['addNewStockPoolApp']);
});