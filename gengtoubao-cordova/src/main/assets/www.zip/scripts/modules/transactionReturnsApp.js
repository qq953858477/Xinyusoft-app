/**
 * Created by qw1 on 2014/12/7.
 */
var transactionReturnsModule = angular.module('transactionReturnsApp',['ngCookies']);
transactionReturnsModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//myFinancialBaseModule.directive('autohq', autohq);
/** 控制器*/
transactionReturnsModule.controller('transactionReturnsCtrl',['$scope','ajaxService', '$cookieStore', transactionReturnsCtrl]);


/**过滤器*/
transactionReturnsModule.filter('numberFormatFilter', numberFormatFilter);

transactionReturnsModule.run(function() {
    document.getElementById("transactionReturnsMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['transactionReturnsApp']);
});
