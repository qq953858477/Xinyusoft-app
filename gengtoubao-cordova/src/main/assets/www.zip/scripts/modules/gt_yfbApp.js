/**
 * Created by qw1 on 2014/12/7.
 */
var gt_yfbModule = angular.module('gt_yfbApp',['ngCookies','ngTouch']);
gt_yfbModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//gt_yfbModule.directive('lcsinfo', lcsinfo);
gt_yfbModule.directive('gtsypl', gtsypl);
/** 控制器*/
//gt_yfbModule.controller('lcs_infoCtrl',['$scope','ajaxService', '$cookieStore', lcs_infoCtrl]);
gt_yfbModule.controller('gtsyplCtrl',['$scope','ajaxService', '$cookieStore', gtsyplCtrl]);
gt_yfbModule.controller('gt_yfbCtrl',['$scope','ajaxService', '$cookieStore', gt_yfbCtrl]);

/**过滤器*/
gt_yfbModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_yfbMain").style.display = "";
}

gt_yfbModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_yfbApp']);
});
