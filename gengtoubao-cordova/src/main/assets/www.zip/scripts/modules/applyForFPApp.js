/**
 * Created by qw1 on 2014/12/7.
 */
var applyForFPModule = angular.module('applyForFPApp',['ngCookies','ngTouch']);
applyForFPModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
applyForFPModule.controller('applyForFPCtrl',['$scope','ajaxService', '$cookieStore', applyForFPCtrl]);


applyForFPModule.run(function() {
    document.getElementById("appffpMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['applyForFPApp']);
});