/**
 * Created by qw1 on 2015/4/17.
 */
var gtStockPoolModule = angular.module('gtStockPoolApp',['ngCookies','ngTouch']);
gtStockPoolModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
gtStockPoolModule.controller('gtStockPoolCtrl',['$scope','ajaxService', '$cookieStore', gtStockPoolCtrl]);


/**过滤器*/
gtStockPoolModule.filter('numberFormatFilter',numberFormatFilter);

gtStockPoolModule.run(function() {
    document.getElementById("gtStockPoolmain").style.display = "";
});


angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtStockPoolApp']);
});