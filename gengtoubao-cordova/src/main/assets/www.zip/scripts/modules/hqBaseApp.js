/**
 * Created by qw1 on 2014/12/7.
 */
var hqBaseModule = angular.module('hqBaseApp',['ngCookies','ngTouch']);
hqBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
hqBaseModule.directive('indexbase', indexbase);
hqBaseModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
hqBaseModule.controller('hqBaseCtrl',['$scope','ajaxService', '$cookieStore',hqBaseCtrl]);

/**过滤器*/
hqBaseModule.filter('numberFormatFilter', numberFormatFilter);


hqBaseModule.run(function() {
    document.getElementById("hqBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['hqBaseApp']);
});
