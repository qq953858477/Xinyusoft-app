/**
 * Created by qw1 on 2014/12/7.
 */
var oneStockHQBaseModule = angular.module('oneStockHQBaseApp',['ngCookies']);
oneStockHQBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
//oneStockHQBaseModule.controller('oneStockHQBaseCtrl',['$scope','ajaxService', '$cookieStore', oneStockHQBaseCtrl]);

/**过滤器*/
oneStockHQBaseModule.filter('numberFormatFilter', numberFormatFilter);

oneStockHQBaseModule.run(function() {
    //document.getElementById("oneStockHQBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['oneStockHQBaseApp']);
});
