/**
 * Created by qw1 on 2014/12/7.
 */
var gt_shareModule = angular.module('gt_shareApp',['ngCookies','ngTouch']);
gt_shareModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
gt_shareModule.directive('gtsykykwccshare', gtsykykwccshare);
gt_shareModule.directive('gtsyjyjl', gtsyjyjl);
gt_shareModule.directive('gtsyntheticalwccshare', gtsyntheticalwccshare);
gt_shareModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);

/** 控制器*/
gt_shareModule.controller('gtsyntheticalwccshareCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalwccshareCtrl]);
gt_shareModule.controller('gt_shareCtrl',['$scope','ajaxService', '$cookieStore', gt_shareCtrl]);
gt_shareModule.controller('gtsykykwccshareCtrl',['$scope','ajaxService', '$cookieStore', gtsykykwccshareCtrl]);
gt_shareModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);

/**过滤器*/
gt_shareModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_shareMain").style.display = "";
}

gt_shareModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_shareApp']);
});
