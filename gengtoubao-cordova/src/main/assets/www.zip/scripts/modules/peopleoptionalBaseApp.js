/**
 * Created by qw1 on 2014/12/7.
 */
var peopleoptionalBaseModule = angular.module('peopleoptionalBaseApp',['ngCookies']);
peopleoptionalBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
peopleoptionalBaseModule.directive('onestockhqbase', onestockhqbase);
peopleoptionalBaseModule.directive('indexbase', indexbase);
peopleoptionalBaseModule.controller('peopleoptionalBaseCtrl',['$scope','ajaxService', '$cookieStore',peopleoptionalBaseCtrl]);

/**过滤器*/
peopleoptionalBaseModule.filter('numberFormatFilter', numberFormatFilter);


peopleoptionalBaseModule.run(function() {
    document.getElementById("peopleoptionalBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['peopleoptionalBaseApp']);
});
