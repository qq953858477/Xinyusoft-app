/**
 * Created by qw1 on 2014/12/7.
 */
var tradeBase_gtzModule = angular.module('tradeBase_gtzApp',['ngCookies', 'ngRoute','ngTouch']);
tradeBase_gtzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
tradeBase_gtzModule.directive('autohq', autohq);

tradeBase_gtzModule.directive('zhassetgtz', zhassetgtz);
tradeBase_gtzModule.directive('tradeinfowgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_info_wgt.html',
        controller:['$scope','ajaxService','$cookieStore',tradeinfowgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});
tradeBase_gtzModule.directive('tradequerywgt', function()
{
    return {
        restrict: 'E',
        templateUrl: 'html/trade_query_wgt.html',
        controller:['$scope','ajaxService','$cookieStore', tradequerywgtCtrl],
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true
    }
});

tradeBase_gtzModule.controller('zh_asset_gtzCtrl',['$scope','ajaxService', '$cookieStore', zh_asset_gtzCtrl]);
tradeBase_gtzModule.controller('tradeinfowgtCtrl',['$scope','ajaxService', '$cookieStore', tradeinfowgtCtrl]);
tradeBase_gtzModule.controller('tradequerywgtCtrl',['$scope','ajaxService', '$cookieStore', tradequerywgtCtrl]);

/** 控制器*/
tradeBase_gtzModule.controller('tradeBase_gtzCtrl',['$scope','ajaxService', '$cookieStore', tradeBase_gtzCtrl]);
/**空白 控制器*/
tradeBase_gtzModule.controller('emptyCtrl',['$scope', 'ajaxService', '$cookieStore', emptyCtrl]);
/** 控制器*/
tradeBase_gtzModule.controller('buysellwgtCtrl',['$scope','ajaxService', '$cookieStore', buysellwgtCtrl]);
/**撤单 控制器*/
tradeBase_gtzModule.controller('cancellationCtrl',['$scope', 'ajaxService', '$cookieStore', cancellationCtrl]);
/**预埋单 控制器*/
tradeBase_gtzModule.controller('prepaywgtCtrl',['$scope', 'ajaxService', '$cookieStore', prepaywgtCtrl]);

/**银证转账 控制器*/
tradeBase_gtzModule.controller('yzzzCtrl',['$scope', 'ajaxService', '$cookieStore', yzzzCtrl]);
/**一键清仓 控制器*/
tradeBase_gtzModule.controller('yjqcwgtCtrl',['$scope', 'ajaxService', '$cookieStore', yjqcwgtCtrl]);
/**一键建仓调仓 控制器*/
tradeBase_gtzModule.controller('yjjctcwgtCtrl',['$scope', 'ajaxService', '$cookieStore', yjjctcwgtCtrl]);



/**持仓 控制器*/
//tradeBaseModule.controller('cccxCtrl',['$scope', 'ajaxService', '$cookieStore',
//    function($scope, ajaxService, $cookieStore) {
//        console.log("查询持仓2222");
//    }
//])

tradeBase_gtzModule.controller('cccxwgtCtrl',['$scope', 'ajaxService', '$cookieStore', cccxwgtCtrl]);
/**当日成交 控制器*/
tradeBase_gtzModule.controller('drcjCtrl',['$scope', 'ajaxService', '$cookieStore', drcjCtrl]);
/**当日委托 控制器*/
tradeBase_gtzModule.controller('drwtCtrl',['$scope', 'ajaxService', '$cookieStore', drwtCtrl]);
/**历史成交 控制器*/
tradeBase_gtzModule.controller('lscjCtrl',['$scope', 'ajaxService', '$cookieStore', lscjCtrl]);
/**历史委托 控制器*/
tradeBase_gtzModule.controller('lswtCtrl',['$scope', 'ajaxService', '$cookieStore', lswtCtrl]);
/**历史资金流水 控制器*/
tradeBase_gtzModule.controller('lszjlsCtrl',['$scope', 'ajaxService', '$cookieStore', lszjlsCtrl]);




/**过滤器*/
tradeBase_gtzModule.filter('numberFormatFilter',numberFormatFilter);

/**路由管理器*/
tradeBase_gtzModule.
    config(['$routeProvider', function($routeProvider) {
        $routeProvider.
            when('/buysell', {templateUrl: 'views/buysell_wgt.html', controller: 'buysellwgtCtrl'}).
            when('/cancellation', {templateUrl: 'views/cancellation.html', controller: 'cancellationCtrl'}).
            when('/prepay', {templateUrl: 'views/prepay_wgt.html', controller: 'prepaywgtCtrl'}).
            when('/yjqc', {templateUrl: 'views/yjqc_wgt.html', controller: 'yjqcwgtCtrl'}).
            when('/yjjctc', {templateUrl: 'views/yjjctc_wgt.html', controller: 'yjjctcwgtCtrl'}).
            when('/yzzz', {templateUrl: 'views/yzzz.html', controller: 'yzzzCtrl'}).

            when('/cccx', {templateUrl: 'views/cccx_wgt.html', controller: 'cccxwgtCtrl'}).
            when('/drcj', {templateUrl: 'views/drcj.html', controller: 'drcjCtrl'}).
            when('/drwt', {templateUrl: 'views/drwt.html', controller: 'drwtCtrl'}).
            when('/lscj', {templateUrl: 'views/lscj.html', controller: 'lscjCtrl'}).
            when('/lswt', {templateUrl: 'views/lswt.html', controller: 'lswtCtrl'}).
            when('/lszjls', {templateUrl: 'views/lszjls.html', controller: 'lszjlsCtrl'}).
            otherwise({redirectTo: '/empty'});
    }]);


tradeBase_gtzModule.run(function() {
    document.getElementById("tradeBase_gtzMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['tradeBase_gtzApp']);
});
