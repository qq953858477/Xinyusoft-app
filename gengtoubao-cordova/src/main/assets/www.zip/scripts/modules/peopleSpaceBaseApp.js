var peopleSpaceBaseModule = angular.module('peopleSpaceBaseApp',['ui.router','infinite-scroll','ngCookies']);
//var peopleSpaceBaseModule = angular.module('peopleSpaceBaseApp',['ui.router','infinite-scroll','ngCookies']);

peopleSpaceBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

peopleSpaceBaseModule.directive('persongtinfo', persongtinfo);
//peopleSpaceBaseModule.directive('indexbase', indexbase);
//peopleSpaceBaseModule.directive('onestockhqbase', onestockhqbase);
//peopleSpaceBaseModule.directive('peopleoptional', peopleoptional);
//peopleSpaceBaseModule.directive('onepersonchart', onepersonchart);
peopleSpaceBaseModule.directive('onepersonchart',function(){
    return {
        restrict: 'E',
        templateUrl: 'onePersonWin.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: onePersonWinCtrl
    };
});

//peopleSpaceBaseModule.directive('jiepanrelativedir', jiepanrelativedir);
//peopleSpaceBaseModule.directive('jiepanrelativedir',function(){
//    return {
//        restrict: 'E',
//        templateUrl: 'jiepan_relative_directive.html',
//        //template: '<span>Hi there</span>',
//        replace: true,
//        transclude: true
//    };
//});


/** 控制器*/

peopleSpaceBaseModule.controller('person_gt_infoCtrl',['$scope','ajaxService', '$cookieStore', person_gt_infoCtrl]);
peopleSpaceBaseModule.controller('peopleSpaceBaseCtrl',['$scope','ajaxService', '$cookieStore', peopleSpaceBaseCtrl]);
//peopleSpaceBaseModule.controller('peopleoptionalBaseCtrl',['$scope','ajaxService', '$cookieStore',peopleoptionalBaseCtrl]);
peopleSpaceBaseModule.controller('onePersonWinCtrl',['$scope','ajaxService', '$cookieStore','$sce',onePersonWinCtrl]);

/**过滤器*/
peopleSpaceBaseModule.filter('numberFormatFilter', numberFormatFilter);

//peopleSpaceBaseModule.run(function()
//{
//    document.getElementById("peopleSpaceBaseMain").style.display = "";
//});

peopleSpaceBaseModule.run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            //document.getElementById("jiepanApp").style.display = "";
            //FastClick.attach(document.body);
            document.getElementById("peopleSpaceBaseMain").style.display = "";
        }
    ]

);

peopleSpaceBaseModule.factory('jpajaxService', ['$http', jpajaxService]);
peopleSpaceBaseModule.factory('tabService', ['$stateParams', '$location', '$state', tabService]);
/** 控制器*/
peopleSpaceBaseModule.controller('jiepanMainCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanMainCtrl]);
peopleSpaceBaseModule.controller('jiepanListCtrl', ['$scope', 'jpajaxService', 'tabService', jiepanListCtrl]);

peopleSpaceBaseModule.directive('relative', function () {
    return {
        restrict: 'E',
        templateUrl: 'template/relativeTemp.html',
        //template: '<span>Hi there</span>',
        replace: true,
        transclude: true,
        controller: jiepanMainCtrl
    }
})
//peopleSpaceBaseModule.directive('jiepanrelativedir',function(){
//    return {
//        restrict: 'E',
//        templateUrl: 'jiepan_relative_directive.html',
//        //template: '<span>Hi there</span>',
//        replace: true,
//        transclude: true
//    };
//});

//行情
peopleSpaceBaseModule.directive('jponestockhqbase', jponestockhqbase);

peopleSpaceBaseModule.filter('dateFilter', function () {
    return function (dateInput) {
        //2015-08-21 15:06:59.0
        var returndate = '';
        returndate = dateInput.substr(0, dateInput.length - 5);
        return returndate;

    }

});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['peopleSpaceBaseApp']);
});


