/**
 * Created by qw1 on 2014/12/7.
 */
var jtBaseModule = angular.module('jtBaseApp',['ngCookies']);
jtBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
jtBaseModule.controller('jtBaseCtrl',['$scope','ajaxService', '$cookieStore', jtBaseCtrl]);


/**过滤器*/
jtBaseModule.filter('numberFormatFilter', numberFormatFilter);

jtBaseModule.run(function() {
    document.getElementById("jtBaseMain").style.display = "";
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['jtBaseApp']);
});
