/**
 * Created by qw1 on 2014/12/7.
 */
var gt_fwz_fbzModule = angular.module('gt_fwz_fbzApp',['ngCookies','ngTouch']);
gt_fwz_fbzModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
//gt_fwz_fbzModule.factory('hintSerivce',['$rootScope', hintSerivce]);

gt_fwz_fbzModule.directive('gtsyntheticalyccfw', gtsyntheticalyccfw);
gt_fwz_fbzModule.directive('gtsyccfw', gtsyccfw);
gt_fwz_fbzModule.directive('gtsyjrjyjl', gtsyjrjyjl);
gt_fwz_fbzModule.directive('gtsyjyjl', gtsyjyjl);
gt_fwz_fbzModule.directive('gtplshow', gtplshow);
gt_fwz_fbzModule.directive('gtplinput', gtplinput);
gt_fwz_fbzModule.directive('gtsysyt', gtsysyt);
gt_fwz_fbzModule.directive('hqbaseonestockhqbase', hqbaseonestockhqbase);
/** 控制器*/
gt_fwz_fbzModule.controller('gtsyccfwCtrl',['$scope','ajaxService', '$cookieStore', gtsyccfwCtrl]);
gt_fwz_fbzModule.controller('gtsyjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjyjlCtrl]);
gt_fwz_fbzModule.controller('gtsysytCtrl',['$scope','ajaxService', '$cookieStore', gtsysytCtrl]);
gt_fwz_fbzModule.controller('gtsyjrjyjlCtrl',['$scope','ajaxService', '$cookieStore', gtsyjrjyjlCtrl]);
gt_fwz_fbzModule.controller('gtplshowCtrl',['$scope','ajaxService', '$cookieStore', gtplshowCtrl]);
gt_fwz_fbzModule.controller('gtplinputCtrl',['$scope','ajaxService', '$cookieStore', gtplinputCtrl]);
gt_fwz_fbzModule.controller('gtsyntheticalyccfwCtrl',['$scope','ajaxService', '$cookieStore', gtsyntheticalyccfwCtrl]);
//gt_fwz_fbzModule.controller('gt_fwz_fbzCtrl',['$scope','ajaxService', '$cookieStore','hintService', gt_fwz_fbzCtrl]);
gt_fwz_fbzModule.controller('gt_fwz_fbzCtrl',['$scope','ajaxService', '$cookieStore','$sce', gt_fwz_fbzCtrl]);

/**过滤器*/
gt_fwz_fbzModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gt_fwz_fbzMain").style.display = "";
}

gt_fwz_fbzModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gt_fwz_fbzApp']);
});
