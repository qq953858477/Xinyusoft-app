/**
 * Created by qw1 on 2014/12/7.
 */
var indexBaseModule = angular.module('indexBaseApp',['ngCookies']);
indexBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
indexBaseModule.controller('indexBaseCtrl',['$scope','ajaxService', '$cookieStore', indexBaseCtrl]);

/**过滤器*/
indexBaseModule.filter('numberFormatFilter', numberFormatFilter);

//indexBaseModule.run(function() {
//    document.getElementById("indexBaseMain").style.display = "";
//});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['indexBaseApp']);
});
