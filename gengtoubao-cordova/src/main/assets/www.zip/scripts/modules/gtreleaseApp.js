/**
 * Created by qw1 on 2014/12/7.
 */
var gtreleaseModule = angular.module('gtreleaseApp',['ngCookies']);
gtreleaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);
/** 控制器*/
gtreleaseModule.controller('gtreleaseCtrl',['$scope','ajaxService', '$cookieStore', gtreleaseCtrl]);

/**过滤器*/
gtreleaseModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("gtreleaseMain").style.display = "";
}

gtreleaseModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['gtreleaseApp']);
});
