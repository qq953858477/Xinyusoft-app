/**
 * Created by qw1 on 2014/12/7.
 */
var newfpBaseModule = angular.module('newfpBaseApp',['ngCookies']);
newfpBaseModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

/** 控制器*/
newfpBaseModule.controller('newfpBaseCtrl',['$scope','ajaxService', '$cookieStore', newfpBaseCtrl]);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("newfpBaseMain").style.display = "";
}

/**过滤器*/
newfpBaseModule.filter('numberFormatFilter', numberFormatFilter);

newfpBaseModule.run(function() {
    //document.getElementById("newfpBaseMain").style.display = "";
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['newfpBaseApp']);
});
