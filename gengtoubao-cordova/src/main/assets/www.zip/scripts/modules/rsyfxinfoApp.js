/**
 * Created by qw1 on 2014/12/7.
 */
var rsyfxinfoModule = angular.module('rsyfxinfoApp',['ngCookies','ngTouch']);
rsyfxinfoModule.factory('ajaxService',['$rootScope', '$http', '$cookieStore',ajaxService]);

/** 控制器*/
rsyfxinfoModule.controller('rsyfxinfoCtrl',['$scope','ajaxService', '$cookieStore', rsyfxinfoCtrl]);

/**过滤器*/
rsyfxinfoModule.filter('numberFormatFilter', numberFormatFilter);

var intervalDuration = 50;//间隔时间，100
var intervalId;
dscl = function()
{
    if (intervalId != undefined)
    {
        clearInterval(intervalId);
    }
    document.getElementById("rsyfxinfoMain").style.display = "";
}

rsyfxinfoModule.run(function() {
    intervalId = setInterval(dscl, intervalDuration);
});

angular.element(document).ready(function() {
    angular.bootstrap(document, ['rsyfxinfoApp']);
});
