var jsonp = true;
var jsonpUrl = "http://www.xinyusoft.com:8085/uuFinancialPlanner/JSONP";//真实环境
//var jsonpUrl = "http://120.26.117.113:8080/uuFinancialPlanner/JSONP";//测试环境
//var jsonpUrl = "http://test.xinyusoft.com:8080/uuFinancialPlanner/JSONP";//测试环境

//var jsonpUrl = "http://www.xinyusoft.com:8085/uuFinancialPlanner/JSONP";
//var jsonpUrl = "http://180.166.77.54:64888/JSONP";
//var jsonpUrl = "http://127.0.0.1:8080/JSONP";
//var jsonUrl = "http://218.93.10.245:18080/JSONP";
function ajaxService($rootScope, $http, $cookieStore) {
    var isFirst = true;
    var checkSystemInterval = null;

    var queryList = {};
    var queryList1 = {};

    $http.defaults.transformResponse = function(data,head)
    {
        if (angular.isString(data) && data.indexOf("<")==-1)
        {
            try{
            var str = "d,";
            data = data.replace(eval("/"+str+"/gi"), ",");

            str = "d}";
             data = data.replace(eval("/"+str+"/gi"), "}");
              str = "d]";
             data = data.replace(eval("/"+str+"/gi"), "]");
            data = eval("eval("+data+")");
            }catch(e)
            {
                console.error(e+"\r\n解析出错，数据源为\r\n"+data);
            }
        }
        return data;
    }

    var checkSystem = function () {
      if (!checkSystemInterval)
      {
        checkSystemInterval = setInterval(function(){
          send("counter.GetSystemStatusAction",{},function(data){},true);
        },60*1000);

      }
    }

    var send = function (action, message, callback, async) {

        //var sessionId = $cookieStore.get("sessionid");
        var localStorage = window.localStorage;
        var sessionId = localStorage.getItem("sessionid");
        if (sessionId != null && typeof(sessionId) != 'undefined' && sessionId.length != 0) {
            message["session.id"] = sessionId;//sessionId;
        }
        message["command"] = action;

        //console.log("action", action);

        var par = {};
        for (var key in message) {
            par[key + ""] = encodeURI(encodeURI(message[key + ""]))
        }

        if (jsonp) {
            //myUrl = jsonpUrl+"?callback=JSON_CALLBACK";
            myUrl = jsonpUrl + "?rmd="+new Date().getTime()+"&shopid=-1&callback=JSON_CALLBACK";
            var requestUrl = "";
            for (var key in message) {
                myUrl += ("&" + key + "=" + encodeURI(encodeURI(encodeURI(message[key + ""]))));
                requestUrl += ("&" + key + "=" + encodeURI(encodeURI(encodeURI(message[key + ""]))));
            }
            queryList[action+"#$$#"+JSON.stringify(message)] = callback;
            queryList1[callback] = action+"#$$#"+JSON.stringify(message);
            //console.log(queryList);
            //console.log("地址", myUrl);
            var obj = $http.jsonp(myUrl).success(
                function (data)
                {
                  if(data.op.code == 'upgrading') {

                  //  if(true) {
                    var upgradingDiv = document.getElementById("upgrading");
                    if (!upgradingDiv) {
                      // 升级div浮层不存在
                        var bodyHeight = window.innerHeight;
                        var bodyWidth = window.innerWidth;
                      upgradingDiv = document.createElement("div");
                      upgradingDiv.id = "upgrading";
                      upgradingDiv.style.position = 'fixed';
                      upgradingDiv.style.zIndex = 99999;
                      upgradingDiv.style.backgroundImage = "url(images/qd.png)";
                      upgradingDiv.style.backgroundRepeat = "no-repeat";
                      upgradingDiv.style.backgroundSize = "100%";
                      upgradingDiv.style.top = 0;
                      upgradingDiv.style.left = 0 ;
                      upgradingDiv.style.width = bodyWidth + "px";
                      upgradingDiv.style.height = bodyHeight + "px";
                        //upgradingDiv.width = "100%";
                        //upgradingDiv.height ="100%";

                      document.body.appendChild(upgradingDiv);

                      // var upgradingImg = document.createElement("img");
                      // upgradingImg.src = "images/qd.png";
                      // upgradingImg.style.width = bodyWidth + "px";
                      // upgradingImg.style.height = bodyHeight + "px";
                      // upgradingDiv.appendChild(upgradingImg);

                        var contentDiv = document.createElement("h2");
                        contentDiv.style.fontSize = "18px";
                        contentDiv.style.width = bodyWidth + "px";
                        contentDiv.style.color = "#FFFFFF";
                        contentDiv.style.textAlign = "center";
                        contentDiv.style.marginTop = bodyHeight * 0.8 + "px";
                        contentDiv.innerHTML = "系统升级中，请稍候...";

                      upgradingDiv.appendChild(contentDiv);

                      checkSystem();

                  }
                }else{
                      queryList[queryList1[callback]] = null;
                  var upgradingDiv = document.getElementById("upgrading");
                  if (upgradingDiv) {
                      // 删除元素
                      document.body.removeChild(upgradingDiv);
                      // 停止定时器
                      if (checkSystemInterval)
                      {
                        clearInterval(checkSystemInterval);
                        checkSystemInterval = null;
                          //console.log(queryList);
                          //window.location.reload();
                          for ( var i in queryList) {
                              var _cb = queryList[i];
                              if(_cb != null)
                              {
                                  var _action = i.split("#$$#")[0];
                                  var _message = i.split("#$$#")[1];
                                  //console.log("send after upgrading "+_action +" "+_message);
                                  send(_action,JSON.parse(_message),_cb,false);
                              }
                          }
                      }
                  }

                      try{
                          callback(data);
                      }catch (e)
                      {}
                    };
                }

            );
        }
        else {
            $http({method: 'post', url: 'ESBServlet', params: par})
                .success(function (data, status, headers, config) {
                    //console.log(data);
                    //alert(data);
                    if (data.op.errortype != null && data.op.errortype == 'nologin') {
                        //TODO:可弹出框登录
                        //window.location.href = "login.html";
                    } else {
                        callback(data);
                    }
                });
        }
    };


    return {
        sendMessage: function (action, message, callback, async) {
            //console.log(message.toString());
            message['randomcode']= Math.random(10000);
            send(action, message, callback, async);
        },

        sendMessageForGrid: function (action, message, callback, gridData) {

            $rootScope.$broadcast('statuschange', {'data': gridData, 'gridstatus': '--- 正 在 加 载 ---'});
            send(action, message, function (data) {

                    var isEmptyData = false;
                    for (d in data) {
                        if (data[d] && data[d].length == 0) {
                            isEmptyData = true;
                            break;
                        }
                    }

                    if (data.page&&data.page.totalcount==0)
                    {
                        isEmptyData = true;
                    }

                    if (isEmptyData) {
                        $rootScope.$broadcast('statuschange', {'data': gridData, 'gridstatus': '--- 暂 无 数 据 ---'});
                    }
                    callback(data);
                },
                true);
        },

        exportExcel: function (name, columnDefs, data) {
            var par = {};
            par['name'] = encodeURI(encodeURI(name));
            var _head = "";
            var _data = "";
            var headField = [];
            angular.forEach(columnDefs, function (value, key) {
                _head += value['displayName'] + "|";
                headField.push(value['field']);
            });
            _head = _head.substring(0, _head.length - 1);

            angular.forEach(data, function (value, key) {
                angular.forEach(headField, function (_v, _k) {
                    var s = "";
                    if (_v.indexOf(".") != -1) {
                        var t = _v.split(".");
                        s = value[t[0]][t[1]];
                    }
                    else {
                        s = value[_v];
                    }

                    if (angular.isUndefined(s)) {
                        _data += "|";
                    }
                    else {
                        _data += (s + "|");
                    }
                });
                _data = _data.substring(0, _data.length - 1);
                _data += "|;"
            });

            _data = _data.substring(0, _data.length - 2);

            par['head'] = encodeURI(encodeURI(_head));
            par['data'] = encodeURI(encodeURI(_data));

            angular.element(".forExport").remove();

            var form = angular.element("<form class=\"forExport\">");   //定义一个form表单

            form.attr('style', 'display:none');   //在form表单中添加查询参数

            form.attr('target', '');

            form.attr('method', 'post');

            form.attr('action', "ExportExcel");


            var input1 = angular.element('<input>');

            input1.attr('type', 'hidden');

            input1.attr('name', 'name');

            input1.attr('value', par.name);

            var input2 = angular.element('<input>');

            input2.attr('type', 'hidden');

            input2.attr('name', 'head');

            input2.attr('value', par.head);

            var input3 = angular.element('<input>');

            input3.attr('type', 'hidden');

            input3.attr('name', 'data');

            input3.attr('value', par.data);


            angular.element('body').append(form);  //将表单放置在web中

            form.append(input1);   //将查询参数控件提交到表单上
            form.append(input2);
            form.append(input3);
            form.submit();

//            window.location.href = "ExportExcel?name="+par.name+"&head="+par.head+"&data="+par.data;
//            $http({method:'post',url:'ExportExcel',params:par}).success(function(data, status, headers, config){
//
//            });
        },

        getSSHQ : function(exchange,code,cb){
            var message = {};
            message['exchange'] = exchange;
            message['code'] = code;
            send("dhql.getHQByExchangeAndCodeAction", message, cb, true);
        },

        searchStock : function(q,cb){
            var par = {};
            par['q'] = q;

			$http({method: 'get', url: 'StockSearch', params: par})
                .success(function (data, status, headers, config) {
                   var obj = eval("("+data+")")

					var array1 = obj.split("^");

					var list = [];
					for (var i in array1)
					{
						var o = {};
						var tempArray = array1[i].split('~');
						if (tempArray[0] =='sh' ||tempArray[0] =='sz' )
						{
							o['exchange'] = tempArray[0].toUpperCase( );
							o['stockcode'] = tempArray[1];
							o['stockname'] = tempArray[2];
							list.push(o);
						}
					}

					cb(list);
                });
        },

        getKey : function(account,cb){
            var message = {};
            message['account'] = account;
            send("dhql.secretKeyAction", message, function(data){
                var _ = new zm();
                cb(_.b(data.key));
            }, true);
        }
    };
}
