
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
//var exec = cordova.require("cordova/exec");
//	exec(callbackok,callbackerr,"AndroidAPIforJS", "test1", ["test"]);
//
function gt_syCtrl($scope, ajaxService, $cookieStore, $sce) {
	
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.ewmDivShow = false;//二维码界面
    $scope.plInputShow = false;//评论
    $scope.productname = "";//产品名
    $scope.productid = "";//产品id
    $scope.account = "";//账户
    $scope.plCount = "--";
    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，服务结束时间
    $scope.jssjstrsy = "";//8位，日收益分析之类的用
    $scope.opentype = "";//打开方式

    $scope.isyk = true;//是否是游客

    $scope.tabOneShow = true;//收益
    $scope.tabTwoShow = false;//持仓
    $scope.tabThreeShow = false;//交易记录
    $scope.tabFourShow = false;//评论

    $scope.index = "1";//默认显示报名

    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "--";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.beginzc = "--";//初始资金
    $scope.dqgtInfo.rundays = "--";//实盘天数

    $scope.ljsyshow = "";//累计收益
    $scope.dqgtInfo.productfbzname = "";

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通
    $scope.fcfsArray = [];//分成方式

    $scope.fzintervalId;//复制链接定时

    //服务设置
    $scope.assetopenflagall = "N"; //对大众，资金收益公开
    $scope.clearpositionopenflagall = "N";//对大众，已清除记录公开
    $scope.positionamountopenflagall = "N"; //对大众，持仓数量公开
    $scope.positionvarietyopenflagall = "N";//对大众，持仓品种公开
    $scope.tradecommandopenflagall = "N";//对大众，交易指令公开

    $scope.sendflowerMark = true;
    $scope.pltitleshow = "评论";//评论的title

    $scope.productid = getParameter("productid");
    $scope.account = getParameter("account");
    $scope.bgtuserid = getParameter("bgtuserid");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息
    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    $scope.sce = $sce.trustAsResourceUrl;


    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        //$scope.ztcaption = _data.caption;
        //var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        //$scope.$broadcast("setParameters", cstr);
    });

    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;

            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            //$scope.dqgtInfo.zq = product.gentouperiod;
            //$scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.dqgtInfo.zxgtje = product.minmoney;
            //$scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            //$scope.dqgtInfo.beginzc = product.beginzc;//初始资金
            $scope.dqgtInfo.rundays = product.rundays;//实盘天数
            //var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str;//报名截止日期
            //var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2;//服务结束时间
            //var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3;//服务开始时间
            //var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            //$scope.kssjstr = $scope.dqgtInfo.fwkssj.toString().substr(0,8);
            $scope.kssjstr = "";
            $scope.ljsyshow = (parseFloat(product.ljsy)*100).toFixed(2) + "%";//累计收益率
            $scope.dqgtInfo.productfbzname = product.user.user.f_nickname;//产品发布者name

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }
            $scope.showinfo()
            //$scope.changeTab($scope.index);
        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.showinfo = function()
    {
        //收益等信息
        var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
        $scope.$broadcast("setParameters", cstr);

        //持仓、今日交易记录、历史交易记录
        var cstr  = {"account":$scope.account, "caption": "gtsycc"};
        $scope.$broadcast("setParameters", cstr);

        //评论
        var cstr  = {"account":$scope.account, "caption": "gtplshow"};
        $scope.$broadcast("setParameters", cstr);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//收益
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
            $scope.$broadcast("setParameters", cstr);

        }
        else if(_str == "2")//持仓
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsycc"};
            $scope.$broadcast("setParameters", cstr);

        }
        else if(_str == "3")//交易记录
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;

        }
        else if(_str == "4")//评论
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;

            var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            $scope.$broadcast("setParameters", cstr);
        }

    }

    //$scope.p_getgentouproductCallBack = function(_data)
    //{
    //    console.log("产品关系", _data);
    //}

    //$scope.getInfo = function()
    //{
    //    var message = {};
    //
    //    message['productid'] = $scope.productid;
    //    message['userid'] = $scope.userObj.f_id;
    //    console.log("产品关系",$scope.productid);
    //    ajaxService.sendMessage("gentou.getUserProductRelationAction", message, $scope.p_getgentouproductCallBack);
    //}

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflagall = _data.assetopenflagall.toString();
            $scope.clearpositionopenflagall = _data.clearpositionopenflagall.toString();
            $scope.positionamountopenflagall = _data.positionamountopenflagall.toString();
            $scope.positionvarietyopenflagall = _data.positionvarietyopenflagall.toString();
            $scope.tradecommandopenflagall = _data.tradecommandopenflagall.toString();
        }
        $scope.getdqgtInfo();
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            //alert("当前评论数" + $scope.plCount);
            selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    
    //获取评论数量
    $scope.getplcount = function()
    {
    	//selectHasRead($scope.productid,$scope.userObj.f_id);
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    $scope.addproductllcsCallBack = function(_data)
    {
        //console.log("添加浏览次数：", _data);
    }

    //添加浏览次数
    $scope.addproductllcs = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['productid'] = $scope.productid;
        ajaxService.sendMessage("sunflower.addproductbrowseaction", message, $scope.addproductllcsCallBack);
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
        //console.log("init");
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.jssjstr = getyesterdayno();
            $scope.getcpsz();
            //$scope.getplcount();
            $scope.isguanzhuget();
            $scope.addproductllcs();

        }catch (e){}
    }

    $scope.fbzInit();

    $scope.sendflowerCallBack = function(_data)
    {
        //console.log("送花", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.getpl();
        }

        $scope.sendflowerMark = true;
    }

    //送花
    $scope.sendflowerClick = function()
    {
        if($scope.sendflowerMark)
        {
            $scope.sendflowerMark = false;
            var message = {};
            //message['contenttype'] = "text";
            message['cnt'] = "//flower//";
            message['cnttype'] = "2"; //1：文字评论；2：送花；3：语音
            message['subjectid'] = $scope.productid;
            message['subjecttype'] = "product";
            message['subjectuserid'] = $scope.bgtuserid;
            message['userid'] = $scope.userObj.f_id;
            //alert("message="+angular.toJson(message));
            ajaxService.sendMessage("user.addcommentaction", message, $scope.sendflowerCallBack);
        }
    }

    //查看分成方式
    $scope.gotofcfs = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //历史交易记录
    $scope.gotolsjy = function()
    {
        $scope.mainShow = false;
        $scope.lsjyjlDivShow = true;

        var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
        $scope.$broadcast("setParameters", cstr);
    }

    $scope.lsjyjlBackto = function()
    {
        $scope.mainShow = true;
        $scope.lsjyjlDivShow = false;
    }

    //分享
    //$scope.fxClick = function()
    //{
    //    //var title = $scope.userName + ' 邀请您关注向日葵理财服务';
    //    var title = $scope.productname;
    //    var desc = '向日葵理财，您的私人理财师～～';
    //    var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/gt_share.html?productid=" + $scope.productid;
    //    shareUrlToDialog(_content, title, desc, function(data){
    //        //alert(JSON.stringify(data));
    //    },function(){
    //        //alert("微信邀请好友失败，请重试");
    //        myAlert("微信分享失败");
    //    })
    //}

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }

    $scope.fwqxgzCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.fwqxgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.fwqxgzCallback);
        }
    }

    //评论
    $scope.plClick = function()
    {
        $scope.mainShow = false;
        $scope.plInputShow = true;
    }

    //评论返回
    $scope.plinputbackto = function()
    {
        $scope.mainShow = true;
        $scope.plInputShow = false;
        $scope.getpl();
    }

    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天， 累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天，累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    $scope.fbgtBackto = function()
    {
        //console.log(getbackList());
        if($scope.opentype == "newwebview")
        {
            //window.location.href = "back";
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }

}



