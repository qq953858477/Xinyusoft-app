
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function transactionReturnsCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.account ="";//账户
    $scope.extra = "";//委托唯一编号
    $scope.htbh = "";//合同编号
    $scope.stockcode = "";
    $scope.qsday = "";

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.account = getParameter("account");
    $scope.extra = getParameter("extra");
    $scope.htbh = getParameter("htbh");
    $scope.stockcode = getParameter("stockcode");
    $scope.qsday = getParameter("qsday");
    $scope.stockinfo = {};


    $scope.getInfoCallBack = function(_data)
    {
        console.log("成交回报", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.wtInfo = {};
            $scope.dqzgObj = {};
            $scope.stockinfo = {};
            $scope.gtqkListArray = [];
                var mainorderobj = _data.mainorder;
                $scope.stockinfo.name = mainorderobj.name;
                $scope.side = mainorderobj.side;
                if($scope.side == "B")
                {
                    $scope.buyShow = true;
                }
                else
                {
                    $scope.sellShow = true;
                }
                $scope.wtInfo.wtsl = mainorderobj.wtsl;
                $scope.wtInfo.wtsj = mainorderobj.wtsj;
                $scope.wtInfo.cjsl = mainorderobj.cjsl;
                if(parseFloat(mainorderobj.wtjg) == 0)
                {
                    $scope.wtInfo.wtjg = "市价";
                }
                else
                {
                    $scope.wtInfo.wtjg = parseFloat(mainorderobj.wtjg).toFixed(2)+"元";
                }

                if(parseFloat($scope.wtInfo.cjsl) == 0)
                {
                    $scope.wtInfo.cjjg = "0.00元";
                }
                else
                {
                    $scope.wtInfo.cjjg = (parseFloat(mainorderobj.cjje)/parseFloat($scope.wtInfo.cjsl)).toFixed(2) + "元";
                }
                $scope.dqzgObj.headurl = mainorderobj.user.user.f_head;
                $scope.dqzgObj.name = mainorderobj.user.user.f_nickname;

                var arr2 = _data.gentouorderlist;
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.userid = arr2[i].user.user.f_id;
                    obj.headurl = arr2[i].user.user.f_head;
                    obj.name = arr2[i].user.user.f_nickname;
                    obj.wtsl = arr2[i].wtsl;
                    obj.wtsj = arr2[i].wtsj.toString().substr(0,10);
                    obj.cjsl = arr2[i].cjsl;
                    obj.account = arr2[i].account;
                    if(parseFloat(arr2[i].wtjg) == 0)
                    {
                        obj.wtjg = "市价";
                    }
                    else
                    {
                        obj.wtjg = parseFloat(arr2[i].wtjg).toFixed(2)+"元";
                    }

                    if(parseFloat(obj.cjsl) == 0)
                    {
                        obj.cjjg = "0.00元";
                    }
                    else
                    {
                        obj.cjjg = (parseFloat(arr2[i].cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }
                    $scope.gtqkListArray.push(obj);
                }
            }
    }

    $scope.getInfo = function()
    {
        var message = {};
        //message["page.size"] = 'max';
        //message['page.no'] = "";
        message['account'] = $scope.account;
        message['extra'] =  $scope.extra;
        message['htbh'] =  $scope.htbh;
        message['stockcode'] =  $scope.stockcode;
        if($scope.qsday != undefined && $scope.qsday != null && $scope.qsday != "")
        {
            message['day'] =  $scope.qsday;
        }
        console.log(message);
        ajaxService.sendMessage("sunflower.p_p_selectgentouorder", message, $scope.getInfoCallBack);
    }

    //初始相关操作界面
    $scope.mytrInit = function()
    {
        var localStorage = window.localStorage;
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }

        $scope.getInfo();

    }

    $scope.mytrInit();

    //成交回报返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



