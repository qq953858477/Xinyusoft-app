
function rsyfxinfoCtrl($scope, ajaxService, $cookieStore) {
    $scope.userObj = {};
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.tsInfo = false;

    $scope.account = getParameter("account");
    $scope.kssj = getParameter("sj");
    $scope.jssj = getParameter("sj");
    $scope.datestr = decodeURI(getParameter("datestr"));
    $scope.opentype = getParameter("opentype");

    $scope.xqArray = [];

    //console.log("4354");

    $scope.selectDayProfitDetailActionCallBack = function(_data)
    {
        $scope.xqArray = [];
        console.log("数据", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.dayprofitdetaillist;
            if (arr.length > 0)
            {
                for (var i = 0; i < arr.length; i++)
                {
                    var obj = {};
                    obj.stockcode = arr[i].stockcode;
                    obj.stockname = arr[i].name;
                    obj.exchange = arr[i].exchange;
                    obj.stockcodeall = obj.exchange + obj.stockcode;
                    obj.zqsl = parseInt(arr[i].zsl);//总数量
                    obj.dqj = parseFloat(arr[i].currprice).toFixed(2);//当前价
                    obj.cbj = parseFloat(arr[i].preprice).toFixed(2);//成本价
                    obj.yk = arr[i].yk;
                    if (parseFloat(obj.yk) > 0) {
                        obj.flag = "1";
                    }
                    else if (parseFloat(obj.yk) < 0) {
                        obj.flag = "-1";
                    }
                    else {
                        obj.flag = "0";
                    }
                    obj.side = arr[i].side.toString();
                    if(arr[i].side.toString() == "B")
                    {
                        obj.sidestr = "买入";
                        obj.pricename1 = "收盘价：";
                        obj.pricename2 = "买入价：";
                    }
                    else if(arr[i].side.toString() == "S")
                    {
                        obj.sidestr = "卖出";
                        obj.pricename1 = "卖出价：";
                        obj.pricename2 = "昨收价：";
                    }
                    else
                    {
                        obj.sidestr = "持有";
                        obj.pricename1 = "收盘价：";
                        obj.pricename2 = "昨收价：";
                    }

                    $scope.xqArray.push(obj);
                }
            }
            else
            {
                $scope.tsInfo = true;
            }
        }
    }

    $scope.infoinit = function()
    {
        var message = {};
        message['account'] = $scope.account;
        message['kssj'] = $scope.kssj;
        message['jssj'] = $scope.jssj;
        message['page.size'] = "max";
        message['page.no'] = "";

        ajaxService.sendMessage("counter.selectDayProfitDetailAction", message, $scope.selectDayProfitDetailActionCallBack) ;
    }

    $scope.infoinit();

    $scope.rsyback = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else if ($scope.opentype == "winlocbackhis")
        {
            history.go(-1);
        }
        else
        {
            window.location = getbackList();
        }
    }

}




