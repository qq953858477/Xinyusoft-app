
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function fundAdjustmentCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
    $scope.userName = "";
    $scope.productid = "";//产品id
    $scope.linkid = "";//签约id
    $scope.mainaccount = "";//主账户
    $scope.backtitle = "";
    $scope.jetype = "";//跟投：gt；fw：fw
    $scope.zjmark;//追加、减少
    $scope.opentype = "";//打开类型
    $scope.opindex = "";
    $scope.opindex = getParameter("opindex");
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.jetype = getParameter("jetype");
    //$scope.dqje = getParameter("dqje");//当前金额
    $scope.productid = getParameter("productid");//产品id
    $scope.linkid = getParameter("linkid");//签约id
    $scope.mainaccount = getParameter("mainaccount");//主账户
    $scope.tradeaccount = "";//子账户

    $scope.tjMark = true;//是否可以提交

    $scope.dqje = "";//当前金额
    $scope.kzjzj = "";//可以追加的金额
    $scope.kjszj = "";//可以减少的金额
    $scope.zjzjvalue = "";//追加金额
    $scope.jszjvalue = "";//减少金额

    $scope.scintervalDuration = 300;//间隔时间，8000毫秒
    $scope.scintervalId;

    $scope.innumber = 1;


    $scope.ccselectsecuritymoneyactionCallBack = function(_data)
    {
        //console.log("可减少金额", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.kjszj = jqnumxsdlw(parseFloat(_data.money.kyzj));
        }
    }

    //当前跟投可减少金额
    $scope.gtjszj = function()
    {
        var message = {};
        message['account'] = $scope.tradeaccount;
        //console.log("可减少金额", message);
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.ccselectsecuritymoneyactionCallBack);
    }

    //当前跟投金额
    $scope.p_getgentouinfobyidCallBack = function(_data)
    {
        //console.log("跟投："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.accountlink;
            $scope.dqje = obj.money;
            $scope.tradeaccount = obj.linkaccount;//跟投账户
            //console.log($scope.dqje, $scope.tradeaccount);

            if($scope.opindex == '2')
            {
                $scope.gtjszj();
            }
        }
    }

    $scope.getkgtzjactionCallBack = function(_data)
    {
        //console.log("可追加金额", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.kzjzj = jqnumxsdlw(parseFloat(_data.kyzj));
        }
    }

    //当前跟投金额
    $scope.dqgtje = function()
    {
        //当前跟投金额
        var message = {};
        message['linkid'] = $scope.linkid;
        ajaxService.sendMessage("gentou.p_getgentouinfobyid", message, $scope.p_getgentouinfobyidCallBack);
    }

    //当前跟投可追加金额
    $scope.gtzjjzj = function()
    {
        //可追加金额
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['account'] = $scope.mainaccount;
        ajaxService.sendMessage("gentou.getkgtzjaction", message, $scope.getkgtzjactionCallBack);
    }


    $scope.fwjszjCallBack = function(_data)
    {
        //console.log("可减少金额", _data);
        var obj = _data.money;
        $scope.kjszj = jqnumxsdlw(parseFloat(obj.kyzj));
        //console.log("可减少金额", jqnumxsdlw(parseFloat(704234.22)));
    }

    //当前服务可减少金额
    $scope.fwjszj = function()
    {
        var message = {};
        message['account'] = $scope.tradeaccount;
        ajaxService.sendMessage("sunflower.p_getmoney", message, $scope.fwjszjCallBack) ;
    }

    //服务
    $scope.getkfwzjactionCallBack = function(_data)
    {
        //console.log("可追加金额", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.kzjzj = jqnumxsdlw(parseFloat(_data.kyzj));
        }
    }

    //当前服务可追加金额
    $scope.fwzjzj = function()
    {
        var message = {};
        message['userid'] =  $scope.userObj.f_id;
        message['account'] = $scope.mainaccount;
        ajaxService.sendMessage("gentou.getkgtzjaction", message, $scope.getkfwzjactionCallBack);
    }



    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.dqje  = product.beginzc;//初始金额
            $scope.tradeaccount = product.account;

            if($scope.opindex == '2')
            {
                $scope.fwjszj();
            }
        }
    }


    //当前服务的金额
    $scope.dqfwje = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);
    }


    $scope.getzjInfo = function ()
    {
        if($scope.jetype == "gt")//跟投
        {
            $scope.gtzjjzj();
        }
        else if($scope.jetype == "fw")//服务
        {
            $scope.fwzjzj();
        }
    }

    $scope.getjsInfo = function()
    {
        if($scope.jetype == "gt")//跟投
        {
            $scope.gtjszj();
        }
        else if($scope.jetype == "fw")//服务
        {
            $scope.fwjszj();
        }
    }

    $scope.changeTab = function(_index)
    {
        if(_index == "1")
        {
            $scope.zjmark = true;
            $scope.getzjInfo();
        }
        else
        {
            $scope.zjmark = false;

            if($scope.opindex != '2')
            {
                $scope.getjsInfo();
            }
            else
            {
                if($scope.innumber>1)
                {
                    $scope.getjsInfo();
                }
            }
        }
        $scope.innumber = $scope.innumber+1;
    }


    //初始相关操作界面
    $scope.fundinit = function()
    {
        var localStorage = window.localStorage;
        //$scope.sftype = localStorage.getItem("lcsstatus");
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.headstr = "";
        if($scope.userObj.f_head == undefined || $scope.userObj.f_head == "" || $scope.userObj.f_head == null)
        {
            $scope.headstr = "";
        }
        else
        {
            $scope.headstr = $scope.userObj.f_head;
        }
        $scope.changeTab($scope.opindex);

        if($scope.jetype == "gt")
        {
            $scope.dqgtje();
        }
        else if($scope.jetype == "fw")
        {
            $scope.dqfwje();
        }
    }

    $scope.fundinit();


    $scope.qrzjClick = function()
    {
        if($scope.tjMark == true)
        {
            $scope.tjMark = false;
            $scope.scintervalId = setInterval($scope.gotozjmyConfirm, $scope.scintervalDuration);
        }
    }

    $scope.gotozjmyConfirm = function()
    {
        if ($scope.scintervalId != undefined)
        {
            clearInterval($scope.scintervalId);
        }
        if($scope.zjzjvalue == "" || parseFloat($scope.zjzjvalue) == 0)
        {
            $scope.tjMark = true;
            myAlert("请输入需追加的金额");
            return;
        }
        if(valueCheck($scope.zjzjvalue) == false)
        {
            $scope.tjMark = true;
            myAlert("请输入正确的数值");
            return;
        }
        if(parseFloat($scope.zjzjvalue) > parseFloat($scope.kzjzj))
        {
            $scope.tjMark = true;
            myAlert("追加的金额不能大于可追加金额");
            return;
        }
        var str = "确定追加金额  " + $scope.zjzjvalue +  "元吗？";
        myConfirm(str, $scope.zjconfirm, $scope.thisunok);
    }

    $scope.zjconfirm = function()
    {
        layer.closeAll();
        $scope.tjMark == false;//提交中
        if ($scope.jetype == "gt")//跟投
        {
            var message = {};
            message['linkid'] = $scope.linkid;
            message['side'] = "B";//追加：B；减少：S
            message['money'] = $scope.zjzjvalue;
            message['productid'] = $scope.productid;
            console.log("追加：" + message);
            ajaxService.sendMessage("sunflower.p_transferaccountlinkmoney", message, $scope.gtqrzjCallBack);
        }
        else if ($scope.jetype == "fw")//服务
        {
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['side'] = "B";//追加：B；减少：S
            message['money'] = $scope.zjzjvalue;
            message['productid'] = $scope.productid;
            console.log("追加：" + message);
            ajaxService.sendMessage("sunflower.p_transfergentouproductmoney", message, $scope.fwqrzjCallBack);
        }
    }

    //跟投金额转入
    $scope.gtqrzjCallBack = function(_data)
    {
        //console.log("金额转入", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.zjzjvalue = "";
            $scope.dqgtje();
            $scope.gtzjjzj();
        }
        else
        {
            myAlert("金额追加失败，原因：" + _data.op.info);
        }
        $scope.tjMark = true;
    }

    //服务金额转入
    $scope.fwqrzjCallBack = function(_data)
    {
        //console.log("金额转入", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.zjzjvalue = "";
            $scope.dqfwje();
            $scope.fwzjzj();
        }
        else
        {
            myAlert("金额追加失败，原因：" + _data.op.info);
        }
        $scope.tjMark = true;
    }

    $scope.qrjsClick = function()
    {
        if($scope.tjMark == true)
        {
            $scope.tjMark = false;
            $scope.scintervalId = setInterval($scope.gotojsmyConfirm, $scope.scintervalDuration);
        }

    }

    $scope.gotojsmyConfirm = function()
    {
        if ($scope.scintervalId != undefined)
        {
            clearInterval($scope.scintervalId);
        }
        if($scope.jszjvalue == "" || parseFloat($scope.jszjvalue) == 0)
        {
            $scope.tjMark = true;
            myAlert("请输入需追加的金额");
            return;
        }
        if(valueCheck($scope.jszjvalue) == false)
        {
            $scope.tjMark = true;
            myAlert("请输入正确的数值");
            return;
        }
        if(parseFloat($scope.jszjvalue) > parseFloat($scope.kjszj))
        {
            $scope.tjMark = true;
            myAlert("减少的金额不能大于可减少金额");
            return;
        }

        var str = "确定减少金额  " + $scope.jszjvalue +  "元吗？";
        myConfirm(str, $scope.jsconfirm, $scope.thisunok);
    }

    $scope.jsconfirm = function()
    {
        layer.closeAll();
        $scope.tjMark == false;//提交中
        if($scope.jetype == "gt")//跟投
        {
            var message = {};
            message['linkid'] =  $scope.linkid;
            message['side'] = "S";//追加：B；减少：S
            message['money'] = $scope.jszjvalue;
            message['productid'] = $scope.productid;
            //console.log("减少：" + message);
            ajaxService.sendMessage("sunflower.p_transferaccountlinkmoney", message, $scope.gtqrjsCallBack);
        }
        else if($scope.jetype == "fw")//服务
        {
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['side'] = "S";//追加：B；减少：S
            message['money'] = $scope.jszjvalue;
            message['productid'] = $scope.productid;
            //console.log("减少：" + message);
            ajaxService.sendMessage("sunflower.p_transfergentouproductmoney", message, $scope.fwqrjsCallBack);
        }
    }

    $scope.thisunok = function()
    {
        $scope.tjMark = true;
    }

    //跟投
    $scope.gtqrjsCallBack = function(_data)
    {
        //console.log("金额转出", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jszjvalue = "";
            $scope.dqgtje();
            if($scope.opindex != '2') {
                $scope.gtjszj();
            }
        }
        else
        {
            myAlert("金额减少失败，原因：" + _data.op.info);
        }

        $scope.tjMark = true;
    }

    //服务
    $scope.fwqrjsCallBack = function(_data)
    {
        //console.log("金额转出", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jszjvalue = "";
            $scope.dqfwje();
            if($scope.opindex != '2') {
                $scope.fwjszj();
            }
        }
        else
        {
            myAlert("金额减少失败，原因：" + _data.op.info);
        }

        $scope.tjMark = true;
    }

    //返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



