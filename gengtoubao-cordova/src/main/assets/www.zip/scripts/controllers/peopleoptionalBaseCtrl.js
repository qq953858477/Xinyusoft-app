﻿/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */

function peopleoptionalBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.applyforFPshow = false;//是否可申请理财师
    $scope.zxlistDivShow = true;//自选股列表
    $scope.stockDiv = false;//股票搜索

    $scope.zxgintervalId;
    $scope.zxgintervalDuration = 5000;//间隔时间，3000毫秒
    $scope.opentype = "";//打开方式
    $scope.peopleID = "";

    $scope.stocklist = [];
    $scope.order = "0";//0-不排序 1-升序 2-降序
    $scope.orderobj = "";//zxj-最新价 zdf-涨跌幅 zd-涨跌， +升序 -降序

    $scope.oneStockHQBaseShow = false;//股票
    $scope.indexbaseShow = false;//指数
    $scope.dqxzstock = {};//当前选中
    $scope.userObj = {}

    //$scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");//打开方式
    $scope.peopleID = getParameter("peopleID");
    $scope.userObj = JSON.parse(localStorage.getItem('user'));

    //去除
    $scope.optionhqthisClearInterval = function () {
        if ($scope.zxgintervalId != undefined) {
            clearInterval($scope.zxgintervalId);
        }
    }

    $scope.getSelfStock =function()
    {
        var message = {};
        message["userid"] = $scope.peopleID;
        message["ordeCol"] = "";
        message["ordeBy"] = "";
        //console.log("$scope.peopleID", $scope.peopleID);

        ajaxService.sendMessage("hq.getzxghqaction",message,function(_data)
        {
            //console.log("自选股列表：" + _data);
            $scope.stocklist = [];
            if(_data.op.code.toString() == "Y")
            {
                var arr = _data.data;
                //console.log(arr);
                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.index = i;
                    obj.asset = arr[i].asset;//类型
                    obj.gpdm = arr[i].symbol;
                    obj.zqjc = arr[i].name;
                    obj.exchange = arr[i].exchange.toString();
                    obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                    obj.zxj = parseFloat(arr[i].price.toString());
                    obj.status = arr[i].stockstatus.toString();
                    //console.log("状态：" + arr[i].stockstatus.toString())
                    obj.xzzt = "1";//选中状态，样式更改
                    obj.zd = parseFloat(arr[i].zd.toString());
                    obj.zdf = parseFloat(arr[i].zdf.toString());
                    //if (obj.status == '3')
                    //{
                    //    obj.zdf = -10000;
                    //    obj.zd = -10000;
                    //}
                    $scope.stocklist.push(obj);
                }
            }
            $scope.optionhqthisClearInterval();
            $scope.zxgintervalId = setInterval($scope.getSelfStock, $scope.zxgintervalDuration);
        })
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "1";
        message['belonguserid'] = $scope.peopleID;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    $scope.opinit = function()
    {
        $scope.getSelfStock();
        $scope.isguanzhuget();
    }
    $scope.opinit();

    $scope.gzzxgCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
        }
        else
        {
            myAlert("加关注失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }


    //关注自选股
    $scope.gzzxg = function()
    {
        if($scope.guanzhuing == true) {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "1";
            message['belonguserid'] = $scope.peopleID;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.gzzxgCallBack);
        }
    }

    $scope.qxgzzxgCallback  = function(_data)
    {
        //console.log("取消关注", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = false;
        }
        else
        {
            myAlert("取消失败，原因：" + _data.op.info);
        }
        $scope.guanzhuing = true;
    }

    //取消关注
    $scope.qxgzzxg = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "1";
            message['belonguserid'] = $scope.peopleID;
            //console.log("取消关注", message);
            ajaxService.sendMessage('user.delconcerntbyuseridaction', message, $scope.qxgzzxgCallback);
        }
    }

    $scope.sortStock = function (obj)
    {
        if($scope.orderobj == "")//初始化，未排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else if($scope.orderobj == "+index")//回复原数据排序
        {
            $scope.orderobj = obj;
            $scope.order = "2";//降序
        }
        else
        {
            var str = obj.substr(0,1);//取出符号 ：+ ，-
            obj = obj.substr(1, obj.length-1);
            if($scope.orderobj.indexOf(obj, 0) != -1)//同一个排序字段
            {
                if($scope.order == "1")//升序
                {
                    $scope.orderobj = "+index"; //下标升序
                    $scope.order = "0";//回复原序列
                }
                else if($scope.order == "2")
                {
                    $scope.orderobj = "+" + obj;
                    $scope.order = "1";//升序
                }
                else
                {
                    $scope.orderobj = "-" + obj;
                    $scope.order = "2";//降序
                }
            }
            else//不同排序字段
            {
                $scope.orderobj = "-" + obj;
                $scope.order = "2";//降序
            }
        }

    }

    //个股
    $scope.ggClick = function(_obj)
    {
        _obj.xzzt = "0";
        var obj = {};
        obj.stockcode = _obj.gpdm;
        obj.stockname = encodeURIComponent(_obj.zqjc);
        obj.exchange = _obj.exchange.toString();
        obj.asset = _obj.asset;
        obj.back = "zxglist";
        obj.canadddel = false;
        var localStorage = window.localStorage;
        localStorage.setItem("stockInfo", JSON.stringify(obj));
        //$cookieStore.put('stockInfo', obj);
        //window.location.href = "oneStockHQBase.html";

        $scope.dqxzstock = obj;

        $scope.optionhqthisClearInterval();
        $scope.zxlistDivShow = false;
        if(_obj.asset == "0" || _obj.asset == "5")//股票
        {
            $scope.oneStockHQBaseShow = true;
        }
        else
        {
            $scope.indexbaseShow = true;
        }
        //$scope.parentDivShow(false);
        //$scope.setppBtnShow(false);

        gotoUp();

    }

    $scope.onestockhqbaseBacktoggList = function()
    {
        $scope.oneStockHQBaseShow = false;
        $scope.zxlistDivShow = true;
        $scope.dqxzstock = null;
        $scope.getSelfStock();
        //console.log("主界面显示");
        //$scope.parentDivShow(true);
        //$scope.setppBtnShow(true);
    }

    $scope.onestockhqbaseBacktoSearchList = function()
    {
        $scope.oneStockHQBaseShow = false;
        $scope.stockDiv = true;
        $scope.dqxzstock = null;
    }


    //大盘指数返回
    $scope.indexbaseBackto = function()
    {
        //console.log("大盘指数返回");
        $scope.indexbaseShow = false;
        if($scope.dqxzstock.back == "zxglist")
        {
            $scope.zxlistDivShow = true;
            $scope.getSelfStock();
        }
        else
        {
            $scope.stockDiv = true;
        }
        $scope.dqxzstock = null;
        //$scope.parentDivShow(true);
        //$scope.setppBtnShow(true);
    }

    //自选股返回
    $scope.zsgback = function()
    {
        $scope.optionhqthisClearInterval();
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
        //$scope.zxListBack();
    }
}







