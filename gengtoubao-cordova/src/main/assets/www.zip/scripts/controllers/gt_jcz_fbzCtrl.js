
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_jcz_fbzCtrl($scope, ajaxService, $cookieStore) {
    $scope.isyk = false;//是否是游客
    $scope.isgtz = false;//是否是跟投其他人
    $scope.zqgsname = "--";//证券公司名称
    $scope.productfwsc = "--";//服务时长
    $scope.accountShowValue = "";//跟投主账号，界面显示用
    $scope.plCount = "--";

    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.ewmDivShow = false;//二维码界面
    $scope.jsfwDivShow = false;//结束服务div
    $scope.jsfwfhinfoDivShow = false;//结束服务返回跟投者信息显示
    $scope.productname = "";//产品名
    $scope.productid = "";//产品id
    $scope.account = "";//账户
    $scope.index = "1";//默认显示收益
    $scope.gtzArray = [];//跟投者的信息
    $scope.jsgtgtzArr = [];//结束跟投后跟投者状态信息
    $scope.lsjyjlDivShow = false;//历史交易记录

    $scope.fzintervalId;//复制链接定时

    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，服务结束时间

    $scope.tabOneShow = true;//收益
    $scope.tabTwoShow = false;//理财师
    $scope.tabThreeShow = false;//跟投

    $scope.dqgtInfo = {};//当前跟投的条款
    $scope.dqgtInfo.productname = "--";
    $scope.dqgtInfo.productid = "--";//产品id
    $scope.dqgtInfo.zq = "--";
    $scope.dqgtInfo.mbsy = "--";
    $scope.dqgtInfo.zxgtje = "--";
    $scope.dqgtInfo.zdgtje = "--";
    $scope.dqgtInfo.bmjzsj = "--";
    $scope.dqgtInfo.fwfbsj = "--";//服务发布时间
    $scope.dqgtInfo.fwkssj = "--";//服务开始时间
    $scope.dqgtInfo.fwjssj = "--";//服务结束时间
    $scope.dqgtInfo.desc = "--";//理财计划
    $scope.dqgtInfo.beginzc = "--";//初始资金
    $scope.dqgtInfo.rundays = "--";//实盘天数

    $scope.ljsyshow = "";//累计收益
    $scope.dqgtInfo.productfbzname = "";

    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通
    $scope.fcfsArray = [];//分成方式

    $scope.gtzinfo = {};//总跟投信息
    $scope.gtzinfo.zgtje = "--";//总跟投金额
    $scope.gtzinfo.ljyk = "--";//累计收益
    $scope.gtzinfo.ljsyl = "--";//累计收益率

    $scope.jshgtzinfo = {};//解除后总跟投信息
    $scope.jshgtzinfo.zgtje = "--";//总跟投金额
    $scope.jshgtzinfo.ljyk = "--";//累计收益
    $scope.jshgtzinfo.ljsyl = "--";//累计收益率

    $scope.productljsy = "";//服务累计收益

    $scope.ztcaption = "";
    $scope.productid = getParameter("productid");
    $scope.account = getParameter("account");
    //$scope.accountShowValue = $scope.account;
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");

    $scope.jsgtMark = true;
    $scope.jsgtErrorInfo = "";
    //$scope.gtxqDivShow = false;//跟投详情
    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }
    $scope.zhListObj = {};//账户信息

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息

    $scope.isguanzhu = true;//是否关注 true:关注；false:未关注
    $scope.guanzhuing = true;//点击关注是否可以操作

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
    });

    $scope.getgtzinfoCallBack = function(_data)
    {
        console.log("跟投者信息", _data);
        $scope.gtzinfo = {};//总跟投信息
        $scope.gtzinfo.zgtje = 0.00;//总跟投金额
        $scope.gtzinfo.ljyk = 0.00;//累计收益
        $scope.gtzinfo.ljsyl = 0.00;//累计收益率
        $scope.gtzArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkuser.user.f_head;
                obj.username = arr[i].linkuser.user.f_nickname;
                obj.userid = arr[i].linkuser.user.f_id;//跟投者的用户信息
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.money = parseFloat(arr[i].money);//跟投金额
                $scope.gtzinfo.zgtje = $scope.gtzinfo.zgtje + obj.money;
                //obj.drsyl = (parseFloat(arr[i].linkaccountmoney.jrsy) * 100).toFixed(2);
                //obj.ljsyl = (parseFloat(arr[i].linkaccountmoney.ljsy) * 100).toFixed(2);
                obj.drsyl = parseFloat(arr[i].linkaccountmoney.jrsy);
                obj.ljsyl = parseFloat(arr[i].linkaccountmoney.ljsy);
                obj.ljyk = parseFloat(arr[i].linkaccountmoney.ljyk);
                $scope.gtzinfo.ljyk = $scope.gtzinfo.ljyk + obj.ljyk;
                obj.status = arr[i].status.toString();//状态
                console.log(" obj.status",  obj.status);

                obj.linkaccount = arr[i].linkaccount;
                obj.linkid = arr[i].id;
                obj.bgtuserid = arr[i].linkeduser.user.f_id;

                //if(obj.status == "B")
                //{
                //    obj.statusstr = "实盘中";
                //}
                //else if(obj.status == "C")
                //{
                //    obj.statusstr = "解除中";
                //}
                //else if(obj.status == "D")
                //{
                //    obj.statusstr = "未支付";
                //}
                //else if(obj.status == "E")
                //{
                //    obj.statusstr = "已结束";
                //}
                $scope.gtzArray.push(obj);
            }

            $scope.gtzinfo.ljsyl = $scope.gtzinfo.ljyk/$scope.gtzinfo.zgtje*100;
        }
    }

    //跟投者信息
    $scope.getgtzinfo = function()
    {
        $scope.gtzArray = [];
        var message = {};
        message['account'] = $scope.zhListObj.tradeaccount;
        message['productid'] = $scope.productid;
        message['userid'] = "";
        message['linkoriginalaccount'] = "";
        message['page.size'] = "max";
        message['page.no'] = "";
        ajaxService.sendMessage("gentou.p_selectallgentou", message, $scope.getgtzinfoCallBack);
    }

    $scope.p_getgentouproductCallBack = function(_data)
    {
        console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.dqgtInfo = {};
            $scope.dqgtInfo.productname = product.name;
            $scope.dqgtInfo.productid = $scope.productid;//产品id
            $scope.dqgtInfo.zq = product.gentouperiod;
            $scope.dqgtInfo.mbsy = product.targetprofit + "%";
            $scope.dqgtInfo.zxgtje = product.minmoney;
            $scope.dqgtInfo.zdgtje = product.maxmoney;
            $scope.dqgtInfo.desc = product.desc;//说明，理财计划
            $scope.dqgtInfo.beginzc = product.beginzc;//初始资金
            //$scope.dqgtInfo.rundays = product.rundays;//实盘天数
            var str = product.endapplyday;
            //$scope.dqgtInfo.bmjzsj = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//报名截止日期
            $scope.dqgtInfo.bmjzsj = str;//报名截止日期
            var str2 = product.endgentouday;
            //$scope.dqgtInfo.fwjssj = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//服务结束时间
            $scope.dqgtInfo.fwjssj = str2;//服务结束时间
            console.log("结束时间",$scope.dqgtInfo.fwjssj );
            var str3 = product.gentouday;
            //$scope.dqgtInfo.fwkssj = str3.substr(0,4) + "-" + str3.substr(4,2) + "-" + str3.substr(6,2);//服务开始时间
            $scope.dqgtInfo.fwkssj = str3;//服务开始时间
            var str4 = product.createtime;
            //$scope.dqgtInfo.fwfbsj = str4.substr(0,10);//服务发布时间
            $scope.dqgtInfo.fwfbsj = str4;//服务发布时间

            $scope.kssjstr = $scope.dqgtInfo.fwkssj.toString().substr(0,8);
            $scope.ljsyshow = (parseFloat(product.ljsy)*100).toFixed(2) + "%";//累计收益率
            $scope.dqgtInfo.productfbzname = product.user.user.f_nickname;//产品发布者name

            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }

            var fbzaccountobj = product.accountcompany;
            //console.log("fbzaccountobj",fbzaccountobj);
            var obj = {};
            obj.id = fbzaccountobj.id;
            obj.zqgs = fbzaccountobj.company;
            obj.zqgsname = fbzaccountobj.companyname;
            obj.account = fbzaccountobj.account.toString();
            obj.zqgsiocnurl = getzqgsLogo(obj.zqgs);//公司logo
            obj.zhxm = fbzaccountobj.name;//账户姓名，添加账户时输入信息
            obj.tradeaccount = product.account;
            obj.newflag = fbzaccountobj.newflag;//是否已经转账操作
            $scope.zqgsname = obj.zqgsname;

            $scope.productfwsc = $scope.dqgtInfo.zq;

            $scope.zhListObj = obj;
            $scope.accountShowValue = $scope.zhListObj.account;
            //console.log("账户",$scope.zhListObj);
            var sharearr = product.share;
            //console.log("分成比例" +product.share);
            for(var i = 0;i<sharearr.length;i++)
            {
                var obj = {};
                obj.downprofit = sharearr[i].downprofit;//目标收益
                obj.share = sharearr[i].share;
                var fc = parseInt(obj.share)/10;
                obj.label = fc +":" +(10-fc) ;
                //obj.desc = "目标收益" +  sharearr[i].downprofit + "%后，跟投收益部分按照" + obj.label + "分成";\
                if(fc == 2)
                {
                    obj.desc = "跟投用户实际收益超出平台基准收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；没有超出平台基准收益，理财师不分成";
                }
                else
                {
                    obj.desc = "跟投用户实际收益超出理财包目标收益部分，理财师" + obj.share + "%，跟投用户" + (100-obj.share) +"%分成；若未达到目标收益，按二八分成方式结算";
                }
                obj.status = true;
                $scope.fcfsArray.push(obj);
            }


            $scope.getgtzinfo();
            $scope.changeTab($scope.index);
        }
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
            $scope.$broadcast("setParameters", cstr);

        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsycc"};
            $scope.$broadcast("setParameters", cstr);

        }
        else if(_str == "3")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;
        }
        else if(_str == "4")//评论
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;
            var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            $scope.$broadcast("setParameters", cstr);
            $scope.plmark = false;
        }
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    $scope.isguanzhugetCallBack = function(_data)
    {
        //console.log("关注状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.existflag.toString() == "true")
            {
                $scope.isguanzhu = true;//已关注
            }
            else
            {
                $scope.isguanzhu = false;//未关注
            }
        }
    }

    $scope.isguanzhuget = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['concernttype'] = "3";
        message['belonguserid'] = $scope.bgtuserid;
        message['concerntid'] = $scope.productid;
        ajaxService.sendMessage("user.isconcerntaction", message, $scope.isguanzhugetCallBack);
    }

    //初始相关操作界面
    $scope.fbzInit = function()
    {
        //console.log("gbz","bbb")
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.bgtuserid = $scope.userObj.f_id;
            $scope.getdqgtInfo();
            $scope.getplcount();
            $scope.isguanzhuget();
            $scope.jssjstr = getyesterdayno();

        }catch (e){}
    }

    //$scope.fbzInit();

    $scope.appInit = function()
    {
        document.addEventListener('deviceready', function()
        {
            $scope.fbzInit();
        }, false);
    }
    $scope.appInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //历史交易记录
    $scope.gotolsjy = function()
    {
        $scope.mainShow = false;
        $scope.lsjyjlDivShow = true;

        var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
        $scope.$broadcast("setParameters", cstr);
    }

    $scope.lsjyjlBackto = function()
    {
        $scope.mainShow = true;
        $scope.lsjyjlDivShow = false;
    }


    //去到跟投者信息界面
    $scope.gotogtzInfo = function(_obj)
    {
        if(_obj.status == "B")//实盘中
        {
            //setbackList(window.location.href);
            //window.location = "gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs";
            openNewInterface("gt_fwz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs" + "&&opentype=newwebview");
        }
        else if(_obj.status == "C")//解除中
        {
            //setbackList(window.location.href);
            //window.location = "gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid;
            openNewInterface("gt_jcz_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs" + "&&opentype=newwebview");
        }
        else if(_obj.status == "D")//历史
        {
            //setbackList(window.location.href);
            //window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs";
            openNewInterface("gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs" + "&&opentype=newwebview");
        }
        else if(_obj.status == "E")//历史
        {
            //setbackList(window.location.href);
            //window.location = "gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs";
            openNewInterface("gt_history_gtz.html?&linkaccount=" +_obj.linkaccount+"&&productid="+_obj.productid + "&&linkid=" +_obj.linkid + "&&bgtuserid=" +_obj.bgtuserid + "&&identity=lcs" + "&&opentype=newwebview");
        }
    }

    ////跟投详情
    //$scope.gtxqCkick = function()
    //{
    //    $scope.mainShow = false;
    //    $scope.gtxqDivShow = true;
    //}
    //
    //$scope.gtxqbackto = function()
    //{
    //    $scope.mainShow = true;
    //    $scope.gtxqDivShow = false;
    //}

    //进入账号
    $scope.zhlistItemClick = function()
    {
        var _obj = $scope.zhListObj;
        var localStorage = window.localStorage;
        localStorage.setItem("account", _obj.tradeaccount);
        localStorage.setItem("accountcompany", _obj.zqgs);//证券公司id
        localStorage.setItem("accountName", encodeURIComponent(_obj.zqgsname));
        localStorage.setItem("accountShow", encodeURIComponent(_obj.account));
        localStorage.setItem("newflag", encodeURIComponent(_obj.newflag));
        //console.log(_obj.tradeaccount, _obj.account);

        //setbackList(window.location.href + "&&index=1");
        //window.location.href = "tradeBase_bgt.html";
        openNewInterface("tradeBase_bgt.html?opentype=newwebview");
    }

    //结束服务
    $scope.jsfwClick = function()
    {
        $scope.mainShow = false;
        $scope.jsfwDivShow = true;
        $scope.jsgtMark = true;
        $scope.jsgtErrorInfo = "";
    }

    //取消结束服务
    $scope.thisCancel = function()
    {
        $scope.mainShow = true;
        $scope.jsfwDivShow = false;
        $scope.jsgtMark = true;
        $scope.jsgtErrorInfo = "";
    }

    //确定结束服务
    $scope.thisConfirm = function()
    {
        if($scope.jsgtMark)
        {
            $scope.jsgtMark = false;
            $scope.jsgtErrorInfo = "";
            var message = {};
            message['productid'] = $scope.productid;
            console.log("结束服务",$scope.productid);
            ajaxService.sendMessage("sunflower.p_endgentouproduct", message, $scope.p_endgentouproductCallBack);
        }
    }

    $scope.p_endgentouproductCallBack = function(_data)
    {
        //console.log("结束服务", _data)
        if(_data.op.code.toString() == "Y")
        {
            $scope.jsfwDivShow = false;
            $scope.jsfwfhinfoDivShow = true;

            $scope.getjshxx();
        }
        else
        {
            $scope.jsgtErrorInfo = "结束跟投操作失败，原因：" + _data.op.info;
        }
        $scope.jsgtMark = true;
    }

    $scope.getjshxx = function()
    {
        $scope.getljsy();
        $scope.getjsgtlist();
    }


    $scope.getljsy = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.getljsyCallBack);

    }

    $scope.getljsyCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productljsy = (parseFloat(product.ljsy)*100).toFixed(2) + "%";//累计收益率
        }
    }

    $scope.getjsgtlist = function()
    {
        //console.log("结束服务");
        $scope.jsgtgtzArr = [];
        var message = {};
        message['account'] = $scope.zhListObj.tradeaccount;
        message['productid'] = $scope.productid;
        message['userid'] = "";
        message['linkoriginalaccount'] = "";
        message['page.size'] = "max";
        message['page.no'] = "";
        ajaxService.sendMessage("gentou.p_selectallgentou", message, $scope.getjsgtlistCallBack);
    }

    $scope.getjsgtlistCallBack = function(_data)
    {
        console.log("结束跟投返回", _data);
        $scope.jsgtgtzArr = [];
        $scope.jshgtzinfo.zgtje = 0.00;//总跟投金额
        $scope.jshgtzinfo.ljyk = 0.00;//累计收益
        $scope.jshgtzinfo.ljsyl = 0.00;//累计收益率
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.accountlinklist;
            for (var i = 0; i < arr.length; i++)
            {
                var obj = {};
                obj.hearurl = arr[i].linkuser.user.f_head;
                obj.username = arr[i].linkuser.user.f_nickname;
                obj.userid = arr[i].linkuser.user.f_id;//跟投者的用户信息
                obj.productid = arr[i].productid;
                obj.productname = arr[i].productname;
                obj.zq = arr[i].gentouperiod;
                obj.money = parseFloat(arr[i].money);//跟投金额
                $scope.jshgtzinfo.zgtje = $scope.jshgtzinfo.zgtje + obj.money;
                //obj.drsyl = (parseFloat(arr[i].linkaccountmoney.jrsy) * 100).toFixed(2);
                //obj.ljsyl = (parseFloat(arr[i].linkaccountmoney.ljsy) * 100).toFixed(2);
                obj.drsyl = parseFloat(arr[i].linkaccountmoney.jrsy);
                obj.ljsyl = parseFloat(arr[i].linkaccountmoney.ljsy);
                obj.ljyk = parseFloat(arr[i].linkaccountmoney.ljyk);
                $scope.jshgtzinfo.ljyk = $scope.jshgtzinfo.ljyk + obj.ljyk;
                obj.status = arr[i].status.toString();//状态
                console.log(" obj.status",  obj.status);
                //if(obj.status == "B")
                //{
                //    obj.statusstr = "实盘中";
                //}
                //else if(obj.status == "C")
                //{
                //    obj.statusstr = "解除中";
                //}
                //else if(obj.status == "D")
                //{
                //    obj.statusstr = "未支付";
                //}
                //else if(obj.status == "E")
                //{
                //    obj.statusstr = "已结束";
                //}
                $scope.jsgtgtzArr.push(obj);
            }
            $scope.jshgtzinfo.ljsyl = $scope.jshgtzinfo.ljyk/$scope.jshgtzinfo.zgtje*100;
        }
    }

    //分享
    //$scope.fxClick = function()
    //{
    //    //var title = $scope.userName + ' 邀请您关注跟投宝服务';
    //    var title = $scope.productname;
    //    var desc = '跟投宝，您的私人理财师～～';
    //    var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/gt_share.html?productid=" + $scope.productid;
    //    shareUrlToDialog(_content, title, desc, function(data){
    //        //alert(JSON.stringify(data));
    //    },function(){
    //        //alert("微信邀请好友失败，请重试");
    //        myAlert("微信分享失败");
    //    })
    //}

    $scope.fwjgzCallBack = function(_data)
    {
        //console.log("加关注",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.isguanzhu = true;
            $scope.guanzhuing = false;
        }
        else
        {
            $scope.guanzhuing = true;
            myAlert("加关注失败，原因：" + _data.op.info);
        }
    }

    //加关注
    $scope.fwjgz = function()
    {
        if($scope.guanzhuing == true)
        {
            $scope.guanzhuing = false;
            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['concernttype'] = "3";
            message['belonguserid'] = $scope.bgtuserid;
            message['concerntid'] = $scope.productid;
            message['linkurl'] = "";
            message['logo'] = "";
            message['lastmsgtime'] = "";
            message['lastmsg'] = "";

            ajaxService.sendMessage("user.addconcerntaction", message, $scope.fwjgzCallBack);
        }
    }


    //分享到微信
    $scope.weixinfx = function()
    {
        var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天，累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname +'，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        //console.log('跟投服务 "' + $scope.productname+'" 累计收益：' + $scope.ljsyshow, '理财师：' +$scope.dqgtInfo.productfbzname +'，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);

        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {

        var title = encodeURI('跟投服务 "' + $scope.productname + '"，实盘第' + $scope.dqgtInfo.rundays + '天， 累计收益：' + $scope.ljsyshow);
        var desc = encodeURI('理财师：' +$scope.dqgtInfo.productfbzname +'，服务时长：'+ getfwscStr($scope.dqgtInfo.zq) + '，目标收益：' + $scope.dqgtInfo.mbsy);
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.mainShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gt_nav_share.html?productid=" + $scope.productid;
        //cz(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:200,height:200});
    }

    $scope.ewmBackto = function()
    {
        $scope.mainShow = true;
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    //结束跟投后返回
    $scope.backtoP = function()
    {
        $scope.fbgtBackto();
    }

    $scope.fbgtBackto = function()
    {
        //console.log(getbackList());
        //if($scope.backtitle == "实盘")
        //{
        //    window.location.href = "back";
        //}
        //else
        //{
        //    window.location = getbackList();
        //}
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

    //读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    if(res.rows.length == 0){

                        $scope.hasReadNum = 0;

                    }else
                    {
                        $scope.hasReadNum = res.rows.item(0).readnum;

                    }

                    //alert("已读取评论数" + $scope.hasReadNum);

                    if($scope.hasReadNum < $scope.plCount)
                    {
                        $scope.plmark = true;
                    }
                    else
                    {
                        $scope.plmark = false;
                    }
                });
        })
    }



}

