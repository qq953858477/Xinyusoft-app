function myhome()
{
    return {
        restrict: 'E',
        //templateUrl: 'index.html',
        templateUrl: 'home.html',
        //controller:['$scope','ajaxService','$cookieStore',myFinancialBaseCtrl],
        //template: '<span>Hi there444</span>',
        //replace: true,
        transclude: true
    };
}


/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/

var homeslides = [];
function myhomeCtrl($scope, ajaxService, $cookieStore)
{
    //console.log("首页", $scope.cesxinxi);
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.homebaseShow = true;
    $scope.indexbaseShow = false;//大盘指数
    $scope.sqlcsDivShow = true;//申请理财师
    $scope.yqhyDivShow = false;//邀请好友
    $scope.funintShow = false;//功能介绍
    $scope.spxjpDivshow = false;//实盘下解盘
    $scope.kbDivshow = false;//快报
    $scope.lcskbList = [];//快报
    //$scope.lcsstatus = "";
    $scope.dymark = false;
    $scope.homeewmShow = false;//二维码显示

    $scope.newjjbb = {};
    $scope.newjjbb.stockcode = "";
    $scope.newjjbb.stockname = "";
    $scope.newjjbb.type = "";
    $scope.newjjbb.typestr = "";;
    $scope.newjjbb.exchange = "";

    $scope.slides = [];
    // 添加轮播图源
    //$scope.slides.push({id: 4, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_lcsjlh.png?20160121', text: '明星理财师交流会', active: false, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_lcsjlh_info.png?20160121', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_lcsjlh_info.png?20160121'});
    //$scope.slides.push({id: 3, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_yqhd.png?20151229', text: '推荐跟投用户奖励', active: false, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/jlgz1.png?20151229', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/jlgz1.png?20151229'});
    //$scope.slides.push({id: 2, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syjz.png?20151229', text: '基准收益', active: false, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syjz_info.png?20151229', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syjz_info.png?20151229'});
    //$scope.slides.push({id: 0, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_jcgt.png?20151229', text: '提前结束跟投', active: true, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_jcgt_info.png?20151229', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_jcgt_info.png?20151229'});
    //$scope.slides.push({id: 1, image: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syfc.png?20151229', text: '收益分成方式', active: false, directUrl: 'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syfc_info.png?20151229', shareurl:'http://www.xinyusoft.com:8085/uuFinancialPlanner/images/banner_syfc_info.png?20151229'});

    //console.log("slides", $scope.slides.length);
    homeslides = $scope.slides;

    $scope.jyzbintervalDuration = 8000;//间隔时间，8000毫秒
    $scope.jyzbintervalId;

    $scope.quickbtnDiv = false;

    //去除
    $scope.jyzbClearInterval = function () {
        if ($scope.jyzbintervalId != undefined) {
            clearInterval($scope.jyzbintervalId);
        }
    }

    $scope.getnewjybbCallBack = function(_data)
    {
        //console.log("交易直播", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.traderecord;
            if(arr.length>0)
            {
                $scope.newjjbb = {};
                $scope.newjjbb.stockcode = arr[0].code;
                $scope.newjjbb.stockname = arr[0].stockname;
                $scope.newjjbb.exchange = arr[0].exchange;
                $scope.newjjbb.type = arr[0].side
                if($scope.newjjbb.type == "B")
                {
                    $scope.newjjbb.typestr = "买入";
                }
                else
                {
                    $scope.newjjbb.typestr = "卖出";
                }
            }
        }
    }

    //当日交易播报
    $scope.getnewjybb = function()
    {
        //console.log("4343");
        var message = {};
        ajaxService.sendMessage('sunflower.getLcsTradeRecordAction', message, $scope.getnewjybbCallBack);
    }

    $scope.isjytimeCallBack = function(_data)
    {
        //console.log(timeistradeing);
        //console.log("交易时间", _data);
        if(_data.op.code.toString() == "Y")
        {
            if(_data.ftradeday == "Y" && _data.ftradetime == "Y")
            {
                timeistradeing = true;
            }
            else
            {
                timeistradeing = false;
            }
            //console.log(timeistradeing);
        }

        $scope.getnewjybb();
        //console.log("交易",timeistradeing);
        if(timeistradeing == true)
        {
            $scope.jyzbintervalId = setInterval($scope.getnewjybb, $scope.jyzbintervalDuration);
        }
    }
    //是否是交易时间
    $scope.isjytime = function()
    {
        var message = {};
        ajaxService.sendMessage("counter.GetSystemStatusAction", message, $scope.isjytimeCallBack);
    }

    $scope.init = function(newValue, oldValue, scope)
    {
        //console.log("home", newValue, oldValue);
        if(newValue)
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.userid = $scope.userObj.f_id;
            //console.log("home", $scope.userid);
            //$scope.lcsstatus =  localStorage.getItem("lcsstatus");

            //if($scope.dymark == false)
            //{
            //    var swiper = new Swiper('.swiper-container', {
            //        pagination: '.swiper-pagination',
            //        nextButton: '.swiper-button-next',
            //        prevButton: '.swiper-button-prev',
            //        slidesPerView: 1,
            //        paginationClickable: true,
            //        spaceBetween: 0,
            //        loop: true,
            //        paginationBulletRender: function (index, className) {
            //            //return '<span class="' + swiper-pagination-bullet + '">' + (index + 1) + '</span>';
            //            return '<span class="' + className + '">' + '</span>';
            //        }
            //    });
            //    $scope.dymark = true;
            //}

            //$scope.isjytime();

        }
        else
        {
            $scope.jyzbClearInterval();
        }
    }

    $scope.$watch('basetabOneShow', $scope.init);

    //更多功能
    $scope.morefunClick = function()
    {
        //$scope.quickBtnClick();
        //$scope.baseBottomVisible(false);
        //$scope.fpBaseDivShow = false;
        //$scope.setwxsm();
    }

    $scope.setwxsm = function()
    {
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        //var dzstr = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx4fbfd12de50a98c7&redirect_uri=http://wxtest.xinyusoft.com/weixin/testServlet?sid="+"652379c1-914e-4d9c-93c6-0a41dfe9bb90"+"&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
        $("#wxsmimg").qrcode({text:dzstr,width:200,height:200,src:$scope.head});
    }

    $scope.funintback = function()
    {
        $scope.homebaseShow = true;//主界面
        $scope.funintShow = false;//功能介绍
        $scope.baseBottomVisible(true);
    }

    //首页快捷键入口
    $scope.indexbtnClick = function(_str)
    {
        switch (_str)
        {
            case "1"://发布跟投
                //window.location = "gtrelease.html";
                openNewInterface("gtrelease.html" + "?opentype=newwebview" + "&&backtitle=" + encodeURI("关注"), "homeupdatefwlist");
                break;
            case "2"://发布观点
                setbackList("uufpBase.html?baseindex=1");
                window.location = "jiepan-fabu-gd.html" + "?backtitle=" + encodeURI("关注")+ "&&userid=" + $scope.userid;
                //openNewInterface("jiepan-fabu-gd.html" + "?backtitle=" + encodeURI("关注") + "&&opentype=newwebview" + "&&userid=" + $scope.userid);
                break;
            case "3"://自选股
                //window.location.href = "optionalBase.html" + "?backtitle=" + encodeURI("关注");
                openNewInterface("optionalBase.html" + "?backtitle=" + encodeURI("关注"), "homezxgupdateCallBack");
                break;
            case "4"://二维码
                //开户
                //openNewInterface("openAccounts.html?opentype=newwebview" + "&backtitle=" + encodeURI("关注"));
                $scope.gotoewmShow();
                break;
            case "5"://邀请好友--微信好友
                $scope.getwxLink();
                break;
            case "6"://好友 -- 朋友圈
                $scope.me_yqhy_pyq();
                break;
            default:
                break;
        }
    }

    $scope.gotoewmShow = function()
    {
        $scope.setwxsm();
        $scope.homebaseShow = false;
        $scope.homeewmShow = true;
        $scope.baseBottomVisible(false);
    }

    $scope.homeewmback = function()
    {
        $scope.homebaseShow = true;
        $scope.homeewmShow = false;
        $scope.baseBottomVisible(true);
    }

    homeupdatefwlist = function()
    {
        $scope.homeupdatefw();
    }

    homezxgupdateCallBack = function()
    {
        $scope.basezxgUpdate();
    }

    //交易直播
    $scope.jyzbClick = function()
    {
        //window.location.href = "jytitle.html";
        //window.location.href = "tradinglive.html" + "?backtitle=" + encodeURI("关注");
        //openNewInterface("tradinglive.html" + "?backtitle=" + encodeURI("关注") + "&&opentype=newwebview");
    }

    $scope.hometdClcik = function(_str)
    {
        //switch (_str)
        //{
        //    case "1"://快报
        //        $scope.homebaseShow = false;
        //        $scope.kbDivshow = true;
        //        $scope.baseBottomVisible(false);
        //        $scope.getlcskb();
        //        break;
        //    case "2"://交易直播
        //        //window.location.href = "jytitle.html";
        //        //window.location.href = "tradinglive.html" + "?backtitle=" + encodeURI("关注");
        //        openNewInterface("tradinglive.html" + "?backtitle=" + encodeURI("关注") + "&&opentype=newwebview");
        //        break;
        //    case "3"://收益榜
        //        //setbackList("uufpBase.html?baseindex=1");
        //        //window.location = "benefitsList.html" + "?backtitle=" + encodeURI("关注");
        //        openNewInterface("benefitsList.html" + "?backtitle=" + encodeURI("关注") + "&&opentype=newwebview");
        //        break;
        //    case "4"://理财师
        //        openNewInterface("newfpBase.html?backtitle=" + encodeURI("关注"));
        //        //window.location.href ="newfpBase.html?backtitle=" + encodeURI("关注");
        //        break;
        //    default:
        //        break;
        //}
    }

    //生成链接
    $scope.getwxLink = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        setUrl2(_str);
    }


    setUrl2  = function(_content)
    {
        //console.log(_content);
        var title = $scope.userName + '邀请您使用“向日葵理财”';
        var desc = '向日葵理财，您的私人理财师～～';

        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信邀请好友失败，请重试");
        })
    }

    $scope.spxjpClick = function()
    {
        $scope.homebaseShow = false;//主界面
        $scope.funintShow = true;//解盘
        $scope.baseBottomVisible(false);
    }

    $scope.funintback = function()
    {
        $scope.homebaseShow = true;//主界面
        $scope.funintShow = false;//解盘
        $scope.baseBottomVisible(true);
        gotoUp();
    }

    $scope.backtolcsList = function()
    {
        $scope.homebaseShow = true;//主界面
        $scope.funintShow = false;//解盘
        $scope.baseBottomVisible(true);
        gotoUp();
    }

}



