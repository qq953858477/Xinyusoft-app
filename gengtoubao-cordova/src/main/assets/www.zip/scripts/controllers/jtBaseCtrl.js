
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function jtBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.index = "1";//跳转至当前页面时的位置
    $scope.jtMainshow = true;
    $scope.ydDivShow = false;//引导界面
    $scope.djDivShow = false;//首先登记界面
    $scope.alldjDivShow = false;//所有登记

    $scope.jtfzintervalId;//复制链接定时
    $scope.jtewmDivShow = false;//二维码界面
    $scope.opentype = "";//打开方式

    $scope.gpcodename = "";//股票代码或者名称
    $scope.cbj = "";//成本价
    $scope.ccsl = "";//持仓数量
    $scope.lxdh = "";//联系电话
    $scope.desc = "";//说明

    $scope.gpcodename2 = "";//股票代码或者名称
    $scope.cbj2 = "";//成本价
    $scope.ccsl2 = "";//持仓数量

    $scope.dqjtlist = [];//当前登记

    //$scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = getParameter("opentype");

    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.bcidstr = localStorage.getItem('bcid');

    //当前解套的登记列表
    $scope.getdqjtlistCallBack = function(_data)
    {
        $scope.dqjtlist = [];
        //console.log("33", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.jietaoregisterlist;
            //arr = [];
            if(arr.length>0)
            {
                $scope.ydDivShow = false;
                $scope.alldjDivShow = true;

                for(var i = 0;i<arr.length;i++)
                {
                    var obj = {};
                    obj.gpcodename = arr[i].stockcode;
                    obj.cbj = arr[i].cbj;
                    obj.number = arr[i].number;
                    obj.telephone = arr[i].telephone;
                    obj.desc = arr[i].desc;
                    $scope.dqjtlist.push(obj);
                }
            }
            else
            {
                $scope.ydDivShow = true;
                $scope.alldjDivShow = false;
            }
        }
    }

    $scope.getdqjtlist = function()
    {
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['page.size'] = "max";
        message['page.no'] = "";
        console.log(message);
        ajaxService.sendMessage("sunflower.selectjietaoregisteraction", message, $scope.getdqjtlistCallBack);
    }

    $scope.discinit = function()
    {
        $scope.getdqjtlist();
    }
    $scope.discinit();

    //第一次进入登记解套界面
    $scope.djjtlinkClick = function()
    {
        $scope.ydDivShow = false;
        $scope.djDivShow = true;
        gotoUp();
    }

    //解套登记
    $scope.jtdjClick = function()
    {
        console.log("3434324",$scope.gpcodename, $scope.ccsl);
        if($scope.gpcodename == "" || $scope.ccsl == "")
        {
            //console.log("333");
            myAlert("请填写相关信息");
            return;
        }
        if(numericCheck($scope.ccsl) == false)
        {
            myAlert("持仓数量含有非数字字符");
            return;
        }
        if(valueCheck($scope.cbj) == false)
        {
            myAlert("请填写正确的成本价");
            return;
        }
        if($scope.lxdh != "")
        {
            if(numericCheck($scope.lxdh) == false)
            {
                myAlert("手机号码含有非数字字符");
                return;
            }
            if($scope.lxdh.length != 11)
            {
                myAlert("请输入正确的手机号码");
                return;
            }
        }
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['stockcode'] = $scope.gpcodename;
        message['cbj'] = $scope.cbj;
        message['number'] = $scope.ccsl;
        message['telephone'] = $scope.lxdh;
        message['desc'] = $scope.desc;
        console.log("登记", message);
        ajaxService.sendMessage("sunflower.addjietaoregisteraction", message, $scope.addjietaoregisteractionCallBack);
    }

    $scope.addjietaoregisteractionCallBack = function(_data)
    {
        //console.log("登记结果", _data);
        if(_data.op.code.toString() == "Y")
        {
            //登记成功
            //$scope.errorinfo = "登记成功！";
            $scope.gpcodename = "";//股票代码或者名称
            $scope.cbj = "";//成本价
            $scope.ccsl = "";//持仓数量
            $scope.desc = "";//说明
            $scope.djlbShow = true;
            $scope.$apply();

            if($scope.alldjDivShow == false)
            {
                $scope.ckdjjlClick();
            }
            else
            {
                $scope.getdqjtlist();
            }
        }
        else
        {
            myAlert("登记失败，原因：" + _data.op.info);
        }
    }

    $scope.jtdjClick2 = function()
    {
        if($scope.gpcodename2 == "" || $scope.ccsl2 == "")
        {
            myAlert("请填写相关信息");
            return;
        }
        if(valueCheck($scope.cbj2) == false)
        {
            myAlert("请填写正确的成本价");
            return;
        }
        if(numericCheck($scope.ccsl2) == false)
        {
            myAlert("持仓数量含有非数字字符");
            return;
        }

        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['stockcode'] = $scope.gpcodename2;
        message['cbj'] = $scope.cbj2;
        message['number'] = $scope.ccsl2;
        console.log("登记", message);
        ajaxService.sendMessage("sunflower.addjietaoregisteraction", message, $scope.addjietaoregisteractionCallBack2);
    }

    $scope.addjietaoregisteractionCallBack2 = function(_data)
    {
        //console.log("登记结果", _data);
        if(_data.op.code.toString() == "Y")
        {
            //登记成功
            //$scope.errorinfo = "登记成功！";
            //$scope.djlbShow = true;
            $scope.gpcodename2 = "";//股票代码或者名称
            $scope.cbj2 = "";//成本价
            $scope.ccsl2 = "";//持仓数量
            $scope.$apply();
            $scope.getdqjtlist();
        }
        else
        {
            myAlert("登记失败，原因：" + _data.op.info);
        }
    }

    //查看登记记录
    $scope.ckdjjlClick = function()
    {
        $scope.alldjDivShow = true;
        $scope.djDivShow = false;
        $scope.getdqjtlist();
    }

    //分享到微信
    $scope.jt_weixinfx = function()
    {
        var title = "股票解套预约";
        var desc = '被套牢的股民们，福利来啦～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/jt_introduce_share.html?inviterID=" + $scope.userObj.f_id +"&bcid=" + $scope.bcidstr;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.jt_pyqfx = function()
    {
        var title = "股票解套预约";
        var desc = '被套牢的股民们，福利来啦～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/jt_introduce_share.html?inviterID=" + $scope.userObj.f_id +"&bcid=" + $scope.bcidstr;
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.jt_codefans = function()
    {
        var box=document.getElementById("jtplk2");
        box.style.display="block";
        $scope.jtfzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/jt_introduce_share.html?inviterID=" + $scope.userObj.f_id +"&bcid=" + $scope.bcidstr);
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("jtplk2");
        box.style.display="none";
        if ($scope.jtfzintervalId != undefined)
        {
            clearInterval($scope.jtfzintervalId);
        }
    }

    $scope.jt_erwmShow = function()
    {
        $scope.jtMainshow = false;
        $scope.jtewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/jt_introduce_share.html?inviterID=" + $scope.userObj.f_id +"&bcid=" + $scope.bcidstr;
        //console.log(dzstr);
        $("#jtewmimg").qrcode({text:dzstr,width:220,height:220});
    }

    $scope.jtewmBackto = function()
    {
        $scope.jtMainshow = true
        $scope.jtewmDivShow = false;
        $("#jtewmimg").html("");
    }

    $scope.jtBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}




