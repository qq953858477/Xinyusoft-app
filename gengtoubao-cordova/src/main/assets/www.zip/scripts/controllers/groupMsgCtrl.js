﻿
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function groupMsgCtrl($scope, ajaxService, $cookieStore) {
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;
	$scope.bottomtab1Show = true;
	$scope.nofriend = false;
	$scope.tabOneShow = true;
    $scope.tabTwoShow = false;
	$scope.index = '1';
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.opentype = "";
    $scope.opentype = getParameter("opentype");
	$scope.role = "";
	$scope.temp = [];
	var times = 0;

    //初始相关操作界面
    $scope.Init = function()
    {
        //console.log(11);
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
			//alert(angular.toJson($scope.userObj));
			if($scope.userObj.f_role == "PT"||$scope.userObj.f_role == "PTM"){
				$scope.role = "-1";
			}else{
				$scope.role = "-2";
			}
			$scope.getGroups();
        }catch (e){
			//alert(e);
		}
    }
	
    $scope.backto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }
	
	//获取群组列表
	$scope.getGroups = function()
    {
		
        $scope.gandfArray = [];
        console.log("群组列表");
        var message = {};
        message['Group.userid'] = $scope.userObj.f_id;
        message['subjecttype'] = "groupTalk";
		//alert(angular.toJson(message));
        ajaxService.sendMessage("user.selectgroup", message, $scope.getfriendAllInfoCallBack) ;
	}
	//callback
	$scope.getfriendAllInfoCallBack = function(_data)
    {
        console.log("群组列表",_data);
        $scope.gandfArray = [];
		//alert(_data.op.code.toString());
		//alert(angular.toJson(_data));
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.grouplist;
			//alert(angular.toJson(element));
            for (var item in element)
            {
                var obj = {};
				obj.id = $scope.userObj.f_id;
				obj.iconUrl = element[item]['f_head'];
				obj.headurl = $scope.userObj.f_head;
				obj.name = $scope.userObj.f_nickname;
				obj.group_id = element[item]['f_id'];
				obj.master_id = element[item]['f_user_id'];
                obj.group_name = element[item]['f_groupname'];
				obj.membercount = element[item]['membercount'];
				obj.f_id = element[item]['groupmember_id'];
				//alert(obj.f_id);
                obj.infoNum = 0;//有多少未读消息
                obj.lastmsgid = 0;//已经读过的消息位置
				obj.check = false;
				$scope.temp.push(obj);
				//$scope.getMembers(obj.group.id);
                $scope.gandfArray.push(obj);
            }
        }

    }
	
    $scope.Init();
	$scope.gotoTop = function()
    {
        document.documentElement.scrollTop = document.body.scrollTop = 0;//页面置顶
    }
    $scope.gotoTop();
	
	//进入聊天窗口
	$scope.gandfItemClick = function(_obj)
    {
        _obj.xzzt = "0";
		var getTimestamp=new Date().getTime();
		//alert(_obj.master_id);
        setbackList(window.location.href);
        window.location = "groupChat.html?id=" + _obj.id + "&name=" + encodeURI(_obj.name) + "&headurl=" + encodeURIComponent(_obj.headurl)+"&newmsgcount="+_obj.infoNum + "&lastmsgid="+_obj.lastmsgid+"&timestamp="+getTimestamp+"&type=group"+"&groupid="+_obj.group_id+"&groupname="+encodeURI(_obj.group_name)+"&masterid="+_obj.master_id;
    }
	//进入系统消息窗口
	$scope.systemMsg = function(){
		//alert($scope.role);
		setbackList(window.location.href);
		window.location = "systemMsg.html?groupname=系统消息&type=group&groupid="+$scope.role;
		//window.location = "groupChat.html?groupname=系统消息&type=group&groupid="+$scope.role;
	}
	$scope.delGroup = function(obj){
        console.log("群组列表");
        var message = {};
        message['Groupmember.id'] = obj.f_id;
		//alert(obj.f_id);
		//alert(angular.toJson(message));
        ajaxService.sendMessage("user.deletegroupmember", message, $scope.getdeleteGroupCallBack) ;
	}
	$scope.getdeleteGroupCallBack = function(_data){
		//alert(angular.toJson(_data));
	}
}



