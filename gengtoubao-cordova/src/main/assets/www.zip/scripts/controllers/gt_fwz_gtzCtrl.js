
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function gt_fwz_gtzCtrl($scope, ajaxService, $cookieStore, $sce) {
    $scope.isyk = false;//是否是游客
    $scope.isgtz = true;//是否是跟投其他人
    $scope.zqgsname = "--";//证券公司名称
    $scope.accountShowValue = "";//跟投主账号，界面显示用
    $scope.plCount = "--";

    $scope.identity = "";//查看者的身份
    $scope.lsjyjlDivShow = false;//历史交易记录

    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//主界面
    $scope.plInputShow = false;//评论
    $scope.linkid = "";
    $scope.index = "1";//默认显示收益

    $scope.tabOneShow = true;//收益
    $scope.tabTwoShow = false;//持仓
    $scope.tabThreeShow = false;//交易记录
    $scope.tabFourShow = false;//评论
    //$scope.gtxqDivShow = false;//跟投详情
    $scope.dqgtInfo = {};
    $scope.dqgtInfo.rundays = "--";//实盘天数

    $scope.kssjstr = "";//开始时间
    $scope.jssjstr = "";//8位，服务结束时间

    $scope.gtsytstartdate = ""//收益图开始日期
    $scope.gtsytenddate = "";//收益图结束日期

    $scope.productname = "";//产品名
    $scope.productid = "--";//产品id
    $scope.headurl = "--";//用户头像
    $scope.name = "--";//用户名字
    $scope.zxgtje = "--";//最小跟投金额
    $scope.zyx = "--";//止盈线
    $scope.zsx = "--";//止损线
    $scope.gtje = "--";//跟投金额
    $scope.lcjhdesc = "--";//理财计划
    $scope.gtzhzqgs = "";//跟投账户证券公司
    $scope.gtzhzqgsstr = "";//跟投账户证券公司
    $scope.gtzhzqzh = "--";//跟投账户证券账户
    $scope.isgtjj = false;//是否是跟投基金

    $scope.gtzhInfoObj = null;//跟投账户信息
    $scope.hscheck = false;//是否 开通沪深
    $scope.cybcheck = false;//是否开通创业板
    $scope.ggtcheck = false;//是否开通港股通

    //服务设置
    $scope.assetopenflaggentou = "N";///对跟投者，资金收益公开
    $scope.clearpositionopenflaggentou = "N";///对跟投者，已清除记录公开
    $scope.positionamountopenflaggentou = "N";//对跟投者，持仓数量公开
    $scope.positionvarietyopenflaggentou = "N";//对跟投者持仓品种公开
    $scope.tradecommandopenflaggentou = "N";//对跟投者，交易指令公开

    $scope.account = "";//账户
    $scope.dqwtsjh = "";//当前委托随机号
    $scope.yjqchqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.yjqchqintervalId;

    $scope.jcgtfirstShow = false; //解除跟投第一步
    $scope.jcgtsecondShow = false;//解除跟投第二步
    $scope.ispc = false;//是否平仓
    $scope.jcgtErrorInfo = "";//解除操作中的错误提示
    $scope.jcgtMark = true;
    $scope.settleid = "";//结算单编号
    $scope.jsdInfo = null;//结算单
    $scope.firstin = true;//第一次进入界面


    $scope.productid = getParameter("productid");
    $scope.account = getParameter("linkaccount");
    $scope.linkid = getParameter("linkid");//当前跟投账户的id
    $scope.bgtuserid = getParameter("bgtuserid");//被跟投用户的id
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title
    $scope.identity = getParameter("identity");
    $scope.opentype = getParameter("opentype");

    var index2 = getParameter("index");
    if(index2 != "" && index2 != undefined)
    {
        $scope.index = index2;
    }

    //$scope.plmark = false;//未读评论标记
    $scope.hasReadNum = 0;//用户已读信息

    $scope.sce = $sce.trustAsResourceUrl;


    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
    });


    $scope.showinfo = function()
    {
        //收益等信息
        var cstr  = {"account":$scope.account, "caption": "gtsynthetical"};
        $scope.$broadcast("setParameters", cstr);

        //收益图
        var cstr  = {"account":$scope.account, "caption": "gtsysyt"};
        $scope.$broadcast("setParameters", cstr);

        ////持仓、今日交易记录、历史交易记录
        //var cstr  = {"account":$scope.account, "caption": "gtsycc"};
        //$scope.$broadcast("setParameters", cstr);
        //
        ////评论
        //var cstr  = {"account":$scope.account, "caption": "gtplshow"};
        //$scope.$broadcast("setParameters", cstr);
    }


    $scope.p_getgentouproductCallBack = function(_data)
    {
        //console.log("产品："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var product = _data.product;
            $scope.productname = product.name;
            $scope.headurl = product.user.user.f_head;
            $scope.name = product.user.user.f_nickname;//用户名字
            $scope.userid = product.user.user.f_id;
            $scope.zxgtje = product.minmoney;
            $scope.lcjhdesc = product.desc;//说明，理财计划
            //var str = product.endapplyday;
            //$scope.bmjzsj = str;//报名截止日期
            //var str2 = product.endgentouday;
            //$scope.fwjssj = str2;//服务结束时间
            //var str3 = product.gentouday;
            //$scope.fwkssj = str3;//服务开始时间
            //var str4 = product.createtime;
            //$scope.fwfbsj = str4;//服务发布时间
            //$scope.kssjstr = $scope.fwkssj.toString().substr(0,8);
            $scope.kssjstr = "";
            var ywarr = product.tradevariety;
            if(ywarr.length>0)
            {
                for(var j = 0;j<ywarr.length;j++)
                {
                    if(ywarr[j] == "A")
                    {
                        $scope.hscheck = true;
                    }
                    if(ywarr[j] == "C")
                    {
                        $scope.cybcheck = true;
                    }
                    if(ywarr[j] == "H")
                    {
                        $scope.ggtcheck = true;
                    }
                }
            }
        }
        $scope.changeTab($scope.index);
        $scope.getgtinfo();
    }

    $scope.getdqgtInfo = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品信息",$scope.productid);
        ajaxService.sendMessage("sunflower.p_getgentouproduct", message, $scope.p_getgentouproductCallBack);

    }

    $scope.checkisgtjjCallBack = function(_data)
    {
        //console.log("判断是否是跟投基金", _data);
        if(_data.op.code.toString() == "Y")//是跟投基金
        {
            $scope.gtzhzqgs = "跟投基金";
            $scope.isgtjj = true;
        }
        else//不是跟投基金
        {
            $scope.gtzhzqgs = $scope.gtzhzqgsstr;
            $scope.isgtjj = false;
        }
    }

    //判断是否是跟投基金
    $scope.checkisgtjj = function()
    {
        var message = {};
        message['account'] = $scope.gtzhzqzh;
        ajaxService.sendMessage("sunflower.isexperienceaccountrule", message, $scope.checkisgtjjCallBack);
    }

    $scope.gedqzzhzlzhCallBack = function(_data)
    {
        //console.log("自留账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.selfaccountlist;
            if(arr.length>0)
            {
                $scope.gtzhInfoObj.tradeaccount = arr[0].selfaccount;//自留账户
            }
        }
    }

    $scope.gedqzzhzlzh = function()
    {
        var message = {};
        message['account'] = $scope.gtzhzqzh;
        message['page.no'] = "1";
        message['page.size'] = "max";
        ajaxService.sendMessage("gentou.selectselfaccountaction", message, $scope.gedqzzhzlzhCallBack);
    }

    $scope.p_getgentouinfobyidCallBack = function(_data)
    {
        //console.log("跟投："+ _data);
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.accountlink;
            if(obj.stopprofit != null && obj.stopprofit != "" && obj.stopprofit != undefined)
            {
                $scope.zyx = obj.stopprofit;
            }
            if(obj.stoploss != null && obj.stoploss != "" && obj.stoploss != undefined)
            {
                $scope.zsx = obj.stoploss;
            }
            $scope.zqgsname = obj.linkaccountmoney.companyname;
            $scope.accountShowValue = obj.linkaccountmoney.belongaccount;
            $scope.gtje = parseFloat(obj.money);

            var linkObj = obj.linkaccountmoney;
            $scope.gtzhzqzh = linkObj.belongaccount;//主账户
            //$scope.gtzhzqgs = linkObj.companyname;
            $scope.gtzhzqgsstr = linkObj.companyname;

            $scope.gtzhInfoObj = {};
            //$scope.gtzhInfoObj.tradeaccount = linkObj.account;//自留账户
            $scope.gtzhInfoObj.zqgs  = linkObj.company;//证券公司id
            $scope.gtzhInfoObj.zqgsname = linkObj.companyname;
            $scope.gtzhInfoObj.account = linkObj.belongaccount;//主账户
            $scope.gtzhInfoObj.newflag = "N";//表示已经转过账

            //$scope.dqgtInfo.rundays = obj.rundays;//实盘天数
            $scope.gtchangezjMark = true;//可以修改资金

            var dstestr = obj.createtime.toString();
            $scope.gtsytstartdate = dstestr.substr(0,4) + dstestr.substr(5,2) + dstestr.substr(8,2);
            $scope.gtsytenddate = gettodayno();//收益图结束日期
            //console.log($scope.gtsytstartdate, $scope.gtsytenddate);

            if($scope.firstin)
            {
                $scope.showinfo();//图形收益等显示
                $scope.checkisgtjj();
                $scope.gedqzzhzlzh();//获取当前主账户的自留账户
            }
            $scope.firstin = false;
        }
    }

    $scope.getgtinfo = function()
    {
        var message = {};
        message['linkid'] = $scope.linkid;
        ajaxService.sendMessage("gentou.p_getgentouinfobyid", message, $scope.p_getgentouinfobyidCallBack);
    }

    //收益、理财师、跟投
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//综合
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "qysyjrjyjl"};
            $scope.$broadcast("setParameters", cstr);
        }
        else if(_str == "2")//交易
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = true;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = false;
            var cstr  = {"account":$scope.account, "caption": "gtsycc"};
            $scope.$broadcast("setParameters", cstr);
        }
        else if(_str == "3")//交易记录
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = true;
            $scope.tabFourShow = false;
        }
        else
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabThreeShow = false;
            $scope.tabFourShow = true;

            //var cstr  = {"account":$scope.account, "caption": "gtsypl"};
            //$scope.$broadcast("setParameters", cstr);
            //
            //$scope.plmark = false;
        }
    }

    $scope.getcpszCallBack = function(_data)
    {
        //console.log("服务设置", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.assetopenflaggentou = _data.assetopenflaggentou.toString();
            $scope.clearpositionopenflaggentou = _data.clearpositionopenflaggentou.toString();
            $scope.positionamountopenflaggentou = _data.positionamountopenflaggentou.toString();
            $scope.positionvarietyopenflaggentou = _data.positionvarietyopenflaggentou.toString();
            $scope.tradecommandopenflaggentou = _data.tradecommandopenflaggentou.toString();
        }
        $scope.getdqgtInfo();
    }

    $scope.getcpsz = function()
    {
        var message = {};
        message['productid'] = $scope.productid;
        //console.log("产品id", $scope.productid);
        ajaxService.sendMessage("sunflower.getproductsettingaction", message, $scope.getcpszCallBack);
    }

    $scope.getplcountCallBack = function(_data)
    {
        //console.log("消息",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.plCount = _data.count;
            //selectHasRead($scope.productid,$scope.userObj.f_id);
        }
    }

    //获取评论数量
    $scope.getplcount = function()
    {
        var message = {};
        message['subjectid'] = $scope.productid;
        message['subjecttype'] = "product";
        ajaxService.sendMessage("user.getcommentnumbysubjectidaction", message, $scope.getplcountCallBack);
    }

    //初始相关操作界面
    $scope.gtzInit = function()
    {
        try
        {
            var localStorage = window.localStorage;
            $scope.userObj = JSON.parse(localStorage.getItem('user'));
            $scope.getcpsz();
            //$scope.getplcount();
            $scope.jssjstr = getyesterdayno();

        }catch (e){}
    }
    $scope.gtzInit();

    //$scope.appInit = function()
    //{
    //    document.addEventListener('deviceready', function()
    //    {
    //        $scope.gtzInit();
    //    }, false);
    //}
    //$scope.appInit();

    //查看分成方式
    $scope.gotofcfs = function()
    {
        openNewInterface("gt_fcfs.html?opentype=newwebview");
        //window.location.href ="gt_fcfs.html";
    }

    //历史交易记录
    $scope.gotolsjy = function()
    {
        $scope.mainShow = false;
        $scope.lsjyjlDivShow = true;

        var cstr  = {"account":$scope.account, "caption": "gtsyjyjl"};
        $scope.$broadcast("setParameters", cstr);
    }

    $scope.lsjyjlBackto = function()
    {
        $scope.mainShow = true;
        $scope.lsjyjlDivShow = false;
    }

    //
    ////跟投详情
    //$scope.gtxqCkick = function()
    //{
    //    $scope.mainShow = false;
    //    $scope.gtxqDivShow = true;
    //}
    //
    //$scope.gtxqbackto = function()
    //{
    //    $scope.mainShow = true;
    //    $scope.gtxqDivShow = false;
    //}

    $scope.jcgtClick = function()
    {
        $scope.mainShow = false;//解除跟投
        $scope.jcgtfirstShow = true;

        $scope.jcquerycc();
    }

    $scope.jcquerycc = function ()
    {
        var message = {};
        message['account'] = $scope.account;
        //console.log("持仓", $scope.account);
        ajaxService.sendMessage("sunflower.p_selectposition", message, function (result) {
            //console.log("持仓",result);
            $scope.gtdqccArray = [];
            if (result.op.code == 'Y')
            {
                //$scope.ccljyk = parseFloat(result.ccyk.toString());
                var arr = result.securitypositionlist;
                if (arr.length > 0)
                {
                    for(var i= 0;i<arr.length;i++)
                    {
                        var obj = {};
                        obj.stockcode = arr[i].code;
                        obj.stockname = arr[i].name;
                        obj.exchange = arr[i].exchange;
                        obj.stockcodeall = obj.exchange +obj.stockcode;
                        obj.zqsl = parseInt(arr[i].kysl) + parseInt(arr[i].djsl);//可用数量
                        obj.kysl = parseInt(arr[i].kysl);
                        obj.dqj = parseFloat(arr[i].dqj).toFixed(2);
                        obj.cbj = parseFloat(arr[i].cbj);
                        obj.yk = arr[i].fdyk;
                        obj.zdf = parseFloat(arr[i].zdf).toFixed(2) + "%";
                        obj.status = arr[i].status;
                        obj.statusstr = getccStatus(obj.status);
                        $scope.gtdqccArray.push(obj);
                    }
                } else {
                    $scope.gtdqccArray = [];
                }
            } else {
                $scope.gtdqccArray = [];
            }
        });
    };

    $scope.backtopre = function()
    {
        $scope.mainShow = true;//解除跟投
        $scope.jcgtfirstShow = false;
        $scope.jcgtErrorInfo = "";
    }


    //解除申请同意协议
    $scope.jcsqtyxyClick = function()
    {
        if($scope.jcgtMark)
        {
            $scope.pcClick();
        }
    }

    //平仓
    $scope.pcClick = function()
    {
        $scope.jcgtMark = false;
        $scope.jcgtErrorInfo = "解除中...";
        $scope.settleid = "";
        $scope.ispc = true;
        var message = {};
        message['accountlinkid'] = $scope.linkid;
        message['pc'] = true;
        var newdate = new Date();
        message['pcextra'] = $scope.account + newdate.getTime();
        $scope.dqwtsjh = message['pcextra'];
        //console.log("accountlinkid", $scope.linkid);
        //console.log("message", message);
        ajaxService.sendMessage("gentou.p_removegentou", message, $scope.pcCallBack);

    }

    $scope.pcCallBack = function(_data)
    {
        //console.log("平仓",_data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.jcgtErrorInfo = "";
            $scope.settleid = _data.settleid;

            $scope.jcgtfirstShow = false;
            $scope.jcgtsecondShow = true;
            gotoUp();
            $scope.cjhbArray = [];

            for(var i = 0;i<$scope.gtdqccArray.length;i++)
            {
                var obj2 = {};
                obj2.gpdm = $scope.gtdqccArray[i].stockcode;
                obj2.gpmc = $scope.gtdqccArray[i].stockname;
                obj2.tc = $scope.gtdqccArray[i].exchange.toString().toUpperCase() + $scope.gtdqccArray[i].stockcode;
                obj2.tradetype = "卖出";
                obj2.xdwtsl = $scope.gtdqccArray[i].kysl;
                obj2.side = "S";

                obj2.wtsl = "--";
                obj2.wtsj = "";
                obj2.wtjg = "--";//parseFloat(obj.wtjg).toFixed(2);
                obj2.cjsl = "--";
                obj2.cjjg = "--";
                $scope.cjhbArray.push(obj2);
            }

            $scope.yjqcgetcjhb();

            //$scope.getjsdinfo();
        }
        else
        {
            $scope.jcgtErrorInfo = "解除跟投失败，原因：" + _data.op.info;
        }

        $scope.jcgtMark = true;
    }


    //获取成交回报
    $scope.yjqcgetcjhb = function()
    {
        var message = {};
        message['account'] = $scope.account;
        message['extra'] =  $scope.dqwtsjh;
        //console.log(message['account'],message['extra']);

        ajaxService.sendMessage("sunflower.p_selectbatchorder", message, $scope.yjqcgetcjhbCallBack);
    }

    $scope.yjqcgetcjhbCallBack = function(_data)
    {
        $scope.yjqcClearInterval();
        //console.log("一键清仓", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            //if($scope.cjhbArray.length == 0)
            //{
            //    for(var i=0;i<arr.length;i++)
            //    {
            //        var obj3 = arr[i].mainorder;
            //        var obj2 = {};
            //        obj2.gpdm = obj3.code;
            //        obj2.gpmc = obj3.name;
            //        obj2.tc = obj3.exchange.toString().toUpperCase() + obj2.gpdm;
            //        obj2.tradetype = "卖出";
            //        obj2.side = "S";
            //        $scope.cjhbArray.push(obj2);
            //    }
            //}

            for(var i=0;i<arr.length;i++)
            {
                var obj = arr[i].mainorder;
                var tc = obj.exchange.toString().toUpperCase() + obj.code;
                var mark = false;
                for(var j = 0;j<$scope.cjhbArray.length;j++)
                {
                    if(tc == $scope.cjhbArray[j].tc)
                    {
                        mark = true;
                        $scope.cjhbArray[j].wtsl = obj.wtsl;
                        $scope.cjhbArray[j].wtsj = obj.wtsj;
                        $scope.cjhbArray[j].wtjg = "市价";//parseFloat(obj.wtjg).toFixed(2);
                        $scope.cjhbArray[j].cjsl = parseFloat(obj.cjsl);
                        if(obj.cjsl == 0)
                        {
                            $scope.cjhbArray[j].cjjg = "0.00元";
                        }
                        else
                        {
                            $scope.cjhbArray[j].cjjg = (parseFloat(obj.cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                        }
                        break;
                    }
                }
                if(mark == false)
                {
                    var obj2 = {};
                    obj2.gpdm = obj.code;
                    obj2.gpmc = obj.name;
                    obj2.tc = obj.exchange.toString().toUpperCase() + obj2.gpdm;
                    obj2.tradetype = "卖出";
                    obj2.xdwtsl = obj.wtsl;
                    obj2.side = "S";

                    obj2.wtsl = obj.wtsl;
                    obj2.wtsj = obj.wtsj;
                    obj2.wtjg = "市价";//parseFloat(obj.wtjg).toFixed(2);
                    obj2.cjsl = parseFloat(obj.cjsl);
                    if(obj.cjsl == 0)
                    {
                        obj2.cjjg = "0.00元";
                    }
                    else
                    {
                        obj2.cjjg = (parseFloat(obj.cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }

                    $scope.cjhbArray.push(obj2);
                }
            }
            $scope.yjqcClearInterval();
            $scope.yjqchqintervalId = setInterval($scope.yjqcgetcjhb, $scope.yjqchqintervalDuration);
        }
    }

    $scope.getjsdinfo = function()
    {
        var message = {};
        message['settleid'] = $scope.settleid;
        ajaxService.sendMessage("gentou.p_getsettleinfo", message, $scope.p_getsettleinfoCallBack);
    }

    //结算单
    $scope.p_getsettleinfoCallBack = function(_data)
    {
        $scope.jsdInfo = {};
        //console.log("结算单", _data)
        if(_data.op.code.toString() == "Y")
        {
            var obj = _data.settleinfo;
            $scope.jsdInfo.syl = parseFloat(obj.profit)/parseFloat(obj.money);//收益率
            var str = obj.day.toString();
            $scope.jsdInfo.jsr = str.substr(0,4) + "-" + str.substr(4,2) + "-" + str.substr(6,2);//结算日
            $scope.jsdInfo.productname = obj.productname;//跟投账户名称
            $scope.jsdInfo.sr = obj.profit;//收入
            var sharestr = obj.share;//分成
            //console.log("分成",sharestr);
            if(sharestr == undefined || sharestr == null || sharestr == "")
            {
                $scope.jsdInfo.fc = 0;
            }
            else
            {
                $scope.jsdInfo.fc = sharestr;
            }
            $scope.jsdInfo.dqzf = obj.paymoney;//当期支付
            var str2 = obj.lastpayday.toString();
            $scope.jsdInfo.jzrq = str2.substr(0,4) + "-" + str2.substr(4,2) + "-" + str2.substr(6,2);//截止日期
        }
    }

    $scope.backtofirst = function()//返回第一步
    {
        $scope.jcgtfirstShow = true;
        $scope.jcgtsecondShow = false;
    }


    $scope.backtoPreviousLevel = function()
    {
        $scope.yjqcClearInterval();
        $scope.fbgtBackto();
    }

    //进入跟投账户
    $scope.gtzhClick = function ()
    {
        if($scope.gtzhInfoObj != null)
        {
            if($scope.isgtjj == true)//跟投基金
            {
                var _obj = $scope.gtzhInfoObj;
                var localStorage = window.localStorage;
                localStorage.setItem("account", _obj.tradeaccount);
                localStorage.setItem("accountcompany", _obj.zqgs);//证券公司id
                localStorage.setItem("accountName", encodeURIComponent(_obj.zqgsname));
                localStorage.setItem("accountShow", encodeURIComponent(_obj.account))
                localStorage.setItem("newflag", encodeURIComponent(_obj.newflag));
                //console.log(_obj.tradeaccount, _obj.account);
                //setbackList(window.location.href);
                //window.location.href = "tradeBase_gtjj.html";

                openNewInterface("tradeBase_gtjj.html?opentype=newwebview");
            }
            else//非跟投基金
            {
                var _obj = $scope.gtzhInfoObj;
                var localStorage = window.localStorage;
                localStorage.setItem("account", _obj.tradeaccount);
                localStorage.setItem("accountcompany", _obj.zqgs);//证券公司id
                localStorage.setItem("accountName", encodeURIComponent(_obj.zqgsname));
                localStorage.setItem("accountShow", encodeURIComponent(_obj.account))
                localStorage.setItem("newflag", encodeURIComponent(_obj.newflag));
                //setbackList(window.location.href);
                //window.location.href = "tradeBase_gtz.html";

                openNewInterface("tradeBase_gtz.html?opentype=newwebview");
            }
        }
    }


    //分享
    $scope.fxClick = function()
    {
        //var title = $scope.userName + ' 邀请您关注跟投宝服务';
        var title = $scope.productname;
        var desc = '跟投宝，您的私人理财师～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/gt_share.html?productid=" + $scope.productid;
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })
    }


    $scope.fbgtBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location = getbackList();
        }
    }

    $scope.yjqcClearInterval = function()
    {
        if ($scope.yjqchqintervalId != undefined) {
            clearInterval($scope.yjqchqintervalId);
        }
    }

    //读本地数据库
    function selectHasRead(productid,userid){
        //alert("select");
        var db = window.sqlitePlugin.openDatabase({
            name : "data\\hDB",
            bgType : 1
        });
        //alert(db);
        db.transaction(function(tx){
            tx.executeSql("CREATE TABLE IF NOT EXISTS read (productid text, userid text, readnum text)");
            tx.executeSql("SELECT * FROM read WHERE productid = "+productid+" and userid = "+userid,[],
                function(tx,res)
                {
                    if(res.rows.length == 0){

                        $scope.hasReadNum = 0;

                    }else
                    {
                        $scope.hasReadNum = res.rows.item(0).readnum;

                    }

                    //alert("已读取评论数" + $scope.hasReadNum);

                    if($scope.hasReadNum < $scope.plCount)
                    {
                        $scope.plmark = true;
                    }
                    else
                    {
                        $scope.plmark = false;
                    }
                });
        })
    }

}



