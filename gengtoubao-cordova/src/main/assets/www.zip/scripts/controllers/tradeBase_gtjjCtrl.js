/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function tradeBase_ggjjCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.account = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.username = "";
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.tabOneShow = true;//综合
    $scope.tabTwoShow = false;//交易
    $scope.tabFourShow = false;//查询
    $scope.smDivShow = false;//说明
    $scope.ztcaption = "";
    $scope.valueChange = false;
    $scope.deviceid = "";//设备号

    $scope.yyappArray = [];//已使用app
    $scope.ygtArray = [];//已跟投
    $scope.mxArray = [];//明细
    $scope.backtitle = "";//返回的title
    $scope.yqraccount = 0;//邀请人数

    $scope.fzintervalId;//复制链接定时
    $scope.ewmDivShow = false;//二维码界面
    $scope.gtjjzrDivShow = false;//跟投基金转让界面
    $scope.zsmoney = "";//转让money
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.shareurl = "http://www.xinyusoft.com:8085/uuFinancialPlanner/images/jlgz1.png";
    $scope.bcidstr = "-1";// 跟投宝："-1"; 雷帝:333

    var localStorage = window.localStorage;
    $scope.username = decodeURIComponent(localStorage.getItem('nickname'));

    //$scope.account = getParameter("account");
    var ind = getParameter("index");

    if(ind != "")
    {
       // $scope.index = ind;
    }

    var localStorage = window.localStorage;
    //$scope.sessionID = localStorage.getItem('sessionid');
    $scope.account = localStorage.getItem('account');
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.accountzqgs = decodeURIComponent(localStorage.getItem('accountName'));
    $scope.accountShowValue = localStorage.getItem('accountShow');//界面显示用
    $scope.head = decodeURIComponent(localStorage.getItem('iconurl'));
    //alert("设备号   " + localStorage.getItem("deviceid"));
    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid") != undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }
    //alert("设备号   "+ $scope.deviceid);

    $scope.accountcompany = localStorage.getItem('accountcompany');//证券公司
    $scope.opentype = getParameter("opentype");//打开方式

    //$scope.sessionID = $cookieStore.get('sessionid');
    //$scope.account = $cookieStore.get('account');
    //$scope.userObj = $cookieStore.get('user');
    //$scope.accountzqgs = decodeURIComponent($cookieStore.get('accountName'));


    $scope.accountStr = "***" + $scope.account.substr($scope.account.length-4);

    $scope.urlShow = false;
    //console.log($scope.sessionID,  $scope.account);

    //侦听子对象对参数的请求
    $scope.$on("getParameters", function(e,_data)
    {
        //console.log("侦听子对象对参数的请求");
        $scope.ztcaption = _data.caption;
        var cstr  = {"account":$scope.account, "caption": $scope.ztcaption};
        $scope.$broadcast("setParameters", cstr);
    });
    //console.log("tradeBase");

    //综合、交易/查询、关联切换
    $scope.changeTab = function(_str)
    {
        if(_str == "1")//交易
        {
            $scope.tabOneShow = true;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = false;

            //if($scope.valueChange)
            //{
                //console.log("重新获取数据");
                var cstr  = {"account":$scope.account, "caption": "zh_asset_gtjj"};
                $scope.$broadcast("setParameters", cstr);
            //}
        }
        else if(_str == "2")//交易
        {
            //$scope.tabOneShow = false;
            //$scope.tabTwoShow = true;
            //$scope.tabFourShow = false;

        }
        else//查询
        {
            $scope.tabOneShow = false;
            $scope.tabTwoShow = false;
            $scope.tabFourShow = true;
        }

        $scope.valueChange = true;
    }
    $scope.getexperiencegoldbyuseridactionCallBack = function(_data)
    {
        $scope.yyappArray = [];
        $scope.ygtArray = [];
        //console.log("212321data",_data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.downapplist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
                obj.money = arr[i].f_money;
                var str = arr[i].f_createtime.toString();
                obj.timestr = str.substr(0,10);
                $scope.yyappArray.push(obj);
            }

            var arr = _data.gtlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.headurl = arr[i].f_head;
                obj.name = arr[i].f_nickname;
                obj.money = arr[i].f_money;
                var str = arr[i].f_createtime.toString();
                obj.timestr = str.substr(0,10);
                $scope.ygtArray.push(obj);
            }
        }
    }

    $scope.mxbackto = function()
    {
        $scope.changeTab("1");
    }

    $scope.selectexperienceflowactionCallBack = function(_data)
    {
        //console.log("明细", _data);
        $scope.mxArray = [];
        $scope.yqraccount = 0;
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.experienceflowlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.type = arr[i].type.toString(); //firstlogin：邀请人成功； firstgentou：被邀请人做跟投；gentou：自己做跟投； transfer：转出； receivetransfer：接受转入
                if(obj.type == "firstlogin")
                {
                    $scope.yqraccount = $scope.yqraccount +1;
                }
                obj.changemoney = arr[i].changemoney;
                obj.money = arr[i].money;
                try
                {
                    obj.headurl = arr[i].inviteruser.user.f_head;
                    obj.name = arr[i].inviteruser.user.f_nickname;
                }
                catch (e)
                {
                    obj.headurl = "";
                    obj.name = "";
                }
                var times = arr[i].createtime.toString();
                obj.timestr = times.substr(0,19);
                if(obj.type == "gentou")
                {
                    obj.productname = arr[i].productname;
                }
                $scope.mxArray.push(obj);
            }
            if($scope.mxArray.length>0)
            {
                $scope.mxArray.sort(function(a, b)
                {
                    return new Date(b.timestr.replace(/-/g, "/")) - new Date(a.timestr.replace(/-/g, "/"))
                });
            }
        }
    }

    $scope.getInfo = function()
    {
        //console.log(333);
        //var message = {};
        //message['userid'] = $scope.userObj.f_id;
        //console.log("获取账户列表",$scope.userObj.f_id);
        //ajaxService.sendMessage("user.getexperiencegoldbyuseridaction", message, $scope.getexperiencegoldbyuseridactionCallBack);

        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['page.size'] = "max";
        message['page.no'] = "1";
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.selectexperienceflowaction", message, $scope.selectexperienceflowactionCallBack);

    }

    $scope.gtjjinit = function()
    {
        $scope.getInfo();
        $scope.changeTab($scope.index);
    }

    $scope.gtjjinit();

    //进入说明页面
    $scope.smClick = function()
    {
        $scope.homeDivShow = false;
        $scope.smDivShow = true;
    }

    //说明页返回
    $scope.smbackto = function()
    {
        $scope.homeDivShow = true;
        $scope.smDivShow = false;
    }


    //进入转送界面
    $scope.gotzsClick = function()
    {
        $scope.homeDivShow = false;
        $scope.gtjjzrDivShow = true;
    }

    //返回
    $scope.ggjjzsbackto = function()
    {
        $scope.homeDivShow = true;
        $scope.gtjjzrDivShow = false;
    }

    //转送
    $scope.zsClick = function()
    {
        //console.log($scope.zsmoney);
        if($scope.zsmoney == "")
        {
            myAlert("请输入转让金额");
            return;
        }
        if($scope.checkValue($scope.zsmoney) == false)
        {
            myAlert("请输入正确的数值");
            return;
        }
        if(parseFloat($scope.zsmoney)<100)
        {
            myAlert("转送金额需大于100元");
            return;
        }
        if(parseFloat($scope.zsmoney)%100 != 0)
        {
            myAlert("转送金额需为100的整数倍");
            return;
        }
        if(parseFloat($scope.zsmoney)>$scope.kyggjj)
        {
            myAlert("转送金额不可大于可用跟投基金");
            return;
        }
        //冻结基金金额
        var message = {};
        message['userid'] = $scope.userObj.f_id;
        message['transfermoney'] = $scope.zsmoney;
        //console.log("获取账户列表",$scope.userObj.f_id);
        ajaxService.sendMessage("sunflower.addexperiencetransferaction", message, $scope.addexperiencetransferactionCallBack);

    }

    $scope.addexperiencetransferactionCallBack = function(_data)
    {
        //console.log("33", _data);
        if(_data.op.code.toString() == "Y")
        {
            var str = _data.id;
            var title = $scope.username + " 转送跟投基金 " + $scope.zsmoney + " 元";
            var desc = '跟投宝，您的私人理财师～～';
            //var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?shareurl=" + encodeURI($scope.shareurl);
            //var _content = "http://test.xinyusoft.com:8080/uuFinancialPlanner/share/gtjjzs_lq.html?userid=" + $scope.userObj.f_id + "&money=" + $scope.zsmoney + "&transferID=" + str;
            var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/gtjjzs_lq.html?userid=" + $scope.userObj.f_id + "&money=" + $scope.zsmoney + "&transferID=" + str;
            $scope.zsmoney = "";
            shareUrlToDialog(_content, title, desc, function(data){
                //alert(JSON.stringify(data));
            },function(){
                //alert("微信邀请好友失败，请重试");
                myAlert("微信分享失败");
            })
        }
        else
        {
            myAlert("转送跟投基金失败");
        }
    }



    //返回上一级 ：交易、账号
    $scope.backtoPreviousLevel = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else {
            window.location.href = getbackList();
        }
    }

    //邀请好友
    $scope.me_yqhy_wxhy = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.username) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.username + '邀请您使用“跟投宝”';
        var desc = '跟投宝，您的私人理财师～～';

        shareUrlToDialog(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("微信邀请好友失败，请重试");
        })
    }

    $scope.me_yqhy_pyq = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.username) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.username + '邀请您使用“跟投宝”';
        var desc = '跟投宝，您的私人理财师～～';

        shareUrlToFriend(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("朋友圈分享失败");
        })
    }

    $scope.me_yqhy_ewm = function()
    {
        $scope.homeDivShow = false;
        $scope.wxyqewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.username) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        //console.log(dzstr);
        $("#wxyqewmimg").qrcode({text:dzstr,width:220,height:220});
    }
    $scope.wxyqewmBackto = function()
    {
        $scope.homeDivShow = true
        $scope.wxyqewmDivShow = false;

        $("#wxyqewmimg").html("");
    }



    //分享到微信
    $scope.weixinfx = function()
    {
        var title = "推荐跟投用户奖励";
        var desc = '跟投宝，您的私人理财师～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?shareurl=" + encodeURI($scope.shareurl);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("微信分享失败");
        })

    }

    //分享到朋友圈
    $scope.pyqfx = function()
    {
        var title = "推荐跟投用户奖励";
        var desc = '跟投宝，您的私人理财师～～';
        var _content = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?shareurl=" + encodeURI($scope.shareurl);
        shareUrlToFriend(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            //alert("微信邀请好友失败，请重试");
            myAlert("朋友圈分享失败");
        })

    }

    //复制链接
    $scope.codefans = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="block";
        $scope.fzintervalId = setInterval($scope.deletefz, 2000);
        setClipBoard("http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?shareurl=" + encodeURI($scope.shareurl));
    }

    $scope.deletefz = function()
    {
        var box=document.getElementById("plk2");
        box.style.display="none";
        if ($scope.fzintervalId != undefined)
        {
            clearInterval($scope.fzintervalId);
        }
    }

    $scope.erwmShow = function()
    {
        $scope.smDivShow = false;
        $scope.ewmDivShow = true;
        //var box=document.getElementById("ewmimg");
        //$("#ewmimg").qrcode({text:msgText,width:150,height:150,src:"images/kh-logo.png"});
        var dzstr = "http://www.xinyusoft.com:8085/uuFinancialPlanner/share/activity_share.html?shareurl=" + encodeURI($scope.shareurl);
        //console.log(dzstr);
        $("#ewmimg").qrcode({text:dzstr,width:220,height:220});
    }

    $scope.ewmBackto = function()
    {
        $scope.smDivShow = true
        $scope.ewmDivShow = false;

        $("#ewmimg").html("");
    }

    //判断是否全为数值和小数点
    $scope.checkValue = function(_str)
    {
        var len = _str.length;
        for(var i=0;i<len;i++)
        {
            //console.log(_str.charAt(i));
            if(_str.charAt(i)>"9" || _str.charAt(i)<"0")
            {
                return false;
            }
        }
        return true;
    }


}




