/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function myGroupBaseCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.mygroupmainShow = true;
    $scope.fsDivShow = true;//粉丝是否显示
    $scope.khDivShow = true;//客户是否显示

    $scope.bottomtab1Show = true;//下方tab

    $scope.mygindex = "1";//跳转至当前页面时的位置
    $scope.addDivShow = false;//添加选择界面显示
    $scope.wxinvitedShow = false;//微信邀请界面是否显示
    $scope.invitePath = "";//邀请链接

    $scope.gandfArray = [];//好友\群组列表
    $scope.nofriend = false;//无好友：true， 有好友：false
    $scope.wxyqMark = "1";//1：从初始界面进入，2：从菜单进入

    $scope.userObj = {};//客户信息
    $scope.userObj = $cookieStore.get('user');
    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
    $scope.head = decodeURIComponent(localStorage.getItem('iconurl'));
        //console.log("$scope.userObj", $scope.userObj)
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.ws;//websocket

    $scope.intervalDuration = 3000;//间隔时间，3000毫秒
    $scope.intervalId;


    //$scope.account = getParameter("account");
    var ind = getParameter("index");

    $scope.accountzqgs = decodeURIComponent(getParameter("accountName"));
    if(ind != "")
    {
        $scope.mygindex = ind;
    }

    //创建连接，准备接收推送消息
    $scope.receiveMessage = function()
    {
        //var channelID = "uulc";
        //var topic= "talk";
        //$scope.ws = webSocketReq($scope.chatonMessage, null, $scope.userObj.f_id,"ws://121.40.177.191:9988", channelID, topic);
        //
        //
        ////关联申请的推送
        //var channelID = "linkapply";
        //var topic= "glsqts";
        ////$scope.ws = webSocketReq(function(event){console.log("linkapply", event.toString())},null,"1","ws://121.40.177.191:8871", channelID);		//ws://10.29.226.22:8888 ws://121.40.177.191:8881
        //$scope.ws = webSocketReq($scope.onMessage, null, $scope.userObj.f_id,"ws://121.40.177.191:9988", channelID, topic);

    }

    //聊天
    $scope.chatonMessage = function(event)
    {
        $scope.$apply($scope.chatonMessagedeal(event));
    }

    $scope.chatonMessagedeal = function(event)
    {
        var _data = JSON.parse(event.data);
        //console.log("聊天信息", _data);
        if(_data != null)
        {
            var formid = _data.f.toString();//好友id
            for(var i = 0;i<$scope.gandfArray.length;i++)
            {
                if($scope.gandfArray[i].id == formid)
                {
                    $scope.gandfArray[i].infoNum = $scope.gandfArray[i].infoNum + 1;
                    if($scope.gandfArray[i].infoNum > 99)
                    {
                        $scope.gandfArray[i].infoNumStr = "99+";
                    }
                    else
                    {
                        $scope.gandfArray[i].infoNumStr = $scope.gandfArray[i].infoNum.toString();
                    }

                    break;
                }
            }
        }
    }

    //邀请
    $scope.onMessage = function(event)
    {
        //alert("邀请推送：" + event.data);
        $scope.$apply($scope.onMessagedeal(event));
    }

    $scope.onMessagedeal = function(event)
    {
        var _data = JSON.parse(event.data);
        //console.log("_data.type", _data.type);
        var formid = _data.fromuser.toString();//好友id
        for(var i = 0;i<$scope.gandfArray.length;i++)
        {
            if($scope.gandfArray[i].id == formid)
            {
                $scope.gandfArray[i].infoNum = $scope.gandfArray[i].infoNum + 1;
                if($scope.gandfArray[i].infoNum > 99)
                {
                    $scope.gandfArray[i].infoNumStr = "99+";
                }
                else
                {
                    $scope.gandfArray[i].infoNumStr = $scope.gandfArray[i].infoNum.toString();
                }

                break;
            }
        }
    }

    //判断邀请人是否是当前用户
    $scope.checkinvite =  function(_str)
    {
        var istrue = false;
        if(_str == undefined || _str == null || _str == "")
        {
            istrue =  false;
        }
        else
        {
            if(_str == $scope.userObj.f_id)
            {
                istrue = true;
            }
            else
            {
                istrue = false;
            }
        }
        return istrue;
    }

    $scope.getfriendAllInfoCallBack = function(_data)
    {
        //console.log("好友列表",_data);
        $scope.gandfArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.friendlist;
            for (var item = 0;item<element.length;item++)
            {
                var obj = {};
				//obj.infoNum = 0;
				obj.recordid = element[item]['f_id'];
                obj.iconUrl = element[item]['f_head'];
                obj.name = element[item]['f_nickname'];
                obj.id = element[item]['f_friend_id'];//element[item]['f_friend_id'];
                //obj.mobile = element[item]['f_head'];
                obj.role = element[item]['f_role'].toString();
                if(obj.role.indexOf("V",0) != -1)
                {
                    obj.vshow = true;
                }
                else
                {
                    obj.vshow = false;
                }
                if(obj.role.indexOf("G",0) != -1)//有G，跟投过
                {
                    obj.isgtg = true;
                }
                else
                {
                    obj.isgtg = false;
                }

                var deviceid = element[item]['f_deviceid'];
                if(deviceid == undefined || deviceid == null || deviceid == "")
                {
                    obj.userapp = false;
                }
                else
                {
                    obj.userapp = true;
                }

                obj.inviterid = element[item]['f_inviterid'];
                //console.log(obj.inviterid, $scope.userObj.f_id);
                obj.isinvite = $scope.checkinvite(obj.inviterid);
                obj.source = element[item]['f_source'];
                obj.system_id = element[item]['f_system_id'];
                //obj.weixinhao = element[item]['f_head'];
                obj.token = element[item]['f_token'];
                obj.openid = element[item]['f_openid'];
                obj.infoNum = element[item]['newmsgcount'];//有多少未读消息
                obj.lastmsgid =  element[item]['lastmsgid'];//已经读过的消息位置
                var fprovince = element[item]['f_province'];
                var fcity = element[item]['f_city'];

                if(fprovince == undefined && fcity == undefined)
                {
                    obj.dq = "";
                }
                else if(fprovince != undefined && fcity != undefined)
                {
                    obj.dq = fprovince + fcity;
                }
                else if(fprovince == undefined && fcity != undefined)
                {
                    obj.dq = fcity;
                }
                else
                {
                    obj.dq = fprovince;
                }

                if(obj.infoNum > 99)
                {
                    obj.infoNumStr = "99+";
                }
                else
                {
                    obj.infoNumStr = obj.infoNum.toString();
                }
                obj.xzzt = "1";
                if(element[item]['f_friend_id'].toString() != $scope.userObj.f_id)
                {
                    $scope.gandfArray.push(obj);
                }
            }
            if($scope.gandfArray.length>0)
            {
                $scope.nofriend = false;
                //间隔执行
                //console.log("间隔执行", $scope.intervalId);
                $scope.thisClearInterval();
                $scope.intervalId = setInterval($scope.repeatingFunction, $scope.intervalDuration);
            }
            else
            {
                $scope.nofriend = true;
            }
        }

    }

    //获取好友列表
    $scope.getFriends = function()
    {
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        message['friendinfo'] = "Y";
        ajaxService.sendMessage("user.selectfriendinfo", message, $scope.getfriendAllInfoCallBack) ;

        //var obj = {};
        //obj.iconUrl = "images/ico02_1.png";
        //obj.name = "刘建良";
        //obj.id = "1";
        //obj.mobile = "";
        //obj.role = "V";
        //obj.source = "";
        //obj.system_id = "";
        //obj.weixinhao = "";
        //if(obj.role == "V")
        //{
        //    obj.vshow = true;
        //}
        //else
        //{
        //    obj.vshow = false;
        //}
        //obj.xzzt = "1";
        //
        //$scope.gandfArray.push(obj);
        //
        //obj = {};
        //obj.iconUrl = "images/ico02_1.png";
        //obj.name = "王维";
        //obj.id = "2";
        //obj.mobile = "";
        //obj.role = "V";
        //obj.source = "";
        //obj.system_id = "";
        //obj.weixinhao = "";
        //if(obj.role == "V")
        //{
        //    obj.vshow = true;
        //}
        //else
        //{
        //    obj.vshow = false;
        //}
        //obj.xzzt = "1";
        //$scope.gandfArray.push(obj);
        //
        //obj = {};
        //obj.iconUrl = "images/ico02_1.png";
        //obj.name = "程静怡";
        //obj.id = "3";
        //obj.mobile = "";
        //obj.role = "V";
        //obj.source = "";
        //obj.system_id = "";
        //obj.weixinhao = "";
        //if(obj.role == "V")
        //{
        //    obj.vshow = true;
        //}
        //else
        //{
        //    obj.vshow = false;
        //}
        //obj.xzzt = "1";
        //$scope.gandfArray.push(obj);

       //$scope.receiveMessage();
    }


    //定时执行，获取未读取的信息
    $scope.repeatingFunction = function()
    {
        //console.log("定时执行，获取未读取的信息");
        var message = {};
        message['user.id'] = $scope.userObj.f_id;
        message['friendinfo'] = "";
        ajaxService.sendMessage("user.selectfriendinfo", message, $scope.getfriendwdCallBack) ;
    }

    //获取未读消息个数
    $scope.getfriendwdCallBack = function(_data)
    {
        var arr = [];
        //console.log("列表未读信息更新",_data);
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.friendlist;
            for (var item in element) {
                var obj = {};
                obj.id = element[item]['f_friend_id'];//element[item]['f_friend_id'];
                obj.infoNum = element[item]['newmsgcount'];//有多少未读消息
                obj.lastmsgid = element[item]['lastmsgid'];//已经读过的消息位置
                arr.push(obj);
            }

            for(var i = 0;i<arr.length;i++)
            {
                for(var j = 0;j<$scope.gandfArray.length;j++)
                {
                    if($scope.gandfArray[j].id == arr[i].id)
                    {
                        $scope.gandfArray[j].infoNum = arr[i].infoNum;
                        $scope.gandfArray[j].lastmsgid =  arr[i].lastmsgid;//已经读过的消息位置
                        if($scope.gandfArray[j].infoNum > 99)
                        {
                            $scope.gandfArray[j].infoNumStr = "99+";
                        }
                        else
                        {
                            $scope.gandfArray[j].infoNumStr = $scope.gandfArray[j].infoNum.toString();
                        }
                        break;
                    }
                }
            }
        }
    }

    //进入单个聊天窗口
    $scope.gandfItemClick = function(_obj)
    {
        //_obj.xzzt = "0";
        _obj.infoNum = 0;
        _obj.infoNumStr = "0";
        $scope.thisClearInterval();
        //setbackList(window.location.href);
        //window.location = "onePersonWin.html?id=" + _obj.id + "&name=" + encodeURI(_obj.name) + "&headurl=" + encodeURIComponent(_obj.iconUrl)+"&newmsgcount="+_obj.infoNum + "&lastmsgid="+_obj.lastmsgid+"&type=person";
        //

        var localStorage = window.localStorage;
        localStorage.setItem("peopleID", _obj.id);
        //setbackList(window.location.href);
        //window.location.href="peopleSpaceBase.html";
        openNewInterface("peopleSpaceBase.html?opentype=newwebview&page=list");
    }

    friendlistUpdate = function()
    {
    	$scope.bottomtabClick($scope.mygindex);
    }


    //点击切换 ：群组、搜索
    $scope.bottomtabClick = function(_str)
    {
        $scope.bottomtab1Show = true;
        //获取好友列表
        $scope.getFriends();
        //$scope.gotoTop();
    }




    $scope.mygrinit = function(newValue, oldValue, scope)
    {
        if(newValue)
        {
            $scope.bottomtabClick($scope.mygindex);
            //$scope.receiveMessage();
        }
        else
        {

        }
    }

    $scope.bottomtabClick($scope.mygindex);
    //$scope.$watch('basetabThreeShow', $scope.mygrinit);

    $scope.firstwxyqhy = function()
    {
        //$scope.wxyqMark = "1";
        //$scope.mygroupmainShow = false;
        //$scope.addDivShow = false;
        //$scope.wxinvitedShow = true;
        //$scope.getLink();
        $scope.geturl();
    }

    //进入添加界面
    $scope.addDivClick = function()
    {
        $scope.mygroupmainShow = false;
        $scope.addDivShow = true;
    }

    $scope.goto = function(_str)
    {
        switch (_str)
        {
            case "1":
                break;
            case "2":
                break;
            case "3":
                //$scope.getLink();
                $scope.geturl();
                break;
            default:
                break;
        }
    }

    $scope.geturl = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        setUrl(_str);
    }

    //生成链接
    $scope.getLink = function()
    {
        //console.log("gtlink");
        var path = location.href;
        //console.log(path);
        $scope.invitePath = "";
        if(path != "")
        {
            var index = path.lastIndexOf("/", path.length);
            //console.log(index);
            //pathstr = http://127.0.0.1:8080/uuFinancialPlanner/myGroupBase.html;
            //$scope.invitePath = path.substr(0,index+1);
            //$scope.invitePath = "http://www.xinyusoft.com:8085/uuFinancialPlanner/";
            //$scope.invitePath = $scope.invitePath + "invitedConnectionsBase.html?inviterName=" + $cookieStore.get('nickname') + "&inviterID=" + $scope.userObj.f_id + "&systemID=1";
            //$scope.invitePath = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx4fbfd12de50a98c7&redirect_uri=http://www.xinyusoft.com:8085/weixin/GetUserInfoServlet?btntype=addfriend%26";
            //$scope.invitePath = $scope.invitePath + "inviterName=" + $cookieStore.get('nickname') + "%26inviterID=" +  $scope.userObj.f_id + "&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
            var message = {};
            message['inviterID'] = $scope.userObj.f_id;
            //message['userName'] = $cookieStore.get('nickname');
            message['userName'] = encodeURI($scope.userName);
            message['bcid'] = $scope.bcidstr;
            //console.log(message);
            ajaxService.sendMessage("user.getShortInviteUrlByUser", message, $scope.getShortInviteUrlByUserCallBack) ;
        }
    }

    $scope.getShortInviteUrlByUserCallBack = function(_data)
    {
        if(_data.op.code.toString() == "Y")
        {
            //$scope.invitePath = _data.shorturl.toString();
            //console.log("32323", $scope.invitePath);
            setUrl(_data.shorturl.toString());
        }
        else
        {
            //alert("邀请链接获取失败");
            myAlert("微信邀请好友失败，请重试");
        }
    }

    setUrl  = function(_content)
    {
        //console.log(_content);
        var namestr = $scope.userName;
        var title = namestr + '邀请您使用“向日葵理财”';
        var desc = '向日葵理财，您的私人理财师～～';
        //console.log(namestr, _content);
        //alert(namestr + " " +_content);
        shareUrlToDialog(_content, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("微信邀请好友失败，请重试");
        })
    }


    $scope.group_yqhy_wxhy = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.userName + '邀请您使用“向日葵理财”';
        var desc = '向日葵理财，您的私人理财师～～';

        shareUrlToDialog(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("微信邀请好友失败，请重试");
        })
    }

    $scope.group_yqhy_pyq = function()
    {
        var _str = "http://www.xinyusoft.com:8085/uuFinancialPlanner/inviting.html?inviterName=" + encodeURI($scope.userName) + "&inviterID=" + $scope.userObj.f_id + "&header=" + $scope.head + "&systemID=" + $scope.userObj.f_system_id + "&bcid=" + $scope.bcidstr;
        var title = $scope.userName + '邀请您使用“向日葵理财”';
        var desc = '向日葵理财，您的私人理财师～～';

        shareUrlToFriend(_str, title, desc, function(data){
            //alert(JSON.stringify(data));
        },function(){
            myAlert("朋友圈分享失败");
        })
    }


    //复制链接
    $scope.copylinkClick = function()
    {
        try
        {
            setClipBoard($scope.invitePath , function(_data)
            {
                //alert("读取onSuccess:" + _data);
                //获取token
                if(_data.result == 1)//成功
                {
                    alert("成功复制到粘贴板" );
                }
                else//失败
                {
                    alert("复制失败");
                }
            }, function(e){
                alert("复制失败");
            });
        }
        catch(e){
            //alert(e.toString());
            alert("复制失败");
        }
        //window.prompt("Copy to clipboard: Ctrl+C, Enter", $scope.invitePath);
    }

    //返回
    $scope.backtoPrevious = function()
    {
        $scope.mygroupmainShow = true;
        $scope.addDivShow = false;
    }

    //返回添加列表
    $scope.backtoPreviouslist = function()
    {
        if($scope.wxyqMark == "1")
        {
            $scope.mygroupmainShow = true;
            $scope.addDivShow = false;
            $scope.wxinvitedShow = false;
        }
        else
        {
            $scope.mygroupmainShow = false;
            $scope.addDivShow = true;
            $scope.wxinvitedShow = false;
        }
    }


    //点击不显示手机弹出的键盘
    $scope.closePopClick = function()
    {}

    //去除
    $scope.thisClearInterval = function()
    {
        if($scope.intervalId != undefined)
        {
            clearInterval($scope.intervalId);
        }
    }

	//删除好友
	$scope.delfriend = function(obj){
		var message = {};
        message['Friend.id'] = obj.recordid;
		//alert(angular.toJson(message));
        ajaxService.sendMessage("user.deletefriend", message, $scope.getdeleteCallBack);
	}
	
	$scope.getdeleteCallBack = function(_data){
		//alert(angular.toJson(_data));
	}

    $scope.backto = function()
    {
        closeNewBrowser();
    }
}




