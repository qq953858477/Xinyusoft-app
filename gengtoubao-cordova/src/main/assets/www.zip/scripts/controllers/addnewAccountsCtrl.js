
/**
* 控制器
* @param $scope
* @param loginService
* @param amqService_noSession
*/
function addnewAccountsCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.userObj = {};//客户信息
    $scope.mainShow = true;//账户列表
    $scope.addzhDivshow = false;//添加账户
    $scope.zszhShow = false;//真实账户
    $scope.monizhshow = false;//模拟账户
    $scope.userName = "";
    $scope.backtitle = "";

    $scope.newzqzh = "";//新的证券账号
    $scope.newzqzhpassword = "";//新的证券账号密码
    $scope.newzqzhtxpassword = "";//新的证券通讯密码
    $scope.newzqyj = "0.0003";//新的证券账号佣金
    $scope.newxm = "";//新的账户姓名
    $scope.zsaddinfo = "";//真实账户添加操作中提示信息;

    $scope.mnnewzhzdje = "";
    $scope.mnnewxm = "";//模拟账户姓名
    $scope.mnnewzqyj = "0.0008";
    $scope.moniaddinfo = "";//模拟账户添加操作中提示信息

    $scope.monizqgsArray = [];//模拟证券公司
    $scope.zqgsArray = [];//证券公司
    $scope.selectedzqgs = {};//证券公司id
    $scope.addnewzqzhMark = true;//新加管理账号中

    $scope.mnzdjeArray = [];//模拟指定金额
    $scope.dqmnje = null;//选中的金额

    $scope.opentype = "";//打开类型
    $scope.opentype = getParameter("opentype");
    $scope.backtitle = decodeURI(getParameter("backtitle"));//返回的title

    $scope.sftype = "";

    //模拟账户指定金额
    $scope.setmnzdje = function()
    {
        $scope.mnzdjeArray = [];
        var obj = {};
        obj.label = "10万";
        obj.id = "1";
        obj.value = 100000;
        obj.check = false;
        $scope.mnzdjeArray.push(obj);

        obj = {};
        obj.label = "100万";
        obj.id = "2";
        obj.value = 1000000;
        obj.check = false;
        $scope.mnzdjeArray.push(obj);

        obj = {};
        obj.label = "1000万";
        obj.id = "3";
        obj.value = 10000000;
        obj.check = false;
        $scope.mnzdjeArray.push(obj);

    }

    //设置指定金额为false
    $scope.setzdjeallfalse = function()
    {
        for(var i = 0;i<$scope.mnzdjeArray.length;i++)
        {
            if($scope.mnzdjeArray[i].check == true)
            {
                $scope.mnzdjeArray[i].check = false;
                break;
            }
        }
    }

    //添加证券账户
    $scope.addSecurityAccountClick = function()
    {
        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqzhtxpassword = "";
        $scope.newzqyj = "0.0003";
        $scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewxm = "";
        $scope.mnnewzqyj = "0.0008";
        $scope.dqmnje = null;
        $scope.setzdjeallfalse();
    }

    //获取证券公司
    $scope.selectsecuritycompanyactionCallBack = function(_data)
    {
        //console.log("证券公司", _data);
        $scope.zqgsArray = [];
        $scope.monizqgsArray = [];
        if(_data.op.code.toString() == "Y")
        {
            var element = _data.securitycompanylist;
            //console.log(element.length);
            for (var item = 0;item < element.length; item++)
            {
                var obj = {};
                obj.id = element[item]['company'];
                obj.idstr = element[item]['company'].substr(0,1).toUpperCase();
                obj.name = element[item]['name'];
                obj.logo = getzqgsLogo(element[item]['company']);
                obj.apistatus = element[item]['apistatus'];//接口状态 0：表示正常，1：查资金有问题
                obj.passpwdflag = element[item]['passpwdflag'];//通讯密码 Y：需要，N：不需要
                //console.log("obj.apistatus", obj.passpwdflag, obj.name);
                //console.log("obj.apistatus", obj.apistatus, obj.name);
                if(obj.id != "moni")
                {
                    //console.log(obj.idstr);
                    $scope.zqgsArray.push(obj);
                }
                else
                {
                    $scope.monizqgsArray.push(obj);
                }
            }
        }

        if($scope.zqgsArray.length>0)
        {
            for(var i = 0;i<$scope.zqgsArray.length;i++)
            {
                if(i == 0)
                {
                    $scope.zqgsArray[i].idstrShow = true;
                }
                else
                {
                    if($scope.zqgsArray[i].idstr == $scope.zqgsArray[i-1].idstr)
                    {
                        $scope.zqgsArray[i].idstrShow = false;
                    }
                    else
                    {
                        $scope.zqgsArray[i].idstrShow = true;
                    }
                }
            }
        }
    }

    //获取证券公司
    $scope.getzqgs = function()
    {
        //console.log("证券公司");
        $scope.zqgsArray = [];
        $scope.monizqgsArray = [];
        var message = {};
        message['page.size'] = "max";
        message['page.no'] = "";
        message['company'] = "";
        message['name'] = "";
        message['desc'] = "";
        message['market'] = "";
        message['userid'] = $scope.userObj.f_id;
        ajaxService.sendMessage("sunflower.p_getsecuritycompany", message, $scope.selectsecuritycompanyactionCallBack);
        //ajaxService.sendMessage("counter.selectsecuritycompanyaction", message, $scope.selectsecuritycompanyactionCallBack);
    }

    //初始相关操作界面
    $scope.myfinInit = function()
    {
        var localStorage = window.localStorage;
        $scope.sftype = localStorage.getItem("lcsstatus");
        $scope.userObj = JSON.parse(localStorage.getItem('user'));
        $scope.userName = decodeURIComponent(localStorage.getItem('nickname'));
        $scope.setmnzdje();
        $scope.addSecurityAccountClick();
        $scope.getzqgs();
    }

    $scope.myfinInit();

    //进入添加界面
    $scope.zqgsItemClick = function(_obj)
    {
        $scope.mainShow = false;
        $scope.addzhDivshow = true;
        $scope.selectedzqgs = _obj;

        if(_obj.id == "moni")
        {
            $scope.zszhShow = false;
            $scope.monizhshow = true;

            $scope.mnzdjeArray[0].check = true;
            $scope.dqmnje = $scope.mnzdjeArray[0];
        }
        else
        {
            $scope.zszhShow = true;
            $scope.monizhshow = false;
        }
    }

    //确定增加关联账号
    $scope.addnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.newzqzh == "")
            {
                $scope.zsaddinfo = "请输入证券账号";
                return;
            }
            if($scope.newzqzhpassword == "")
            {
                $scope.zsaddinfo = "请输入交易密码";
                return;
            }
            if($scope.selectedzqgs.passpwdflag == 'Y')//需要通讯密码
            {
                if($scope.newzqzhtxpassword == "")
                {
                    $scope.zsaddinfo = "请输入通讯密码";
                    return;
                }
            }
            $scope.zsaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['account'] = $scope.newzqzh;//当前账号
            if($scope.selectedzqgs.passpwdflag == 'Y')
            {
                message['password'] = $scope.newzqzhpassword + "," + $scope.newzqzhtxpassword;
            }
            else
            {
                message['password'] = $scope.newzqzhpassword;
            }
            message['company'] = $scope.selectedzqgs.id;
            message['source'] = "A";
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.newzqyj;
            message['name'] = $scope.newxm;//备注名
            //console.log("增加证券账户", message);
            $scope.zsaddinfo = "添加账户中，请稍候...";
            ajaxService.sendMessage("sunflower.p_bindsecurity", message, $scope.p_bindsecurityaccountCallBack);
        }
    }

    $scope.p_bindsecurityaccountCallBack = function(_data)
    {
        //console.log("增加证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.newzqzh = "";
            $scope.newzqzhpassword = "";
            $scope.newzqzhtxpassword = "";
            $scope.newzqyj = "0.0003";
            $scope.newxm = "";
            $scope.zsaddinfo = "证券账户添加成功";
        }
        else
        {
            $scope.zsaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }

    //确定增加关联模拟账号
    $scope.moniaddnewzqzhConfirm = function()
    {
        if($scope.addnewzqzhMark)
        {
            if($scope.mnnewxm == "")
            {
                $scope.moniaddinfo = "请输入备注名";
                return;
            }
            $scope.moniaddinfo = "";
            $scope.addnewzqzhMark = false;

            var message = {};
            message['userid'] = $scope.userObj.f_id;
            message['yj'] = $scope.mnnewzqyj;
            message['money'] = $scope.dqmnje.value;
            message['name'] =  $scope.mnnewxm;
            //console.log("增加模拟账户", message);
            ajaxService.sendMessage("counter.p_bindmoniaccount", message, $scope.bindmoniaccountCallBack);
        }
    }

    $scope.bindmoniaccountCallBack = function(_data)
    {
        //console.log("增加模拟证券账户", _data);
        if(_data.op.code.toString() == "Y")
        {
            $scope.mnnewzhzdje = "";
            $scope.mnnewxm = "";
            $scope.mnnewzqyj = "0.0008";
            $scope.moniaddinfo = "模拟账户添加成功";
        }
        else
        {
            $scope.moniaddinfo = "失败原因：" + _data.op.info;
        }
        $scope.addnewzqzhMark = true;
    }

    $scope.mnjecheckClick = function (_obj)
    {
        //console.log("check");
        for(var i = 0;i<$scope.mnzdjeArray.length;i++)
        {
            if($scope.mnzdjeArray[i].check)
            {
                $scope.mnzdjeArray[i].check = false;
                break;
            }
        }
        _obj.check = true;
        $scope.dqmnje = _obj;
    }


    //返回证券公司列表
    $scope.backtozqgslist = function()
    {
        $scope.mainShow = true;
        $scope.addzhDivshow = false;
        $scope.selectedzqgs = {};

        $scope.newzqzh = "";
        $scope.newzqzhpassword = "";
        $scope.newzqzhtxpassword = "";
        $scope.newzqyj = "0.0003";
        $scope.newxm = "";
        $scope.mnnewzhzdje = "";
        $scope.mnnewxm = "";
        $scope.dqmnje = null;
        $scope.setzdjeallfalse();
        $scope.mnnewzqyj = "0.0008";
        $scope.addnewzqzhMark = true;
        $scope.zsaddinfo = "";
        $scope.moniaddinfo = "";
    }

    //开户
    $scope.khClick = function()
    {
        openNewInterface("openAccounts.html?opentype=newwebview");
    }
    //返回
    $scope.zhbackBackto = function()
    {
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location = getbackList();
        }
    }

}



