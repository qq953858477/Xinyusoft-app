var htmlType = "onestockhqType";
var code = "";
var sshqCanvasWidth = 0;
var sshqCanvasHeight = 0;
var hqajaxService;
var stock;
var klCycle = "day";

/**
 * 控制器
 * @param $scope
 * @param loginService
 * @param amqService_noSession
 */
function tradeBase_buysellCtrl($scope, ajaxService, $cookieStore) {
    $scope.sessionID = "";//session
    $scope.accountzqgs = ""//证券公司
    $scope.childaccount = "";
    $scope.accountStr = "";//账号显示
    $scope.userObj = {};//客户信息
    $scope.index = "1";//默认显示综合
    $scope.homeDivShow = true;//主界面信息
    $scope.tradeallShow = true;
    $scope.gtqkDiv = false;//跟投界面
    $scope.isbgt = "";//0:是， 1：不是

    $scope.hqShow = true;
    $scope.buyShow = false;
    $scope.sellShow = false;
    $scope.tradetype = "b";//b:买入；s：卖出
    $scope.opentype = "";//打开方式
    $scope.stockjysdm = "";//股票代码和交易所


    $scope.dqwtsjh = "";//当前委托随机号
    $scope.marketbuyMark = false;//是否市价买入
    $scope.marketsellMark = false;//是否市价卖出
    $scope.inputstockShow = true;//显示输入框并可操作
    $scope.deviceid = "";
    $scope.hq = {};
    $scope.wtjg;
    $scope.wtsl;
    $scope.kysl;
    $scope.mcjg;//卖出价格
    $scope.mcsl;//卖出数量
    $scope.mckysl;//卖出可用数量
    $scope.ddlx = "i";//报价方式
    $scope.buykyzj = 0;//可用资金
    $scope.zdkmShow = false;//最大可买是否显示
    $scope.flashbuyfiveDivShow = false;
    $scope.wtInfo = null;//委托信息
    $scope.sellwtInfo = null;//卖出委托信息
    $scope.stockcodeall = "";
    $scope.buyErrorInfo = "";//买入错误提示
    $scope.sellErrorInfo = "";//卖出错误提示

    $scope.buysellhqintervalDuration = 5000;//间隔时间，5000毫秒
    $scope.buysellhqintervalId;

    $scope.gtqkListArray = [];
    $scope.dqzgObj = null;//当前账户

    $scope.buySearchStockListArray = [];
    $scope.buygpssShow = false;

    $scope.sellSearchStockListArray = [];
    $scope.sellgpssShow = false;


    $scope.f10DivShow = false;//f10
    $scope.f10Src = "";//f10地址
    $scope.oneStockHQbasetab1Show = true;
    $scope.oneStockHQbasetab2Show = false;
    $scope.oneStockHQbasetab3Show = false;
    $scope.oneStockHQbasetab4Show = false;
    $scope.oneStockHQbasetab5Show = false;


    $scope.stock = {};
    $scope.stock.netchange = "--";//涨跌
    $scope.stock.netchangeratio = "--";//涨跌幅
    $scope.stock.close = "--";//最新
    $scope.stock.open =  "--";//今开
    $scope.stock.preclose = "--";//昨收
    $scope.stock.volume = "--";//成交量
    $scope.stock.amplituderatio = "--";//振幅
    $scope.stock.high = "--";//最高
    $scope.stock.low = "--";//最低
    $scope.stock.amount = "--";//成交额

    $scope.stock.capitalization = "--";//总市值
    $scope.stock.peratio = "--";//市盈率
    $scope.stock.turnoverRatio = "--";//换手
    $scope.stock.currencyValue = "--";//流通
    $scope.jyjlArray = [];//交易记录
    hqajaxService = ajaxService;


    var ind = getParameter("index");

    if(ind != "")
    {
       // $scope.index = ind;
    }
    var localStorage = window.localStorage;
    $scope.userObj = JSON.parse(localStorage.getItem('user'));
    $scope.childaccount = getParameter("account");//交易账户
    $scope.accountzqgs = decodeURI(getParameter("accountName"));//证券公司
    $scope.accountShowValue = getParameter("accountShow");//界面显示用
    $scope.opentype = getParameter("opentype");//打开方式
    //$scope.tradetype = getParameter("tradetype");//交易类型
    $scope.stockjysdm = getParameter("stock").toLowerCase();//股票代码
    $scope.isbgt = getParameter('isbgt');//是否被跟投
    $scope.accountcompany = getParameter('accountcompany');//证券公司
    console.log($scope.childaccount, $scope.accountzqgs, $scope.accountShowValue, $scope.opentype, $scope.tradetype, $scope.accountcompany, $scope.stockjysdm);

    if(localStorage.getItem("deviceid") != null && localStorage.getItem("deviceid")!= undefined)
    {
        $scope.deviceid = localStorage.getItem("deviceid");
    }


    //去除
    $scope.buysellClearInterval = function () {
        if ($scope.buysellhqintervalId != undefined) {
            clearInterval($scope.buysellhqintervalId);
        }
    }

    //清空界面数据
    $scope.onestockhqbaseClear = function()
    {
        $scope.stock = {};
        $scope.stock.netchange = "--";//涨跌
        $scope.stock.netchangeratio = "--";//涨跌幅
        $scope.stock.close = "--";//最新
        $scope.stock.open =  "--";//今开
        $scope.stock.preclose = "--";//昨收
        $scope.stock.volume = "--";//成交量
        $scope.stock.amplituderatio = "--";//振幅
        $scope.stock.high = "--";//最高
        $scope.stock.low = "--";//最低
        $scope.stock.amount = "--";//成交额

        $scope.stock.capitalization = "--";//总市值
        $scope.stock.peratio = "--";//市盈率
        $scope.stock.turnoverRatio = "--";//换手
        $scope.stock.currencyValue = "--";//流通

        $scope.stockcode = "";//代码
        $scope.exchange = "";//交易所
        $scope.stockname = "";
        $scope.stockInfo = null;
        $scope.datestr = "";//头部时间和状态

        $scope.oneStockHQbasetab1Show = true;
        $scope.oneStockHQbasetab2Show = false;
        $scope.oneStockHQbasetab3Show = false;
        $scope.oneStockHQbasetab4Show = false;
        $scope.oneStockHQbasetab5Show = false;

        //$scope.onestockhqbaseClearInterval();

        $("#onestockhqbasesshqLine").clearCanvasAll();
        $("#onestockhqbasefiveLine").clearCanvasAll();
        $("#onestockhqbasecanvasKL").clearCanvasAll();
        $("#onestockhqbasecanvasWeekKL").clearCanvasAll();
        $("#onestockhqbasecanvasMonthKL").clearCanvasAll();

        dataF = [];
        data5F = [];
        data5FDate = [];
        f5PreClose = 0;
        f5High = 0;
        f5Low = 0;
        dayKLpainter = null;
        weekKLpainter = null;
        monthKLpainter = null;
        sshqChart = null;
        fivechart = null;
    }

    //买卖切换
    $scope.tradetabClick = function(_str)
    {
        if(_str == "buy")
        {
            $scope.buyShow = true;//买入显示
            $scope.sellShow = false;//卖出显示
        }
        else
        {
            $scope.buyShow = false;//买入显示
            $scope.sellShow = true;//卖出显示

            if($scope.stockcodeall != "")//卖出界面
            {
                $scope.getmckysl();
            }
        }
        if($scope.gtqkDiv && $scope.isbgt == '0')
        {
            $scope.tradeallShow = true;
            $scope.gtqkDiv = false;//跟投情况
        }
    }

    //点击不显示手机弹出的键盘
    $scope.buysellClosePopClick = function(){
        $scope.buySearchStockListArray = [];
    };

    $scope.marketbuyChoose = function()
    {
        //console.log($scope.marketbuyMark);
        $scope.marketbuyMark = !$scope.marketbuyMark;
        $scope.kysl = "-";
        if($scope.stockcodeall != "" && $scope.marketbuyMark)
        {
            $scope.wtjg = "";
            $scope.getkysl();
        }
    }

    $scope.marketsellChoose = function()
    {
        //console.log($scope.marketsellMark);
        $scope.marketsellMark = !$scope.marketsellMark;
        if($scope.stockcodeall != "" && $scope.marketsellMark)
        {
            $scope.mcjg = "";
        }

    }

    $scope.selectsecuritymoneyactionCallBack = function(_data)
    {
        var arr = _data.moneylist;
        if(arr.length>0)
        {
            $scope.buykyzj = parseFloat(arr[0].kyzj.toString());
            //console.log("可用资金", $scope.kyzj);
        }
    }

    //最大可用
    $scope.getkyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.kysl  = _data.kmsl;
        }
    }

    $scope.getkysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['exchange'] = $scope.stockcodeall.substring(0,2).toUpperCase();
        message['account'] = $scope.childaccount;
        if($scope.marketbuyMark)//市价
        {
            message['price'] = 0;
            //console.log("price1：", message['price']);
        }
        else
        {
            message['price'] = $scope.wtjg;
            //console.log("price2：", message['price']);
        }
        //console.log("可用数量查询，委托价格：" ,  message['stockcode'], message['exchange'], message['account'], message['price']);
        ajaxService.sendMessage("sunflower.p_getzdkm", message, $scope.getkyslCallBack);

    }

    $scope.wtjgChange = function(_value)
    {
        //console.log("wtjgChange", $scope.wtjg);
        $scope.wtjg = _value;
        if(_value != "" && Number(_value) !=0)
        {
            $scope.getkysl();
        }
        else
        {
            $scope.kysl = "-";
        }
    }

    $scope.hq = {};
    $scope.queryhq = function (stockcode)
    {
        //console.log("11111", stockcode);
        //alert("stockcode"  + stockcode);
        if(stockcode != null && stockcode != "" && stockcode != undefined)
        {
            var message = {};
            if (stockcode.length == 8) stockcode = stockcode.substring(2);
            message['code'] = $scope.hq.exchange + stockcode;
            //alert("查询：" + stockcode);
            //ajaxService.sendMessage("model.sshqaction", message, $scope.sshqactionCallBack);
            $scope.buysellClearInterval();
            $scope.onestockhqbaseClear();
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;
            $scope.buysellhqintervalId = setInterval($scope.dscl, $scope.buysellhqintervalDuration);
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.mcjg = "";
            $scope.mckysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    };

    $scope.gpdmchange = function()
    {
        //alert("change");
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.wtjg = "";
        //    $scope.kysl = "-";
        //    $scope.zdkmShow = false;
        //    //$scope.$apply();
        //}
        //if($scope.wtInfo != null)
        //{
        //    $scope.wtInfo = null;
        //    $scope.gtqkListArray = [];
        //}
        //$scope.stockcodeall = "";

        if($scope.hq.stockcode != "")
        {
            $scope.buygpssShow = true;
            $scope.buycheckContent();
        }
        else
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            console.log(4243);
        }
        if($scope.wtInfo != null)
        {
            $scope.wtInfo = null;
            $scope.gtqkListArray = [];
        }
        $scope.stockcodeall = "";
    }

    $scope.buycheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.buysearchStockCallBack);
    }

    //搜索股票返回
    $scope.buysearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.buySearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.buySearchStockListArray = arr;
                    if($scope.buySearchStockListArray.length == 1)
                    {
                        $scope.setbuyonegp();
                    }
                }
                else {
                    $scope.buySearchStockListArray = [];
                    $scope.buygpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.buySearchStockListArray = [];
            $scope.buygpssShow = false;
            return;
        }
    }

    $scope.setbuyonegp = function()
    {
        if($scope.buySearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.buySearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.buySearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.buySearchStockListArray[0].exchange).toLowerCase();
                $scope.buygpssShow = false;
                $scope.queryhq($scope.buySearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.buycheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.buygpssShow = false;
        $scope.queryhq(_obj.gpdm);

    }

    //股票行情
    $scope.sshqactionCallBack = function(_data)
    {
        //console.log("行情查询返回：" ,_data);
        //alert("查询返回：" + _data.code.toString());
        if (_data.op.code == 'Y')
        {
            //result.hq.uplimit = Number(result.hq.uplimit).toFixed(2);
            //result.hq.downlimit = Number(result.hq.downlimit).toFixed(2);
            //alert("查询返回：" + result.buyv.toString());
            if(_data.datalist.length==0)
            {
                return;
            }
            var result = _data.datalist[0];
            var obj = {};
            var buyvarr = result.bid;
            obj.buyv1 = Math.floor(Number(buyvarr[0].volume)/100)+'手';
            obj.buyv2 = Math.floor(Number(buyvarr[1].volume)/100)+'手';
            obj.buyv3 = Math.floor(Number(buyvarr[2].volume)/100)+'手';
            obj.buyv4 = Math.floor(Number(buyvarr[3].volume)/100)+'手';
            obj.buyv5 = Math.floor(Number(buyvarr[4].volume)/100)+'手';

            obj.buyp1 = Number(buyvarr[0].price).toFixed(2);
            obj.buyp2 = Number(buyvarr[1].price).toFixed(2);
            obj.buyp3 = Number(buyvarr[2].price).toFixed(2);
            obj.buyp4 = Number(buyvarr[3].price).toFixed(2);
            obj.buyp5 = Number(buyvarr[4].price).toFixed(2);


            var sellvarr = result.ask;
            obj.sellv1 = Math.floor(Number(sellvarr[0].volume)/100)+'手';
            obj.sellv2 = Math.floor(Number(sellvarr[1].volume)/100)+'手';
            obj.sellv3 = Math.floor(Number(sellvarr[2].volume)/100)+'手';
            obj.sellv4 = Math.floor(Number(sellvarr[3].volume)/100)+'手';
            obj.sellv5 = Math.floor(Number(sellvarr[4].volume)/100)+'手';

            obj.sellp1 = Number(sellvarr[0].price).toFixed(2);
            obj.sellp2 = Number(sellvarr[1].price).toFixed(2);
            obj.sellp3 = Number(sellvarr[2].price).toFixed(2);
            obj.sellp4 = Number(sellvarr[3].price).toFixed(2);
            obj.sellp5 = Number(sellvarr[4].price).toFixed(2);

            obj.stockcode = result.stockbasic.stockcode;
            obj.exchange = result.stockbasic.exchange;
            obj.lastprice = result.close;//最新价格
            obj.name = result.stockbasic.stockname;

            //if(obj.name != null && obj.name != "" && obj.name != undefined)
            //{
            //    $scope.inputstockShow = false;
            //}

            //console.log("交易所", obj.exchange);

            $scope.hq = obj;
            $scope.stockcodeall = $scope.hq.exchange + $scope.hq.stockcode;
            //console.log("$scope.stockcodeall", $scope.stockcodeall);
            //$scope.wtjg = Number($scope.hq.lastprice);

            $scope.zdkmShow = true;
            //取可用数量
            if($scope.marketbuyMark && $scope.buyShow)
            {
                $scope.getkysl();
            }
            if($scope.sellShow)//卖出界面
            {
                $scope.getmckysl();
            }
        }
        else
        {
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.wtjg = "";
            $scope.kysl = "-";
            $scope.zdkmShow = false;
            //$scope.$apply();
        }
    }

    $scope.dscl = function()
    {
        //$scope.buysellClearInterval();
        if($scope.stockcodeall != null && $scope.stockcodeall != "" && $scope.stockcodeall != undefined)
        {
            var message = {};
            message['code'] = $scope.stockcodeall;
            ajaxService.sendMessage("hq.getsnapshot", message, $scope.sshqactionCallBack) ;

            if($scope.wtInfo != null)
            {
                if($scope.wtInfo.code == "Y")
                {
                    if($scope.isbgt == '0')//被跟投
                    {
                        var message2 = {};
                        message2['account'] = $scope.childaccount;
                        message2['extra'] =  $scope.dqwtsjh;
                        //console.log(message['account'],message['extra']);

                        ajaxService.sendMessage("sunflower.p_selectbatchorder", message2, $scope.buygetcjhbCallBack);
                    }
                    else//无跟投
                    {
                        var message2 = {};
                        message2['account'] = $scope.childaccount;
                        message2['htbh'] = $scope.wtInfo.htbh;
                        console.log("委托", message2);
                        ajaxService.sendMessage("sunflower.p_selectorder", message2, $scope.p_selectorderCallBack) ;
                    }

                }
            }

            if($scope.sellwtInfo != null)
            {
                if($scope.sellwtInfo.code == "Y")
                {
                    if($scope.isbgt == '0')//被跟投
                    {
                        var message2 = {};
                        message2['account'] = $scope.childaccount;
                        message2['extra'] =  $scope.dqwtsjh;
                        //console.log(message['account'],message['extra']);
                        ajaxService.sendMessage("sunflower.p_selectbatchorder", message2, $scope.sellgetcjhbCallBack);
                    }
                    else
                    {
                        var message2 = {};
                        message2['account'] = $scope.childaccount;
                        message2['htbh'] = $scope.sellwtInfo.htbh;
                        ajaxService.sendMessage("sunflower.p_selectorder", message2, $scope.p_selectorderCallBack2) ;
                    }
                }
            }

            $scope.hqloadStockInfo();
        }

    }

    //加载股票信息
    $scope.hqloadStockInfo = function()
    {
        htmlType = "onestockhqType";
        var message = {};
        message['code'] = $scope.hq.exchange + $scope.hq.stockcode;
        ajaxService.sendMessage('hq.getsnapshot', message, $scope.getsnapshotCallBack);
    }

    $scope.getsnapshotCallBack = function(_data)
    {
        //console.log("个股", _data);
        if(_data.op.code.toString() == "Y" && _data.datalist.length>0)
        {
            var obj  = _data.datalist[0];
            $scope.stock = {};
            $scope.stock.netchange = Number(obj.netchange).toFixed(2);//涨跌
            $scope.stock.close = Number(obj.close).toFixed(2);//最新
            $scope.stock.open =  Number(obj.open).toFixed(2);//今开
            $scope.stock.preclose = Number(obj.preclose).toFixed(2);//昨收
            $scope.stock.volume = (obj.volume/100).toFixed(0);//成交量
            //console.log(obj.volume);
            $scope.stock.amplituderatio = Number(obj.amplituderatio).toFixed(2);//振幅
            $scope.stock.high = Number(obj.high).toFixed(2);//最高
            $scope.stock.low = Number(obj.low).toFixed(2);//最低
            $scope.stock.amount = obj.amount;//成交额
            if(Number(obj.peratio)<0)
            {
                $scope.stock.peratio = "--";//市盈率
            }
            else
            {
                $scope.stock.peratio = Number(obj.peratio).toFixed(2) ;//市盈率
            }
            $scope.stock.turnoverRatio = Number(obj.turnoverratio).toFixed(2);//换手

            $scope.stock.capitalization1 = obj.capitalization;//总市值
            var capitalization2 = Number($scope.stock.capitalization1) / 100000000;
            var capitalizationpro = ($scope.stock.capitalization1+"").split(".");
            var fixed1 = capitalizationpro[0].length - 3;
            $scope.stock.capitalization = capitalization2.toFixed(Math.abs(fixed1))+"亿";

            $scope.stock.currencyvalue1 = obj.currencyvalue;//流通
            var currencyValue2= Number($scope.stock.currencyvalue1) / 100000000;
            var currencyValuepro = ($scope.stock.currencyValue1+"").split(".");

            var fixed2 = currencyValuepro[0].length - 7;
            $scope.stock.currencyvalue = currencyValue2.toFixed(Math.abs(fixed2))+"亿";

            $scope.stock.inside1 = Number(obj.inside)/100; //内盘
            if(Number($scope.stock.inside1) > 1000)
            {
                var inside1 = Number($scope.stock.inside1) / 10000;
                var insidepro = (inside1+"").split(".");
                var fixed = insidepro[0].length - 3;
                $scope.stock.inside = inside1.toFixed(Math.abs(fixed))+"万";
            }
            else
            {
                $scope.stock.inside = $scope.stock.inside1.toString();
            }

            $scope.stock.outside1 = Number(obj.outside)/100;//外盘
            if(Number($scope.stock.outside1) > 1000)
            {
                var outside1 = Number($scope.stock.outside1) / 10000;
                var outsidepro = (outside1+"").split(".");
                var fixed = outsidepro[0].length - 3;
                $scope.stock.outside = outside1.toFixed(Math.abs(fixed))+"万";
            }
            else
            {
                $scope.stock.outside = $scope.stock.outside1.toString();
            }
            if(Number(obj.netchangeratio) > 0)
            {
                $scope.stock.netchangeratio = "+" + Number(obj.netchangeratio).toFixed(2);//涨跌幅
                $scope.stock.status = "1";//1:红，2：绿，3：白
            }
            else
            {
                $scope.stock.netchangeratio = Number(obj.netchangeratio).toFixed(2);
                if(Number(obj.netchangeratio)<0)
                {
                    $scope.stock.status = "2";
                }
                else
                {
                    $scope.stock.status = "3";
                }
            }

            $scope.stock.stockstatus = obj.stockbasic.stockstatus.toString();

            var date = obj.date;
            var time = obj.time;
            //$scope.datestr = getDateStr(date,time);

            var exchangestatustype = _data[$scope.hq.exchange+"_status"].exchangestatustype;

            if(exchangestatustype =="0")
            {
                $scope.datestr = "集合竞价";
            }
            else if(exchangestatustype =="1")
            {
                $scope.datestr = "交易中";
            }
            else if(exchangestatustype =="2")
            {
                $scope.datestr = "午间休市";
            }
            else if(exchangestatustype =="3")
            {
                $scope.datestr = "已收盘";
            }
            else if(exchangestatustype =="4")
            {
                $scope.datestr = "未开盘";
            }
            else if(exchangestatustype =="5")
            {
                $scope.datestr = "法定节假日休市";
            }
            stock = $scope.stock;
            if($scope.oneStockHQbasetab1Show)
            {
                drawF();
            }
            else if($scope.oneStockHQbasetab2Show)
            {
                draw5F();
            }

            //if($scope.stock.stockstatus != "2" || $scope.datestr != "交易中")
            //{
            //    $scope.onestockhqbaseClearInterval();
            //}

        }
    }

    $scope.getjyjl = function()
    {
        var message = {};
        message['account'] = $scope.childaccount;
        message['stockcode'] = $scope.hq.stockcode;
        //console.log("交易记录",message);
        ajaxService.sendMessage('counter.selectstocktraderecordaction', message, $scope.getjyjlCallBack);
    }

    $scope.getjyjlCallBack = function(_data)
    {
        $scope.jyjlArray = [];
        //console.log("交易记录", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.traderecordlist;
            for(var i = 0;i<arr.length;i++)
            {
                var obj = {};
                obj.side = arr[i].side.toString();
                if(obj.side == "B")
                {
                    obj.typestr = "买入";
                }
                else if(obj.side == "S")
                {
                    obj.typestr = "卖出";
                }
                obj.gpjg = parseFloat(arr[i].cjjg).toFixed(2);
                obj.gpsl = arr[i].cjsl;
                obj.timestr = arr[i].date.toString().substr(0,10);
                $scope.jyjlArray.push(obj);
            }
        }
    }

    $scope.hqinit = function()
    {

        $scope.getjyjl();

        sshqCanvasWidth = getWidth();//- 10;
        sshqCanvasHeight = 310;

        code = $scope.hq.exchange + $scope.hq.stockcode;
        $scope.hqloadStockInfo();
            //$scope.ssintervalId = setInterval($scope.hqloadStockInfo, $scope.ssintervalDuration);
    }

    $scope.changeTab = function(_str)
    {
        if(_str == "1")
        {
            $scope.hqShow = true;
            $scope.buyShow = false;
            $scope.sellShow = false;

            $scope.hqinit();
        }
        else if(_str == "2")
        {
            $scope.hqShow = false;
            $scope.buyShow = true;
            $scope.sellShow = false;
        }
        else if(_str == "3")
        {
            $scope.hqShow = false;
            $scope.buyShow = false;
            $scope.sellShow = true;
        }
    }

    $scope.buysellInit = function()
    {
        //if($scope.tradetype == "b")//买入
        //{
        //    $scope.buyShow = true;
        //    $scope.sellShow = false;
        //}
        //else
        //{
        //    $scope.buyShow = false;
        //    $scope.sellShow = true;
        //}
        $scope.hq = {};
        $scope.hq.stockcode = $scope.stockjysdm.substring(2);
        $scope.hq.exchange = ($scope.stockjysdm.substr(0,2)).toLowerCase();
        $scope.queryhq($scope.hq.stockcode);

        $scope.changeTab("1");

    }

    $scope.buysellInit();

    //查询委托状态
    $scope.p_selectorderCallBack = function(_data)
    {
        //console.log("查询委托状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            if(arr.length>0)
            {
                $scope.wtInfo.wtsl = arr[0].wtsl;
                $scope.wtInfo.wtsj = arr[0].wtsj;
                $scope.wtInfo.cjsl = arr[0].cjsl;
                if(parseFloat(arr[0].wtjg) == 0)
                {
                    $scope.wtInfo.wtjg = "市价";
                }
                else
                {
                    $scope.wtInfo.wtjg = parseFloat(arr[0].wtjg).toFixed(2)+"元";
                }

                if(parseFloat($scope.wtInfo.cjsl) == 0)
                {
                    $scope.wtInfo.cjjg = "0.00元";
                }
                else
                {
                    $scope.wtInfo.cjjg = (parseFloat(arr[0].cjje)/parseFloat($scope.wtInfo.cjsl)).toFixed(2) + "元";
                }
                //$scope.wtInfo.cjsj = arr[i].cjsj;
            }
        }
    }

    //查询委托状态
    $scope.p_selectorderCallBack2 = function(_data)
    {
        //console.log("查询委托状态", _data);
        if(_data.op.code.toString() == "Y")
        {
            var arr = _data.securityorderlist;
            if(arr.length>0) {
                $scope.sellwtInfo.wtsl = arr[0].wtsl;
                $scope.sellwtInfo.wtsj = arr[0].wtsj;
                $scope.sellwtInfo.cjsl = arr[0].cjsl;
                if (parseFloat(arr[0].wtjg) == 0) {
                    $scope.sellwtInfo.wtjg = "市价";
                }
                else {
                    $scope.sellwtInfo.wtjg = parseFloat(arr[0].wtjg).toFixed(2) + "元";
                }

                if (parseFloat($scope.sellwtInfo.cjsl) == 0) {
                    $scope.sellwtInfo.cjjg = "0.00元";
                }
                else {
                    $scope.sellwtInfo.cjjg = (parseFloat(arr[0].cjje) / parseFloat($scope.sellwtInfo.cjsl)).toFixed(2) + "元";
                }
                //$scope.sellwtInfo.cjsj = arr[0].cjsj;
            }
        }
    }

    $scope.buygetcjhbCallBack = function(_data)
    {
        //console.log("查询跟投状态", _data);
        var arr = _data.securityorderlist;
        if(arr.length>0)
        {
            var mainorderobj = arr[0].mainorder;
            $scope.wtInfo.wtsl = mainorderobj.wtsl;
            $scope.wtInfo.wtsj = mainorderobj.wtsj;
            $scope.wtInfo.cjsl = mainorderobj.cjsl;
            if(parseFloat(mainorderobj.wtjg) == 0)
            {
                $scope.wtInfo.wtjg = "市价";
            }
            else
            {
                $scope.wtInfo.wtjg = parseFloat(mainorderobj.wtjg).toFixed(2)+"元";
            }

            if(parseFloat($scope.wtInfo.cjsl) == 0)
            {
                $scope.wtInfo.cjjg = "0.00元";
            }
            else
            {
                $scope.wtInfo.cjjg = (parseFloat(mainorderobj.cjje)/parseFloat($scope.wtInfo.cjsl)).toFixed(2) + "元";
            }

            var arr2 = arr[0].gentouorderlist;
            if($scope.gtqkListArray.length == 0)
            {
                //console.log("length0");
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.userid = arr2[i].user.user.f_id;
                    obj.headurl = arr2[i].user.user.f_head;
                    obj.name = arr2[i].user.user.f_nickname;
                    obj.wtsl = arr2[i].wtsl;
                    obj.wtsj = arr2[i].wtsj.toString().substr(0,10);
                    obj.cjsl = arr2[i].cjsl;
                    obj.account = arr2[i].account;
                    if(parseFloat(arr2[i].wtjg) == 0)
                    {
                        obj.wtjg = "市价";
                    }
                    else
                    {
                        obj.wtjg = parseFloat(arr2[i].wtjg).toFixed(2)+"元";
                    }

                    if(parseFloat(obj.cjsl) == 0)
                    {
                        obj.cjjg = "0.00元";
                    }
                    else
                    {
                        obj.cjjg = (parseFloat(arr2[i].cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }
                    $scope.gtqkListArray.push(obj);
                }
            }
            else
            {
                //console.log("length不为0", $scope.gtqkListArray.length);
                for(var i = 0;i<arr2.length;i++)
                {
                    for(var j = 0;j<$scope.gtqkListArray.length;j++)
                    {
                        if($scope.gtqkListArray[j].account == arr2[i].account)
                        {
                            $scope.gtqkListArray[j].wtsl = arr2[i].wtsl;
                            $scope.gtqkListArray[j].wtsj = arr2[i].wtsj.toString().substr(0,10);
                            $scope.gtqkListArray[j].cjsl = arr2[i].cjsl;
                            $scope.gtqkListArray[j].cjje = arr2[i].cjje;

                            if(parseFloat($scope.gtqkListArray[j].cjsl) == 0)
                            {
                                $scope.gtqkListArray[j].cjjg = "0.00元";
                            }
                            else
                            {
                                $scope.gtqkListArray[j].cjjg = (parseFloat($scope.gtqkListArray[j].cjje)/parseFloat(arr2[i].cjsl)).toFixed(2) + "元";
                            }

                            //console.log("2222222222", arr2[i].cjsl, $scope.gtqkListArray[j].cjje, $scope.gtqkListArray[j].cjjg);
                            break;
                        }
                    }
                }
            }
        }

    }

    $scope.sellgetcjhbCallBack = function(_data)
    {
        //console.log("查询跟投状态", _data);
        var arr = _data.securityorderlist;
        if(arr.length>0)
        {
            var mainorderobj = arr[0].mainorder;
            $scope.sellwtInfo.wtsl = mainorderobj.wtsl;
            $scope.sellwtInfo.wtsj = mainorderobj.wtsj;
            $scope.sellwtInfo.cjsl = mainorderobj.cjsl;
            if(parseFloat(mainorderobj.wtjg) == 0)
            {
                $scope.sellwtInfo.wtjg = "市价";
            }
            else
            {
                $scope.sellwtInfo.wtjg = parseFloat(mainorderobj.wtjg).toFixed(2)+"元";
            }

            if(parseFloat($scope.sellwtInfo.cjsl) == 0)
            {
                $scope.sellwtInfo.cjjg = "0.00元";
            }
            else
            {
                $scope.sellwtInfo.cjjg = (parseFloat(mainorderobj.cjje)/parseFloat($scope.sellwtInfo.cjsl)).toFixed(2) + "元";
            }

            var arr2 = arr[0].gentouorderlist;
            if($scope.gtqkListArray.length == 0)
            {
                //console.log("length0");
                for(var i = 0;i<arr2.length;i++)
                {
                    var obj = {};
                    obj.userid = arr2[i].user.user.f_id;
                    obj.headurl = arr2[i].user.user.f_head;
                    obj.name = arr2[i].user.user.f_nickname;
                    obj.wtsl = arr2[i].wtsl;
                    obj.wtsj = arr2[i].wtsj.toString().substr(0,10);
                    obj.cjsl = arr2[i].cjsl;
                    obj.account = arr2[i].account;
                    if(parseFloat(arr2[i].wtjg) == 0)
                    {
                        obj.wtjg = "市价";
                    }
                    else
                    {
                        obj.wtjg = parseFloat(arr2[i].wtjg).toFixed(2)+"元";
                    }

                    if(parseFloat(obj.cjsl) == 0)
                    {
                        obj.cjjg = "0.00元";
                    }
                    else
                    {
                        obj.cjjg = (parseFloat(arr2[i].cjje)/parseFloat(obj.cjsl)).toFixed(2) + "元";
                    }
                    $scope.gtqkListArray.push(obj);
                }
            }
            else
            {
                //console.log("length不为0");
                for(var i = 0;i<arr2.length;i++)
                {
                    for(var j = 0;j<$scope.gtqkListArray.length;j++)
                    {
                        if($scope.gtqkListArray[j].account == arr2[i].account)
                        {
                            $scope.gtqkListArray[j].wtsl = arr2[i].wtsl;
                            $scope.gtqkListArray[j].wtsj = arr2[i].wtsj.toString().substr(0,10);
                            $scope.gtqkListArray[j].cjsl = arr2[i].cjsl;
                            $scope.gtqkListArray[j].cjje = arr2[i].cjje;

                            if(parseFloat($scope.gtqkListArray[j].cjsl) == 0)
                            {
                                $scope.gtqkListArray[j].cjjg = "0.00元";
                            }
                            else
                            {
                                $scope.gtqkListArray[j].cjjg = (parseFloat($scope.gtqkListArray[j].cjje)/parseFloat(arr2[i].cjsl)).toFixed(2) + "元";
                            }
                            break;
                        }
                    }
                }
            }
        }

    }

    //买入
    $scope.buyClick = function()
    {
        $scope.buyErrorInfo = "";
        if($scope.marketbuyMark)//市价买入
        {
            $scope.marketbuy();
        }
        else
        {
            $scope.limitbuy();
        }
    }

    $scope.limitbuy = function(obj)
    {
        //console.log("委托数量",$scope.wtsl);
        $scope.wtInfo = null;
        $scope.gtqkListArray = [];
        //console.log($scope.wtInfo);
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl))
        {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        if(r.test($scope.wtjg) == false)
        {
            $scope.buyErrorInfo = "请输入有效的委托价格";
            return;
        }
        if(decimaldigitsCheck($scope.wtjg.toString()) == false)
        {
            $scope.buyErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        //if($scope.wtjg.toString().length>0 && $scope.wtjg.toString().substr(0,1) == "0")
        //{
        //    $scope.buyErrorInfo = "请输入有效的委托价格";
        //    return;
        //}
        $scope.buyErrorInfo = "";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        // var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        myConfirm(str, $scope.buyconfirm)//确定买入
    }

    $scope.buyconfirm = function()
    {
        console.log("buyconfirm");
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();
        message["ddlx"] = 'limit';
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = $scope.wtjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtInfo.opwtcode = "Y";//委托成功
                $scope.wtInfo.wtsl = 0;//委托数量
                $scope.wtInfo.wtsj = "";//委托时间
                $scope.wtInfo.cjsl = 0;//成交数量
                $scope.wtInfo.cjsj = "";//成交时间
                if($scope.isbgt == "0")
                {
                    $scope.wtInfo.htbh = result.htbh;
                    $scope.wtInfo.xdwtsl = $scope.wtsl;
                }
                $scope.wtsl = 0;
                //$scope.getkysl();
            }
            else
            {
                $scope.wtInfo.opwtcode = "N";//委托成功
                $scope.wtInfo.info = result.op.info;
            }
        }, false);
    }

    //买卖五档的显示
    $scope.flashbuyfiveDivShowClick = function()
    {
        $scope.flashbuyfiveDivShow = !$scope.flashbuyfiveDivShow;
    }

    //市价买入
    $scope.marketbuy = function()
    {
        $scope.wtInfo = null;
        $scope.gtqkListArray = [];
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.buyErrorInfo = "请输入有效的证券代码";
            return;
        }
        if($scope.wtsl <= 0)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.wtsl) == false)
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl.toString().length>0 && $scope.wtsl.toString().substr(0,1) == "0")
        {
            $scope.buyErrorInfo = "请输入有效的买入数量";
            return;
        }
        if($scope.wtsl%100!=0)
        {
            $scope.buyErrorInfo = "买入数量必须为100的整数倍";
            return;
        }
        if($scope.kysl == "-" || $scope.kysl == "" || $scope.kysl == undefined)
        {
            $scope.buyErrorInfo = "最大可买为空";
            return;
        }
        if ($scope.wtsl > Number($scope.kysl)) {
            $scope.buyErrorInfo = "委托数量大于最大可买，请重新输入";
            return;
        }
        $scope.buyErrorInfo = "";

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定买入  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.wtsl + "股吗？";
        myConfirm(str, $scope.marketbuyconfirm)
    };

    $scope.marketbuyconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'B';
        message["wtsl"] = $scope.wtsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log("买入", message)

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            console.log("交易", result);
            $scope.wtInfo = {};
            $scope.wtInfo.code = result.op.code;

            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.wtInfo.opwtcode = "Y";//委托成功
                $scope.wtInfo.wtsl = 0;//委托数量
                $scope.wtInfo.wtsj = "";//委托时间
                $scope.wtInfo.cjsl = 0;//成交数量
                $scope.wtInfo.cjsj = "";//成交时间
                $scope.wtInfo.htbh = result.htbh;
                if($scope.isbgt == "0") {
                    $scope.wtInfo.xdwtsl = $scope.wtsl;
                }
                $scope.wtsl = 0;
                $scope.getkysl();
            }
            else
            {
                $scope.wtInfo.opwtcode = "N";//委托成功
                $scope.wtInfo.info = result.op.info;
            }
        }, false);
    }

    //卖出股票代码change
    $scope.sellgpdmchange = function()
    {
        //if($scope.hq.stockcode == "")
        //{
        //    $scope.hq = getEmptyHQ();
        //    $scope.stockcodeall = "";
        //    $scope.mcjg = "";
        //    $scope.mckysl = "-";
        //}
        if($scope.hq.stockcode != "")
        {
            $scope.sellgpssShow = true;
            $scope.sellcheckContent();
        }
        else
        {
            //console.log(12123);
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            $scope.hq = getEmptyHQ();
            $scope.stockcodeall = "";
            $scope.mcjg = "";
            $scope.mckysl = "-";
        }
        if($scope.sellwtInfo != null)
        {
            $scope.sellwtInfo = null;
            $scope.gtqkListArray = [];
        }
        $scope.stockcodeall = "";
    }

    $scope.sellcheckContent = function()
    {
        var message = {};
        message['key'] = $scope.hq.stockcode.toUpperCase();//encodeURI(encodeURI($scope.searchStockValue));
        ajaxService.sendMessage('hq.searchstockbykeywords', message, $scope.sellsearchStockCallBack);
    }

    //搜索股票返回
    $scope.sellsearchStockCallBack = function(_data)
    {
        //console.log("搜索",_data);
        $scope.sellSearchStockListArray = [];
        if($scope.hq.stockcode == "")
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
        if(_data.op.code.toString() == "Y")
        {
            if(_data.key.toString() == $scope.hq.stockcode.toUpperCase())
            {
                var element = _data.data;
                if (element.length > 0)
                {
                    var arr = [];
                    for (var i = 0; i < element.length; i++)
                    {
                        var obj = {};
                        obj.asset = element[i]['asset'].toString();//类型 0：股票，4：指数
                        obj.gpdm = element[i]['symbol'].toString();
                        obj.zqjc = element[i]['name'].toString();
                        obj.exchange = element[i]['exchange'].toString();//交易所
                        obj.label = obj.zqjc + "(" + obj.gpdm + ")";
                        obj.tc = obj.exchange.toUpperCase() + obj.gpdm;
                        obj.zxj = "0";
                        obj.status = "";
                        obj.xzzt = "1";//选中状态，样式更改
                        obj.zd = "0";
                        obj.zdf = "0";
                        if (obj.asset == "0" || obj.asset == "5")
                        {
                            arr.push(obj);
                        }
                    }
                    $scope.sellSearchStockListArray = arr;
                    if($scope.sellSearchStockListArray.length == 1)
                    {
                        $scope.setsellonegp();
                    }
                }
                else {
                    $scope.sellSearchStockListArray = [];
                    $scope.sellgpssShow = false;
                    return;
                }
            }
        }
        else
        {
            $scope.sellSearchStockListArray = [];
            $scope.sellgpssShow = false;
            return;
        }
    }

    $scope.setsellonegp = function()
    {
        if($scope.sellSearchStockListArray.length>0)
        {
            if($scope.hq.stockcode == $scope.sellSearchStockListArray[0].gpdm)
            {
                $scope.hq.stockcode = $scope.sellSearchStockListArray[0].gpdm;
                $scope.hq.exchange = ($scope.sellSearchStockListArray[0].exchange).toLowerCase();
                $scope.sellgpssShow = false;
                $scope.queryhq($scope.sellSearchStockListArray[0].gpdm);
            }
        }
    }

    $scope.sellcheckItmeClick = function(_obj)
    {
        $scope.hq.stockcode = _obj.gpdm;
        $scope.hq.exchange = (_obj.exchange).toLowerCase();
        $scope.sellgpssShow = false;
        $scope.queryhq(_obj.gpdm);
    }


    //最大可用
    $scope.getmckyslCallBack = function(_data)
    {
        //console.log("可用数量："+ _data);
        //for(var k in _data)
        //{
        //    console.log("key: " + k + "；value: " + _data[k]);
        //}
        if (_data.op.code == 'Y')
        {
            //console.log("可用数量："+ _data.kmsl);
            $scope.mckysl  = _data.zdkm;
        }
    }

    $scope.getmckysl = function()
    {
        var message = {};
        message['stockcode'] = $scope.stockcodeall.substr(2);
        message['account'] = $scope.childaccount;
        ajaxService.sendMessage("sunflower.p_getmaxcansell", message, $scope.getmckyslCallBack);

    }

    $scope.mcjgChange = function(_value)
    {
        $scope.mcjg = _value;
    }

    $scope.sellClick = function()
    {
        $scope.sellErrorInfo = "";
        if($scope.marketsellMark)//市价卖出
        {
            $scope.marketsell();
        }
        else
        {
            $scope.limitsell();
        }
    }

    $scope.limitsell = function()
    {
        $scope.sellwtInfo = null;
        $scope.gtqkListArray = [];
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcjg<=0)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }
        if(r.test($scope.mcjg) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出价格";
            return;
        }
        //if($scope.mcjg.toString().length>0 && $scope.mcjg.toString().substr(0,1) == "0")
        //{
        //    $scope.sellErrorInfo = "请输入有效的卖出价格";
        //    return;
        //}
        if(decimaldigitsCheck($scope.mcjg.toString()) == false)
        {
            $scope.sellErrorInfo = "委托价格小数位最多为两位";
            return;
        }
        $scope.sellErrorInfo = "";
        //if($scope.wtsl%100!=0)
        //{
        //    alert('卖出数量必须为100的整数倍');
        //    return;
        //}

        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.sellconfirm);

    }

    $scope.sellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        message["ddlx"] = 'limit';
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = $scope.mcjg;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log(message);

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.opwtcode = "Y";//委托成功
                $scope.sellwtInfo.wtsl = 0;//委托数量
                $scope.sellwtInfo.wtsj = "";//委托时间
                $scope.sellwtInfo.cjsl = 0;//成交数量
                $scope.sellwtInfo.cjsj = "";//成交时间
                $scope.sellwtInfo.htbh = result.htbh;
                if($scope.isbgt == '0')
                {
                    $scope.sellwtInfo.xdmcsl = $scope.mcsl;
                }
                $scope.mcsl = "";
                $scope.mckysl = "-";
                $scope.mcjg = "";
            }
            else
            {
                $scope.sellwtInfo.opwtcode = "N";//委托成功
                $scope.sellwtInfo.info = result.op.info;
            }

        }, false);
    }

    //市价卖出
    $scope.marketsell = function()
    {
        $scope.sellwtInfo = null;
        $scope.gtqkListArray = [];
        //console.log($scope.excstockcode)
        if($scope.stockcodeall == null ||  $scope.stockcodeall == "")
        {
            $scope.sellErrorInfo = "请输入有效的证券代码";
            return;
        }
        if($scope.mcsl <= 0 || $scope.mcsl == "" || $scope.mcsl == null)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        var r = /^\d+(\.\d+)?$/;
        if(r.test($scope.mcsl) == false)
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mcsl.toString().length>0 && $scope.mcsl.toString().substr(0,1) == "0")
        {
            $scope.sellErrorInfo = "请输入有效的卖出数量";
            return;
        }
        if($scope.mckysl == "-" || $scope.mckysl == "" || $scope.mckysl == undefined)
        {
            $scope.sellErrorInfo = "最大可卖为空";
            return;
        }
        if($scope.mcsl > Number($scope.mckysl))
        {
            $scope.sellErrorInfo = "委托数量大于最大可卖，请重新输入";
            return;
        }
        $scope.sellErrorInfo = "";
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span class="bold">限价买入（'+ $scope.wtjg +'元）</span><BR />买入数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        //var str = "'证券代码：'+$scope.stockcodeall.substring(2)+'<BR />证券名称：'+$scope.hq.name+'<BR />交易策略：<span >限价卖出（'+ $scope.wtjg +'元）</span><BR />卖出数量：'+$scope.wtsl+'股<BR />———————————————<BR />确认进行交易？"
        var str = "确定卖出  " + $scope.hq.name + "(" + $scope.stockcodeall + ")   " + $scope.mcsl + "股吗？";
        myConfirm(str, $scope.marketsellconfirm);
    }

    $scope.marketsellconfirm = function()
    {
        layer.closeAll();
        var message = {};
        message["account"] = $scope.childaccount;
        message["stockcode"] = $scope.stockcodeall.substring(2);
        message["exchange"] = $scope.stockcodeall.substr(0,2).toUpperCase();;
        if(($scope.stockcodeall.substr(0,2)).toUpperCase() == "SZ")
        {
            $scope.ddlx = "f";
        }
        else
        {
            $scope.ddlx = "r";
        }
        message["ddlx"] = $scope.ddlx;
        message["side"] = 'S';
        message["wtsl"] = $scope.mcsl;
        message["wtjg"] = 0;
        message["combPositionId"] = "default";
        message["ip"] = "1";
        message["mac"] = $scope.deviceid;
        var newdate = new Date();
        message['extra'] = $scope.childaccount + newdate.getTime();
        $scope.dqwtsjh = message['extra'];
        //console.log(message);

        ajaxService.sendMessage("sunflower.p_wt", message, function (result)
        {
            //console.log("交易", result);
            $scope.sellwtInfo = {};
            $scope.sellwtInfo.code = result.op.code;
            if(result.op.code == 'Y')
            {
                //alert("委托成功，合同编号：" + result.htbh);
                $scope.sellwtInfo.opwtcode = "Y";//委托成功
                $scope.sellwtInfo.wtsl = 0;//委托数量
                $scope.sellwtInfo.wtsj = "";//委托时间
                $scope.sellwtInfo.cjsl = 0;//成交数量
                $scope.sellwtInfo.cjsj = "";//成交时间
                $scope.sellwtInfo.htbh = result.htbh;
                if($scope.isbgt == "0")
                {
                    $scope.sellwtInfo.xdmcsl = $scope.mcsl;
                }
                $scope.mcsl = "";
                $scope.mckysl = "-";
                $scope.getmckysl();
            }
            else
            {
                $scope.sellwtInfo.opwtcode = "N";//委托成功
                $scope.sellwtInfo.info = result.op.info;
            }
        }, false);
    }

    //查看跟投
    $scope.gotockgt = function()
    {
        $scope.tradeallShow = false;
        $scope.gtqkDiv = true;//跟投情况

        $scope.dqzgObj = {};
        //$scope.dqzgObj.headurl = decodeURIComponent($cookieStore.get('iconurl'));
        //$scope.dqzgObj.name = decodeURIComponent($cookieStore.get('nickname'));

        var localStorage = window.localStorage;
        $scope.dqzgObj.headurl = decodeURIComponent(localStorage.getItem("iconurl"));
        $scope.dqzgObj.name = decodeURIComponent(localStorage.getItem("nickname"));
    }


    $scope.backtradeClick = function()
    {
        $scope.tradeallShow = true;
        $scope.gtqkDiv = false;//跟投情况
        $scope.gtqkListArray = [];
    }



    //行情
    //切换
    $scope.tabChange = function(_str)
    {
        switch (_str)
        {
            case "1":
                $scope.oneStockHQbasetab1Show = true;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                drawF();
                break;
            case "2":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = true;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                draw5F()
                break;
            case "3":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = true;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = false;
                klCycle = "day";
                drawKL();
                break;
            case "4":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = true;
                $scope.oneStockHQbasetab5Show = false;
                klCycle = "week";
                drawWeekKL();
                break;
            case "5":
                $scope.oneStockHQbasetab1Show = false;
                $scope.oneStockHQbasetab2Show = false;
                $scope.oneStockHQbasetab3Show = false;
                $scope.oneStockHQbasetab4Show = false;
                $scope.oneStockHQbasetab5Show = true;
                klCycle = "month";
                drawMonthKL();
            default :
                break;
        }
    }


    //返回上一级 ：交易、账号
    $scope.backtoPreviousLevel = function()
    {
        $scope.onestockhqbaseClear();
        $scope.buysellClearInterval();
        if($scope.opentype == "newwebview")
        {
            closeNewBrowser();
        }
        else
        {
            window.location.href = getbackList();
        }
    }

}




